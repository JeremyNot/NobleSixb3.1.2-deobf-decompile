//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.zero.alpine.type;

public enum EventState
{
    PRE, 
    POST;
    
    private static final EventState[] $VALUES;
    
    static {
        $VALUES = new EventState[] { EventState.PRE, EventState.POST };
    }
}
