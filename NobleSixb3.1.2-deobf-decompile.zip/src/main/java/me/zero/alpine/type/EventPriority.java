//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.zero.alpine.type;

public interface EventPriority
{
    public static final byte HIGHEST = 1;
    public static final byte HIGH = 2;
    public static final byte MEDIUM = 3;
    public static final byte LOW = 4;
    public static final byte LOWEST = 5;
    public static final byte DEFAULT = 3;
}
