//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.zero.alpine.listener;

@FunctionalInterface
public interface EventHook<T>
{
    void invoke(final T p0);
}
