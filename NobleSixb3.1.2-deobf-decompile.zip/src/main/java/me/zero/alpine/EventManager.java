//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.zero.alpine;

import java.lang.reflect.*;
import me.zero.alpine.listener.*;
import java.lang.annotation.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class EventManager implements EventBus
{
    private final Map<Object, List<Listener>> SUBSCRIPTION_CACHE;
    private final Map<Class<?>, List<Listener>> SUBSCRIPTION_MAP;
    private final List<EventBus> ATTACHED_BUSES;
    
    public EventManager() {
        this.SUBSCRIPTION_CACHE = new HashMap<Object, List<Listener>>();
        this.SUBSCRIPTION_MAP = new HashMap<Class<?>, List<Listener>>();
        this.ATTACHED_BUSES = new ArrayList<EventBus>();
    }
    
    public void subscribe(final Object o) {
        this.SUBSCRIPTION_CACHE.computeIfAbsent(o, (Function<? super Object, ? extends List<Listener>>)EventManager::lambda$subscribe$1).forEach(this::subscribe);
        if (!this.ATTACHED_BUSES.isEmpty()) {
            this.ATTACHED_BUSES.forEach(EventManager::lambda$subscribe$2);
        }
    }
    
    public void subscribe(final Object... array) {
        Arrays.stream(array).forEach(this::subscribe);
    }
    
    public void subscribe(final Iterable<Object> iterable) {
        iterable.forEach(this::subscribe);
    }
    
    public void unsubscribe(final Object o) {
        final List<Listener> list = this.SUBSCRIPTION_CACHE.get(o);
        if (list == null) {
            return;
        }
        this.SUBSCRIPTION_MAP.values().forEach((Consumer<? super Object>)EventManager::lambda$unsubscribe$3);
        if (!this.ATTACHED_BUSES.isEmpty()) {
            this.ATTACHED_BUSES.forEach(EventManager::lambda$unsubscribe$4);
        }
    }
    
    public void unsubscribe(final Object... array) {
        Arrays.stream(array).forEach(this::unsubscribe);
    }
    
    public void unsubscribe(final Iterable<Object> iterable) {
        iterable.forEach(this::unsubscribe);
    }
    
    public void post(final Object o) {
        final List<Listener> list = this.SUBSCRIPTION_MAP.get(o.getClass());
        if (list != null) {
            list.forEach(EventManager::lambda$post$5);
        }
        if (!this.ATTACHED_BUSES.isEmpty()) {
            this.ATTACHED_BUSES.forEach(EventManager::lambda$post$6);
        }
    }
    
    public void attach(final EventBus eventBus) {
        if (!this.ATTACHED_BUSES.contains(eventBus)) {
            this.ATTACHED_BUSES.add(eventBus);
        }
    }
    
    public void detach(final EventBus eventBus) {
        if (this.ATTACHED_BUSES.contains(eventBus)) {
            this.ATTACHED_BUSES.remove(eventBus);
        }
    }
    
    private static boolean isValidField(final Field field) {
        return field.isAnnotationPresent(EventHandler.class) && Listener.class.isAssignableFrom(field.getType());
    }
    
    private static Listener asListener(final Object o, final Field field) {
        try {
            final boolean accessible = field.isAccessible();
            field.setAccessible(true);
            final Listener listener = (Listener)field.get(o);
            field.setAccessible(accessible);
            if (listener == null) {
                return null;
            }
            if (listener.getPriority() > 5 || listener.getPriority() < 1) {
                throw new RuntimeException("Event Priority out of bounds! %s");
            }
            return listener;
        }
        catch (IllegalAccessException ex) {
            return null;
        }
    }
    
    private void subscribe(final Listener listener) {
        List<Listener> list;
        int n;
        for (list = this.SUBSCRIPTION_MAP.computeIfAbsent(listener.getTarget(), (Function<? super Class<?>, ? extends List<Listener>>)EventManager::lambda$subscribe$7), n = 0; n < list.size() && listener.getPriority() >= list.get(n).getPriority(); ++n) {}
        list.add(n, listener);
    }
    
    private static List lambda$subscribe$7(final Class clazz) {
        return new ArrayList();
    }
    
    private static void lambda$post$6(final Object o, final EventBus eventBus) {
        eventBus.post(o);
    }
    
    private static void lambda$post$5(final Object o, final Listener listener) {
        listener.invoke(o);
    }
    
    private static void lambda$unsubscribe$4(final Object o, final EventBus eventBus) {
        eventBus.unsubscribe(o);
    }
    
    private static void lambda$unsubscribe$3(final List list, final List list2) {
        Objects.requireNonNull(list);
        list2.removeIf(list::contains);
    }
    
    private static void lambda$subscribe$2(final Object o, final EventBus eventBus) {
        eventBus.subscribe(o);
    }
    
    private static List lambda$subscribe$1(final Object o) {
        return Arrays.stream(o.getClass().getDeclaredFields()).filter(EventManager::isValidField).map((Function<? super Field, ?>)EventManager::lambda$subscribe$0).filter(Objects::nonNull).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
    }
    
    private static Listener lambda$subscribe$0(final Object o, final Field field) {
        return asListener(o, field);
    }
}
