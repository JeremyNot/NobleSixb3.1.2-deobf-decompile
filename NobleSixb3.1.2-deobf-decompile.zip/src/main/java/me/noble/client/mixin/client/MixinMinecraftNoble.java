//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import net.minecraft.client.*;
import net.minecraft.client.multiplayer.*;
import org.spongepowered.asm.mixin.*;
import net.minecraft.client.entity.*;
import net.minecraft.client.audio.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.*;
import me.noble.client.util.*;
import me.noble.client.event.events.*;
import net.minecraft.util.text.*;
import net.minecraftforge.client.event.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.client.settings.*;
import org.lwjgl.input.*;
import net.minecraft.client.gui.*;
import net.minecraft.crash.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ Minecraft.class })
public class MixinMinecraftNoble
{
    @Shadow
    WorldClient world;
    @Shadow
    EntityPlayerSP player;
    @Shadow
    GuiScreen currentScreen;
    @Shadow
    GameSettings gameSettings;
    @Shadow
    GuiIngame ingameGUI;
    @Shadow
    boolean skipRenderWorld;
    @Shadow
    SoundHandler mcSoundHandler;
    
    @Inject(method = { "displayGuiScreen" }, at = { @At("HEAD") }, cancellable = true)
    public void displayGuiScreen(GuiScreen currentScreen, final CallbackInfo callbackInfo) {
        NobleMod.EVENT_BUS.post(new GuiScreenEvent.Closed(Wrapper.getMinecraft().currentScreen));
        final GuiScreenEvent.Displayed displayed = new GuiScreenEvent.Displayed((GuiScreen)currentScreen);
        NobleMod.EVENT_BUS.post(displayed);
        currentScreen = displayed.getScreen();
        if (currentScreen == null && this.world == null) {
            currentScreen = new GuiMainMenu();
        }
        else if (currentScreen == null && this.player.getHealth() <= 0.0f) {
            currentScreen = new GuiGameOver((ITextComponent)null);
        }
        final GuiScreen currentScreen2 = this.currentScreen;
        final GuiOpenEvent guiOpenEvent = new GuiOpenEvent((GuiScreen)currentScreen);
        if (MinecraftForge.EVENT_BUS.post((Event)guiOpenEvent)) {
            return;
        }
        currentScreen = guiOpenEvent.getGui();
        if (currentScreen2 != null && currentScreen != currentScreen2) {
            currentScreen2.onGuiClosed();
        }
        if (currentScreen instanceof GuiMainMenu || currentScreen instanceof GuiMultiplayer) {
            this.gameSettings.showDebugInfo = false;
            this.ingameGUI.getChatGUI().clearChatMessages(true);
        }
        if ((this.currentScreen = (GuiScreen)currentScreen) != null) {
            Minecraft.getMinecraft().setIngameNotInFocus();
            KeyBinding.unPressAllKeys();
            while (Mouse.next()) {}
            while (Keyboard.next()) {}
            final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            ((GuiScreen)currentScreen).setWorldAndResolution(Minecraft.getMinecraft(), scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
            this.skipRenderWorld = false;
        }
        else {
            this.mcSoundHandler.resumeSounds();
            Minecraft.getMinecraft().setIngameFocus();
        }
        callbackInfo.cancel();
    }
    
    @Redirect(method = { "run" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"))
    public void displayCrashReport(final Minecraft minecraft, final CrashReport crashReport) {
        this.save();
    }
    
    @Inject(method = { "shutdown" }, at = { @At("HEAD") })
    public void shutdown(final CallbackInfo callbackInfo) {
        this.save();
    }
    
    private void save() {
        System.out.println("Shutting down: saving Noble configuration");
        NobleMod.saveConfiguration();
        System.out.println("Configuration saved.");
    }
}
