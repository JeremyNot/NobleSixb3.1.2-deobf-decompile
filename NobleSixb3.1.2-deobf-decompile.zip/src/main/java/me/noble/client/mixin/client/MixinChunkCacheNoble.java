//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.block.state.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.render.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ ChunkCache.class })
public class MixinChunkCacheNoble
{
    @Inject(method = { "getBlockState" }, at = { @At("RETURN") }, cancellable = true)
    public void getState(final BlockPos blockPos, final CallbackInfoReturnable<IBlockState> callbackInfoReturnable) {
        if (ModuleManager.isModuleEnabled("XRay")) {
            callbackInfoReturnable.setReturnValue((Object)XRay.transform((IBlockState)callbackInfoReturnable.getReturnValue()));
        }
    }
}
