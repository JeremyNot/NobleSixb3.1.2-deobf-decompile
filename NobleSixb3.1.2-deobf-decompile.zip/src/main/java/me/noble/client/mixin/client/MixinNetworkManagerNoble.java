//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.network.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.event.events.*;
import me.noble.client.*;
import org.spongepowered.asm.mixin.injection.*;
import io.netty.channel.*;
import java.io.*;
import me.noble.client.module.modules.misc.*;

@Mixin({ NetworkManager.class })
public class MixinNetworkManagerNoble
{
    @Inject(method = { "sendPacket(Lnet/minecraft/network/Packet;)V" }, at = { @At("HEAD") }, cancellable = true)
    private void onSendPacket(final Packet<?> packet, final CallbackInfo callbackInfo) {
        final PacketEvent.Send send = new PacketEvent.Send((Packet)packet);
        NobleMod.EVENT_BUS.post(send);
        if (((PacketEvent)send).isCancelled()) {
            callbackInfo.cancel();
        }
    }
    
    @Inject(method = { "channelRead0" }, at = { @At("HEAD") }, cancellable = true)
    private void onChannelRead(final ChannelHandlerContext channelHandlerContext, final Packet<?> packet, final CallbackInfo callbackInfo) {
        final PacketEvent.Receive receive = new PacketEvent.Receive((Packet)packet);
        NobleMod.EVENT_BUS.post(receive);
        if (((PacketEvent)receive).isCancelled()) {
            callbackInfo.cancel();
        }
    }
    
    @Inject(method = { "exceptionCaught" }, at = { @At("HEAD") }, cancellable = true)
    private void exceptionCaught(final ChannelHandlerContext channelHandlerContext, final Throwable t, final CallbackInfo callbackInfo) {
        if (t instanceof IOException && NoPacketKick.isEnabled()) {
            callbackInfo.cancel();
        }
    }
}
