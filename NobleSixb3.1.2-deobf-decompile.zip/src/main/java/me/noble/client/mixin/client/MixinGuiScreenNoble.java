//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import net.minecraft.client.*;
import org.spongepowered.asm.mixin.*;
import net.minecraft.client.gui.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.module.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.inventory.*;
import net.minecraft.nbt.*;
import org.spongepowered.asm.mixin.injection.*;
import me.noble.client.module.modules.gui.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.renderer.*;

@Mixin({ GuiScreen.class })
public class MixinGuiScreenNoble
{
    @Shadow
    public Minecraft mc;
    RenderItem itemRender;
    FontRenderer fontRenderer;
    
    public MixinGuiScreenNoble() {
        this.itemRender = Minecraft.getMinecraft().getRenderItem();
        this.fontRenderer = Minecraft.getMinecraft().fontRendererObj;
    }
    
    @Inject(method = { "renderToolTip" }, at = { @At("HEAD") }, cancellable = true)
    public void renderToolTip(final ItemStack itemStack, final int n, final int n2, final CallbackInfo callbackInfo) {
        if (ModuleManager.isModuleEnabled("ShulkerPreview") && itemStack.getItem() instanceof ItemShulkerBox) {
            final NBTTagCompound getTagCompound = itemStack.getTagCompound();
            if (getTagCompound != null && getTagCompound.hasKey("BlockEntityTag", 10)) {
                final NBTTagCompound getCompoundTag = getTagCompound.getCompoundTag("BlockEntityTag");
                if (getCompoundTag.hasKey("Items", 9)) {
                    callbackInfo.cancel();
                    final NonNullList func_191197_a = NonNullList.func_191197_a(27, (Object)ItemStack.field_190927_a);
                    ItemStackHelper.func_191283_b(getCompoundTag, func_191197_a);
                    GlStateManager.enableBlend();
                    GlStateManager.disableRescaleNormal();
                    RenderHelper.disableStandardItemLighting();
                    GlStateManager.disableLighting();
                    GlStateManager.disableDepth();
                    final int max = Math.max(144, this.fontRenderer.getStringWidth(itemStack.getDisplayName()) + 3);
                    final int n3 = n + 12;
                    final int n4 = n2 - 12;
                    final int n5 = 57;
                    this.itemRender.zLevel = 300.0f;
                    this.drawGradientRectP(n3 - 3, n4 - 4, n3 + max + 3, n4 - 3, -267386864, -267386864);
                    this.drawGradientRectP(n3 - 3, n4 + n5 + 3, n3 + max + 3, n4 + n5 + 4, -267386864, -267386864);
                    this.drawGradientRectP(n3 - 3, n4 - 3, n3 + max + 3, n4 + n5 + 3, -267386864, -267386864);
                    this.drawGradientRectP(n3 - 4, n4 - 3, n3 - 3, n4 + n5 + 3, -267386864, -267386864);
                    this.drawGradientRectP(n3 + max + 3, n4 - 3, n3 + max + 4, n4 + n5 + 3, -267386864, -267386864);
                    this.drawGradientRectP(n3 - 3, n4 - 3 + 1, n3 - 3 + 1, n4 + n5 + 3 - 1, 1347420415, 1344798847);
                    this.drawGradientRectP(n3 + max + 2, n4 - 3 + 1, n3 + max + 3, n4 + n5 + 3 - 1, 1347420415, 1344798847);
                    this.drawGradientRectP(n3 - 3, n4 - 3, n3 + max + 3, n4 - 3 + 1, 1347420415, 1347420415);
                    this.drawGradientRectP(n3 - 3, n4 + n5 + 2, n3 + max + 3, n4 + n5 + 3, 1344798847, 1344798847);
                    this.fontRenderer.drawString(itemStack.getDisplayName(), n + 12, n2 - 12, 16777215);
                    GlStateManager.enableBlend();
                    GlStateManager.enableAlpha();
                    GlStateManager.enableTexture2D();
                    GlStateManager.enableLighting();
                    GlStateManager.enableDepth();
                    RenderHelper.enableGUIStandardItemLighting();
                    for (int i = 0; i < func_191197_a.size(); ++i) {
                        final int n6 = n + i % 9 * 16 + 11;
                        final int n7 = n2 + i / 9 * 16 - 11 + 8;
                        final ItemStack itemStack2 = (ItemStack)func_191197_a.get(i);
                        this.itemRender.renderItemAndEffectIntoGUI(itemStack2, n6, n7);
                        this.itemRender.renderItemOverlayIntoGUI(this.fontRenderer, itemStack2, n6, n7, (String)null);
                    }
                    RenderHelper.disableStandardItemLighting();
                    this.itemRender.zLevel = 0.0f;
                    GlStateManager.enableLighting();
                    GlStateManager.enableDepth();
                    RenderHelper.enableStandardItemLighting();
                    GlStateManager.enableRescaleNormal();
                }
            }
        }
    }
    
    @Inject(method = { "Lnet/minecraft/client/gui/GuiScreen;drawWorldBackground(I)V" }, at = { @At("HEAD") }, cancellable = true)
    private void drawWorldBackgroundWrapper(final int n, final CallbackInfo callbackInfo) {
        if (this.mc.world != null && ModuleManager.isModuleEnabled("CleanGUI") && ((CleanGUI)ModuleManager.getModuleByName("CleanGUI")).inventoryGlobal.getValue()) {
            callbackInfo.cancel();
        }
    }
    
    private void drawGradientRectP(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        final float n7 = (n5 >> 24 & 0xFF) / 255.0f;
        final float n8 = (n5 >> 16 & 0xFF) / 255.0f;
        final float n9 = (n5 >> 8 & 0xFF) / 255.0f;
        final float n10 = (n5 & 0xFF) / 255.0f;
        final float n11 = (n6 >> 24 & 0xFF) / 255.0f;
        final float n12 = (n6 >> 16 & 0xFF) / 255.0f;
        final float n13 = (n6 >> 8 & 0xFF) / 255.0f;
        final float n14 = (n6 & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        final Tessellator getInstance = Tessellator.getInstance();
        final BufferBuilder getBuffer = getInstance.getBuffer();
        getBuffer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        getBuffer.pos((double)n3, (double)n2, 300.0).color(n8, n9, n10, n7).endVertex();
        getBuffer.pos((double)n, (double)n2, 300.0).color(n8, n9, n10, n7).endVertex();
        getBuffer.pos((double)n, (double)n4, 300.0).color(n12, n13, n14, n11).endVertex();
        getBuffer.pos((double)n3, (double)n4, 300.0).color(n12, n13, n14, n11).endVertex();
        getInstance.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }
}
