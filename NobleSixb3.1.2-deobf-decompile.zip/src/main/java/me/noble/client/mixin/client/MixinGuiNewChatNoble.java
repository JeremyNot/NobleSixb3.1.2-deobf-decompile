//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import me.noble.client.module.modules.gui.*;
import org.spongepowered.asm.mixin.injection.*;
import net.minecraft.client.gui.*;

@Mixin({ GuiNewChat.class })
public abstract class MixinGuiNewChatNoble
{
    @Redirect(method = { "drawChat" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V"))
    private void drawRectBackgroundClean(final int n, final int n2, final int n3, final int n4, final int n5) {
        if (!CleanGUI.enabled() || (CleanGUI.enabled() && !CleanGUI.chatGlobal.getValue())) {
            Gui.drawRect(n, n2, n3, n4, n5);
        }
    }
    
    @Redirect(method = { "drawChat" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/FontRenderer;drawStringWithShadow(Ljava/lang/String;FFI)I"))
    private int drawStringWithShadowClean(final FontRenderer fontRenderer, final String s, final float n, final float n2, final int n3) {
        if (!CleanGUI.enabled() || (CleanGUI.enabled() && !CleanGUI.chatGlobal.getValue())) {
            return fontRenderer.drawStringWithShadow(s, n, n2, n3);
        }
        return fontRenderer.drawString(s, (int)n, (int)n2, n3);
    }
}
