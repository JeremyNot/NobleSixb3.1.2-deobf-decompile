//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.network.*;
import net.minecraft.network.play.server.*;
import net.minecraft.world.chunk.*;
import me.noble.client.*;
import me.noble.client.event.events.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin({ NetHandlerPlayClient.class })
public class MixinNetHandlerPlayClientNoble
{
    @Inject(method = { "handleChunkData" }, at = { @At(value = "INVOKE", target = "Lnet/minecraft/world/chunk/Chunk;read(Lnet/minecraft/network/PacketBuffer;IZ)V") }, locals = LocalCapture.CAPTURE_FAILHARD)
    private void read(final SPacketChunkData sPacketChunkData, final CallbackInfo callbackInfo, final Chunk chunk) {
        NobleMod.EVENT_BUS.post(new ChunkEvent(chunk, sPacketChunkData));
    }
}
