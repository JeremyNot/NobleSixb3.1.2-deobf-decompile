//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import net.minecraft.network.handshake.client.*;
import org.spongepowered.asm.mixin.*;
import net.minecraft.network.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.module.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ C00Handshake.class })
public class MixinC00HandshakeNoble
{
    @Shadow
    int protocolVersion;
    @Shadow
    String ip;
    @Shadow
    int port;
    @Shadow
    EnumConnectionState requestedState;
    
    @Inject(method = { "writePacketData" }, at = { @At("HEAD") }, cancellable = true)
    public void writePacketData(final PacketBuffer packetBuffer, final CallbackInfo callbackInfo) {
        if (ModuleManager.isModuleEnabled("FakeVanillaClient")) {
            callbackInfo.cancel();
            packetBuffer.writeVarIntToBuffer(this.protocolVersion);
            packetBuffer.writeString(this.ip);
            packetBuffer.writeShort(this.port);
            packetBuffer.writeVarIntToBuffer(this.requestedState.getId());
        }
    }
}
