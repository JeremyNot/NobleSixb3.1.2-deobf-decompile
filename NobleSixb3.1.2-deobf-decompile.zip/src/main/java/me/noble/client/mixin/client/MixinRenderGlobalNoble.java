//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import net.minecraft.client.*;
import org.spongepowered.asm.mixin.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ RenderGlobal.class })
public class MixinRenderGlobalNoble
{
    @Shadow
    Minecraft mc;
    @Shadow
    public ChunkRenderContainer renderContainer;
    
    @Inject(method = { "renderBlockLayer(Lnet/minecraft/util/BlockRenderLayer;)V" }, at = { @At("HEAD") }, cancellable = true)
    public void renderBlockLayer(final BlockRenderLayer blockRenderLayer, final CallbackInfo callbackInfo) {
        callbackInfo.cancel();
    }
}
