//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.entity.*;
import net.minecraft.world.*;
import com.mojang.authlib.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.util.*;
import net.minecraft.client.renderer.entity.*;
import me.noble.client.module.modules.misc.*;
import net.minecraft.client.renderer.entity.layers.*;
import java.util.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ AbstractClientPlayer.class })
public class MixinAbstractClientPlayerNoble
{
    @Inject(method = { "<init>" }, at = { @At("RETURN") })
    public void AbstractClientPlayer(final World world, final GameProfile gameProfile, final CallbackInfo callbackInfo) {
        for (final RenderPlayer renderPlayer : Wrapper.getMinecraft().getRenderManager().getSkinMap().values()) {
            renderPlayer.addLayer((LayerRenderer)new LayerCape(renderPlayer));
        }
    }
}
