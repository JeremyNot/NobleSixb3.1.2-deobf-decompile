//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.entity.*;
import me.noble.client.event.events.*;
import me.noble.client.*;
import org.spongepowered.asm.mixin.injection.*;
import me.noble.client.module.modules.movement.*;
import me.noble.client.module.modules.player.*;

@Mixin({ Entity.class })
public class MixinEntityNoble
{
    @Redirect(method = { "applyEntityCollision" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;addVelocity(DDD)V"))
    public void addVelocity(final Entity entity, final double n, final double n2, final double n3) {
        final EntityEvent.EntityCollision entityCollision = new EntityEvent.EntityCollision(entity, n, n2, n3);
        NobleMod.EVENT_BUS.post(entityCollision);
        if (entityCollision.isCancelled()) {
            return;
        }
        entity.motionX += n;
        entity.motionY += n2;
        entity.motionZ += n3;
        entity.isAirBorne = true;
    }
    
    @Redirect(method = { "move" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isSneaking()Z"))
    public boolean isSneaking(final Entity entity) {
        return SafeWalk.shouldSafewalk() || Scaffold.shouldScaffold() || entity.isSneaking();
    }
}
