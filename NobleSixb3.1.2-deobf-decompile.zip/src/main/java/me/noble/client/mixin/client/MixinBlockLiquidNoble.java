//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.block.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.module.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ BlockLiquid.class })
public class MixinBlockLiquidNoble
{
    @Inject(method = { "modifyAcceleration" }, at = { @At("HEAD") }, cancellable = true)
    public void modifyAcceleration(final World world, final BlockPos blockPos, final Entity entity, final Vec3d returnValue, final CallbackInfoReturnable callbackInfoReturnable) {
        if (ModuleManager.isModuleEnabled("Velocity")) {
            callbackInfoReturnable.setReturnValue((Object)returnValue);
            callbackInfoReturnable.cancel();
        }
    }
}
