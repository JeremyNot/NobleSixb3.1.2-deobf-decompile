//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import net.minecraft.block.*;
import org.spongepowered.asm.mixin.*;
import net.minecraft.block.state.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import java.util.*;
import net.minecraft.entity.*;
import javax.annotation.*;
import me.noble.client.event.events.*;
import me.noble.client.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ BlockStateContainer.StateImplementation.class })
public class MixinStateImplementationNoble
{
    @Shadow
    @Final
    private Block block;
    
    @Redirect(method = { "addCollisionBoxToList" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;addCollisionBoxToList(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/AxisAlignedBB;Ljava/util/List;Lnet/minecraft/entity/Entity;Z)V"))
    public void addCollisionBoxToList(final Block block, final IBlockState blockState, final World world, final BlockPos blockPos, final AxisAlignedBB axisAlignedBB, final List<AxisAlignedBB> list, @Nullable final Entity entity, final boolean b) {
        final AddCollisionBoxToListEvent addCollisionBoxToListEvent = new AddCollisionBoxToListEvent(block, blockState, world, blockPos, axisAlignedBB, (List)list, entity, b);
        NobleMod.EVENT_BUS.post(addCollisionBoxToListEvent);
        if (!addCollisionBoxToListEvent.isCancelled()) {
            this.block.addCollisionBoxToList(blockState, world, blockPos, axisAlignedBB, (List)list, entity, b);
        }
    }
}
