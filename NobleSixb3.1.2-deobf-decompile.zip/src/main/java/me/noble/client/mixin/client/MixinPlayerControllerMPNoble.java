//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import me.noble.client.module.modules.player.*;
import me.noble.client.util.*;
import net.minecraft.entity.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.client.entity.*;
import me.noble.client.event.events.*;
import me.noble.client.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ PlayerControllerMP.class })
public class MixinPlayerControllerMPNoble
{
    @Redirect(method = { "onPlayerDamageBlock" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/block/state/IBlockState;getPlayerRelativeBlockHardness(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)F"))
    float getPlayerRelativeBlockHardness(final IBlockState blockState, final EntityPlayer entityPlayer, final World world, final BlockPos blockPos) {
        return blockState.getPlayerRelativeBlockHardness(entityPlayer, world, blockPos) * (TpsSync.isSync() ? (LagCompensator.INSTANCE.getTickRate() / 20.0f) : 1.0f);
    }
    
    @Inject(method = { "attackEntity" }, at = { @At("HEAD") }, cancellable = true)
    public void attackEntity(final EntityPlayer entityPlayer, final Entity entity, final CallbackInfo callbackInfo) {
        if (entity == null) {
            return;
        }
        if (entity instanceof EntityPlayerSP) {
            final ClientPlayerAttackEvent clientPlayerAttackEvent = new ClientPlayerAttackEvent(entity);
            NobleMod.EVENT_BUS.post(clientPlayerAttackEvent);
            if (clientPlayerAttackEvent.isCancelled()) {
                callbackInfo.cancel();
            }
        }
    }
}
