//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.mixin.client;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.renderer.entity.layers.*;
import net.minecraft.entity.*;
import net.minecraft.inventory.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.noble.client.module.modules.gui.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.monster.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ LayerArmorBase.class })
public abstract class MixinLayerArmorBaseNoble
{
    @Inject(method = { "renderArmorLayer" }, at = { @At("HEAD") }, cancellable = true)
    public void onRenderArmorLayer(final EntityLivingBase entityLivingBase, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final EntityEquipmentSlot entityEquipmentSlot, final CallbackInfo callbackInfo) {
        if (ArmourHide.INSTANCE.isEnabled()) {
            if (!ArmourHide.INSTANCE.player.getValue() && entityLivingBase instanceof EntityPlayer) {
                if (!ArmourHide.shouldRenderPiece(entityEquipmentSlot)) {
                    callbackInfo.cancel();
                }
            }
            else if (!ArmourHide.INSTANCE.armourstand.getValue() && entityLivingBase instanceof EntityArmorStand) {
                if (!ArmourHide.shouldRenderPiece(entityEquipmentSlot)) {
                    callbackInfo.cancel();
                }
            }
            else if (!ArmourHide.INSTANCE.mobs.getValue() && entityLivingBase instanceof EntityMob && !ArmourHide.shouldRenderPiece(entityEquipmentSlot)) {
                callbackInfo.cancel();
            }
        }
    }
}
