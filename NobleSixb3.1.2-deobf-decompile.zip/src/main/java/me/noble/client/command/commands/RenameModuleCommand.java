//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;
import me.noble.client.module.*;

public class RenameModuleCommand extends Command
{
    public RenameModuleCommand() {
        super("renamemodule", new ChunkBuilder().append("module", true, new ModuleParser()).append("name").build(), new String[0]);
        this.setDescription("Rename a module to something else");
    }
    
    public void call(final String[] array) {
        if (array.length == 0) {
            sendChatMessage("Please specify a module!");
            return;
        }
        final Module moduleByName = ModuleManager.getModuleByName(array[0]);
        if (moduleByName == null) {
            sendChatMessage(String.valueOf(new StringBuilder().append("Unknown module '").append(array[0]).append("'!")));
            return;
        }
        final String name = (array.length == 1) ? moduleByName.getOriginalName() : array[1];
        if (!name.matches("[a-zA-Z]+")) {
            sendChatMessage("Name must be alphabetic!");
            return;
        }
        sendChatMessage(String.valueOf(new StringBuilder().append("&b").append(moduleByName.getName()).append("&r renamed to &b").append(name)));
        moduleByName.setName(name);
    }
}
