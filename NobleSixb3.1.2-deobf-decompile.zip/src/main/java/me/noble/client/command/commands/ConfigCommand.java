//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.*;
import java.nio.file.*;
import java.io.*;
import me.noble.client.gui.kami.*;
import me.noble.client.command.syntax.*;
import me.noble.client.command.syntax.parsers.*;

public class ConfigCommand extends Command
{
    public void call(final String[] array) {
        if (array[0] == null) {
            Command.sendChatMessage("Missing argument &bmode&r: Choose from reload, save or path");
            return;
        }
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "reload": {
                this.reload();
                return;
            }
            case "save": {
                try {
                    NobleMod.saveConfigurationUnsafe();
                    Command.sendChatMessage("Saved configuration!");
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("Failed to save! ").append(ex.getMessage())));
                }
                return;
            }
            case "path": {
                if (array[1] == null) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("Path to configuration: &b").append(Paths.get(NobleMod.getConfigName(), new String[0]).toAbsolutePath().toString())));
                    return;
                }
                final String s = array[1];
                if (!NobleMod.isFilenameValid(s)) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("&b").append(s).append("&r is not a valid path")));
                    return;
                }
                try (final BufferedWriter bufferedWriter = Files.newBufferedWriter(Paths.get("KAMILastConfig.txt", new String[0]), new OpenOption[0])) {
                    bufferedWriter.write(s);
                    this.reload();
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("Configuration path set to &b").append(s).append("&r!")));
                }
                catch (IOException ex2) {
                    ex2.printStackTrace();
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("Couldn't set path: ").append(ex2.getMessage())));
                    return;
                }
                break;
            }
        }
        Command.sendChatMessage("Incorrect mode, please choose from: reload, save or path");
    }
    
    private void reload() {
        (NobleMod.getInstance().guiManager = new KamiGUI()).initializeGUI();
        NobleMod.loadConfiguration();
        Command.sendChatMessage("Configuration reloaded!");
    }
    
    public ConfigCommand() {
        super("config", new ChunkBuilder().append("mode", true, new EnumParser(new String[] { "reload", "save", "path" })).append("path", true, new DependantParser(0, new DependantParser.Dependency(new String[][] { { "path", "path" } }, ""))).build(), new String[] { "cfg" });
        this.setDescription("Change where your config is saved or manually save and reload your config");
    }
}
