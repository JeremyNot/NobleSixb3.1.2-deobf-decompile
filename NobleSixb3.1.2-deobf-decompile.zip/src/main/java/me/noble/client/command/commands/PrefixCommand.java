//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.*;

public class PrefixCommand extends Command
{
    public void call(final String[] array) {
        if (array.length <= 0) {
            Command.sendChatMessage("Please specify a new prefix!");
            return;
        }
        if (array[0] != null) {
            Command.commandPrefix.setValue(array[0]);
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Prefix set to &b").append(Command.commandPrefix.getValue())));
        }
        else if (array[0].equals("\\")) {
            Command.sendChatMessage("Error: \"\\\" is not a supported prefix");
        }
        else {
            Command.sendChatMessage("Please specify a new prefix!");
        }
    }
    
    public PrefixCommand() {
        super("prefix", new ChunkBuilder().append("character").build(), new String[0]);
        this.setDescription("Changes the prefix to your new key");
    }
}
