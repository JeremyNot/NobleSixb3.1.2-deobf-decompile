//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.module.modules.chat.*;
import me.noble.client.module.*;
import me.noble.client.command.syntax.*;

public class ChatSuffixCommand extends Command
{
    public void call(final String[] array) {
        final ChatSuffix chatSuffix = (ChatSuffix)ModuleManager.getModuleByName("ChatSuffix");
        if (chatSuffix == null) {
            Command.sendErrorMessage("&cThe ChatSuffix module is not available for some reason. Make sure the name you're calling is correct and that you have the module installed!!");
            return;
        }
        if (!chatSuffix.isEnabled() || !chatSuffix.textMode.getValue().equals(ChatSuffix.TextMode.CUSTOM)) {
            Command.sendWarningMessage("&6Warning: The ChatSuffix module is not enabled, or you don't have custom mode enabled!");
            Command.sendWarningMessage("The command will still work, but will not visibly do anything.");
        }
        for (final String value : array) {
            if (value != null) {
                chatSuffix.customText.setValue(value);
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("Set the Custom Text Mode to <").append(value).append(">")));
            }
        }
    }
    
    public ChatSuffixCommand() {
        super("chatsuffix", new ChunkBuilder().append("ending").build(), new String[] { "chat", "customchat" });
        this.setDescription("Allows you to customize ChatSuffix's custom setting");
    }
}
