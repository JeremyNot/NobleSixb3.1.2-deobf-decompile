//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax.parsers;

import me.noble.client.command.syntax.*;

public class DependantParser extends AbstractParser
{
    private Dependency dependancy;
    int dependantIndex;
    
    protected String getDefaultChunk(final SyntaxChunk syntaxChunk) {
        return this.dependancy.getEscape();
    }
    
    public DependantParser(final int dependantIndex, final Dependency dependancy) {
        this.dependantIndex = dependantIndex;
        this.dependancy = dependancy;
    }
    
    public String getChunk(final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s) {
        if (s != null && !s.equals("")) {
            return "";
        }
        if (array2.length <= this.dependantIndex) {
            return this.getDefaultChunk(syntaxChunk);
        }
        if (array2[this.dependantIndex] == null || array2[this.dependantIndex].equals("")) {
            return "";
        }
        return this.dependancy.feed(array2[this.dependantIndex]);
    }
    
    public static class Dependency
    {
        String[][] map;
        String escape;
        
        public String[][] getMap() {
            return this.map;
        }
        
        public Dependency(final String[][] map, final String escape) {
            this.map = new String[0][];
            this.map = map;
            this.escape = escape;
        }
        
        public String getEscape() {
            return this.escape;
        }
        
        private String[] containsKey(final String[][] array, final String s) {
            for (final String[] array2 : array) {
                if (array2[0].equals(s)) {
                    return array2;
                }
            }
            return null;
        }
        
        public String feed(final String s) {
            final String[] containsKey = this.containsKey(this.map, s);
            if (containsKey != null) {
                return containsKey[1];
            }
            return this.getEscape();
        }
    }
}
