//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command;

import me.noble.client.command.commands.*;
import me.noble.client.util.*;
import me.noble.client.*;
import java.util.*;

public class CommandManager
{
    private ArrayList<Command> commands;
    
    public CommandManager() {
        this.commands = new ArrayList<Command>();
        for (final Class<?> clazz : ClassFinder.findClasses(BindCommand.class.getPackage().getName(), Command.class)) {
            if (Command.class.isAssignableFrom(clazz)) {
                try {
                    this.commands.add((Command)clazz.getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]));
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    System.err.println(String.valueOf(new StringBuilder().append("Couldn't initiate command ").append(clazz.getSimpleName()).append("! Err: ").append(ex.getClass().getSimpleName()).append(", message: ").append(ex.getMessage())));
                }
            }
        }
        NobleMod.log.info("Commands initialised");
    }
    
    public ArrayList<Command> getCommands() {
        return this.commands;
    }
    
    public Command getCommandByLabel(final String s) {
        for (final Command command : this.commands) {
            if (command.getLabel().equals(s)) {
                return command;
            }
        }
        return null;
    }
    
    private static String strip(final String s, final String s2) {
        if (s.startsWith(s2) && s.endsWith(s2)) {
            return s.substring(s2.length(), s.length() - s2.length());
        }
        return s;
    }
    
    public void callCommand(final String s) {
        final String[] split = s.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
        final String substring = split[0].substring(1);
        final String[] removeElement = removeElement(split, 0);
        for (int i = 0; i < removeElement.length; ++i) {
            if (removeElement[i] != null) {
                removeElement[i] = strip(removeElement[i], "\"");
            }
        }
        for (final Command command : this.commands) {
            if (command.getLabel().equalsIgnoreCase(substring)) {
                if (!command.getAliases().isEmpty()) {
                    Command.sendChatMessage("This command has aliases!");
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append(command.getLabel()).append(", ").append(String.join(", ", command.getAliases()))));
                }
                command.call(split);
                return;
            }
            for (int j = 0; j < command.getAliases().size(); ++j) {
                if (((String)command.getAliases().get(j)).equalsIgnoreCase(substring)) {
                    command.call(split);
                    return;
                }
            }
        }
        Command.sendChatMessage("Unknown command. try 'cmds' for a list of commands.");
    }
    
    public static String[] removeElement(final String[] array, final int n) {
        final LinkedList<String> list = new LinkedList<String>();
        for (int i = 0; i < array.length; ++i) {
            if (i != n) {
                list.add(array[i]);
            }
        }
        return list.toArray(array);
    }
}
