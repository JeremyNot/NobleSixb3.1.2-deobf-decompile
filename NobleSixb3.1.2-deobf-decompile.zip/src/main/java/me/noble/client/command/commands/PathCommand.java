//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.*;
import net.minecraft.pathfinding.*;
import me.noble.client.module.modules.render.*;

public class PathCommand extends Command
{
    int y;
    int z;
    int x;
    
    public PathCommand() {
        super("path", new ChunkBuilder().append("x").append("y").append("z").build(), new String[] { "pathfind" });
        this.x = Integer.MIN_VALUE;
        this.y = Integer.MIN_VALUE;
        this.z = Integer.MIN_VALUE;
        this.setDescription("Pathfinding for AutoWalk");
    }
    
    public void call(final String[] array) {
        if (array[0] != null && array[0].equalsIgnoreCase("retry")) {
            if (this.x != Integer.MIN_VALUE) {
                Pathfind.createPath(new PathPoint(this.x, this.y, this.z));
                if (!Pathfind.points.isEmpty()) {
                    Command.sendChatMessage("Path created!");
                }
                return;
            }
            Command.sendChatMessage("No location to retry pathfinding to.");
        }
        else {
            if (array.length <= 3) {
                Command.sendChatMessage("&cMissing arguments: x, y, z");
                return;
            }
            try {
                this.x = Integer.parseInt(array[0]);
                this.y = Integer.parseInt(array[1]);
                this.z = Integer.parseInt(array[2]);
                Pathfind.createPath(new PathPoint(this.x, this.y, this.z));
                if (!Pathfind.points.isEmpty()) {
                    Command.sendChatMessage("Path created!");
                }
            }
            catch (NumberFormatException ex) {
                Command.sendChatMessage("Error: input must be numerical");
            }
        }
    }
}
