//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax.parsers;

import me.noble.client.command.syntax.*;
import me.noble.client.setting.*;
import me.noble.client.module.*;
import java.util.*;

public class ValueParser extends AbstractParser
{
    int moduleIndex;
    
    public String getChunk(final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s) {
        if (this.moduleIndex > array2.length - 1 || s == null) {
            return this.getDefaultChunk(syntaxChunk);
        }
        final Module moduleByName = ModuleManager.getModuleByName(array2[this.moduleIndex]);
        if (moduleByName == null) {
            return "";
        }
        final HashMap<String, Setting> hashMap = new HashMap<String, Setting>();
        for (final Setting setting : moduleByName.settingList) {
            if (setting.getName().toLowerCase().startsWith(s.toLowerCase())) {
                hashMap.put(setting.getName(), setting);
            }
        }
        if (hashMap.isEmpty()) {
            return "";
        }
        return new TreeMap<Object, Setting>(hashMap).firstEntry().getValue().getName().substring(s.length());
    }
    
    public ValueParser(final int moduleIndex) {
        this.moduleIndex = moduleIndex;
    }
}
