//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax.parsers;

import net.minecraft.block.*;
import net.minecraft.util.*;
import me.noble.client.command.syntax.*;
import java.util.*;

public class BlockParser extends AbstractParser
{
    private static HashMap<String, Block> blockNames;
    
    public static String getNameFromBlock(final Block block) {
        if (!BlockParser.blockNames.containsValue(block)) {
            return null;
        }
        return (String)getKeyFromValue(BlockParser.blockNames, block);
    }
    
    public static Object getKeyFromValue(final Map map, final Object o) {
        for (final Object next : map.keySet()) {
            if (map.get(next).equals(o)) {
                return next;
            }
        }
        return null;
    }
    
    public static Block getBlockFromName(final String s) {
        if (!BlockParser.blockNames.containsKey(s)) {
            return null;
        }
        return BlockParser.blockNames.get(s);
    }
    
    static {
        BlockParser.blockNames = new HashMap<String, Block>();
    }
    
    public BlockParser() {
        if (!BlockParser.blockNames.isEmpty()) {
            return;
        }
        for (final ResourceLocation resourceLocation : Block.REGISTRY.getKeys()) {
            BlockParser.blockNames.put(resourceLocation.toString().replace("minecraft:", "").replace("_", ""), (Block)Block.REGISTRY.getObject((Object)resourceLocation));
        }
    }
    
    public String getChunk(final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s) {
        try {
            if (s == null) {
                return String.valueOf(new StringBuilder().append(syntaxChunk.isHeadless() ? "" : syntaxChunk.getHead()).append(syntaxChunk.isNecessary() ? "<" : "[").append(syntaxChunk.getType()).append(syntaxChunk.isNecessary() ? ">" : "]"));
            }
            final HashMap<String, Block> hashMap = new HashMap<String, Block>();
            for (final String s2 : BlockParser.blockNames.keySet()) {
                if (s2.toLowerCase().startsWith(s.toLowerCase().replace("minecraft:", "").replace("_", ""))) {
                    hashMap.put(s2, BlockParser.blockNames.get(s2));
                }
            }
            if (hashMap.isEmpty()) {
                return "";
            }
            return new TreeMap<String, Object>(hashMap).firstEntry().getKey().substring(s.length());
        }
        catch (Exception ex) {
            return "";
        }
    }
}
