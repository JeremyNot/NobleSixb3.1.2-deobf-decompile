//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.*;
import me.noble.client.*;
import java.util.*;
import java.util.function.*;

public class CommandsCommand extends Command
{
    public CommandsCommand() {
        super("commands", SyntaxChunk.EMPTY, new String[] { "cmd", "cmds" });
        this.setDescription("Gives you this list of commands");
    }
    
    private static String lambda$call$0(final Command command) {
        return command.getLabel();
    }
    
    private static void lambda$call$1(final Command command) {
        Command.sendChatMessage(String.valueOf(new StringBuilder().append("&7").append(Command.getCommandPrefix()).append(command.getLabel()).append("&r ~ &8").append(command.getDescription())));
    }
    
    public void call(final String[] array) {
        NobleMod.getInstance().getCommandManager().getCommands().stream().sorted(Comparator.comparing((Function<? super T, ? extends Comparable>)CommandsCommand::lambda$call$0)).forEach(CommandsCommand::lambda$call$1);
    }
}
