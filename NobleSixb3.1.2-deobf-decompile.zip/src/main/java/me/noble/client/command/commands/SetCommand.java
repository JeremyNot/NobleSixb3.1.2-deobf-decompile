//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import java.util.function.*;
import java.util.stream.*;
import me.noble.client.module.*;
import java.util.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;
import me.noble.client.setting.*;

public class SetCommand extends Command
{
    public void call(final String[] array) {
        if (array[0] == null) {
            Command.sendChatMessage("Please specify a module!");
            return;
        }
        final Module moduleByName = ModuleManager.getModuleByName(array[0]);
        if (moduleByName == null) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Unknown module &b").append(array[0]).append("&r!")));
            return;
        }
        if (array[1] == null) {
            final String join = String.join(", ", (Iterable<? extends CharSequence>)moduleByName.settingList.stream().map((Function<? super Object, ?>)SetCommand::lambda$call$0).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
            if (join.isEmpty()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("Module &b").append(moduleByName.getName()).append("&r has no settings.")));
            }
            else {
                Command.sendStringChatMessage(new String[] { "Please specify a setting! Choose one of the following:", join });
            }
            return;
        }
        final Optional<ISettingUnknown> first = moduleByName.settingList.stream().filter(SetCommand::lambda$call$1).findFirst();
        if (!first.isPresent()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Unknown setting &b").append(array[1]).append("&r in &b").append(moduleByName.getName()).append("&r!")));
            return;
        }
        final ISettingUnknown settingUnknown = first.get();
        if (array[2] == null) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("&b").append(settingUnknown.getName()).append("&r is a &3").append(settingUnknown.getValueClass().getSimpleName()).append("&r. Its current value is &3").append(settingUnknown.getValueAsString())));
            return;
        }
        try {
            settingUnknown.setValueFromString(array[2]);
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Set &b").append(settingUnknown.getName()).append("&r to &3").append(array[2]).append("&r.")));
        }
        catch (Exception ex) {
            ex.printStackTrace();
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Unable to set value! &6").append(ex.getMessage())));
        }
    }
    
    public SetCommand() {
        super("set", new ChunkBuilder().append("module", true, new ModuleParser()).append("setting", true).append("value", true).build(), new String[0]);
        this.setDescription("Change the setting of a certain module");
    }
    
    private static String lambda$call$0(final Setting setting) {
        return setting.getName();
    }
    
    private static boolean lambda$call$1(final String[] array, final Setting setting) {
        return setting.getName().equalsIgnoreCase(array[1]);
    }
}
