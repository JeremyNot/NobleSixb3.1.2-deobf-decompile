//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import net.minecraft.client.*;
import java.awt.datatransfer.*;
import net.minecraft.nbt.*;
import net.minecraft.item.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;
import java.awt.*;

public class NBTCommand extends Command
{
    private final Clipboard clipboard;
    Minecraft mc;
    StringSelection nbt;
    
    public void call(final String[] array) {
        if (array[0].isEmpty()) {
            sendErrorMessage("Invalid Syntax!");
            return;
        }
        final ItemStack getCurrentItem = this.mc.player.inventory.getCurrentItem();
        if (array[0].equalsIgnoreCase("get")) {
            if (getCurrentItem.getTagCompound() != null) {
                sendChatMessage(String.valueOf(new StringBuilder().append("&6&lNBT:\n").append(getCurrentItem.getTagCompound()).append("")));
            }
            else {
                sendErrorMessage(String.valueOf(new StringBuilder().append("No NBT on ").append(getCurrentItem.getDisplayName())));
            }
        }
        else if (array[0].equalsIgnoreCase("copy")) {
            if (getCurrentItem.getTagCompound() != null) {
                this.nbt = new StringSelection(String.valueOf(new StringBuilder().append(getCurrentItem.getTagCompound()).append("")));
                this.clipboard.setContents(this.nbt, this.nbt);
                sendChatMessage(String.valueOf(new StringBuilder().append("&6Copied\n&f").append(getCurrentItem.getTagCompound()).append("\n").append("&6to clipboard.")));
            }
            else {
                sendErrorMessage(String.valueOf(new StringBuilder().append("No NBT on ").append(getCurrentItem.getDisplayName())));
            }
        }
        else if (array[0].equalsIgnoreCase("wipe")) {
            sendChatMessage(String.valueOf(new StringBuilder().append("&6Wiped\n&f").append(getCurrentItem.getTagCompound()).append("\n").append("&6from ").append(getCurrentItem.getDisplayName()).append(".")));
            getCurrentItem.setTagCompound(new NBTTagCompound());
        }
    }
    
    public NBTCommand() {
        super("nbt", new ChunkBuilder().append("action", true, new EnumParser(new String[] { "get", "copy", "wipe" })).build(), new String[0]);
        this.mc = Minecraft.getMinecraft();
        this.clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        this.setDescription("Does NBT related stuff (&7get&8, &7copy&8, &7set&8)");
    }
}
