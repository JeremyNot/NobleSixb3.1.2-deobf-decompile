//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import java.net.*;
import java.io.*;
import me.noble.client.util.*;
import net.minecraft.client.network.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;
import net.minecraft.client.*;
import com.mojang.util.*;
import com.google.gson.*;
import java.util.*;

public class FriendCommand extends Command
{
    private static String requestIDs(final String s) {
        try {
            final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL("https://api.mojang.com/profiles/minecraft").openConnection();
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setRequestMethod("POST");
            final OutputStream outputStream = httpURLConnection.getOutputStream();
            outputStream.write(s.getBytes("UTF-8"));
            outputStream.close();
            final BufferedInputStream bufferedInputStream = new BufferedInputStream(httpURLConnection.getInputStream());
            final String convertStreamToString = convertStreamToString(bufferedInputStream);
            bufferedInputStream.close();
            httpURLConnection.disconnect();
            return convertStreamToString;
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    private void lambda$call$0(final String[] array) {
        final Friends.Friend friendByName = this.getFriendByName(array[1]);
        if (friendByName == null) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Failed to find UUID of ").append(array[1])));
            return;
        }
        final Friends instance = Friends.INSTANCE;
        Friends.friends.getValue().add(friendByName);
        Command.sendChatMessage(String.valueOf(new StringBuilder().append("&b").append(friendByName.getUsername()).append("&r has been friended.")));
    }
    
    private static boolean lambda$call$1(final String[] array, final Friends.Friend friend) {
        return friend.getUsername().equalsIgnoreCase(array[1]);
    }
    
    private static boolean lambda$getFriendByName$2(final String s, final NetworkPlayerInfo networkPlayerInfo) {
        return networkPlayerInfo.getGameProfile().getName().equalsIgnoreCase(s);
    }
    
    public FriendCommand() {
        super("friend", new ChunkBuilder().append("mode", true, new EnumParser(new String[] { "add", "del" })).append("name").build(), new String[] { "friends", "f" });
        this.setDescription("Add someone as your friend!");
    }
    
    private Friends.Friend getFriendByName(final String s) {
        final NetworkPlayerInfo networkPlayerInfo = new ArrayList<NetworkPlayerInfo>(Minecraft.getMinecraft().getConnection().getPlayerInfoMap()).stream().filter(FriendCommand::lambda$getFriendByName$2).findFirst().orElse(null);
        if (networkPlayerInfo == null) {
            Command.sendChatMessage("Player isn't online. Looking up UUID..");
            final String requestIDs = requestIDs(String.valueOf(new StringBuilder().append("[\"").append(s).append("\"]")));
            if (requestIDs == null || requestIDs.isEmpty()) {
                Command.sendChatMessage("Couldn't find player ID. Are you connected to the internet? (0)");
            }
            else {
                final JsonElement parse = new JsonParser().parse(requestIDs);
                if (parse.getAsJsonArray().size() == 0) {
                    Command.sendChatMessage("Couldn't find player ID. (1)");
                }
                else {
                    try {
                        return new Friends.Friend(parse.getAsJsonArray().get(0).getAsJsonObject().get("name").getAsString(), UUIDTypeAdapter.fromString(parse.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString()));
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                        Command.sendChatMessage("Couldn't find player ID. (2)");
                    }
                }
            }
            return null;
        }
        return new Friends.Friend(networkPlayerInfo.getGameProfile().getName(), networkPlayerInfo.getGameProfile().getId());
    }
    
    private static String convertStreamToString(final InputStream inputStream) {
        final Scanner useDelimiter = new Scanner(inputStream).useDelimiter("\\A");
        return useDelimiter.hasNext() ? useDelimiter.next() : "/";
    }
    
    public void call(final String[] array) {
        if (array[0] == null) {
            final Friends instance = Friends.INSTANCE;
            if (Friends.friends.getValue().isEmpty()) {
                Command.sendChatMessage("You currently don't have any friends added. &bfriend add <name>&r to add one.");
                return;
            }
            String value = "";
            final Friends instance2 = Friends.INSTANCE;
            final Iterator<Friends.Friend> iterator = Friends.friends.getValue().iterator();
            while (iterator.hasNext()) {
                value = String.valueOf(new StringBuilder().append(value).append(iterator.next().getUsername()).append(", "));
            }
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Your friends: ").append(value.substring(0, value.length() - 2))));
        }
        else {
            if (array[1] == null) {
                Command.sendChatMessage(String.format(Friends.isFriend(array[0]) ? "Yes, %s is your friend." : "No, %s isn't a friend of yours.", array[0]));
                Command.sendChatMessage(String.format(Friends.isFriend(array[0]) ? "Yes, %s is your friend." : "No, %s isn't a friend of yours.", array[0]));
                return;
            }
            if (array[0].equalsIgnoreCase("add") || array[0].equalsIgnoreCase("new")) {
                if (Friends.isFriend(array[1])) {
                    Command.sendChatMessage("That player is already your friend.");
                    return;
                }
                new Thread(this::lambda$call$0).start();
            }
            else {
                if (!array[0].equalsIgnoreCase("del") && !array[0].equalsIgnoreCase("remove") && !array[0].equalsIgnoreCase("delete")) {
                    Command.sendChatMessage("Please specify either &6add&r or &6remove");
                    return;
                }
                if (!Friends.isFriend(array[1])) {
                    Command.sendChatMessage("That player isn't your friend.");
                    return;
                }
                final Friends instance3 = Friends.INSTANCE;
                final Friends.Friend friend = Friends.friends.getValue().stream().filter(FriendCommand::lambda$call$1).findFirst().get();
                final Friends instance4 = Friends.INSTANCE;
                Friends.friends.getValue().remove(friend);
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("&b").append(friend.getUsername()).append("&r has been unfriended.")));
            }
        }
    }
}
