//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.*;

public class CreditsCommand extends Command
{
    public void call(final String[] array) {
        Command.sendChatMessage("\n&l&9Author: \n&b086\n&l&9Contributors: \n&bBella (S-B99)\n&bhub (blockparole)\n&bSasha (EmotionalLove)\n&bQther (d1gress / Vonr)\n&bHHSGPA\n&b20kdc\n&bIronException\n&bcats (Cuhnt)\n&bKatatje\n&bDeauthorized\n&bsnowmii\n&bkdb424\n&Jack (jacksonellsworth03)\n&bcookiedragon234\n&b0x2E (PretendingToCode)\n&bbabbaj\n&bZeroMemes\n&bTheBritishMidget (TBM)\n&bHamburger (Hamburger2k)\n&bDarki\n&bFINZ0\n&bCrystallinqq\n&bElementars\n&bfsck\n&bJamie (jamie27)\n&bWaizy\n&bIt is the end\n&bfluffcq\n&bleijurv\n&bpolymer");
    }
    
    public CreditsCommand() {
        super("credits", (SyntaxChunk[])null, new String[] { "creds" });
        this.setDescription("Prints KAMI Blue's authors and contributors");
    }
}
