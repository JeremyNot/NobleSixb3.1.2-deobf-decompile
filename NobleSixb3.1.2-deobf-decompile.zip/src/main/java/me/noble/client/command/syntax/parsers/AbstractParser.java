//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax.parsers;

import me.noble.client.command.syntax.*;

public abstract class AbstractParser implements SyntaxParser
{
    @Override
    public abstract String getChunk(final SyntaxChunk[] p0, final SyntaxChunk p1, final String[] p2, final String p3);
    
    protected String getDefaultChunk(final SyntaxChunk syntaxChunk) {
        return String.valueOf(new StringBuilder().append(syntaxChunk.isHeadless() ? "" : syntaxChunk.getHead()).append(syntaxChunk.isNecessary() ? "<" : "[").append(syntaxChunk.getType()).append(syntaxChunk.isNecessary() ? ">" : "]"));
    }
}
