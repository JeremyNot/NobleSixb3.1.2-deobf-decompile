//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command;

import me.noble.client.command.syntax.*;
import net.minecraft.client.*;
import me.noble.client.setting.*;
import me.noble.client.util.*;
import net.minecraft.launchwrapper.*;
import me.noble.client.*;
import java.util.*;
import net.minecraft.util.text.*;
import java.util.regex.*;

public abstract class Command
{
    protected String syntax;
    protected ArrayList<String> aliases;
    protected String label;
    protected SyntaxChunk[] syntaxChunks;
    public static Setting<String> commandPrefix;
    protected String description;
    public final Minecraft mc;
    
    public String getDescription() {
        return this.description;
    }
    
    static {
        Command.commandPrefix = Settings.s("commandPrefix", ".");
    }
    
    public ArrayList<String> getAliases() {
        return this.aliases;
    }
    
    public static void sendRawChatMessage(final String s) {
        if (isSendable()) {
            Wrapper.getPlayer().addChatMessage((ITextComponent)new ChatMessage(s));
        }
        else {
            LogWrapper.info(String.valueOf(new StringBuilder().append("KAMI Blue: Avoided NPE by logging to file instead of chat\n").append(s)), new Object[0]);
        }
    }
    
    public abstract void call(final String[] p0);
    
    public static void sendWarningMessage(final String s) {
        sendRawChatMessage(String.valueOf(new StringBuilder().append("&7[&6").append(NobleMod.KAMI_KANJI).append("&7] &r").append(s)));
    }
    
    public static void sendCustomMessage(final String s, final String s2) {
        sendRawChatMessage(String.valueOf(new StringBuilder().append("&7[").append(s2).append(NobleMod.KAMI_KANJI).append("&7] &r").append(s)));
    }
    
    protected SyntaxChunk getSyntaxChunk(final String s) {
        for (final SyntaxChunk syntaxChunk : this.syntaxChunks) {
            if (syntaxChunk.getType().equals(s)) {
                return syntaxChunk;
            }
        }
        return null;
    }
    
    public static void sendStringChatMessage(final String[] array) {
        sendChatMessage("");
        for (int length = array.length, i = 0; i < length; ++i) {
            sendRawChatMessage(array[i]);
        }
    }
    
    public Command(final String label, final SyntaxChunk[] syntaxChunks, final String... array) {
        this.mc = Minecraft.getMinecraft();
        this.label = label;
        this.syntaxChunks = syntaxChunks;
        this.description = "Descriptionless";
        this.aliases = new ArrayList<String>(Arrays.asList(array));
    }
    
    protected void setDescription(final String description) {
        this.description = description;
    }
    
    public SyntaxChunk[] getSyntaxChunks() {
        return this.syntaxChunks;
    }
    
    public static boolean isSendable() {
        return Minecraft.getMinecraft().player != null;
    }
    
    public static String getCommandPrefix() {
        return Command.commandPrefix.getValue();
    }
    
    public static void sendErrorMessage(final String s) {
        sendRawChatMessage(String.valueOf(new StringBuilder().append("&7[&4").append(NobleMod.KAMI_KANJI).append("&7] &r").append(s)));
    }
    
    public Command(final String label, final SyntaxChunk[] syntaxChunks, final ArrayList<String> aliases) {
        this.mc = Minecraft.getMinecraft();
        this.label = label;
        this.syntaxChunks = syntaxChunks;
        this.description = "Descriptionless";
        this.aliases = aliases;
    }
    
    public String getLabel() {
        return this.label;
    }
    
    public static void sendChatMessage(final String s) {
        sendRawChatMessage(String.valueOf(new StringBuilder().append("&7[&9").append(NobleMod.KAMI_KANJI).append("&7] &r").append(s)));
    }
    
    public static class ChatMessage extends TextComponentBase
    {
        String text;
        
        public ChatMessage(final String s) {
            final Matcher matcher = Pattern.compile("&[0123456789abcdefrlosmk]").matcher(s);
            final StringBuffer sb = new StringBuffer();
            while (matcher.find()) {
                matcher.appendReplacement(sb, String.valueOf(new StringBuilder().append("��").append(matcher.group().substring(1))));
            }
            matcher.appendTail(sb);
            this.text = sb.toString();
        }
        
        public ITextComponent createCopy() {
            return (ITextComponent)new ChatMessage(this.text);
        }
        
        public String getUnformattedComponentText() {
            return this.text;
        }
    }
}
