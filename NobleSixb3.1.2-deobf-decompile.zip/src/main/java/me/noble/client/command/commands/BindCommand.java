//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;

public class BindCommand extends Command
{
    public static Setting<Boolean> modifiersEnabled;
    
    public void call(final String[] array) {
        if (array.length == 1) {
            Command.sendChatMessage("Please specify a module.");
            return;
        }
        final String s = array[0];
        final String s2 = array[1];
        if (s.equalsIgnoreCase("modifiers")) {
            if (s2 == null) {
                sendChatMessage("Expected: on or off");
                return;
            }
            if (s2.equalsIgnoreCase("on")) {
                BindCommand.modifiersEnabled.setValue(true);
                sendChatMessage("Turned modifiers on.");
            }
            else if (s2.equalsIgnoreCase("off")) {
                BindCommand.modifiersEnabled.setValue(false);
                sendChatMessage("Turned modifiers off.");
            }
            else {
                sendChatMessage("Expected: on or off");
            }
        }
        else {
            final Module moduleByName = ModuleManager.getModuleByName(s);
            if (moduleByName == null) {
                sendChatMessage(String.valueOf(new StringBuilder().append("Unknown module '").append(s).append("'!")));
                return;
            }
            if (s2 == null) {
                sendChatMessage(String.valueOf(new StringBuilder().append(moduleByName.getName()).append(" is bound to &b").append(moduleByName.getBindName())));
                return;
            }
            int key = Wrapper.getKey(s2);
            if (s2.equalsIgnoreCase("none")) {
                key = -1;
            }
            if (key == 0) {
                sendChatMessage(String.valueOf(new StringBuilder().append("Unknown key '").append(s2).append("'!")));
                return;
            }
            moduleByName.getBind().setKey(key);
            sendChatMessage(String.valueOf(new StringBuilder().append("Bind for &b").append(moduleByName.getName()).append("&r set to &b").append(s2.toUpperCase())));
        }
    }
    
    static {
        BindCommand.modifiersEnabled = SettingBuilder.register(Settings.b("modifiersEnabled", false), "binds");
    }
    
    public BindCommand() {
        super("bind", new ChunkBuilder().append("[module]|modifiers", true, new ModuleParser()).append("[key]|[on|off]", true).build(), new String[0]);
        this.setDescription("Binds a command and or settings to a key");
    }
}
