//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import java.util.concurrent.atomic.*;
import java.util.*;
import java.util.function.*;
import org.apache.commons.lang3.*;
import net.minecraft.util.text.*;
import me.noble.client.command.syntax.*;
import me.noble.client.module.*;

public class EnabledCommand extends Command
{
    public void call(final String[] array) {
        final AtomicReference<String> atomicReference = new AtomicReference<String>("");
        new ArrayList(ModuleManager.getModules()).forEach((Consumer)EnabledCommand::lambda$call$0);
        atomicReference.set(StringUtils.chop(StringUtils.chop(String.valueOf(atomicReference))));
        Command.sendChatMessage(String.valueOf(new StringBuilder().append("Enabled modules: \n").append(TextFormatting.GRAY).append(atomicReference)));
    }
    
    public EnabledCommand() {
        super("enabledlist", (SyntaxChunk[])null, new String[] { "enabled", "enabledmodules" });
        this.setDescription("Prints Enabled Modules");
    }
    
    private static void lambda$call$0(final AtomicReference atomicReference, final Module module) {
        if (module.isEnabled()) {
            atomicReference.set(String.valueOf(new StringBuilder().append(atomicReference).append(module.getName()).append(", ")));
        }
    }
}
