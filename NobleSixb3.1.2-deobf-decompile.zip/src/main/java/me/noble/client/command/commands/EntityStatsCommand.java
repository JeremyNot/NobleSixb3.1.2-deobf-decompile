//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.*;
import java.math.*;
import me.noble.client.command.syntax.*;

public class EntityStatsCommand extends Command
{
    public void call(final String[] array) {
        if (this.mc.player.getRidingEntity() != null && this.mc.player.getRidingEntity() instanceof AbstractHorse) {
            final AbstractHorse abstractHorse = (AbstractHorse)this.mc.player.getRidingEntity();
            final float getMaxHealth = abstractHorse.getMaxHealth();
            final double round = round(43.17 * abstractHorse.getAIMoveSpeed(), 2);
            final double round2 = round(-0.1817584952 * Math.pow(abstractHorse.getHorseJumpStrength(), 3.0) + 3.689713992 * Math.pow(abstractHorse.getHorseJumpStrength(), 2.0) + 2.128599134 * abstractHorse.getHorseJumpStrength() - 0.343930367, 4);
            final String s = (abstractHorse.getOwnerUniqueId() == null) ? "Not tamed." : abstractHorse.getOwnerUniqueId().toString();
            final StringBuilder sb = new StringBuilder("&6Entity Statistics:");
            sb.append("\n&cMax Health: ").append(getMaxHealth);
            sb.append("\n&cSpeed: ").append(round);
            sb.append("\n&cJump: ").append(round2);
            sb.append("\n&cOwner: ").append(s);
            Command.sendChatMessage(String.valueOf(sb));
        }
        else if (this.mc.player.getRidingEntity() instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)this.mc.player.getRidingEntity();
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("&6Entity Stats:\n&cMax Health: &b").append(entityLivingBase.getMaxHealth()).append(" &2HP\n&cSpeed: &b").append(round(43.17 * entityLivingBase.getAIMoveSpeed(), 2)).append(" &2m/s")));
        }
        else {
            Command.sendChatMessage("&4&lError: &cNot riding a compatible entity.");
        }
    }
    
    public static double round(final double n, final int n2) {
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        return BigDecimal.valueOf(n).setScale(n2, RoundingMode.HALF_UP).doubleValue();
    }
    
    public EntityStatsCommand() {
        super("entitystats", (SyntaxChunk[])null, new String[] { "estats", "horestats", "hstats", "vehiclestats" });
        this.setDescription("Print the statistics of the entity you're currently riding");
    }
}
