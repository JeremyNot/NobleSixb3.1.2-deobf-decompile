//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import net.minecraft.tileentity.*;
import me.noble.client.util.*;
import net.minecraft.item.*;
import me.noble.client.command.syntax.*;

public class PeekCommand extends Command
{
    public static TileEntityShulkerBox sb;
    
    public void call(final String[] array) {
        final ItemStack getCurrentItem = Wrapper.getPlayer().inventory.getCurrentItem();
        if (getCurrentItem.getItem() instanceof ItemShulkerBox) {
            final TileEntityShulkerBox sb = new TileEntityShulkerBox();
            sb.blockType = ((ItemShulkerBox)getCurrentItem.getItem()).getBlock();
            sb.setWorldObj(Wrapper.getWorld());
            sb.readFromNBT(getCurrentItem.getTagCompound().getCompoundTag("BlockEntityTag"));
            PeekCommand.sb = sb;
        }
        else {
            Command.sendChatMessage("You aren't carrying a shulker box.");
        }
    }
    
    public PeekCommand() {
        super("peek", SyntaxChunk.EMPTY, new String[0]);
        this.setDescription("Look inside the contents of a shulker box without opening it");
    }
}
