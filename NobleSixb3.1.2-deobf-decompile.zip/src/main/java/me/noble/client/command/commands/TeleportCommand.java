//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import java.text.*;
import net.minecraft.client.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.misc.*;
import net.minecraft.util.math.*;

public class TeleportCommand extends Command
{
    DecimalFormat df;
    Minecraft mc;
    
    public TeleportCommand() {
        super("teleport", new ChunkBuilder().append("x/stop", true, new ModuleParser()).append("y", true).append("z", true).append("blocks per tp", false).build(), new String[] { "tp", "hclip", "clip" });
        this.mc = Minecraft.getMinecraft();
        this.df = new DecimalFormat("#.###");
        this.setDescription("Potentia teleport exploit");
    }
    
    public void call(final String[] array) {
        if (array[0].equalsIgnoreCase("stop")) {
            Command.sendChatMessage("Teleport Cancelled!");
            ModuleManager.getModuleByName("Teleport").disable();
            return;
        }
        if (array.length >= 4 && array[3] != null) {
            Teleport.blocksPerTeleport = Double.valueOf(array[3]);
        }
        else {
            Teleport.blocksPerTeleport = 10000.0;
        }
        if (array.length >= 3) {
            try {
                final double n = array[0].equals("~") ? this.mc.player.posX : ((array[0].charAt(0) == '~') ? (Double.parseDouble(array[0].substring(1)) + this.mc.player.posX) : Double.parseDouble(array[0]));
                final double n2 = array[1].equals("~") ? this.mc.player.posY : ((array[1].charAt(0) == '~') ? (Double.parseDouble(array[1].substring(1)) + this.mc.player.posY) : Double.parseDouble(array[1]));
                final double n3 = array[2].equals("~") ? this.mc.player.posZ : ((array[2].charAt(0) == '~') ? (Double.parseDouble(array[2].substring(1)) + this.mc.player.posZ) : Double.parseDouble(array[2]));
                Teleport.finalPos = new Vec3d(n, n2, n3);
                ModuleManager.getModuleByName("Teleport").enable();
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("\n&aTeleporting to \n&cX: &b").append(this.df.format(n)).append("&a, \n&cY: &b").append(this.df.format(n2)).append("&a, \n&cZ: &b").append(this.df.format(n3)).append("\n&aat &b").append(this.df.format(Teleport.blocksPerTeleport)).append("&c blocks per teleport.")));
            }
            catch (NullPointerException ex) {
                Command.sendErrorMessage("Null Pointer Exception Caught!");
            }
        }
    }
}
