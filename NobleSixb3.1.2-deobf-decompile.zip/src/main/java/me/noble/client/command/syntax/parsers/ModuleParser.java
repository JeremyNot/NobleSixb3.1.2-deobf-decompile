//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax.parsers;

import me.noble.client.command.syntax.*;
import me.noble.client.module.*;

public class ModuleParser extends AbstractParser
{
    private static boolean lambda$getChunk$0(final String s, final Module module) {
        return module.getName().toLowerCase().startsWith(s.toLowerCase());
    }
    
    public String getChunk(final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s) {
        if (s == null) {
            return this.getDefaultChunk(syntaxChunk);
        }
        final Module module = ModuleManager.getModules().stream().filter(ModuleParser::lambda$getChunk$0).findFirst().orElse(null);
        if (module == null) {
            return null;
        }
        return module.getName().substring(s.length());
    }
}
