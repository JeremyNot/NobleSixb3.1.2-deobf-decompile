//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax.parsers;

import me.noble.client.command.syntax.*;
import java.util.*;

public class EnumParser extends AbstractParser
{
    String[] modes;
    
    public String getChunk(final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s) {
        if (s == null) {
            String value = "";
            final String[] modes = this.modes;
            for (int length = modes.length, i = 0; i < length; ++i) {
                value = String.valueOf(new StringBuilder().append(value).append(modes[i]).append(":"));
            }
            return String.valueOf(new StringBuilder().append(syntaxChunk.isHeadless() ? "" : syntaxChunk.getHead()).append(syntaxChunk.isNecessary() ? "<" : "[").append(value.substring(0, value.length() - 1)).append(syntaxChunk.isNecessary() ? ">" : "]"));
        }
        final ArrayList<Comparable> list = new ArrayList<Comparable>();
        for (final String s2 : this.modes) {
            if (s2.toLowerCase().startsWith(s.toLowerCase())) {
                list.add(s2);
            }
        }
        if (list.isEmpty()) {
            return "";
        }
        Collections.sort(list);
        return ((String)list.get(0)).substring(s.length());
    }
    
    public EnumParser(final String[] modes) {
        this.modes = modes;
    }
}
