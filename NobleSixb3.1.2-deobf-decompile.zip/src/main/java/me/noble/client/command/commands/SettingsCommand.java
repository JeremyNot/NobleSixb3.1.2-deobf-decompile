//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.setting.*;
import me.noble.client.setting.impl.*;
import me.noble.client.module.*;
import java.util.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;

public class SettingsCommand extends Command
{
    public void call(final String[] array) {
        if (array[0] == null) {
            Command.sendChatMessage("Please specify a module to display the settings of.");
            return;
        }
        final Module moduleByName = ModuleManager.getModuleByName(array[0]);
        if (moduleByName == null) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Couldn't find a module &b").append(array[0]).append("!")));
            return;
        }
        final List<Setting> settingList = moduleByName.settingList;
        final String[] array2 = new String[settingList.size()];
        for (int i = 0; i < settingList.size(); ++i) {
            final Setting<Object> setting = settingList.get(i);
            array2[i] = String.valueOf(new StringBuilder().append("&b").append(setting.getName()).append("&3(=").append(setting.getValue()).append(")  &ftype: &3").append(setting.getValue().getClass().getSimpleName()));
            if (setting instanceof EnumSetting) {
                final StringBuilder sb = new StringBuilder();
                final String[] array3 = array2;
                final int n = i;
                array3[n] = String.valueOf(sb.append(array3[n]).append("  ("));
                for (final Enum enum1 : (Enum[])((EnumSetting<Object>)setting).clazz.getEnumConstants()) {
                    final StringBuilder sb2 = new StringBuilder();
                    final String[] array5 = array2;
                    final int n2 = i;
                    array5[n2] = String.valueOf(sb2.append(array5[n2]).append(enum1.name()).append(", "));
                }
                array2[i] = String.valueOf(new StringBuilder().append(array2[i].substring(0, array2[i].length() - 2)).append(")"));
            }
        }
        Command.sendStringChatMessage(array2);
    }
    
    public SettingsCommand() {
        super("settings", new ChunkBuilder().append("module", true, new ModuleParser()).build(), new String[0]);
        this.setDescription("List the possible settings of a command");
    }
}
