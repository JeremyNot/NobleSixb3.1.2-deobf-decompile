//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax;

public class SyntaxChunk
{
    private boolean necessary;
    public static final SyntaxChunk[] EMPTY;
    String head;
    private SyntaxParser parser;
    boolean headless;
    String type;
    
    public SyntaxChunk(final String s, final boolean b) {
        this("", s, b);
        this.headless = true;
    }
    
    public String getHead() {
        return this.head;
    }
    
    public SyntaxChunk(final String head, final String type, final boolean necessary) {
        this.headless = false;
        this.head = head;
        this.type = type;
        this.necessary = necessary;
        this.parser = this::lambda$new$0;
    }
    
    public boolean isHeadless() {
        return this.headless;
    }
    
    public String getType() {
        return this.type;
    }
    
    private String lambda$new$0(final String s, final String s2, final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s3) {
        if (s3 != null) {
            return null;
        }
        return String.valueOf(new StringBuilder().append(s).append(this.isNecessary() ? "<" : "[").append(s2).append(this.isNecessary() ? ">" : "]"));
    }
    
    static {
        EMPTY = new SyntaxChunk[0];
    }
    
    public String getChunk(final SyntaxChunk[] array, final SyntaxChunk syntaxChunk, final String[] array2, final String s) {
        final String chunk = this.parser.getChunk(array, syntaxChunk, array2, s);
        if (chunk == null) {
            return "";
        }
        return chunk;
    }
    
    public void setParser(final SyntaxParser parser) {
        this.parser = parser;
    }
    
    public boolean isNecessary() {
        return this.necessary;
    }
}
