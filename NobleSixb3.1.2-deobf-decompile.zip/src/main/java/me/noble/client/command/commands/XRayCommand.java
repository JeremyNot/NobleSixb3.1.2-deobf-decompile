//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.module.modules.render.*;
import me.noble.client.module.*;
import net.minecraft.block.*;
import me.noble.client.command.syntax.*;

public class XRayCommand extends Command
{
    public void call(final String[] array) {
        final XRay xRay = (XRay)ModuleManager.getModuleByName("XRay");
        if (xRay == null) {
            Command.sendErrorMessage("&cThe XRay module is not available for some reason. Make sure the name you're calling is correct and that you have the module installed!!");
            return;
        }
        if (!xRay.isEnabled()) {
            Command.sendWarningMessage("&6Warning: The XRay module is not enabled!");
            Command.sendWarningMessage("These commands will still have effect, but will not visibly do anything.");
        }
        for (final String s : array) {
            if (s != null) {
                if (s.equalsIgnoreCase("help")) {
                    Command.sendChatMessage("The XRay module has a list of blocks");
                    Command.sendChatMessage("Normally, the XRay module hides these blocks");
                    Command.sendChatMessage("When the Invert setting is on, the XRay only shows these blocks");
                    Command.sendChatMessage("This command is a convenient way to quickly edit the list");
                    Command.sendChatMessage("Available options: \n+block: Adds a block to the list\n-block: Removes a block from the list\n=block: Changes the list to only that block\nlist: Prints the list of selected blocks\ndefaults: Resets the list to the default list\nclear: Removes all blocks from the XRay block list\ninvert: Quickly toggles the invert setting");
                }
                else if (s.equalsIgnoreCase("clear")) {
                    xRay.extClear();
                    Command.sendWarningMessage("Cleared the XRay block list");
                }
                else if (s.equalsIgnoreCase("defaults")) {
                    xRay.extDefaults();
                    Command.sendChatMessage("Reset the XRay block list to default");
                }
                else if (s.equalsIgnoreCase("list")) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("\n").append(xRay.extGet())));
                }
                else if (s.equalsIgnoreCase("invert")) {
                    if (xRay.invert.getValue()) {
                        xRay.invert.setValue(false);
                        Command.sendChatMessage("Disabled XRay Invert");
                    }
                    else {
                        xRay.invert.setValue(true);
                        Command.sendChatMessage("Enabled XRay Invert");
                    }
                }
                else if (s.startsWith("=")) {
                    final String replace = s.replace("=", "");
                    xRay.extSet(replace);
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("Set the XRay block list to ").append(replace)));
                }
                else if (s.startsWith("+") || s.startsWith("-")) {
                    final String substring = s.substring(1);
                    if (Block.getBlockFromName(substring) == null) {
                        Command.sendChatMessage(String.valueOf(new StringBuilder().append("&cInvalid block name <").append(substring).append(">")));
                    }
                    else if (s.startsWith("+")) {
                        xRay.extAdd(substring);
                    }
                    else {
                        xRay.extRemove(substring);
                    }
                }
                else {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("&cInvalid subcommand <").append(s).append(">")));
                }
            }
        }
    }
    
    public XRayCommand() {
        super("xray", new ChunkBuilder().append("help").append("+block|-block|=block").append("list|defaults|clear|invert").build(), new String[] { "wallhack", "wireframe" });
        this.setDescription("Allows you to add or remove blocks from the &7xray &8module");
    }
}
