//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.syntax;

import java.util.*;

public class ChunkBuilder
{
    private static final SyntaxChunk[] EXAMPLE;
    List<SyntaxChunk> chunks;
    
    public SyntaxChunk[] build() {
        return this.chunks.toArray(ChunkBuilder.EXAMPLE);
    }
    
    public ChunkBuilder append(final String s) {
        return this.append(s, true);
    }
    
    public ChunkBuilder append(final SyntaxChunk syntaxChunk) {
        this.chunks.add(syntaxChunk);
        return this;
    }
    
    static {
        EXAMPLE = new SyntaxChunk[0];
    }
    
    public ChunkBuilder append(final String s, final boolean b, final SyntaxParser parser) {
        final SyntaxChunk syntaxChunk = new SyntaxChunk(s, b);
        syntaxChunk.setParser(parser);
        this.append(syntaxChunk);
        return this;
    }
    
    public ChunkBuilder() {
        this.chunks = new ArrayList<SyntaxChunk>();
    }
    
    public ChunkBuilder append(final String s, final boolean b) {
        this.append(new SyntaxChunk(s, b));
        return this;
    }
}
