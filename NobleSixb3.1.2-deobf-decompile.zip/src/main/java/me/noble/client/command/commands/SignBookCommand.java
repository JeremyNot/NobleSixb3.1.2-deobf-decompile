//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.*;
import me.noble.client.util.*;
import java.util.*;
import io.netty.buffer.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;

public class SignBookCommand extends Command
{
    public SignBookCommand() {
        super("signbook", new ChunkBuilder().append("name").build(), new String[] { "book", "sign" });
        this.setDescription("Colored book names. &7#n&8 for a new line and &7&&8 for colour codes");
    }
    
    public void call(final String[] array) {
        final ItemStack getCurrentItem = Wrapper.getPlayer().inventory.getCurrentItem();
        final int n = 167;
        if (array.length == 1) {
            Command.sendChatMessage("Please specify a title.");
            return;
        }
        if (getCurrentItem.getItem() instanceof ItemWritableBook) {
            final ArrayList<String> list = new ArrayList<String>();
            for (int i = 0; i < array.length; ++i) {
                list.add(array[i]);
            }
            final String replaceAll = String.join(" ", list).replaceAll("&", Character.toString((char)n)).replaceAll("#n", "\n").replaceAll("null", "");
            if (replaceAll.length() > 31) {
                Command.sendChatMessage("Title cannot be over 31 characters.");
                return;
            }
            final NBTTagList list2 = new NBTTagList();
            list2.appendTag((NBTBase)new NBTTagString(""));
            final NBTTagCompound getTagCompound = getCurrentItem.getTagCompound();
            if (getCurrentItem.hasTagCompound()) {
                if (getTagCompound != null) {
                    getCurrentItem.setTagCompound(getTagCompound);
                }
                getCurrentItem.getTagCompound().setTag("title", (NBTBase)new NBTTagString(replaceAll));
                getCurrentItem.getTagCompound().setTag("author", (NBTBase)new NBTTagString(Wrapper.getPlayer().getName()));
            }
            else {
                getCurrentItem.setTagInfo("pages", (NBTBase)list2);
                getCurrentItem.setTagInfo("title", (NBTBase)new NBTTagString(replaceAll));
                getCurrentItem.setTagInfo("author", (NBTBase)new NBTTagString(Wrapper.getPlayer().getName()));
            }
            final PacketBuffer packetBuffer = new PacketBuffer(Unpooled.buffer());
            packetBuffer.writeItemStackToBuffer(getCurrentItem);
            Wrapper.getPlayer().connection.sendPacket((Packet)new CPacketCustomPayload("MC|BSign", packetBuffer));
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Signed book with title: ").append(replaceAll).append("&r")));
        }
        else {
            Command.sendChatMessage("You must be holding a writable book.");
        }
    }
}
