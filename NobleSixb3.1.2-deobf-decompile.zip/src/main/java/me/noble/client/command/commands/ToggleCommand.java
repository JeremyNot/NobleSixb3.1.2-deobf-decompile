//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.module.*;
import me.noble.client.command.syntax.parsers.*;
import me.noble.client.command.syntax.*;

public class ToggleCommand extends Command
{
    public void call(final String[] array) {
        if (array.length == 0) {
            Command.sendChatMessage("Please specify a module!");
            return;
        }
        final Module moduleByName = ModuleManager.getModuleByName(array[0]);
        if (moduleByName == null) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Unknown module '").append(array[0]).append("'")));
            return;
        }
        moduleByName.toggle();
        Command.sendChatMessage(String.valueOf(new StringBuilder().append(moduleByName.getName()).append(moduleByName.isEnabled() ? " &aenabled" : " &cdisabled")));
    }
    
    public ToggleCommand() {
        super("toggle", new ChunkBuilder().append("module", true, new ModuleParser()).build(), new String[] { "t" });
        this.setDescription("Quickly toggle a module on and off");
    }
}
