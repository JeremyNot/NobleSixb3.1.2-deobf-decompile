//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import me.noble.client.command.syntax.*;
import me.noble.client.*;
import me.noble.client.module.*;
import java.util.*;

public class HelpCommand extends Command
{
    private static final Subject[] subjects;
    private static String subjectsList;
    
    static {
        subjects = new Subject[] { new Subject(new String[] { "type", "int", "boolean", "double", "float" }, new String[] { "Every module has a value, and that value is always of a certain &btype.\n", "These types are displayed in kami as the ones java use. They mean the following:", "&bboolean&r: Enabled or not. Values &3true/false", "&bfloat&r: A number with a decimal point", "&bdouble&r: Like a float, but a more accurate decimal point", "&bint&r: A number with no decimal point" }) };
        HelpCommand.subjectsList = "";
        final Subject[] subjects2 = HelpCommand.subjects;
        for (int length = subjects2.length, i = 0; i < length; ++i) {
            HelpCommand.subjectsList = String.valueOf(new StringBuilder().append(HelpCommand.subjectsList).append(subjects2[i].names[0]).append(", "));
        }
        HelpCommand.subjectsList = HelpCommand.subjectsList.substring(0, HelpCommand.subjectsList.length() - 2);
    }
    
    private static boolean lambda$call$0(final String s, final Subject subject) {
        final String[] names = subject.names;
        for (int length = names.length, i = 0; i < length; ++i) {
            if (names[i].equalsIgnoreCase(s)) {
                return true;
            }
        }
        return false;
    }
    
    public HelpCommand() {
        super("help", new SyntaxChunk[0], new String[] { "?" });
        this.setDescription(String.valueOf(new StringBuilder().append("Delivers help on certain subjects. Use &7").append(Command.getCommandPrefix()).append("help subjects&8 for a list.")));
    }
    
    public void call(final String[] array) {
        if (array[0] == null) {
            Command.sendStringChatMessage(new String[] { String.valueOf(new StringBuilder().append("NobleSix ").append(NobleMod.MODVER)), String.valueOf(new StringBuilder().append("&7Press &r").append(ModuleManager.getModuleByName("ClickGUI").getBindName()).append("&7 to open GUI")), "&7see &9https://blue.bella.wtf&7 for a full version of the faq", "commands&7 to view all available commands", "bind <module> <key>&7 to bind mods", "prefix <prefix>&r to change the command prefix.", "help &7<bind|subjects:[subject]>&r for more help." });
        }
        else {
            final String s = array[0];
            if (s.equals("subjects")) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("Subjects: ").append(HelpCommand.subjectsList)));
            }
            else if (s.equals("bind")) {
                Command.sendChatMessage("You can also use &7.bind&r modifiers on to allow modules to be bound to keybinds with modifiers, e.g &7ctrl + shift + w or ctrl + c.&r");
                Command.sendChatMessage("You can unbind modules with backspace in the GUI or by running &7.bind <module> none&r");
            }
            else {
                final Subject subject = Arrays.stream(HelpCommand.subjects).filter(HelpCommand::lambda$call$0).findFirst().orElse(null);
                if (subject == null) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("No help found for &b").append(array[0])));
                    return;
                }
                Command.sendStringChatMessage(subject.info);
            }
        }
    }
    
    private static class Subject
    {
        String[] names;
        String[] info;
        
        public Subject(final String[] names, final String[] info) {
            this.names = names;
            this.info = info;
        }
    }
}
