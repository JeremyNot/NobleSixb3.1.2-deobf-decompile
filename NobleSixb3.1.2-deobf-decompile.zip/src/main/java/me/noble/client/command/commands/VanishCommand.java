//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.command.commands;

import me.noble.client.command.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;
import me.noble.client.command.syntax.*;

public class VanishCommand extends Command
{
    private static Entity vehicle;
    Minecraft mc;
    
    public VanishCommand() {
        super("vanish", (SyntaxChunk[])null, new String[] { "entitydesync", "edesync", "entityvanish", "evanish", "ev", "van" });
        this.mc = Minecraft.getMinecraft();
        this.setDescription("Allows you to vanish using an entity");
    }
    
    public void call(final String[] array) {
        if (this.mc.player.getRidingEntity() != null && VanishCommand.vehicle == null) {
            VanishCommand.vehicle = this.mc.player.getRidingEntity();
            this.mc.player.dismountRidingEntity();
            this.mc.world.removeEntityFromWorld(VanishCommand.vehicle.getEntityId());
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Vehicle ").append(VanishCommand.vehicle.getName()).append(" removed.")));
        }
        else if (VanishCommand.vehicle != null) {
            VanishCommand.vehicle.isDead = false;
            this.mc.world.addEntityToWorld(VanishCommand.vehicle.getEntityId(), VanishCommand.vehicle);
            this.mc.player.startRiding(VanishCommand.vehicle, true);
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("Vehicle ").append(VanishCommand.vehicle.getName()).append(" created.")));
            VanishCommand.vehicle = null;
        }
        else {
            Command.sendChatMessage("No Vehicle.");
        }
    }
}
