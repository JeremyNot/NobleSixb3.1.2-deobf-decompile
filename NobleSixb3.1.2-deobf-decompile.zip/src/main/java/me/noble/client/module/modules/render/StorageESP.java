//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import me.noble.client.event.events.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import java.util.*;
import me.noble.client.util.*;
import net.minecraft.item.*;

@Module.Info(name = "StorageESP", description = "Draws nice little lines around storage items", category = Module.Category.RENDER)
public class StorageESP extends Module
{
    private Setting<Boolean> dispenser;
    private Setting<Boolean> frame;
    private Setting<Boolean> chest;
    private Setting<Boolean> cart;
    private Setting<Boolean> furnace;
    private Setting<Boolean> shulker;
    private Setting<Boolean> hopper;
    private Setting<Boolean> echest;
    
    public StorageESP() {
        this.chest = (Setting<Boolean>)this.register((Setting)Settings.b("Chest", true));
        this.dispenser = (Setting<Boolean>)this.register((Setting)Settings.b("Dispenser", true));
        this.shulker = (Setting<Boolean>)this.register((Setting)Settings.b("Shulker", true));
        this.echest = (Setting<Boolean>)this.register((Setting)Settings.b("Ender Chest", true));
        this.furnace = (Setting<Boolean>)this.register((Setting)Settings.b("Furnace", true));
        this.hopper = (Setting<Boolean>)this.register((Setting)Settings.b("Hopper", true));
        this.cart = (Setting<Boolean>)this.register((Setting)Settings.b("Minecart", true));
        this.frame = (Setting<Boolean>)this.register((Setting)Settings.b("Item Frame", true));
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        final ArrayList<Triplet<BlockPos, Integer, Integer>> list = new ArrayList<Triplet<BlockPos, Integer, Integer>>();
        GlStateManager.pushMatrix();
        for (final TileEntity tileEntity : Wrapper.getWorld().loadedTileEntityList) {
            final BlockPos getPos = tileEntity.getPos();
            final int tileEntityColor = this.getTileEntityColor(tileEntity);
            int n = 63;
            if (tileEntity instanceof TileEntityChest) {
                final TileEntityChest tileEntityChest = (TileEntityChest)tileEntity;
                if (tileEntityChest.adjacentChestZNeg != null) {
                    n = ~(n & 0x4);
                }
                if (tileEntityChest.adjacentChestXPos != null) {
                    n = ~(n & 0x20);
                }
                if (tileEntityChest.adjacentChestZPos != null) {
                    n = ~(n & 0x8);
                }
                if (tileEntityChest.adjacentChestXNeg != null) {
                    n = ~(n & 0x10);
                }
            }
            if (((tileEntity instanceof TileEntityChest && this.chest.getValue()) || (tileEntity instanceof TileEntityDispenser && this.dispenser.getValue()) || (tileEntity instanceof TileEntityShulkerBox && this.shulker.getValue()) || (tileEntity instanceof TileEntityEnderChest && this.echest.getValue()) || (tileEntity instanceof TileEntityFurnace && this.furnace.getValue()) || (tileEntity instanceof TileEntityHopper && this.hopper.getValue())) && tileEntityColor != -1) {
                list.add(new Triplet<BlockPos, Integer, Integer>(getPos, tileEntityColor, n));
            }
        }
        for (final Entity entity : Wrapper.getWorld().loadedEntityList) {
            final BlockPos getPosition = entity.getPosition();
            final int entityColor = this.getEntityColor(entity);
            if (((entity instanceof EntityItemFrame && this.frame.getValue()) || (entity instanceof EntityMinecartChest && this.cart.getValue())) && entityColor != -1) {
                list.add(new Triplet<BlockPos, Integer, Integer>((entity instanceof EntityItemFrame) ? getPosition.add(0, -1, 0) : getPosition, entityColor, 63));
            }
        }
        KamiTessellator.prepare(7);
        for (final Triplet<BlockPos, Integer, Integer> triplet : list) {
            KamiTessellator.drawBox(triplet.getFirst(), this.changeAlpha(triplet.getSecond(), 100), triplet.getThird());
        }
        KamiTessellator.release();
        GlStateManager.popMatrix();
        GlStateManager.enableTexture2D();
    }
    
    private int getTileEntityColor(final TileEntity tileEntity) {
        if (tileEntity instanceof TileEntityChest || tileEntity instanceof TileEntityDispenser) {
            return ColourUtils.Colors.ORANGE;
        }
        if (tileEntity instanceof TileEntityShulkerBox) {
            return ColourUtils.Colors.RED;
        }
        if (tileEntity instanceof TileEntityEnderChest) {
            return ColourUtils.Colors.PURPLE;
        }
        if (tileEntity instanceof TileEntityFurnace) {
            return ColourUtils.Colors.GRAY;
        }
        if (tileEntity instanceof TileEntityHopper) {
            return ColourUtils.Colors.DARK_RED;
        }
        return -1;
    }
    
    private int getEntityColor(final Entity entity) {
        if (entity instanceof EntityMinecartChest) {
            return ColourUtils.Colors.ORANGE;
        }
        if (entity instanceof EntityItemFrame && ((EntityItemFrame)entity).getDisplayedItem().getItem() instanceof ItemShulkerBox) {
            return ColourUtils.Colors.YELLOW;
        }
        if (entity instanceof EntityItemFrame && !(((EntityItemFrame)entity).getDisplayedItem().getItem() instanceof ItemShulkerBox)) {
            return ColourUtils.Colors.ORANGE;
        }
        return -1;
    }
    
    int changeAlpha(int n, final int n2) {
        n &= 0xFFFFFF;
        return n2 << 24 | n;
    }
    
    public class Triplet<T, U, V>
    {
        private final T first;
        private final U second;
        final StorageESP this$0;
        private final V third;
        
        public U getSecond() {
            return this.second;
        }
        
        public V getThird() {
            return this.third;
        }
        
        public Triplet(final StorageESP this$0, final T first, final U second, final V third) {
            this.this$0 = this$0;
            this.first = first;
            this.second = second;
            this.third = third;
        }
        
        public T getFirst() {
            return this.first;
        }
    }
}
