//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import java.util.function.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import org.lwjgl.opengl.*;
import me.noble.client.util.*;
import net.minecraft.util.math.*;
import me.noble.client.setting.*;
import net.minecraft.entity.player.*;

@Module.Info(name = "EyeFinder", description = "Draw lines from entity's heads to where they are looking", category = Module.Category.RENDER)
public class EyeFinder extends Module
{
    private Setting<Boolean> animals;
    private Setting<Boolean> mobs;
    private Setting<Boolean> players;
    
    private static boolean lambda$onWorldRender$0(final Entity entity) {
        return EyeFinder.mc.player != entity;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        EyeFinder.mc.world.loadedEntityList.stream().filter(EntityUtil::isLiving).filter(EyeFinder::lambda$onWorldRender$0).map(EyeFinder::lambda$onWorldRender$1).filter(EyeFinder::lambda$onWorldRender$2).filter(this::lambda$onWorldRender$3).forEach(this::drawLine);
    }
    
    private void drawLine(final EntityLivingBase entityLivingBase) {
        final RayTraceResult rayTrace = entityLivingBase.rayTrace(6.0, Minecraft.getMinecraft().getRenderPartialTicks());
        if (rayTrace == null) {
            return;
        }
        final Vec3d getPositionEyes = entityLivingBase.getPositionEyes(Minecraft.getMinecraft().getRenderPartialTicks());
        GlStateManager.enableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        final double n = getPositionEyes.xCoord - EyeFinder.mc.getRenderManager().renderPosX;
        final double n2 = getPositionEyes.yCoord - EyeFinder.mc.getRenderManager().renderPosY;
        final double n3 = getPositionEyes.zCoord - EyeFinder.mc.getRenderManager().renderPosZ;
        final double n4 = rayTrace.hitVec.xCoord - EyeFinder.mc.getRenderManager().renderPosX;
        final double n5 = rayTrace.hitVec.yCoord - EyeFinder.mc.getRenderManager().renderPosY;
        final double n6 = rayTrace.hitVec.zCoord - EyeFinder.mc.getRenderManager().renderPosZ;
        GL11.glColor4f(0.2f, 0.1f, 0.3f, 0.8f);
        GlStateManager.glLineWidth(1.5f);
        GL11.glBegin(1);
        GL11.glVertex3d(n, n2, n3);
        GL11.glVertex3d(n4, n5, n6);
        GL11.glVertex3d(n4, n5, n6);
        GL11.glVertex3d(n4, n5, n6);
        GL11.glEnd();
        if (rayTrace.typeOfHit == RayTraceResult.Type.BLOCK) {
            KamiTessellator.prepare(7);
            GL11.glEnable(2929);
            final BlockPos getBlockPos = rayTrace.getBlockPos();
            KamiTessellator.drawBox(KamiTessellator.getBufferBuilder(), getBlockPos.x - 0.01f, getBlockPos.y - 0.01f, getBlockPos.z - 0.01f, 1.01f, 1.01f, 1.01f, 51, 25, 73, 200, 63);
            KamiTessellator.release();
        }
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
    }
    
    public EyeFinder() {
        this.players = (Setting<Boolean>)this.register((Setting)Settings.b("Players", true));
        this.mobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
        this.animals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
    }
    
    private boolean lambda$onWorldRender$3(final EntityLivingBase entityLivingBase) {
        return (this.players.getValue() && entityLivingBase instanceof EntityPlayer) || (EntityUtil.isPassive((Entity)entityLivingBase) ? this.animals.getValue() : this.mobs.getValue());
    }
    
    private static EntityLivingBase lambda$onWorldRender$1(final Entity entity) {
        return (EntityLivingBase)entity;
    }
    
    private static boolean lambda$onWorldRender$2(final EntityLivingBase entityLivingBase) {
        return !entityLivingBase.isDead;
    }
}
