//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import net.minecraft.network.*;
import net.minecraft.util.math.*;
import me.noble.client.util.*;
import net.minecraft.client.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import me.noble.client.setting.*;

@Module.Info(name = "Auto32kBypass", category = Module.Category.COMBAT)
public class Auto32kBypass extends Module
{
    int placeTick;
    int hopperIndex;
    int obiIndex;
    private Setting<Integer> delay;
    BlockPos hopperPos;
    BlockPos origin;
    int dispenserIndex;
    EnumFacing horizontalFace;
    int redstoneIndex;
    int shulkerIndex;
    
    public void changeItem(final int currentItem) {
        Auto32kBypass.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(currentItem));
        Auto32kBypass.mc.player.inventory.currentItem = currentItem;
    }
    
    public boolean isAir(final BlockPos blockPos) {
        return this.getBlock(blockPos) instanceof BlockAir;
    }
    
    public void faceBlock(final BlockPos blockPos, final EnumFacing enumFacing) {
        BlockInteractionHelper.faceVectorPacketInstant(new Vec3d((Vec3i)blockPos.offset(enumFacing)).addVector(0.5, 0.5, 0.5).add(new Vec3d(enumFacing.getDirectionVec()).scale(0.5)));
    }
    
    public boolean checkNulls() {
        return this.hopperIndex != -1 && this.shulkerIndex != -1 && this.redstoneIndex != -1 && this.dispenserIndex != -1 && this.obiIndex != -1 && this.origin != null && this.horizontalFace != null && this.hopperPos != null;
    }
    
    public void onEnable() {
        if (Auto32kBypass.mc == null && Auto32kBypass.mc.player == null) {
            return;
        }
        final int hopperIndex = -1;
        this.obiIndex = hopperIndex;
        this.dispenserIndex = hopperIndex;
        this.redstoneIndex = hopperIndex;
        this.shulkerIndex = hopperIndex;
        this.hopperIndex = hopperIndex;
        this.placeTick = 1;
        if (Auto32kBypass.mc != null && Auto32kBypass.mc.player != null && Auto32kBypass.mc.objectMouseOver != null) {
            this.origin = new BlockPos((double)Auto32kBypass.mc.objectMouseOver.getBlockPos().getX(), (double)Auto32kBypass.mc.objectMouseOver.getBlockPos().getY(), (double)Auto32kBypass.mc.objectMouseOver.getBlockPos().getZ());
            this.horizontalFace = Auto32kBypass.mc.player.getHorizontalFacing();
            this.hopperPos = this.origin.offset(this.horizontalFace.getOpposite()).up();
        }
        else {
            this.toggle();
        }
    }
    
    public void onUpdate() {
        if (Auto32kBypass.mc == null && Auto32kBypass.mc.player == null) {
            return;
        }
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemStack = (ItemStack)Minecraft.getMinecraft().player.inventory.mainInventory.get(i);
            if (itemStack.getItem().equals(Item.getItemFromBlock((Block)Blocks.HOPPER))) {
                this.hopperIndex = i;
            }
            if (itemStack.getItem().equals(Item.getItemFromBlock(Blocks.OBSIDIAN))) {
                this.obiIndex = i;
            }
            if (itemStack.getItem() instanceof ItemShulkerBox) {
                this.shulkerIndex = i;
            }
            if (itemStack.getItem().equals(Item.getItemFromBlock(Blocks.REDSTONE_BLOCK))) {
                this.redstoneIndex = i;
            }
            if (itemStack.getItem().equals(Item.getItemFromBlock(Blocks.DISPENSER))) {
                this.dispenserIndex = i;
            }
        }
        ++this.placeTick;
        if (this.checkNulls()) {
            if (this.placeTick == 3) {
                final Vec3d vec3d = new Vec3d((double)this.origin.getX(), (double)this.origin.getY(), (double)this.origin.getZ());
                this.changeItem(this.obiIndex);
                this.placeBlock(this.origin, EnumFacing.UP, vec3d);
                this.changeItem(this.dispenserIndex);
                this.placeBlock(this.origin.up(), EnumFacing.UP, vec3d);
                this.changeItem(this.hopperIndex);
                final BlockPos up = this.origin.up();
                this.placeBlock(up, this.horizontalFace.getOpposite(), new Vec3d((double)up.getX(), (double)up.getY(), (double)up.getZ()));
                final BlockPos up2 = this.origin.up().up();
                this.faceBlock(up2, EnumFacing.DOWN);
                Auto32kBypass.mc.playerController.processRightClickBlock(Auto32kBypass.mc.player, Auto32kBypass.mc.world, up2, EnumFacing.UP, new Vec3d((double)up2.getX(), (double)up2.getY(), (double)up2.getZ()), EnumHand.MAIN_HAND);
                Auto32kBypass.mc.player.swingArm(EnumHand.MAIN_HAND);
                this.changeItem(this.shulkerIndex);
                this.placeTick = 4;
            }
            if (this.placeTick == this.delay.getValue() + 4) {
                Auto32kBypass.mc.playerController.windowClick(Auto32kBypass.mc.player.openContainer.windowId, 1, Auto32kBypass.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)Auto32kBypass.mc.player);
                Auto32kBypass.mc.player.closeScreen();
                this.placeTick = this.delay.getValue() + 4;
            }
            if (this.placeTick == this.delay.getValue() + 10) {
                Auto32kBypass.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Minecraft.getMinecraft().player, CPacketEntityAction.Action.START_SNEAKING));
                EnumFacing enumFacing = null;
                EnumFacing enumFacing2 = null;
                if (this.horizontalFace == EnumFacing.NORTH) {
                    enumFacing = EnumFacing.WEST;
                    enumFacing2 = EnumFacing.EAST;
                }
                else if (this.horizontalFace == EnumFacing.EAST) {
                    enumFacing = EnumFacing.NORTH;
                    enumFacing2 = EnumFacing.SOUTH;
                }
                else if (this.horizontalFace == EnumFacing.SOUTH) {
                    enumFacing = EnumFacing.EAST;
                    enumFacing2 = EnumFacing.WEST;
                }
                else if (this.horizontalFace == EnumFacing.WEST) {
                    enumFacing = EnumFacing.SOUTH;
                    enumFacing2 = EnumFacing.NORTH;
                }
                this.changeItem(this.redstoneIndex);
                if (enumFacing != null && enumFacing2 != null) {
                    final BlockPos up3 = this.origin.up().up();
                    if (this.isAir(up3.offset(enumFacing))) {
                        this.placeBlock(up3, enumFacing.getOpposite(), new Vec3d((double)up3.getX(), (double)up3.getY(), (double)up3.getZ()));
                    }
                    else if (this.isAir(up3.offset(enumFacing2))) {
                        this.placeBlock(up3, enumFacing2.getOpposite(), new Vec3d((double)up3.getX(), (double)up3.getY(), (double)up3.getZ()));
                    }
                }
                Auto32kBypass.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Minecraft.getMinecraft().player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.faceBlock(this.hopperPos, EnumFacing.UP);
                Auto32kBypass.mc.playerController.processRightClickBlock(Auto32kBypass.mc.player, Auto32kBypass.mc.world, this.hopperPos, EnumFacing.UP, new Vec3d((double)this.hopperPos.getX(), (double)this.hopperPos.getY(), (double)this.hopperPos.getZ()), EnumHand.MAIN_HAND);
                Auto32kBypass.mc.player.swingArm(EnumHand.MAIN_HAND);
                this.toggle();
            }
        }
        else {
            this.toggle();
        }
    }
    
    public void placeBlock(final BlockPos blockPos, final EnumFacing enumFacing, final Vec3d vec3d) {
        BlockInteractionHelper.faceVectorPacketInstant(new Vec3d((Vec3i)blockPos.offset(enumFacing)).addVector(0.5, 0.5, 0.5).add(new Vec3d(enumFacing.getDirectionVec()).scale(0.5)));
        Auto32kBypass.mc.playerController.processRightClickBlock(Minecraft.getMinecraft().player, Minecraft.getMinecraft().world, blockPos, enumFacing, vec3d, EnumHand.MAIN_HAND);
        Auto32kBypass.mc.player.swingArm(EnumHand.MAIN_HAND);
    }
    
    public Auto32kBypass() {
        this.delay = (Setting<Integer>)this.register((Setting)Settings.i("Delay", 15));
        this.placeTick = 1;
    }
    
    public Block getBlock(final BlockPos blockPos) {
        return Auto32kBypass.mc.world.getBlockState(blockPos).getBlock();
    }
}
