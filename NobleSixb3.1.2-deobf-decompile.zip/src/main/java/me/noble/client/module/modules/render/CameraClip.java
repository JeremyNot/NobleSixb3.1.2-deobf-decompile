//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;

@Module.Info(name = "CameraClip", category = Module.Category.RENDER, description = "Allows your camera to pass through blocks")
public class CameraClip extends Module
{
}
