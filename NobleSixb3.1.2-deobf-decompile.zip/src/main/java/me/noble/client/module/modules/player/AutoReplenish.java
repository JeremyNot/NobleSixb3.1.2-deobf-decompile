//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.item.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import me.noble.client.util.*;
import net.minecraft.init.*;
import java.util.*;

@Module.Info(name = "AutoReplenish", category = Module.Category.PLAYER, description = "Refills your Hotbar")
public class AutoReplenish extends Module
{
    private int delayStep;
    private Setting<Integer> threshold;
    private Setting<Integer> tickDelay;
    
    public AutoReplenish() {
        this.threshold = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Threshold").withMinimum(1).withValue(32).withMaximum(63).build());
        this.tickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TickDelay").withMinimum(1).withValue(2).withMaximum(10).build());
        this.delayStep = 0;
    }
    
    private boolean isCompatibleStacks(final ItemStack itemStack, final ItemStack itemStack2) {
        return itemStack.getItem().equals(itemStack2.getItem()) && (!(itemStack.getItem() instanceof ItemBlock) || !(itemStack2.getItem() instanceof ItemBlock) || ((ItemBlock)itemStack.getItem()).getBlock().blockMaterial.equals(((ItemBlock)itemStack2.getItem()).getBlock().blockMaterial)) && itemStack.getDisplayName().equals(itemStack2.getDisplayName()) && itemStack.getItemDamage() == itemStack2.getItemDamage();
    }
    
    public void onUpdate() {
        if (AutoReplenish.mc.player == null) {
            return;
        }
        if (AutoReplenish.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        if (this.delayStep < this.tickDelay.getValue()) {
            ++this.delayStep;
            return;
        }
        this.delayStep = 0;
        final Pair<Integer, Integer> replenishableHotbarSlot = this.findReplenishableHotbarSlot();
        if (replenishableHotbarSlot == null) {
            return;
        }
        final int intValue = replenishableHotbarSlot.getKey();
        final int intValue2 = replenishableHotbarSlot.getValue();
        AutoReplenish.mc.playerController.windowClick(0, intValue, 0, ClickType.PICKUP, (EntityPlayer)AutoReplenish.mc.player);
        AutoReplenish.mc.playerController.windowClick(0, intValue2, 0, ClickType.PICKUP, (EntityPlayer)AutoReplenish.mc.player);
        AutoReplenish.mc.playerController.windowClick(0, intValue, 0, ClickType.PICKUP, (EntityPlayer)AutoReplenish.mc.player);
    }
    
    private int findCompatibleInventorySlot(final ItemStack itemStack) {
        int intValue = -1;
        int n = 999;
        for (final Map.Entry<Integer, ItemStack> entry : getInventory().entrySet()) {
            final ItemStack itemStack2 = entry.getValue();
            if (!itemStack2.field_190928_g) {
                if (itemStack2.getItem() == Items.field_190931_a) {
                    continue;
                }
                if (!this.isCompatibleStacks(itemStack, itemStack2)) {
                    continue;
                }
                final int stackSize = ((ItemStack)AutoReplenish.mc.player.inventoryContainer.getInventory().get((int)entry.getKey())).stackSize;
                if (n <= stackSize) {
                    continue;
                }
                n = stackSize;
                intValue = entry.getKey();
            }
        }
        return intValue;
    }
    
    private static Map<Integer, ItemStack> getInventory() {
        return getInventorySlots(9, 35);
    }
    
    private static Map<Integer, ItemStack> getHotbar() {
        return getInventorySlots(36, 44);
    }
    
    private static Map<Integer, ItemStack> getInventorySlots(int i, final int n) {
        final HashMap<Integer, Object> hashMap = (HashMap<Integer, Object>)new HashMap<Integer, ItemStack>();
        while (i <= n) {
            hashMap.put(i, AutoReplenish.mc.player.inventoryContainer.getInventory().get(i));
            ++i;
        }
        return (Map<Integer, ItemStack>)hashMap;
    }
    
    private Pair<Integer, Integer> findReplenishableHotbarSlot() {
        Pair<Integer, Integer> pair = null;
        for (final Map.Entry<Integer, ItemStack> entry : getHotbar().entrySet()) {
            final ItemStack itemStack = entry.getValue();
            if (!itemStack.field_190928_g) {
                if (itemStack.getItem() == Items.field_190931_a) {
                    continue;
                }
                if (!itemStack.isStackable()) {
                    continue;
                }
                if (itemStack.stackSize >= itemStack.getMaxStackSize()) {
                    continue;
                }
                if (itemStack.stackSize > this.threshold.getValue()) {
                    continue;
                }
                final int compatibleInventorySlot = this.findCompatibleInventorySlot(itemStack);
                if (compatibleInventorySlot == -1) {
                    continue;
                }
                pair = new Pair<Integer, Integer>(compatibleInventorySlot, entry.getKey());
            }
        }
        return pair;
    }
}
