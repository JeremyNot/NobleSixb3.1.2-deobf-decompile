//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.client.*;
import me.noble.client.command.*;

@Module.Info(name = "ShulkerBypass", category = Module.Category.RENDER, description = "Bypasses the shulker preview patch")
public class ShulkerBypass extends Module
{
    public void onEnable() {
        if (Minecraft.getMinecraft().player == null) {
            return;
        }
        Command.sendChatMessage("[ShulkerBypass] To use this throw a shulker on the ground");
    }
}
