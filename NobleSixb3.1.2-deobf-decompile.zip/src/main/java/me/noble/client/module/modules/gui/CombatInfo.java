//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import net.minecraft.item.*;
import me.noble.client.gui.kami.*;
import net.minecraft.util.*;
import me.noble.client.util.*;
import net.minecraft.init.*;
import me.noble.client.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.util.*;
import me.noble.client.gui.rgui.component.container.*;
import java.util.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import me.noble.client.setting.*;

@Module.Info(name = "CombatInfo", category = Module.Category.GUI, description = "You are a spartan now", showOnArray = Module.ShowOnArray.OFF)
public class CombatInfo extends Module
{
    ItemStack itemStack4;
    int XPCount;
    ItemStack itemStack;
    ItemStack itemStack2;
    ItemStack itemStack3;
    int Apple;
    int totemCount;
    int i;
    int l;
    int j;
    int crystalCount;
    int k;
    private Setting<ViewMode> viewMode;
    KamiGUI kamiGUI;
    
    private void crystalRenderc(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getcrystalc());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 19, 27, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation gettotema() {
        if (this.GetTotems() % 10 == 0) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetTotems() % 10 == 1) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetTotems() % 10 == 2) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetTotems() % 10 == 3) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetTotems() % 10 == 4) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetTotems() % 10 == 5) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetTotems() % 10 == 6) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetTotems() % 10 == 7) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetTotems() % 10 == 8) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetTotems() % 10 == 9) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private int GetTotems() {
        this.totemCount = 0;
        this.i = 0;
        while (this.i < 45) {
            this.itemStack = Wrapper.getMinecraft().player.inventory.getStackInSlot(this.i);
            if (this.itemStack.getItem() == Items.field_190929_cY) {
                this.totemCount += this.itemStack.stackSize;
            }
            ++this.i;
        }
        return this.totemCount;
    }
    
    private ResourceLocation getepearlc() {
        if (this.GetEpearls() % 1000 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetEpearls() % 1000 >= 100 && this.GetEpearls() % 1000 < 200) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetEpearls() % 1000 >= 200 && this.GetEpearls() % 1000 < 300) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetEpearls() % 1000 >= 300 && this.GetEpearls() % 1000 < 400) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetEpearls() % 1000 >= 400 && this.GetEpearls() % 1000 < 500) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetEpearls() % 1000 >= 500 && this.GetEpearls() % 1000 < 600) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetEpearls() % 1000 >= 600 && this.GetEpearls() % 1000 < 700) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetEpearls() % 1000 >= 700 && this.GetEpearls() % 1000 < 800) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetEpearls() % 1000 >= 800 && this.GetEpearls() % 1000 < 900) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetEpearls() % 1000 >= 900 && this.GetEpearls() % 1000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    public void onDisable() {
        this.enable();
    }
    
    private void gappleRenderd(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getgappled());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 25, 37, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation getgapplec() {
        if (this.GetApples() % 1000 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetApples() % 1000 >= 100 && this.GetApples() % 1000 < 200) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetApples() % 1000 >= 200 && this.GetApples() % 1000 < 300) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetApples() % 1000 >= 300 && this.GetApples() % 1000 < 400) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetApples() % 1000 >= 400 && this.GetApples() % 1000 < 500) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetApples() % 1000 >= 500 && this.GetApples() % 1000 < 600) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetApples() % 1000 >= 600 && this.GetApples() % 1000 < 700) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetApples() % 1000 >= 700 && this.GetApples() % 1000 < 800) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetApples() % 1000 >= 800 && this.GetApples() % 1000 < 900) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetApples() % 1000 >= 900 && this.GetApples() % 1000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private void totemRenderb(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.gettotemb());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 13, 47, 255, 100);
        postBoxRender();
    }
    
    private void gappleRenderc(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getgapplec());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 19, 37, 255, 100);
        postBoxRender();
    }
    
    private int invPos(final int n) {
        this.kamiGUI = NobleMod.getInstance().getGuiManager();
        if (this.kamiGUI != null) {
            for (final Frame frame : ContainerHelper.getAllChildren((Class)Frame.class, (Container)this.kamiGUI)) {
                if (!frame.getTitle().equalsIgnoreCase("Combat Info")) {
                    continue;
                }
                switch (n) {
                    case 0: {
                        return frame.getX();
                    }
                    case 1: {
                        return frame.getY();
                    }
                    case 3: {
                        if (frame.isPinned()) {
                            return 1;
                        }
                        return 0;
                    }
                    default: {
                        return 0;
                    }
                }
            }
        }
        return 0;
    }
    
    private void gappleRenderb(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getgappleb());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 13, 37, 255, 100);
        postBoxRender();
    }
    
    private void epearlRenderb(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getepearlb());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 13, 17, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation getgappleb() {
        if (this.GetApples() % 100 < 10) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetApples() % 100 >= 10 && this.GetApples() % 100 < 20) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetApples() % 100 >= 20 && this.GetApples() % 100 < 30) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetApples() % 100 >= 30 && this.GetApples() % 100 < 40) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetApples() % 100 >= 40 && this.GetApples() % 100 < 50) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetApples() % 100 >= 50 && this.GetApples() % 100 < 60) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetApples() % 100 >= 60 && this.GetApples() % 100 < 70) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetApples() % 100 >= 70 && this.GetApples() % 100 < 80) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetApples() % 100 >= 80 && this.GetApples() % 100 < 90) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetApples() % 100 >= 90 && this.GetApples() % 100 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private ResourceLocation getgappled() {
        if (this.GetApples() % 10000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetApples() % 10000 >= 1000 && this.GetApples() % 10000 < 2000) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetApples() % 10000 >= 2000 && this.GetApples() % 10000 < 3000) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetApples() % 10000 >= 3000 && this.GetApples() % 10000 < 4000) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetApples() % 10000 >= 4000 && this.GetApples() % 10000 < 5000) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetApples() % 10000 >= 5000 && this.GetApples() % 10000 < 6000) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetApples() % 10000 >= 6000 && this.GetApples() % 10000 < 7000) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetApples() % 10000 >= 7000 && this.GetApples() % 10000 < 8000) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetApples() % 10000 >= 8000 && this.GetApples() % 10000 < 9000) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetApples() % 10000 >= 9000 && this.GetApples() % 10000 < 10000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private void crystalRenderb(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getcrystalb());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 13, 27, 255, 100);
        postBoxRender();
    }
    
    private void totemRendera(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.gettotema());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 47, 255, 100);
        postBoxRender();
    }
    
    private static void preBoxRender() {
        GL11.glPushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
    }
    
    private ResourceLocation getcrystala() {
        if (this.GetCrystals() % 10 == 0) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetCrystals() % 10 == 1) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetCrystals() % 10 == 2) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetCrystals() % 10 == 3) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetCrystals() % 10 == 4) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetCrystals() % 10 == 5) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetCrystals() % 10 == 6) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetCrystals() % 10 == 7) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetCrystals() % 10 == 8) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetCrystals() % 10 == 9) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private ResourceLocation getcrystalb() {
        if (this.GetCrystals() % 100 < 10) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetCrystals() % 100 >= 10 && this.GetCrystals() % 100 < 20) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetCrystals() % 100 >= 20 && this.GetCrystals() % 100 < 30) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetCrystals() % 100 >= 30 && this.GetCrystals() % 100 < 40) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetCrystals() % 100 >= 40 && this.GetCrystals() % 100 < 50) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetCrystals() % 100 >= 50 && this.GetCrystals() % 100 < 60) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetCrystals() % 100 >= 60 && this.GetCrystals() % 100 < 70) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetCrystals() % 100 >= 70 && this.GetCrystals() % 100 < 80) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetCrystals() % 100 >= 80 && this.GetCrystals() % 100 < 90) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetCrystals() % 100 >= 90 && this.GetCrystals() % 100 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private int GetEpearls() {
        this.XPCount = 0;
        this.k = 0;
        while (this.k < 45) {
            this.itemStack3 = Wrapper.getMinecraft().player.inventory.getStackInSlot(this.k);
            if (this.itemStack3.getItem() == Items.EXPERIENCE_BOTTLE) {
                this.XPCount += this.itemStack3.stackSize;
            }
            ++this.k;
        }
        return this.XPCount;
    }
    
    private static void postBoxRender() {
        GlStateManager.disableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }
    
    private void epearlRenderd(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getepearld());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 25, 17, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation getepearlb() {
        if (this.GetEpearls() % 100 < 10) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetEpearls() % 100 >= 10 && this.GetEpearls() % 100 < 20) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetEpearls() % 100 >= 20 && this.GetEpearls() % 100 < 30) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetEpearls() % 100 >= 30 && this.GetEpearls() % 100 < 40) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetEpearls() % 100 >= 40 && this.GetEpearls() % 100 < 50) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetEpearls() % 100 >= 50 && this.GetEpearls() % 100 < 60) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetEpearls() % 100 >= 60 && this.GetEpearls() % 100 < 70) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetEpearls() % 100 >= 70 && this.GetEpearls() % 100 < 80) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetEpearls() % 100 >= 80 && this.GetEpearls() % 100 < 90) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetEpearls() % 100 >= 90 && this.GetEpearls() % 100 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private ResourceLocation getepearld() {
        if (this.GetEpearls() % 10000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetEpearls() % 10000 >= 1000 && this.GetEpearls() % 10000 < 2000) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetEpearls() % 10000 >= 2000 && this.GetEpearls() % 10000 < 3000) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetEpearls() % 10000 >= 3000 && this.GetEpearls() % 10000 < 4000) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetEpearls() % 10000 >= 4000 && this.GetEpearls() % 10000 < 5000) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetEpearls() % 10000 >= 5000 && this.GetEpearls() % 10000 < 6000) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetEpearls() % 10000 >= 6000 && this.GetEpearls() % 10000 < 7000) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetEpearls() % 10000 >= 7000 && this.GetEpearls() % 10000 < 8000) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetEpearls() % 10000 >= 8000 && this.GetEpearls() % 10000 < 9000) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetEpearls() % 10000 >= 9000 && this.GetEpearls() % 10000 < 10000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private void totemRenderd(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.gettotemd());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 25, 47, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation getBox() {
        return new ResourceLocation("textures/gui/combatinfo/base.png");
    }
    
    public CombatInfo() {
        this.viewMode = (Setting<ViewMode>)this.register((Setting)Settings.e("Appearance", ViewMode.NOBLE));
        this.totemCount = 0;
        this.XPCount = 0;
        this.crystalCount = 0;
        this.Apple = 0;
        this.kamiGUI = NobleMod.getInstance().getGuiManager();
    }
    
    private void boxRender(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getBox());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 255, 100);
        postBoxRender();
    }
    
    private int GetCrystals() {
        this.crystalCount = 0;
        this.j = 0;
        while (this.j < 45) {
            this.itemStack2 = Wrapper.getMinecraft().player.inventory.getStackInSlot(this.j);
            if (this.itemStack2.getItem() == Items.END_CRYSTAL) {
                this.crystalCount += this.itemStack2.stackSize;
            }
            ++this.j;
        }
        return this.crystalCount;
    }
    
    private void totemRenderc(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.gettotemc());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 19, 47, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation getgapplea() {
        if (this.GetApples() % 10 == 0) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetApples() % 10 == 1) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetApples() % 10 == 2) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetApples() % 10 == 3) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetApples() % 10 == 4) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetApples() % 10 == 5) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetApples() % 10 == 6) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetApples() % 10 == 7) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetApples() % 10 == 8) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetApples() % 10 == 9) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private int GetApples() {
        this.Apple = 0;
        this.l = 0;
        while (this.l < 45) {
            this.itemStack4 = Wrapper.getMinecraft().player.inventory.getStackInSlot(this.l);
            if (this.itemStack4.getItem() == Items.GOLDEN_APPLE) {
                this.Apple += this.itemStack4.stackSize;
            }
            ++this.l;
        }
        return this.Apple;
    }
    
    private void epearlRendera(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getepearla());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation gettotemd() {
        if (this.GetTotems() % 10000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetTotems() % 10000 >= 1000 && this.GetTotems() % 10000 < 2000) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetTotems() % 10000 >= 2000 && this.GetTotems() % 10000 < 3000) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetTotems() % 10000 >= 3000 && this.GetTotems() % 10000 < 4000) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetTotems() % 10000 >= 4000 && this.GetTotems() % 10000 < 5000) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetTotems() % 10000 >= 5000 && this.GetTotems() % 10000 < 6000) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetTotems() % 10000 >= 6000 && this.GetTotems() % 10000 < 7000) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetTotems() % 10000 >= 7000 && this.GetTotems() % 10000 < 8000) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetTotems() % 10000 >= 8000 && this.GetTotems() % 10000 < 9000) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetTotems() % 10000 >= 9000 && this.GetTotems() % 10000 < 10000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private void crystalRenderd(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getcrystald());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 25, 27, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation gettotemc() {
        if (this.GetTotems() % 1000 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetTotems() % 1000 >= 100 && this.GetTotems() % 1000 < 200) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetTotems() % 1000 >= 200 && this.GetTotems() % 1000 < 300) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetTotems() % 1000 >= 300 && this.GetTotems() % 1000 < 400) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetTotems() % 1000 >= 400 && this.GetTotems() % 1000 < 500) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetTotems() % 1000 >= 500 && this.GetTotems() % 1000 < 600) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetTotems() % 1000 >= 600 && this.GetTotems() % 1000 < 700) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetTotems() % 1000 >= 700 && this.GetTotems() % 1000 < 800) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetTotems() % 1000 >= 800 && this.GetTotems() % 1000 < 900) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetTotems() % 1000 >= 900 && this.GetTotems() % 1000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private void crystalRendera(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getcrystala());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 27, 255, 100);
        postBoxRender();
    }
    
    private void epearlRenderc(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getepearlc());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 19, 17, 255, 100);
        postBoxRender();
    }
    
    private void gappleRendera(final int n, final int n2) {
        preBoxRender();
        CombatInfo.mc.renderEngine.bindTexture(this.getgapplea());
        CombatInfo.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 37, 255, 100);
        postBoxRender();
    }
    
    private ResourceLocation getcrystald() {
        if (this.GetCrystals() % 10000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetCrystals() % 10000 >= 1000 && this.GetCrystals() % 10000 < 2000) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetCrystals() % 10000 >= 2000 && this.GetCrystals() % 10000 < 3000) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetCrystals() % 10000 >= 3000 && this.GetCrystals() % 10000 < 4000) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetCrystals() % 10000 >= 4000 && this.GetCrystals() % 10000 < 5000) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetCrystals() % 10000 >= 5000 && this.GetCrystals() % 10000 < 6000) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetCrystals() % 10000 >= 6000 && this.GetCrystals() % 10000 < 7000) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetCrystals() % 10000 >= 7000 && this.GetCrystals() % 10000 < 8000) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetCrystals() % 10000 >= 8000 && this.GetCrystals() % 10000 < 9000) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetCrystals() % 10000 >= 9000 && this.GetCrystals() % 10000 < 10000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private ResourceLocation getepearla() {
        if (this.GetEpearls() % 10 == 0) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetEpearls() % 10 == 1) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetEpearls() % 10 == 2) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetEpearls() % 10 == 3) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetEpearls() % 10 == 4) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetEpearls() % 10 == 5) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetEpearls() % 10 == 6) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetEpearls() % 10 == 7) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetEpearls() % 10 == 8) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetEpearls() % 10 == 9) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private ResourceLocation gettotemb() {
        if (this.GetTotems() % 100 < 10) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetTotems() % 100 >= 10 && this.GetTotems() % 100 < 20) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetTotems() % 100 >= 20 && this.GetTotems() % 100 < 30) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetTotems() % 100 >= 30 && this.GetTotems() % 100 < 40) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetTotems() % 100 >= 40 && this.GetTotems() % 100 < 50) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetTotems() % 100 >= 50 && this.GetTotems() % 100 < 60) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetTotems() % 100 >= 60 && this.GetTotems() % 100 < 70) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetTotems() % 100 >= 70 && this.GetTotems() % 100 < 80) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetTotems() % 100 >= 80 && this.GetTotems() % 100 < 90) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetTotems() % 100 >= 90 && this.GetTotems() % 100 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    public void onRender() {
        if (this.invPos(3) == 1) {
            this.totemRendera(this.invPos(0), this.invPos(1));
            this.totemRenderb(this.invPos(0), this.invPos(1));
            this.totemRenderc(this.invPos(0), this.invPos(1));
            this.totemRenderd(this.invPos(0), this.invPos(1));
            this.gappleRendera(this.invPos(0), this.invPos(1));
            this.gappleRenderb(this.invPos(0), this.invPos(1));
            this.gappleRenderc(this.invPos(0), this.invPos(1));
            this.gappleRenderd(this.invPos(0), this.invPos(1));
            this.epearlRendera(this.invPos(0), this.invPos(1));
            this.epearlRenderb(this.invPos(0), this.invPos(1));
            this.epearlRenderc(this.invPos(0), this.invPos(1));
            this.epearlRenderd(this.invPos(0), this.invPos(1));
            this.crystalRendera(this.invPos(0), this.invPos(1));
            this.crystalRenderb(this.invPos(0), this.invPos(1));
            this.crystalRenderc(this.invPos(0), this.invPos(1));
            this.crystalRenderd(this.invPos(0), this.invPos(1));
            this.boxRender(this.invPos(0), this.invPos(1));
        }
    }
    
    private ResourceLocation getcrystalc() {
        if (this.GetCrystals() % 1000 < 100) {
            return new ResourceLocation("textures/gui/combatinfo/0.png");
        }
        if (this.GetCrystals() % 1000 >= 100 && this.GetCrystals() % 1000 < 200) {
            return new ResourceLocation("textures/gui/combatinfo/1.png");
        }
        if (this.GetCrystals() % 1000 >= 200 && this.GetCrystals() % 1000 < 300) {
            return new ResourceLocation("textures/gui/combatinfo/2.png");
        }
        if (this.GetCrystals() % 1000 >= 300 && this.GetCrystals() % 1000 < 400) {
            return new ResourceLocation("textures/gui/combatinfo/3.png");
        }
        if (this.GetCrystals() % 1000 >= 400 && this.GetCrystals() % 1000 < 500) {
            return new ResourceLocation("textures/gui/combatinfo/4.png");
        }
        if (this.GetCrystals() % 1000 >= 500 && this.GetCrystals() % 1000 < 600) {
            return new ResourceLocation("textures/gui/combatinfo/5.png");
        }
        if (this.GetCrystals() % 1000 >= 600 && this.GetCrystals() % 1000 < 700) {
            return new ResourceLocation("textures/gui/combatinfo/6.png");
        }
        if (this.GetCrystals() % 1000 >= 700 && this.GetCrystals() % 1000 < 800) {
            return new ResourceLocation("textures/gui/combatinfo/7.png");
        }
        if (this.GetCrystals() % 1000 >= 800 && this.GetCrystals() % 1000 < 900) {
            return new ResourceLocation("textures/gui/combatinfo/8.png");
        }
        if (this.GetCrystals() % 1000 >= 900 && this.GetCrystals() % 1000 < 1000) {
            return new ResourceLocation("textures/gui/combatinfo/9.png");
        }
        return new ResourceLocation("textures/gui/combatinfo/0.png");
    }
    
    private enum ViewMode
    {
        private static final ViewMode[] $VALUES;
        
        NOBLE;
        
        static {
            $VALUES = new ViewMode[] { ViewMode.NOBLE };
        }
    }
}
