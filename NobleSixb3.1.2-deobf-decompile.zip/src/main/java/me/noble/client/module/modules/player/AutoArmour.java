//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.client.renderer.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;

@Module.Info(name = "AutoArmour", category = Module.Category.PLAYER, description = "Automatically equips armour")
public class AutoArmour extends Module
{
    public void onUpdate() {
        if (AutoArmour.mc.player.ticksExisted % 2 == 0) {
            return;
        }
        if (AutoArmour.mc.currentScreen instanceof GuiContainer && !(AutoArmour.mc.currentScreen instanceof InventoryEffectRenderer)) {
            return;
        }
        final int[] array = new int[4];
        final int[] array2 = new int[4];
        for (int i = 0; i < 4; ++i) {
            final ItemStack armorItemInSlot = AutoArmour.mc.player.inventory.armorItemInSlot(i);
            if (armorItemInSlot != null && armorItemInSlot.getItem() instanceof ItemArmor) {
                array2[i] = ((ItemArmor)armorItemInSlot.getItem()).damageReduceAmount;
            }
            array[i] = -1;
        }
        for (int j = 0; j < 36; ++j) {
            final ItemStack getStackInSlot = AutoArmour.mc.player.inventory.getStackInSlot(j);
            if (getStackInSlot.func_190916_E() <= 1) {
                if (getStackInSlot != null) {
                    if (getStackInSlot.getItem() instanceof ItemArmor) {
                        final ItemArmor itemArmor = (ItemArmor)getStackInSlot.getItem();
                        final int n = itemArmor.armorType.ordinal() - 2;
                        if (n != 2 || !AutoArmour.mc.player.inventory.armorItemInSlot(n).getItem().equals(Items.ELYTRA)) {
                            final int damageReduceAmount = itemArmor.damageReduceAmount;
                            if (damageReduceAmount > array2[n]) {
                                array[n] = j;
                                array2[n] = damageReduceAmount;
                            }
                        }
                    }
                }
            }
        }
        for (int k = 0; k < 4; ++k) {
            int n2 = array[k];
            if (n2 != -1) {
                final ItemStack armorItemInSlot2 = AutoArmour.mc.player.inventory.armorItemInSlot(k);
                if (armorItemInSlot2 == null || armorItemInSlot2 != ItemStack.field_190927_a || AutoArmour.mc.player.inventory.getFirstEmptyStack() != -1) {
                    if (n2 < 9) {
                        n2 += 36;
                    }
                    AutoArmour.mc.playerController.windowClick(0, 8 - k, 0, ClickType.QUICK_MOVE, (EntityPlayer)AutoArmour.mc.player);
                    AutoArmour.mc.playerController.windowClick(0, n2, 0, ClickType.QUICK_MOVE, (EntityPlayer)AutoArmour.mc.player);
                    break;
                }
            }
        }
    }
}
