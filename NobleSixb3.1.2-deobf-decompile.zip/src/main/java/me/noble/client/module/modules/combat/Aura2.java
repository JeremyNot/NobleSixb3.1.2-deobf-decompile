//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.misc.*;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import net.minecraft.nbt.*;
import me.noble.client.setting.*;

@Module.Info(name = "Aura2", category = Module.Category.COMBAT, description = "Hits entities around you")
public class Aura2 extends Module
{
    private Setting<Boolean> onlyUse32k;
    private Setting<Boolean> ignoreWalls;
    private Setting<Boolean> attackAnimals;
    private Setting<Boolean> attackMobs;
    private Setting<Boolean> switchTo32k;
    private Setting<Integer> waitTick;
    private int waitCounter;
    private Setting<Boolean> attackPlayers;
    private Setting<WaitMode> waitMode;
    private Setting<Double> hitRange;
    
    private float getLagComp() {
        if (this.waitMode.getValue().equals(WaitMode.DYNAMIC)) {
            return -(20.0f - LagCompensator.INSTANCE.getTickRate());
        }
        return 0.0f;
    }
    
    public void onUpdate() {
        if (Aura2.mc.player.isDead) {
            return;
        }
        final boolean b = Aura2.mc.player.getHeldItemOffhand().getItem().equals(Items.SHIELD) && Aura2.mc.player.getActiveHand() == EnumHand.OFF_HAND;
        if (Aura2.mc.player.isHandActive() && !b) {
            return;
        }
        if (this.waitMode.getValue().equals(WaitMode.DYNAMIC)) {
            if (Aura2.mc.player.getCooledAttackStrength(this.getLagComp()) < 1.0f) {
                return;
            }
            if (Aura2.mc.player.ticksExisted % 2 != 0) {
                return;
            }
        }
        if (this.waitMode.getValue().equals(WaitMode.STATIC) && this.waitTick.getValue() > 0) {
            if (this.waitCounter < this.waitTick.getValue()) {
                ++this.waitCounter;
                return;
            }
            this.waitCounter = 0;
        }
        for (final Entity entity : Minecraft.getMinecraft().world.loadedEntityList) {
            if (!EntityUtil.isLiving(entity)) {
                continue;
            }
            if (entity == Aura2.mc.player) {
                continue;
            }
            if (Aura2.mc.player.getDistanceToEntity(entity) > this.hitRange.getValue()) {
                continue;
            }
            if (((EntityLivingBase)entity).getHealth() <= 0.0f) {
                continue;
            }
            if (this.waitMode.getValue().equals(WaitMode.DYNAMIC) && ((EntityLivingBase)entity).hurtTime != 0) {
                continue;
            }
            if (!this.ignoreWalls.getValue() && !Aura2.mc.player.canEntityBeSeen(entity) && !this.canEntityFeetBeSeen(entity)) {
                continue;
            }
            if (this.attackPlayers.getValue() && entity instanceof EntityPlayer && !Friends.isFriend(entity.getName())) {
                this.attack(entity);
                return;
            }
            Label_0459: {
                if (EntityUtil.isPassive(entity)) {
                    if (this.attackAnimals.getValue()) {
                        break Label_0459;
                    }
                    continue;
                }
                else {
                    if (EntityUtil.isMobAggressive(entity) && this.attackMobs.getValue()) {
                        break Label_0459;
                    }
                    continue;
                }
                continue;
            }
            if (!this.switchTo32k.getValue() && ModuleManager.isModuleEnabled("AutoTool")) {
                AutoTool.equipBestWeapon();
            }
            this.attack(entity);
        }
    }
    
    private void attack(final Entity entity) {
        int n = 0;
        if (this.checkSharpness(Aura2.mc.player.getHeldItemMainhand())) {
            n = 1;
        }
        if (this.switchTo32k.getValue() && n == 0) {
            int currentItem = -1;
            for (int i = 0; i < 9; ++i) {
                final ItemStack getStackInSlot = Aura2.mc.player.inventory.getStackInSlot(i);
                if (getStackInSlot != ItemStack.field_190927_a) {
                    if (this.checkSharpness(getStackInSlot)) {
                        currentItem = i;
                        break;
                    }
                }
            }
            if (currentItem != -1) {
                Aura2.mc.player.inventory.currentItem = currentItem;
                n = 1;
            }
        }
        if (this.onlyUse32k.getValue() && n == 0) {
            return;
        }
        Aura2.mc.playerController.attackEntity((EntityPlayer)Aura2.mc.player, entity);
        Aura2.mc.player.swingArm(EnumHand.MAIN_HAND);
    }
    
    private boolean canEntityFeetBeSeen(final Entity entity) {
        return Aura2.mc.world.rayTraceBlocks(new Vec3d(Aura2.mc.player.posX, Aura2.mc.player.posY + Aura2.mc.player.getEyeHeight(), Aura2.mc.player.posZ), new Vec3d(entity.posX, entity.posY, entity.posZ), false, true, false) == null;
    }
    
    private boolean checkSharpness(final ItemStack itemStack) {
        if (itemStack.getTagCompound() == null) {
            return false;
        }
        final NBTTagList list = (NBTTagList)itemStack.getTagCompound().getTag("ench");
        if (list == null) {
            return false;
        }
        int i = 0;
        while (i < list.tagCount()) {
            final NBTTagCompound getCompoundTagAt = list.getCompoundTagAt(i);
            if (getCompoundTagAt.getInteger("id") == 16) {
                if (getCompoundTagAt.getInteger("lvl") >= 42) {
                    return true;
                }
                break;
            }
            else {
                ++i;
            }
        }
        return false;
    }
    
    private boolean lambda$new$0(final Integer n) {
        return this.waitMode.getValue().equals(WaitMode.STATIC);
    }
    
    public Aura2() {
        this.attackPlayers = (Setting<Boolean>)this.register((Setting)Settings.b("Players", true));
        this.attackMobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
        this.attackAnimals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
        this.hitRange = (Setting<Double>)this.register((Setting)Settings.d("Hit Range", 5.5));
        this.ignoreWalls = (Setting<Boolean>)this.register((Setting)Settings.b("Ignore Walls", true));
        this.waitMode = (Setting<WaitMode>)this.register((Setting)Settings.e("Mode", WaitMode.DYNAMIC));
        this.waitTick = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Tick Delay").withMinimum(0).withValue(3).withVisibility(this::lambda$new$0).build());
        this.switchTo32k = (Setting<Boolean>)this.register((Setting)Settings.b("32k Switch", true));
        this.onlyUse32k = (Setting<Boolean>)this.register((Setting)Settings.b("32k Only", false));
    }
    
    private enum WaitMode
    {
        STATIC, 
        DYNAMIC;
        
        private static final WaitMode[] $VALUES;
        
        static {
            $VALUES = new WaitMode[] { WaitMode.DYNAMIC, WaitMode.STATIC };
        }
    }
}
