//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import java.util.*;
import me.noble.client.module.*;
import me.noble.client.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import me.noble.client.setting.*;

@Module.Info(name = "Spammer", category = Module.Category.CHAT, description = "SPAM")
public class Spammer extends Module
{
    private static Timer timer;
    private Setting<Boolean> greentext;
    private Setting<Boolean> readfile;
    private Setting<Boolean> random;
    private Setting<Integer> delay;
    private static Random rnd;
    private static TimerTask task;
    private static final String fileName;
    private static final String defaultMessage;
    private static List<String> spamMessages;
    private Setting<Boolean> randomsuffix;
    
    public void onDisable() {
        Spammer.timer.cancel();
        Spammer.timer.purge();
        Spammer.spamMessages.clear();
    }
    
    private void readSpamFile() {
        final Iterator<String> iterator = FileHelper.readTextFileAllLines("Noble_Spammer.txt").iterator();
        Spammer.spamMessages.clear();
        while (iterator.hasNext()) {
            final String s = iterator.next();
            if (!s.replaceAll("\\s", "").isEmpty()) {
                Spammer.spamMessages.add(s);
            }
        }
        if (Spammer.spamMessages.size() == 0) {
            Spammer.spamMessages.add("NobleSix is GOD Download NobleSix Client from NobleSix.net");
        }
    }
    
    private void runCycle() {
        if (Spammer.mc.player == null) {
            return;
        }
        if (this.readfile.getValue()) {
            this.readSpamFile();
            this.readfile.setValue(false);
        }
        if (Spammer.spamMessages.size() > 0) {
            String s;
            if (this.random.getValue()) {
                final int nextInt = Spammer.rnd.nextInt(Spammer.spamMessages.size());
                s = Spammer.spamMessages.get(nextInt);
                Spammer.spamMessages.remove(nextInt);
            }
            else {
                s = Spammer.spamMessages.get(0);
                Spammer.spamMessages.remove(0);
            }
            Spammer.spamMessages.add(s);
            if (this.greentext.getValue()) {
                s = String.valueOf(new StringBuilder().append("> ").append(s));
            }
            int n = 0;
            final ArrayList<String> list = new ArrayList<String>();
            if (ModuleManager.isModuleEnabled("ChatSuffix")) {
                n += " \u23d0 Noble".length();
            }
            if (this.randomsuffix.getValue()) {
                list.add(ChatTextUtils.generateRandomHexSuffix(2));
            }
            if (list.size() > 0) {
                final StringBuilder sb = new StringBuilder();
                sb.append(" ");
                final Iterator<String> iterator = list.iterator();
                while (iterator.hasNext()) {
                    sb.append(iterator.next());
                }
                s = String.valueOf(new StringBuilder().append(ChatTextUtils.cropMaxLengthMessage(s, String.valueOf(sb).length() + n)).append(String.valueOf(sb)));
            }
            Spammer.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(s.replaceAll("��", "")));
        }
    }
    
    static void access$000(final Spammer spammer) {
        spammer.runCycle();
    }
    
    public void onEnable() {
        this.readSpamFile();
        Spammer.timer = new Timer();
        if (Spammer.mc.player == null) {
            this.disable();
            return;
        }
        Spammer.task = new TimerTask(this) {
            final Spammer this$0;
            
            @Override
            public void run() {
                Spammer.access$000(this.this$0);
            }
        };
        Spammer.timer.schedule(Spammer.task, 0L, this.delay.getValue());
    }
    
    public Spammer() {
        this.random = (Setting<Boolean>)this.register((Setting)Settings.b("Random", false));
        this.greentext = (Setting<Boolean>)this.register((Setting)Settings.b("Greentext", false));
        this.randomsuffix = (Setting<Boolean>)this.register((Setting)Settings.b("Anti Spam", true));
        this.delay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Send Delay").withRange(100, 60000).withValue(4000).build());
        this.readfile = (Setting<Boolean>)this.register((Setting)Settings.b("Load File", false));
    }
    
    static {
        defaultMessage = "NobleSix is GOD Download NobleSix Client from NobleSix.net";
        fileName = "Noble_Spammer.txt";
        Spammer.spamMessages = new ArrayList<String>();
        Spammer.rnd = new Random();
    }
}
