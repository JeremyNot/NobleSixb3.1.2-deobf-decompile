//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import com.mojang.authlib.*;
import net.minecraft.client.entity.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import java.util.*;

@Module.Info(name = "FakePlayer", category = Module.Category.MISC, description = "Spawns a fake Player")
public class FakePlayer extends Module
{
    private List<Integer> fakePlayerIdList;
    private Setting<SpawnMode> spawnMode;
    private static final String[][] fakePlayerInfo;
    
    public FakePlayer() {
        this.spawnMode = (Setting<SpawnMode>)this.register((Setting)Settings.e("Spawn Mode", SpawnMode.SINGLE));
        this.fakePlayerIdList = null;
    }
    
    private void addFakePlayer(final String s, final String s2, final int n, final int n2, final int n3) {
        final EntityOtherPlayerMP entityOtherPlayerMP = new EntityOtherPlayerMP((World)FakePlayer.mc.world, new GameProfile(UUID.fromString(s), s2));
        entityOtherPlayerMP.copyLocationAndAnglesFrom((Entity)FakePlayer.mc.player);
        entityOtherPlayerMP.posX += n2;
        entityOtherPlayerMP.posZ += n3;
        FakePlayer.mc.world.addEntityToWorld(n, (Entity)entityOtherPlayerMP);
        this.fakePlayerIdList.add(n);
    }
    
    static {
        fakePlayerInfo = new String[][] { { "66666666-6666-6666-6666-666666666600", "derp0", "-3", "0" }, { "66666666-6666-6666-6666-666666666601", "derp1", "0", "-3" }, { "66666666-6666-6666-6666-666666666602", "derp2", "3", "0" }, { "66666666-6666-6666-6666-666666666603", "derp3", "0", "3" }, { "66666666-6666-6666-6666-666666666604", "derp4", "-6", "0" }, { "66666666-6666-6666-6666-666666666605", "derp5", "0", "-6" }, { "66666666-6666-6666-6666-666666666606", "derp6", "6", "0" }, { "66666666-6666-6666-6666-666666666607", "derp7", "0", "6" }, { "66666666-6666-6666-6666-666666666608", "derp8", "-9", "0" }, { "66666666-6666-6666-6666-666666666609", "derp9", "0", "-9" }, { "66666666-6666-6666-6666-666666666610", "derp10", "9", "0" }, { "66666666-6666-6666-6666-666666666611", "derp11", "0", "9" } };
    }
    
    public void onUpdate() {
        if (this.fakePlayerIdList == null || this.fakePlayerIdList.isEmpty()) {
            this.disable();
        }
    }
    
    protected void onEnable() {
        if (FakePlayer.mc.player == null || FakePlayer.mc.world == null) {
            this.disable();
            return;
        }
        this.fakePlayerIdList = new ArrayList<Integer>();
        int n = -101;
        for (final String[] array : FakePlayer.fakePlayerInfo) {
            if (this.spawnMode.getValue().equals(SpawnMode.SINGLE)) {
                this.addFakePlayer(array[0], array[1], n, 0, 0);
                break;
            }
            this.addFakePlayer(array[0], array[1], n, Integer.parseInt(array[2]), Integer.parseInt(array[3]));
            --n;
        }
    }
    
    protected void onDisable() {
        if (FakePlayer.mc.player == null || FakePlayer.mc.world == null) {
            return;
        }
        if (this.fakePlayerIdList != null) {
            final Iterator<Integer> iterator = this.fakePlayerIdList.iterator();
            while (iterator.hasNext()) {
                FakePlayer.mc.world.removeEntityFromWorld((int)iterator.next());
            }
        }
    }
    
    private enum SpawnMode
    {
        MULTI, 
        SINGLE;
        
        private static final SpawnMode[] $VALUES;
        
        static {
            $VALUES = new SpawnMode[] { SpawnMode.SINGLE, SpawnMode.MULTI };
        }
    }
}
