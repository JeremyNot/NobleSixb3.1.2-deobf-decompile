//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import java.util.concurrent.atomic.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import me.noble.client.setting.*;
import java.util.function.*;
import me.noble.client.module.modules.combat.*;
import me.noble.client.module.*;
import java.util.*;

@Module.Info(name = "OffhandGapAsimov", category = Module.Category.NOBLE, description = "Auto Offhand Gapple")
public class OffhandGapAsimov extends Module
{
    private int numOfGaps;
    private Setting<TotemMode> totemMode;
    private int preferredGapSlot;
    private Setting<Boolean> totemOnDisable;
    
    private boolean findGaps() {
        this.numOfGaps = 0;
        final AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.set(Integer.MIN_VALUE);
        getInventoryAndHotbarSlots().forEach((BiConsumer<? super Integer, ? super ItemStack>)this::lambda$findGaps$1);
        if (OffhandGapAsimov.mc.player.getHeldItemOffhand().getItem().equals(Items.GOLDEN_APPLE)) {
            this.numOfGaps += OffhandGapAsimov.mc.player.getHeldItemOffhand().func_190916_E();
        }
        return this.numOfGaps != 0;
    }
    
    public void onUpdate() {
        if (OffhandGapAsimov.mc.player == null) {
            return;
        }
        if (OffhandGapAsimov.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        if (!this.findGaps()) {
            this.disable();
            return;
        }
        if (!OffhandGapAsimov.mc.player.getHeldItemOffhand().getItem().equals(Items.GOLDEN_APPLE)) {
            boolean b = false;
            if (OffhandGapAsimov.mc.player.getHeldItemOffhand().getItem().equals(Items.field_190931_a)) {
                b = true;
            }
            OffhandGapAsimov.mc.playerController.windowClick(0, this.preferredGapSlot, 0, ClickType.PICKUP, (EntityPlayer)OffhandGapAsimov.mc.player);
            OffhandGapAsimov.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)OffhandGapAsimov.mc.player);
            if (!b) {
                OffhandGapAsimov.mc.playerController.windowClick(0, this.preferredGapSlot, 0, ClickType.PICKUP, (EntityPlayer)OffhandGapAsimov.mc.player);
            }
            OffhandGapAsimov.mc.playerController.updateController();
        }
    }
    
    public OffhandGapAsimov() {
        this.totemOnDisable = (Setting<Boolean>)this.register((Setting)Settings.b("TotemOnDisable", true));
        this.totemMode = (Setting<TotemMode>)this.register((Setting)Settings.enumBuilder(TotemMode.class).withName("TotemMode").withValue(TotemMode.KAMI).withVisibility(this::lambda$new$0).build());
    }
    
    public void onDisable() {
        if (!this.totemOnDisable.getValue()) {
            return;
        }
        if (this.totemMode.getValue().equals(TotemMode.KAMI)) {
            final AutoTotem autoTotem = (AutoTotem)ModuleManager.getModuleByName("AutoTotem");
            autoTotem.disableSoft();
            if (autoTotem.isDisabled()) {
                autoTotem.enable();
            }
        }
        if (this.totemMode.getValue().equals(TotemMode.ASIMOV)) {
            final AutoTotemTEST autoTotemTEST = (AutoTotemTEST)ModuleManager.getModuleByName("AutoTotemTEST");
            autoTotemTEST.disableSoft();
            if (autoTotemTEST.isDisabled()) {
                autoTotemTEST.enable();
            }
        }
    }
    
    private static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        return getInventorySlots(9, 44);
    }
    
    private void lambda$findGaps$1(final AtomicInteger atomicInteger, final Integer n, final ItemStack itemStack) {
        int func_190916_E = 0;
        if (itemStack.getItem().equals(Items.GOLDEN_APPLE)) {
            func_190916_E = itemStack.func_190916_E();
            if (atomicInteger.get() < func_190916_E) {
                atomicInteger.set(func_190916_E);
                this.preferredGapSlot = n;
            }
        }
        this.numOfGaps += func_190916_E;
    }
    
    private boolean lambda$new$0(final Object o) {
        return this.totemOnDisable.getValue();
    }
    
    private static Map<Integer, ItemStack> getInventorySlots(int i, final int n) {
        final HashMap<Integer, Object> hashMap = (HashMap<Integer, Object>)new HashMap<Integer, ItemStack>();
        while (i <= n) {
            hashMap.put(i, OffhandGapAsimov.mc.player.inventoryContainer.getInventory().get(i));
            ++i;
        }
        return (Map<Integer, ItemStack>)hashMap;
    }
    
    public void onEnable() {
        if (ModuleManager.getModuleByName("AutoTotem").isEnabled()) {
            ModuleManager.getModuleByName("AutoTotem").disable();
        }
        if (ModuleManager.getModuleByName("AutoTotemTEST").isEnabled()) {
            ModuleManager.getModuleByName("AutoTotemTEST").disable();
        }
    }
    
    private enum TotemMode
    {
        ASIMOV;
        
        private static final TotemMode[] $VALUES;
        
        KAMI;
        
        static {
            $VALUES = new TotemMode[] { TotemMode.KAMI, TotemMode.ASIMOV };
        }
    }
}
