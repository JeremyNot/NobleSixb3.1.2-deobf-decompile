//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import java.util.concurrent.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.command.*;
import net.minecraft.network.play.server.*;
import java.util.stream.*;
import java.util.function.*;
import java.util.regex.*;
import net.minecraft.client.*;
import java.util.*;
import me.noble.client.setting.*;

@Module.Info(name = "AntiSpam", category = Module.Category.CHAT, description = "Removes spam and advertising from the chat", showOnArray = Module.ShowOnArray.OFF)
public class AntiSpam extends Module
{
    private Setting<Boolean> insulters;
    private Setting<Boolean> greenText;
    private Setting<Boolean> filterOwn;
    private Setting<Boolean> webLinks;
    private Setting<Boolean> discordLinks;
    private Setting<Boolean> announcers;
    private Setting<Boolean> spammers;
    private Setting<Boolean> duplicates;
    private Setting<Boolean> tradeChat;
    private Setting<Boolean> ipsAgr;
    private Setting<Boolean> ips;
    private Setting<Boolean> greeters;
    private ConcurrentHashMap<String, Long> messageHistory;
    private Setting<Integer> duplicatesTimeout;
    private Setting<Boolean> numberSuffix;
    private Setting<Boolean> showBlocked;
    @EventHandler
    public Listener<PacketEvent.Receive> listener;
    
    private boolean detectSpam(final String s) {
        if (!this.filterOwn.getValue() && this.findPatterns(FilterPatterns.access$000(), s)) {
            return false;
        }
        if (this.greenText.getValue() && this.findPatterns(FilterPatterns.access$100(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Green Text: ").append(s)));
            }
            return true;
        }
        if (this.discordLinks.getValue() && this.findPatterns(FilterPatterns.access$200(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Discord Link: ").append(s)));
            }
            return true;
        }
        if (this.webLinks.getValue() && this.findPatterns(FilterPatterns.access$300(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Web Link: ").append(s)));
            }
            return true;
        }
        if (this.ips.getValue() && this.findPatterns(FilterPatterns.access$400(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] IP Address: ").append(s)));
            }
            return true;
        }
        if (this.ipsAgr.getValue() && this.findPatterns(FilterPatterns.access$500(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] IP Aggressive: ").append(s)));
            }
            return true;
        }
        if (this.tradeChat.getValue() && this.findPatterns(FilterPatterns.access$600(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Trade Chat: ").append(s)));
            }
            return true;
        }
        if (this.numberSuffix.getValue() && this.findPatterns(FilterPatterns.access$700(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Number Suffix: ").append(s)));
            }
            return true;
        }
        if (this.announcers.getValue() && this.findPatterns(FilterPatterns.access$800(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Announcer: ").append(s)));
            }
            return true;
        }
        if (this.spammers.getValue() && this.findPatterns(FilterPatterns.access$900(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Spammers: ").append(s)));
            }
            return true;
        }
        if (this.insulters.getValue() && this.findPatterns(FilterPatterns.access$1000(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Insulter: ").append(s)));
            }
            return true;
        }
        if (this.greeters.getValue() && this.findPatterns(FilterPatterns.access$1100(), s)) {
            if (this.showBlocked.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Greeter: ").append(s)));
            }
            return true;
        }
        if (this.duplicates.getValue()) {
            if (this.messageHistory == null) {
                this.messageHistory = new ConcurrentHashMap<String, Long>();
            }
            boolean b = false;
            if (this.messageHistory.containsKey(s) && (System.currentTimeMillis() - this.messageHistory.get(s)) / 1000L < this.duplicatesTimeout.getValue()) {
                b = true;
            }
            this.messageHistory.put(s, System.currentTimeMillis());
            if (b) {
                if (this.showBlocked.getValue()) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AntiSpam] Duplicate: ").append(s)));
                }
                return true;
            }
        }
        return false;
    }
    
    private void lambda$new$2(final PacketEvent.Receive receive) {
        if (AntiSpam.mc.player == null || this.isDisabled()) {
            return;
        }
        if (!(receive.getPacket() instanceof SPacketChat)) {
            return;
        }
        final SPacketChat sPacketChat = (SPacketChat)receive.getPacket();
        this.messageHistory.entrySet().stream().filter((Predicate<? super Object>)AntiSpam::lambda$null$0).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()).forEach((Consumer<? super Object>)this::lambda$null$1);
        if (this.detectSpam(sPacketChat.getChatComponent().getUnformattedText())) {
            receive.cancel();
        }
    }
    
    private boolean findPatterns(final String[] array, final String s) {
        for (int length = array.length, i = 0; i < length; ++i) {
            if (Pattern.compile(array[i]).matcher(s).find()) {
                return true;
            }
        }
        return false;
    }
    
    static Minecraft access$1200() {
        return AntiSpam.mc;
    }
    
    public void onDisable() {
        this.messageHistory = null;
    }
    
    private static boolean lambda$null$0(final Map.Entry entry) {
        return entry.getValue() < System.currentTimeMillis() - 600000L;
    }
    
    public void onEnable() {
        this.messageHistory = new ConcurrentHashMap<String, Long>();
    }
    
    private void lambda$null$1(final Map.Entry entry) {
        final Long n = this.messageHistory.remove(entry.getKey());
    }
    
    public AntiSpam() {
        this.greenText = (Setting<Boolean>)this.register((Setting)Settings.b("Green Text", false));
        this.discordLinks = (Setting<Boolean>)this.register((Setting)Settings.b("Discord Links", true));
        this.webLinks = (Setting<Boolean>)this.register((Setting)Settings.b("Web Links", false));
        this.announcers = (Setting<Boolean>)this.register((Setting)Settings.b("Announcers", true));
        this.spammers = (Setting<Boolean>)this.register((Setting)Settings.b("Spammers", true));
        this.insulters = (Setting<Boolean>)this.register((Setting)Settings.b("Insulters", true));
        this.greeters = (Setting<Boolean>)this.register((Setting)Settings.b("Greeters", true));
        this.tradeChat = (Setting<Boolean>)this.register((Setting)Settings.b("Trade Chat", true));
        this.ips = (Setting<Boolean>)this.register((Setting)Settings.b("Server Ips", true));
        this.ipsAgr = (Setting<Boolean>)this.register((Setting)Settings.b("Ips Aggressive", false));
        this.numberSuffix = (Setting<Boolean>)this.register((Setting)Settings.b("Number Suffix", true));
        this.duplicates = (Setting<Boolean>)this.register((Setting)Settings.b("Duplicates", true));
        this.duplicatesTimeout = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Duplicates Timeout").withMinimum(1).withValue(30).withMaximum(600).build());
        this.filterOwn = (Setting<Boolean>)this.register((Setting)Settings.b("Filter Own", false));
        this.showBlocked = (Setting<Boolean>)this.register((Setting)Settings.b("Show Blocked", false));
        this.listener = new Listener<PacketEvent.Receive>(this::lambda$new$2, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    private static class FilterPatterns
    {
        private static final String[] GREETER;
        private static final String[] WEB_LINK;
        private static final String[] GREEN_TEXT;
        private static final String[] INSULTER;
        private static final String[] NUMBER_SUFFIX;
        private static final String[] OWN_MESSAGE;
        private static final String[] IP_ADDR;
        private static final String[] SPAMMER;
        private static final String[] TRADE_CHAT;
        private static final String[] DISCORD;
        private static final String[] ANNOUNCER;
        private static final String[] IP_ADDR_AGR;
        
        static String[] access$800() {
            return FilterPatterns.ANNOUNCER;
        }
        
        static String[] access$400() {
            return FilterPatterns.IP_ADDR;
        }
        
        static String[] access$600() {
            return FilterPatterns.TRADE_CHAT;
        }
        
        static String[] access$900() {
            return FilterPatterns.SPAMMER;
        }
        
        static String[] access$300() {
            return FilterPatterns.WEB_LINK;
        }
        
        static String[] access$500() {
            return FilterPatterns.IP_ADDR_AGR;
        }
        
        static String[] access$1000() {
            return FilterPatterns.INSULTER;
        }
        
        static String[] access$100() {
            return FilterPatterns.GREEN_TEXT;
        }
        
        static {
            ANNOUNCER = new String[] { "I just walked .+ feet!", "I just placed a .+!", "I just attacked .+ with a .+!", "I just dropped a .+!", "I just opened chat!", "I just opened my console!", "I just opened my GUI!", "I just went into full screen mode!", "I just paused my game!", "I just opened my inventory!", "I just looked at the player list!", "I just took a screen shot!", "I just swaped hands!", "I just ducked!", "I just changed perspectives!", "I just jumped!", "I just ate a .+!", "I just crafted .+ .+!", "I just picked up a .+!", "I just smelted .+ .+!", "I just respawned!", "I just attacked .+ with my hands", "I just broke a .+!", "I recently walked .+ blocks", "I just droped a .+ called, .+!", "I just placed a block called, .+!", "Im currently breaking a block called, .+!", "I just broke a block called, .+!", "I just opened chat!", "I just opened chat and typed a slash!", "I just paused my game!", "I just opened my inventory!", "I just looked at the player list!", "I just changed perspectives, now im in .+!", "I just crouched!", "I just jumped!", "I just attacked a entity called, .+ with a .+", "Im currently eatting a peice of food called, .+!", "Im currently using a item called, .+!", "I just toggled full screen mode!", "I just took a screen shot!", "I just swaped hands and now theres a .+ in my main hand and a .+ in my off hand!", "I just used pick block on a block called, .+!", "Ra just completed his blazing ark", "Its a new day yes it is", "I just placed .+ thanks to (http:\\/\\/)?DotGod\\.CC!", "I just flew .+ meters like a butterfly thanks to (http:\\/\\/)?DotGod\\.CC!" };
            SPAMMER = new String[] { "WWE Client's spammer", "Lol get gud", "Future client is bad", "WWE > Future", "WWE > Impact", "Default Message", "IKnowImEZ is a god", "THEREALWWEFAN231 is a god", "WWE Client made by IKnowImEZ/THEREALWWEFAN231", "WWE Client was the first public client to have Path Finder/New Chunks", "WWE Client was the first public client to have color signs", "WWE Client was the first client to have Teleport Finder", "WWE Client was the first client to have Tunneller & Tunneller Back Fill" };
            INSULTER = new String[] { ".+ Download WWE utility mod, Its free!", ".+ 4b4t is da best mintscreft serber", ".+ dont abouse", ".+ you cuck", ".+ https://www.youtube.com/channel/UCJGCNPEjvsCn0FKw3zso0TA", ".+ is my step dad", ".+ again daddy!", "dont worry .+ it happens to every one", ".+ dont buy future it's crap, compared to WWE!", "What are you, fucking gay, .+?", "Did you know? .+ hates you, .+", "You are literally 10, .+", ".+ finally lost their virginity, sadly they lost it to .+... yeah, that's unfortunate.", ".+, don't be upset, it's not like anyone cares about you, fag.", ".+, see that rubbish bin over there? Get your ass in it, or I'll get .+ to whoop your ass.", ".+, may I borrow that dirt block? that guy named .+ needs it...", "Yo, .+, btfo you virgin", "Hey .+ want to play some High School RP with me and .+?", ".+ is an Archon player. Why is he on here? Fucking factions player.", "Did you know? .+ just joined The Vortex Coalition!", ".+ has successfully conducted the cactus dupe and duped a itemhand!", ".+, are you even human? You act like my dog, holy shit.", ".+, you were never loved by your family.", "Come on .+, you hurt .+'s feelings. You meany.", "Stop trying to meme .+, you can't do that. kek", ".+, .+ is gay. Don't go near him.", "Whoa .+ didn't mean to offend you, .+.", ".+ im not pvping .+, im WWE'ing .+.", "Did you know? .+ just joined The Vortex Coalition!", ".+, are you even human? You act like my dog, holy shit." };
            GREETER = new String[] { "Bye, Bye .+", "Farwell, .+" };
            DISCORD = new String[] { "discord.gg", "discordapp.com", "discord.io", "invite.gg" };
            NUMBER_SUFFIX = new String[] { ".+\\d{3,}$" };
            GREEN_TEXT = new String[] { "^<.+> >" };
            TRADE_CHAT = new String[] { "buy", "sell" };
            WEB_LINK = new String[] { "http:\\/\\/", "https:\\/\\/", "www." };
            IP_ADDR = new String[] { "\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\:\\d{1,5}\\b", "\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}", "^(?:http(?:s)?:\\/\\/)?(?:[^\\.]+\\.)?.*\\..*\\..*$", ".*\\..*\\:\\d{1,5}$" };
            IP_ADDR_AGR = new String[] { ".*\\..*$" };
            OWN_MESSAGE = new String[] { String.valueOf(new StringBuilder().append("^<").append(AntiSpam.access$1200().player.getName()).append("> ")), "^To .+: " };
        }
        
        static String[] access$1100() {
            return FilterPatterns.GREETER;
        }
        
        static String[] access$000() {
            return FilterPatterns.OWN_MESSAGE;
        }
        
        static String[] access$700() {
            return FilterPatterns.NUMBER_SUFFIX;
        }
        
        static String[] access$200() {
            return FilterPatterns.DISCORD;
        }
    }
}
