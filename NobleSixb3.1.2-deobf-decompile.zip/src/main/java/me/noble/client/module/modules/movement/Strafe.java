//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;

@Module.Info(name = "Strafe", description = "Automatically makes the player sprint", category = Module.Category.MOVEMENT, showOnArray = Module.ShowOnArray.OFF)
public class Strafe extends Module
{
    public void onUpdate() {
        try {
            if (!Strafe.mc.player.isCollidedHorizontally && Strafe.mc.player.field_191988_bg > 0.0f) {
                Strafe.mc.player.setSprinting(true);
            }
            else {
                Strafe.mc.player.setSprinting(false);
            }
        }
        catch (Exception ex) {}
    }
}
