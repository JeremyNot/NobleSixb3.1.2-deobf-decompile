//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.zero.alpine.listener.*;
import me.noble.client.event.events.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import java.util.function.*;
import me.noble.client.event.*;
import net.minecraft.network.play.client.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import net.minecraft.entity.item.*;
import net.minecraft.block.*;

@Module.Info(name = "Jesus", description = "Allows you to walk on water", category = Module.Category.MOVEMENT)
public class Jesus extends Module
{
    private static final AxisAlignedBB WATER_WALK_AA;
    @EventHandler
    Listener<PacketEvent.Send> packetEventSendListener;
    @EventHandler
    Listener<AddCollisionBoxToListEvent> addCollisionBoxToListEventListener;
    
    private static boolean isAboveLand(final Entity entity) {
        if (entity == null) {
            return false;
        }
        final double n = entity.posY - 0.01;
        for (int i = MathHelper.floor(entity.posX); i < MathHelper.ceil(entity.posX); ++i) {
            for (int j = MathHelper.floor(entity.posZ); j < MathHelper.ceil(entity.posZ); ++j) {
                final BlockPos blockPos = new BlockPos(i, MathHelper.floor(n), j);
                if (Wrapper.getWorld().getBlockState(blockPos).getBlock().isFullBlock(Wrapper.getWorld().getBlockState(blockPos))) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static boolean isAboveBlock(final Entity entity, final BlockPos blockPos) {
        return entity.posY >= blockPos.getY();
    }
    
    static {
        WATER_WALK_AA = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.99, 1.0);
    }
    
    public Jesus() {
        this.addCollisionBoxToListEventListener = new Listener<AddCollisionBoxToListEvent>(Jesus::lambda$new$0, (Predicate<AddCollisionBoxToListEvent>[])new Predicate[0]);
        this.packetEventSendListener = new Listener<PacketEvent.Send>(Jesus::lambda$new$1, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private static void lambda$new$1(final PacketEvent.Send send) {
        if (send.getEra() == KamiEvent.Era.PRE && send.getPacket() instanceof CPacketPlayer && EntityUtil.isAboveWater((Entity)Jesus.mc.player, true) && !EntityUtil.isInWater((Entity)Jesus.mc.player) && !isAboveLand((Entity)Jesus.mc.player) && Jesus.mc.player.ticksExisted % 2 == 0) {
            final CPacketPlayer cPacketPlayer = (CPacketPlayer)send.getPacket();
            cPacketPlayer.y += 0.02;
        }
    }
    
    public void onUpdate() {
        if (!ModuleManager.isModuleEnabled("Freecam") && EntityUtil.isInWater((Entity)Jesus.mc.player) && !Jesus.mc.player.isSneaking()) {
            Jesus.mc.player.motionY = 0.1;
            if (Jesus.mc.player.getRidingEntity() != null && !(Jesus.mc.player.getRidingEntity() instanceof EntityBoat)) {
                Jesus.mc.player.getRidingEntity().motionY = 0.3;
            }
        }
    }
    
    private static void lambda$new$0(final AddCollisionBoxToListEvent addCollisionBoxToListEvent) {
        if (Jesus.mc.player != null && addCollisionBoxToListEvent.getBlock() instanceof BlockLiquid && (EntityUtil.isDrivenByPlayer(addCollisionBoxToListEvent.getEntity()) || addCollisionBoxToListEvent.getEntity() == Jesus.mc.player) && !(addCollisionBoxToListEvent.getEntity() instanceof EntityBoat) && !Jesus.mc.player.isSneaking() && Jesus.mc.player.fallDistance < 3.0f && !EntityUtil.isInWater((Entity)Jesus.mc.player) && (EntityUtil.isAboveWater((Entity)Jesus.mc.player, false) || EntityUtil.isAboveWater(Jesus.mc.player.getRidingEntity(), false)) && isAboveBlock((Entity)Jesus.mc.player, addCollisionBoxToListEvent.getPos())) {
            final AxisAlignedBB offset = Jesus.WATER_WALK_AA.offset(addCollisionBoxToListEvent.getPos());
            if (addCollisionBoxToListEvent.getEntityBox().intersectsWith(offset)) {
                addCollisionBoxToListEvent.getCollidingBoxes().add(offset);
            }
            addCollisionBoxToListEvent.cancel();
        }
    }
}
