//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import net.minecraftforge.client.event.*;
import me.zero.alpine.listener.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.pathfinding.*;
import me.noble.client.util.*;
import net.minecraft.entity.player.*;
import me.noble.client.module.modules.render.*;
import me.noble.client.module.*;

@Module.Info(name = "AutoWalk", category = Module.Category.PLAYER)
public class AutoWalk extends Module
{
    @EventHandler
    private Listener<InputUpdateEvent> inputUpdateEventListener;
    private Setting<AutoWalkMode> mode;
    
    public AutoWalk() {
        this.mode = (Setting<AutoWalkMode>)this.register((Setting)Settings.e("Mode", AutoWalkMode.FORWARD));
        this.inputUpdateEventListener = new Listener<InputUpdateEvent>(this::lambda$new$0, (Predicate<InputUpdateEvent>[])new Predicate[0]);
    }
    
    private void lookAt(final PathPoint pathPoint) {
        final double[] calculateLook = EntityUtil.calculateLookAt(pathPoint.xCoord + 0.5f, pathPoint.yCoord, pathPoint.zCoord + 0.5f, (EntityPlayer)AutoWalk.mc.player);
        AutoWalk.mc.player.rotationYaw = (float)calculateLook[0];
        AutoWalk.mc.player.rotationPitch = (float)calculateLook[1];
    }
    
    private void lambda$new$0(final InputUpdateEvent inputUpdateEvent) {
        switch (this.mode.getValue()) {
            case FORWARD: {
                inputUpdateEvent.getMovementInput().field_192832_b = 1.0f;
                break;
            }
            case BACKWARDS: {
                inputUpdateEvent.getMovementInput().field_192832_b = -1.0f;
                break;
            }
            case PATH: {
                if (Pathfind.points.isEmpty()) {
                    return;
                }
                inputUpdateEvent.getMovementInput().field_192832_b = 1.0f;
                if (AutoWalk.mc.player.isInWater() || AutoWalk.mc.player.isInLava()) {
                    AutoWalk.mc.player.movementInput.jump = true;
                }
                else if (AutoWalk.mc.player.isCollidedHorizontally && AutoWalk.mc.player.onGround) {
                    AutoWalk.mc.player.jump();
                }
                if (!ModuleManager.isModuleEnabled("Pathfind") || Pathfind.points.isEmpty()) {
                    return;
                }
                this.lookAt(Pathfind.points.get(0));
                break;
            }
        }
    }
    
    private enum AutoWalkMode
    {
        private static final AutoWalkMode[] $VALUES;
        
        PATH, 
        BACKWARDS, 
        FORWARD;
        
        static {
            $VALUES = new AutoWalkMode[] { AutoWalkMode.FORWARD, AutoWalkMode.BACKWARDS, AutoWalkMode.PATH };
        }
    }
}
