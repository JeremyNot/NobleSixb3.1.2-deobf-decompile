//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import me.noble.client.util.*;
import java.util.*;
import net.minecraft.block.*;
import me.noble.client.setting.*;

@Module.Info(name = "LegCrystals", category = Module.Category.COMBAT)
public class LegCrystals extends Module
{
    private Setting<Double> range;
    private boolean switchCooldown;
    
    private Vec3d findPlaceableBlock(final Vec3d vec3d) {
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$000())) && !this.isExplosionProof(vec3d.add(Offsets.access$100()).addVector(0.0, 1.0, 0.0))) {
            return vec3d.add(Offsets.access$000());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$100()))) {
            return vec3d.add(Offsets.access$100());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$200())) && !this.isExplosionProof(vec3d.add(Offsets.access$300()).addVector(0.0, 1.0, 0.0))) {
            return vec3d.add(Offsets.access$200());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$300()))) {
            return vec3d.add(Offsets.access$300());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$400())) && !this.isExplosionProof(vec3d.add(Offsets.access$500()).addVector(0.0, 1.0, 0.0))) {
            return vec3d.add(Offsets.access$400());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$500()))) {
            return vec3d.add(Offsets.access$500());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$600())) && !this.isExplosionProof(vec3d.add(Offsets.access$700()).addVector(0.0, 1.0, 0.0))) {
            return vec3d.add(Offsets.access$600());
        }
        if (this.canPlaceCrystal(vec3d.add(Offsets.access$700()))) {
            return vec3d.add(Offsets.access$700());
        }
        return null;
    }
    
    public void onUpdate() {
        if (LegCrystals.mc.player == null) {
            return;
        }
        int currentItem = -1;
        if (LegCrystals.mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) {
            currentItem = LegCrystals.mc.player.inventory.currentItem;
        }
        else {
            for (int i = 0; i < 9; ++i) {
                if (LegCrystals.mc.player.inventory.getStackInSlot(i).getItem() == Items.END_CRYSTAL) {
                    currentItem = i;
                    break;
                }
            }
        }
        if (currentItem == -1) {
            return;
        }
        final EntityPlayer closestTarget = this.findClosestTarget();
        if (closestTarget == null) {
            return;
        }
        final Vec3d placeableBlock = this.findPlaceableBlock(closestTarget.getPositionVector().addVector(0.0, -1.0, 0.0));
        if (placeableBlock == null) {
            return;
        }
        final BlockPos blockPos = new BlockPos(placeableBlock);
        if (LegCrystals.mc.player.inventory.currentItem != currentItem) {
            LegCrystals.mc.player.inventory.currentItem = currentItem;
            this.switchCooldown = true;
            return;
        }
        if (this.switchCooldown) {
            this.switchCooldown = false;
            return;
        }
        LegCrystals.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(blockPos, EnumFacing.UP, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
    }
    
    private boolean canPlaceCrystal(final Vec3d vec3d) {
        final BlockPos blockPos = new BlockPos(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
        final BlockPos add = blockPos.add(0, 1, 0);
        final BlockPos add2 = blockPos.add(0, 2, 0);
        return (LegCrystals.mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || LegCrystals.mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && LegCrystals.mc.world.getBlockState(add).getBlock() == Blocks.AIR && LegCrystals.mc.world.getBlockState(add2).getBlock() == Blocks.AIR && LegCrystals.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add)).isEmpty() && LegCrystals.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add2)).isEmpty();
    }
    
    private EntityPlayer findClosestTarget() {
        Object o = null;
        for (final EntityPlayer entityPlayer : LegCrystals.mc.world.playerEntities) {
            if (entityPlayer == LegCrystals.mc.player) {
                continue;
            }
            if (Friends.isFriend(entityPlayer.getName())) {
                continue;
            }
            if (!EntityUtil.isLiving((Entity)entityPlayer)) {
                continue;
            }
            if (entityPlayer.getHealth() <= 0.0f) {
                continue;
            }
            if (LegCrystals.mc.player.getDistanceToEntity((Entity)entityPlayer) > this.range.getValue()) {
                continue;
            }
            if (o == null) {
                o = entityPlayer;
            }
            else {
                if (LegCrystals.mc.player.getDistanceToEntity((Entity)entityPlayer) >= LegCrystals.mc.player.getDistanceToEntity((Entity)o)) {
                    continue;
                }
                o = entityPlayer;
            }
        }
        return (EntityPlayer)o;
    }
    
    private boolean isExplosionProof(final Vec3d vec3d) {
        final Block getBlock = LegCrystals.mc.world.getBlockState(new BlockPos(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord)).getBlock();
        return getBlock == Blocks.BEDROCK || getBlock == Blocks.OBSIDIAN || getBlock == Blocks.ANVIL || getBlock == Blocks.ENDER_CHEST || getBlock == Blocks.BARRIER;
    }
    
    public LegCrystals() {
        this.range = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Range").withMinimum(1.0).withValue(5.5).withMaximum(10.0).build());
        this.switchCooldown = false;
    }
    
    private static class Offsets
    {
        private static final Vec3d NORTH1;
        private static final Vec3d SOUTH2;
        private static final Vec3d EAST1;
        private static final Vec3d WEST2;
        private static final Vec3d EAST2;
        private static final Vec3d SOUTH1;
        private static final Vec3d WEST1;
        private static final Vec3d NORTH2;
        
        static Vec3d access$600() {
            return Offsets.WEST2;
        }
        
        static Vec3d access$400() {
            return Offsets.SOUTH2;
        }
        
        static Vec3d access$700() {
            return Offsets.WEST1;
        }
        
        static Vec3d access$200() {
            return Offsets.EAST2;
        }
        
        static Vec3d access$100() {
            return Offsets.NORTH1;
        }
        
        static Vec3d access$300() {
            return Offsets.EAST1;
        }
        
        static Vec3d access$000() {
            return Offsets.NORTH2;
        }
        
        static {
            NORTH1 = new Vec3d(0.0, 0.0, -1.0);
            NORTH2 = new Vec3d(0.0, 0.0, -2.0);
            EAST1 = new Vec3d(1.0, 0.0, 0.0);
            EAST2 = new Vec3d(2.0, 0.0, 0.0);
            SOUTH1 = new Vec3d(0.0, 0.0, 1.0);
            SOUTH2 = new Vec3d(0.0, 0.0, 2.0);
            WEST1 = new Vec3d(-1.0, 0.0, 0.0);
            WEST2 = new Vec3d(-2.0, 0.0, 0.0);
        }
        
        static Vec3d access$500() {
            return Offsets.SOUTH1;
        }
    }
}
