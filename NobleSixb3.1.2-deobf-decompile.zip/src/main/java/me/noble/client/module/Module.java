//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module;

import me.noble.client.util.*;
import net.minecraft.client.*;
import me.noble.client.*;
import java.util.*;
import me.noble.client.setting.builder.*;
import me.noble.client.event.events.*;
import me.noble.client.setting.*;
import com.google.common.base.*;
import com.google.gson.*;
import org.lwjgl.input.*;
import java.lang.annotation.*;

public class Module
{
    private final Category category;
    private Setting<Bind> bind;
    private final String originalName;
    public List<Setting> settingList;
    private final Setting<String> name;
    private final String description;
    public boolean alwaysListening;
    private Setting<ShowOnArray> showOnArray;
    private Setting<Boolean> enabled;
    protected static final Minecraft mc;
    
    static {
        mc = Minecraft.getMinecraft();
    }
    
    private static boolean lambda$new$0(final Boolean b) {
        return false;
    }
    
    public void onUpdate() {
    }
    
    public void toggle() {
        this.setEnabled(!this.isEnabled());
    }
    
    public boolean isEnabled() {
        return this.enabled.getValue();
    }
    
    public Category getCategory() {
        return this.category;
    }
    
    public String getOriginalName() {
        return this.originalName;
    }
    
    protected void registerAll(final Setting... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.register((Setting<Object>)array[i]);
        }
    }
    
    public void enable() {
        this.enabled.setValue(true);
        this.onEnable();
        if (!this.alwaysListening) {
            NobleMod.EVENT_BUS.subscribe(this);
        }
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public Bind getBind() {
        return this.bind.getValue();
    }
    
    public void setName(final String value) {
        this.name.setValue(value);
    }
    
    public void onRender() {
    }
    
    protected <T> Setting<T> register(final Setting<T> setting) {
        if (this.settingList == null) {
            this.settingList = new ArrayList<Setting>();
        }
        this.settingList.add(setting);
        return SettingBuilder.register(setting, String.valueOf(new StringBuilder().append("modules.").append(this.originalName)));
    }
    
    public ShowOnArray getShowOnArray() {
        return this.showOnArray.getValue();
    }
    
    public String getHudInfo() {
        return null;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
    }
    
    private Info getAnnotation() {
        if (this.getClass().isAnnotationPresent(Info.class)) {
            return this.getClass().getAnnotation(Info.class);
        }
        throw new IllegalStateException(String.valueOf(new StringBuilder().append("No Annotation on class ").append(this.getClass().getCanonicalName()).append("!")));
    }
    
    public Module() {
        this.originalName = this.getAnnotation().name();
        this.category = this.getAnnotation().category();
        this.description = this.getAnnotation().description();
        this.name = this.register(Settings.s("Name", this.originalName));
        this.bind = this.register(Settings.custom("Bind", Bind.none(), new BindConverter(null)).build());
        this.enabled = this.register(Settings.booleanBuilder("Enabled").withVisibility(Module::lambda$new$0).withValue(false).build());
        this.showOnArray = this.register(Settings.e("Visible", this.getAnnotation().showOnArray()));
        this.settingList = new ArrayList<Setting>();
        this.alwaysListening = this.getAnnotation().alwaysListening();
        this.registerAll(this.bind, this.enabled, this.showOnArray);
    }
    
    public void setEnabled(final boolean b) {
        if (this.enabled.getValue() != b) {
            if (b) {
                this.enable();
            }
            else {
                this.disable();
            }
        }
    }
    
    protected void onDisable() {
    }
    
    public String getBindName() {
        return this.bind.getValue().toString();
    }
    
    public void disable() {
        this.enabled.setValue(false);
        this.onDisable();
        if (!this.alwaysListening) {
            NobleMod.EVENT_BUS.unsubscribe(this);
        }
    }
    
    public void destroy() {
    }
    
    protected final void setAlwaysListening(final boolean alwaysListening) {
        this.alwaysListening = alwaysListening;
        if (alwaysListening) {
            NobleMod.EVENT_BUS.subscribe(this);
        }
        if (!alwaysListening && this.isDisabled()) {
            NobleMod.EVENT_BUS.unsubscribe(this);
        }
    }
    
    public boolean isDisabled() {
        return !this.isEnabled();
    }
    
    protected void onEnable() {
    }
    
    public String getName() {
        return this.name.getValue();
    }
    
    protected <T> Setting<T> register(final SettingBuilder<T> settingBuilder) {
        if (this.settingList == null) {
            this.settingList = new ArrayList<Setting>();
        }
        final Setting<T> buildAndRegister = settingBuilder.buildAndRegister(String.valueOf(new StringBuilder().append("modules.").append(this.name)));
        this.settingList.add(buildAndRegister);
        return buildAndRegister;
    }
    
    private class BindConverter extends Converter<Bind, JsonElement>
    {
        final Module this$0;
        
        protected Object doBackward(final Object o) {
            return this.doBackward((JsonElement)o);
        }
        
        private BindConverter(final Module this$0) {
            this.this$0 = this$0;
        }
        
        protected JsonElement doForward(final Bind bind) {
            return (JsonElement)new JsonPrimitive(bind.toString());
        }
        
        protected Bind doBackward(final JsonElement jsonElement) {
            String s = jsonElement.getAsString();
            if (s.equalsIgnoreCase("None")) {
                return Bind.none();
            }
            boolean b = false;
            boolean b2 = false;
            boolean b3 = false;
            if (s.startsWith("Ctrl+")) {
                b = true;
                s = s.substring(5);
            }
            if (s.startsWith("Alt+")) {
                b2 = true;
                s = s.substring(4);
            }
            if (s.startsWith("Shift+")) {
                b3 = true;
                s = s.substring(6);
            }
            int keyIndex = -1;
            try {
                keyIndex = Keyboard.getKeyIndex(s.toUpperCase());
            }
            catch (Exception ex) {}
            if (keyIndex == 0) {
                return Bind.none();
            }
            return new Bind(b, b2, b3, keyIndex);
        }
        
        BindConverter(final Module module, final Module$1 object) {
            this(module);
        }
        
        protected Object doForward(final Object o) {
            return this.doForward((Bind)o);
        }
    }
    
    public enum ShowOnArray
    {
        ON, 
        OFF;
        
        private static final ShowOnArray[] $VALUES;
        
        static {
            $VALUES = new ShowOnArray[] { ShowOnArray.ON, ShowOnArray.OFF };
        }
    }
    
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Info {
        ShowOnArray showOnArray() default ShowOnArray.ON;
        
        boolean alwaysListening() default false;
        
        Category category();
        
        String name();
        
        String description() default "Descriptionless";
    }
    
    public enum Category
    {
        private static final Category[] $VALUES;
        
        RENDER("Render", false), 
        EXPLOITS("Exploits", false);
        
        boolean hidden;
        
        GUI("GUI", false);
        
        String name;
        
        CHAT("Chat", false), 
        MISC("Misc", false), 
        HIDDEN("Hidden", true), 
        PLAYER("Player", false), 
        NOBLE("NobleClient", false), 
        COMBAT("Combat", false), 
        MOVEMENT("Movement", false);
        
        public String getName() {
            return this.name;
        }
        
        private Category(final String name, final boolean hidden) {
            this.name = name;
            this.hidden = hidden;
        }
        
        static {
            $VALUES = new Category[] { Category.COMBAT, Category.EXPLOITS, Category.NOBLE, Category.RENDER, Category.MISC, Category.PLAYER, Category.MOVEMENT, Category.GUI, Category.CHAT, Category.HIDDEN };
        }
        
        public boolean isHidden() {
            return this.hidden;
        }
    }
}
