//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import net.minecraft.inventory.*;
import me.noble.client.setting.*;

@Module.Info(name = "ArmourHide", category = Module.Category.GUI, description = "Hides the armour on selected entities", showOnArray = Module.ShowOnArray.OFF)
public class ArmourHide extends Module
{
    public Setting<Boolean> mobs;
    public Setting<Boolean> player;
    public Setting<Boolean> boots;
    public Setting<Boolean> chestplate;
    public Setting<Boolean> armourstand;
    public static ArmourHide INSTANCE;
    public Setting<Boolean> leggins;
    public Setting<Boolean> helmet;
    
    public static boolean shouldRenderPiece(final EntityEquipmentSlot entityEquipmentSlot) {
        return (entityEquipmentSlot == EntityEquipmentSlot.HEAD && ArmourHide.INSTANCE.helmet.getValue()) || (entityEquipmentSlot == EntityEquipmentSlot.CHEST && ArmourHide.INSTANCE.chestplate.getValue()) || (entityEquipmentSlot == EntityEquipmentSlot.LEGS && ArmourHide.INSTANCE.leggins.getValue()) || (entityEquipmentSlot == EntityEquipmentSlot.FEET && ArmourHide.INSTANCE.boots.getValue());
    }
    
    public ArmourHide() {
        this.player = (Setting<Boolean>)this.register((Setting)Settings.b("Players", false));
        this.armourstand = (Setting<Boolean>)this.register((Setting)Settings.b("Armour Stands", true));
        this.mobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", true));
        this.helmet = (Setting<Boolean>)this.register((Setting)Settings.b("Helmet", false));
        this.chestplate = (Setting<Boolean>)this.register((Setting)Settings.b("Chestplate", false));
        this.leggins = (Setting<Boolean>)this.register((Setting)Settings.b("Leggings", false));
        this.boots = (Setting<Boolean>)this.register((Setting)Settings.b("Boots", false));
        ArmourHide.INSTANCE = this;
    }
}
