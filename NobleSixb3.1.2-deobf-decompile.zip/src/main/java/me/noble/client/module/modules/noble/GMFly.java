//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.module.*;

@Module.Info(name = "NobleFly", category = Module.Category.NOBLE, description = "Godmode Fly")
public class GMFly extends Module
{
    private void toggleFly(final boolean b) {
        GMFly.mc.player.capabilities.isFlying = b;
        if (GMFly.mc.player.capabilities.isCreativeMode) {
            return;
        }
        GMFly.mc.player.capabilities.allowFlying = b;
    }
    
    public void onUpdate() {
        this.toggleFly(true);
    }
    
    public void onEnable() {
        this.toggleFly(true);
    }
    
    public void onDisable() {
        this.toggleFly(false);
    }
}
