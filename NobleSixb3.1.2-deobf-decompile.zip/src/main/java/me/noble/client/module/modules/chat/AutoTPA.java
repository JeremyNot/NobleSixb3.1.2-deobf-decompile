//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.server.*;
import me.noble.client.util.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(name = "AutoTPA", description = "Automatically decline or accept TPA requests", category = Module.Category.CHAT)
public class AutoTPA extends Module
{
    private Setting<mode> mod;
    @EventHandler
    public Listener<PacketEvent.Receive> receiveListener;
    
    private void lambda$new$0(final PacketEvent.Receive receive) {
        if (receive.getPacket() instanceof SPacketChat && ((SPacketChat)receive.getPacket()).getChatComponent().getUnformattedText().contains(" has requested to teleport to you.")) {
            switch (this.mod.getValue()) {
                case ACCEPT: {
                    Wrapper.getPlayer().sendChatMessage("/tpaccept");
                    break;
                }
                case DENY: {
                    Wrapper.getPlayer().sendChatMessage("/tpdeny");
                    break;
                }
            }
        }
    }
    
    public AutoTPA() {
        this.mod = (Setting<mode>)this.register((Setting)Settings.e("Response", mode.DENY));
        this.receiveListener = new Listener<PacketEvent.Receive>(this::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    public enum mode
    {
        DENY;
        
        private static final mode[] $VALUES;
        
        ACCEPT;
        
        static {
            $VALUES = new mode[] { mode.ACCEPT, mode.DENY };
        }
    }
}
