//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import me.noble.client.gui.kami.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import me.noble.client.setting.*;
import me.noble.client.*;
import net.minecraft.item.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.util.*;
import me.noble.client.gui.rgui.component.container.*;
import java.util.*;
import net.minecraft.util.*;

@Module.Info(name = "InventoryViewer", category = Module.Category.GUI, description = "View your inventory on screen", showOnArray = Module.ShowOnArray.OFF)
public class InventoryViewer extends Module
{
    KamiGUI kamiGUI;
    private Setting<ViewMode> viewMode;
    
    private static void preItemRender() {
        GL11.glPushMatrix();
        GL11.glDepthMask(true);
        GlStateManager.clear(256);
        GlStateManager.disableDepth();
        GlStateManager.enableDepth();
        RenderHelper.enableStandardItemLighting();
        GlStateManager.scale(1.0f, 1.0f, 0.01f);
    }
    
    private void boxRender(final int n, final int n2) {
        preBoxRender();
        InventoryViewer.mc.renderEngine.bindTexture(this.getBox());
        InventoryViewer.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 162, 54);
        postBoxRender();
    }
    
    public InventoryViewer() {
        this.viewMode = (Setting<ViewMode>)this.register((Setting)Settings.e("Appearance", ViewMode.ICONLARGE));
        this.kamiGUI = NobleMod.getInstance().getGuiManager();
    }
    
    private static void preBoxRender() {
        GL11.glPushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
    }
    
    private void itemRender(final NonNullList<ItemStack> list, final int n, final int n2) {
        for (int size = list.size(), i = 9; i < size; ++i) {
            final int n3 = n + 1 + i % 9 * 18;
            final int n4 = n2 + 1 + (i / 9 - 1) * 18;
            preItemRender();
            InventoryViewer.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)list.get(i), n3, n4);
            InventoryViewer.mc.getRenderItem().renderItemOverlays(InventoryViewer.mc.fontRendererObj, (ItemStack)list.get(i), n3, n4);
            postItemRender();
        }
    }
    
    private int invPos(final int n) {
        this.kamiGUI = NobleMod.getInstance().getGuiManager();
        if (this.kamiGUI != null) {
            for (final Frame frame : ContainerHelper.getAllChildren((Class)Frame.class, (Container)this.kamiGUI)) {
                if (!frame.getTitle().equalsIgnoreCase("inventory viewer")) {
                    continue;
                }
                switch (n) {
                    case 0: {
                        return frame.getX();
                    }
                    case 1: {
                        return frame.getY();
                    }
                    case 3: {
                        if (frame.isPinned()) {
                            return 1;
                        }
                        return 0;
                    }
                    default: {
                        return 0;
                    }
                }
            }
        }
        return 0;
    }
    
    private static void postBoxRender() {
        GlStateManager.disableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }
    
    private static void postItemRender() {
        GlStateManager.scale(1.0f, 1.0f, 1.0f);
        RenderHelper.disableStandardItemLighting();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.disableLighting();
        GlStateManager.scale(0.5, 0.5, 0.5);
        GlStateManager.disableDepth();
        GlStateManager.enableDepth();
        GlStateManager.scale(2.0f, 2.0f, 2.0f);
        GL11.glPopMatrix();
    }
    
    private ResourceLocation getBox() {
        if (this.viewMode.getValue().equals(ViewMode.CLEAR)) {
            return new ResourceLocation("textures/gui/container/invpreview.png");
        }
        if (this.viewMode.getValue().equals(ViewMode.ICONBACK)) {
            return new ResourceLocation("textures/gui/container/one.png");
        }
        if (this.viewMode.getValue().equals(ViewMode.SOLID)) {
            return new ResourceLocation("textures/gui/container/two.png");
        }
        if (this.viewMode.getValue().equals(ViewMode.SOLIDCLEAR)) {
            return new ResourceLocation("textures/gui/container/three.png");
        }
        if (this.viewMode.getValue().equals(ViewMode.ICON)) {
            return new ResourceLocation("textures/gui/container/four.png");
        }
        if (this.viewMode.getValue().equals(ViewMode.ICONLARGE)) {
            return new ResourceLocation("textures/gui/container/five.png");
        }
        if (this.viewMode.getValue().equals(ViewMode.ICONLARGEBG)) {
            return new ResourceLocation("textures/gui/container/six.png");
        }
        return new ResourceLocation("textures/gui/container/generic_54.png");
    }
    
    public void onDisable() {
        this.enable();
    }
    
    public void onRender() {
        if (this.invPos(3) == 1) {
            final NonNullList mainInventory = InventoryViewer.mc.player.inventory.mainInventory;
            this.boxRender(this.invPos(0), this.invPos(1));
            this.itemRender((NonNullList<ItemStack>)mainInventory, this.invPos(0), this.invPos(1));
        }
    }
    
    private enum ViewMode
    {
        MC;
        
        private static final ViewMode[] $VALUES;
        
        ICON, 
        CLEAR, 
        ICONLARGEBG, 
        ICONLARGE, 
        SOLIDCLEAR, 
        SOLID, 
        ICONBACK;
        
        static {
            $VALUES = new ViewMode[] { ViewMode.ICONLARGEBG, ViewMode.ICONLARGE, ViewMode.MC, ViewMode.ICON, ViewMode.ICONBACK, ViewMode.CLEAR, ViewMode.SOLID, ViewMode.SOLIDCLEAR };
        }
    }
}
