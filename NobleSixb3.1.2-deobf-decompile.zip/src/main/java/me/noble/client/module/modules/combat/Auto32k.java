//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import java.text.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import me.noble.client.setting.*;
import net.minecraft.init.*;
import me.noble.client.module.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import java.math.*;
import net.minecraft.item.*;
import me.noble.client.command.*;
import me.noble.client.util.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import net.minecraft.block.*;

@Module.Info(name = "Auto32k", category = Module.Category.COMBAT, description = "Places blocks to dispense a 32k")
public class Auto32k extends Module
{
    private static boolean isSneaking;
    private Setting<Double> placeRange;
    private static final DecimalFormat df;
    private Setting<Boolean> debugMessages;
    private static final List<Block> shulkerList;
    private Setting<Integer> yOffset;
    private Setting<Boolean> autoEnableHitAura;
    private Setting<Boolean> placeCloseToEnemy;
    private Setting<Boolean> placeObiOnTop;
    private Setting<Boolean> moveToHotbar;
    private static final List<Block> blackList;
    private int swordSlot;
    
    private static void placeBlock(final BlockPos blockPos) {
        if (!Auto32k.mc.world.getBlockState(blockPos).getMaterial().isReplaceable()) {
            return;
        }
        if (!checkForNeighbours(blockPos)) {
            return;
        }
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            final EnumFacing getOpposite = enumFacing.getOpposite();
            if (Auto32k.mc.world.getBlockState(offset).getBlock().canCollideCheck(Auto32k.mc.world.getBlockState(offset), false)) {
                final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
                final Block getBlock = Auto32k.mc.world.getBlockState(offset).getBlock();
                if (Auto32k.blackList.contains(getBlock) || Auto32k.shulkerList.contains(getBlock)) {
                    Auto32k.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Auto32k.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    Auto32k.isSneaking = true;
                }
                BlockInteractionHelper.faceVectorPacketInstant(add);
                Auto32k.mc.playerController.processRightClickBlock(Auto32k.mc.player, Auto32k.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
                Auto32k.mc.player.swingArm(EnumHand.MAIN_HAND);
                Auto32k.mc.rightClickDelayTimer = 4;
                return;
            }
        }
    }
    
    public Auto32k() {
        this.moveToHotbar = (Setting<Boolean>)this.register((Setting)Settings.b("Move 32k to Hotbar", true));
        this.autoEnableHitAura = (Setting<Boolean>)this.register((Setting)Settings.b("Auto enable Hit Aura", true));
        this.placeRange = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Place range").withMinimum(1.0).withValue(4.0).withMaximum(10.0).build());
        this.yOffset = (Setting<Integer>)this.register((Setting)Settings.i("Y Offset (Hopper)", 2));
        this.placeCloseToEnemy = (Setting<Boolean>)this.register((Setting)Settings.b("Place close to enemy", false));
        this.placeObiOnTop = (Setting<Boolean>)this.register((Setting)Settings.b("Place Obi on Top", true));
        this.debugMessages = (Setting<Boolean>)this.register((Setting)Settings.b("Debug Messages", true));
    }
    
    static {
        blackList = Arrays.asList(Blocks.ENDER_CHEST, (Block)Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.CRAFTING_TABLE, Blocks.ANVIL, Blocks.BREWING_STAND, (Block)Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER, Blocks.TRAPDOOR);
        shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        df = new DecimalFormat("#.#");
    }
    
    public void onUpdate() {
        if (this.isDisabled() || Auto32k.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (!(Auto32k.mc.currentScreen instanceof GuiContainer)) {
            return;
        }
        if (!this.moveToHotbar.getValue()) {
            this.disable();
            return;
        }
        if (this.swordSlot == -1) {
            return;
        }
        boolean b = true;
        if (((GuiContainer)Auto32k.mc.currentScreen).inventorySlots.getSlot(0).getStack().field_190928_g) {
            b = false;
        }
        if (!((GuiContainer)Auto32k.mc.currentScreen).inventorySlots.getSlot(this.swordSlot).getStack().field_190928_g) {
            b = false;
        }
        if (b) {
            Auto32k.mc.playerController.windowClick(((GuiContainer)Auto32k.mc.currentScreen).inventorySlots.windowId, 0, this.swordSlot - 32, ClickType.SWAP, (EntityPlayer)Auto32k.mc.player);
            if (this.autoEnableHitAura.getValue()) {
                ModuleManager.getModuleByName("Aura").enable();
            }
            this.disable();
        }
    }
    
    private static boolean hasNeighbour(final BlockPos blockPos) {
        final EnumFacing[] values = EnumFacing.values();
        for (int length = values.length, i = 0; i < length; ++i) {
            if (!Auto32k.mc.world.getBlockState(blockPos.offset(values[i])).getMaterial().isReplaceable()) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean checkForNeighbours(final BlockPos blockPos) {
        if (!hasNeighbour(blockPos)) {
            final EnumFacing[] values = EnumFacing.values();
            for (int length = values.length, i = 0; i < length; ++i) {
                if (hasNeighbour(blockPos.offset(values[i]))) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }
    
    private void lambda$onEnable$0(final Map map, final BlockPos blockPos, final Double n) {
        if (!this.isAreaPlaceable(blockPos)) {
            map.remove(blockPos);
        }
    }
    
    protected void onEnable() {
        if (this.isDisabled() || Auto32k.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            this.disable();
            return;
        }
        Auto32k.df.setRoundingMode(RoundingMode.CEILING);
        int currentItem = -1;
        int n = -1;
        int currentItem2 = -1;
        this.swordSlot = -1;
        for (int n2 = 0; n2 < 9 && (currentItem == -1 || n == -1 || currentItem2 == -1); ++n2) {
            final ItemStack getStackInSlot = Auto32k.mc.player.inventory.getStackInSlot(n2);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    final Block getBlock = ((ItemBlock)getStackInSlot.getItem()).getBlock();
                    if (getBlock == Blocks.HOPPER) {
                        currentItem = n2;
                    }
                    else if (Auto32k.shulkerList.contains(getBlock)) {
                        n = n2;
                    }
                    else if (getBlock == Blocks.OBSIDIAN) {
                        currentItem2 = n2;
                    }
                }
            }
        }
        if (currentItem == -1) {
            if (this.debugMessages.getValue()) {
                Command.sendChatMessage("[Auto32k] Hopper missing, disabling.");
            }
            this.disable();
            return;
        }
        if (n == -1) {
            if (this.debugMessages.getValue()) {
                Command.sendChatMessage("[Auto32k] Shulker missing, disabling.");
            }
            this.disable();
            return;
        }
        final int n3 = (int)Math.ceil(this.placeRange.getValue());
        final List<BlockPos> sphere = ((CrystalAura)ModuleManager.getModuleByName("CrystalAura")).getSphere(CrystalAura.getPlayerPos(), (float)n3, n3, false, true, 0);
        final HashMap<BlockPos, Double> hashMap = (HashMap<BlockPos, Double>)new HashMap<Object, Double>();
        Object o = null;
        boolean b = false;
        for (final BlockPos blockPos : sphere) {
            for (final Entity entity : Auto32k.mc.world.loadedEntityList) {
                if (!(entity instanceof EntityPlayer)) {
                    continue;
                }
                if (entity == Auto32k.mc.player) {
                    continue;
                }
                if (Friends.isFriend(entity.getName())) {
                    continue;
                }
                if (this.yOffset.getValue() != 0 && Math.abs(Auto32k.mc.player.getPosition().y - blockPos.y) > Math.abs(this.yOffset.getValue())) {
                    continue;
                }
                if (!this.isAreaPlaceable(blockPos)) {
                    continue;
                }
                final double getDistance = entity.getDistance((double)blockPos.x, (double)blockPos.y, (double)blockPos.z);
                hashMap.put(blockPos, hashMap.containsKey(blockPos) ? (hashMap.get(blockPos) + getDistance) : getDistance);
                b = true;
            }
        }
        if (hashMap.size() > 0) {
            hashMap.forEach((BiConsumer<? super Object, ? super Double>)this::lambda$onEnable$0);
            if (hashMap.size() == 0) {
                b = false;
            }
        }
        if (b) {
            if (this.placeCloseToEnemy.getValue()) {
                if (this.debugMessages.getValue()) {
                    Command.sendChatMessage("[Auto32k] Placing close to Enemy");
                }
                o = ((Map.Entry<BlockPos, V>)Collections.min((Collection<?>)hashMap.entrySet(), (Comparator<? super Object>)Map.Entry.comparingByValue())).getKey();
            }
            else {
                if (this.debugMessages.getValue()) {
                    Command.sendChatMessage("[Auto32k] Placing far from Enemy");
                }
                o = ((Map.Entry<BlockPos, V>)Collections.max((Collection<?>)hashMap.entrySet(), (Comparator<? super Object>)Map.Entry.comparingByValue())).getKey();
            }
        }
        else {
            if (this.debugMessages.getValue()) {
                Command.sendChatMessage("[Auto32k] No enemy nearby, placing at first valid position.");
            }
            for (final BlockPos blockPos2 : sphere) {
                if (this.isAreaPlaceable(blockPos2)) {
                    o = blockPos2;
                    break;
                }
            }
        }
        if (o == null) {
            if (this.debugMessages.getValue()) {
                Command.sendChatMessage("[Auto32k] No valid position in range to place!");
            }
            this.disable();
            return;
        }
        if (this.debugMessages.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Auto32k] Place Target: ").append(((BlockPos)o).x).append(" ").append(((BlockPos)o).y).append(" ").append(((BlockPos)o).z).append(" Distance: ").append(Auto32k.df.format(Auto32k.mc.player.getPositionVector().distanceTo(new Vec3d((Vec3i)o))))));
        }
        Auto32k.mc.player.inventory.currentItem = currentItem;
        placeBlock(new BlockPos((Vec3i)o));
        Auto32k.mc.player.inventory.currentItem = n;
        placeBlock(new BlockPos((Vec3i)((BlockPos)o).add(0, 1, 0)));
        if (this.placeObiOnTop.getValue() && currentItem2 != -1) {
            Auto32k.mc.player.inventory.currentItem = currentItem2;
            placeBlock(new BlockPos((Vec3i)((BlockPos)o).add(0, 2, 0)));
        }
        if (Auto32k.isSneaking) {
            Auto32k.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Auto32k.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            Auto32k.isSneaking = false;
        }
        Auto32k.mc.player.inventory.currentItem = n;
        Auto32k.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(new BlockPos((Vec3i)o), EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
        this.swordSlot = n + 32;
    }
    
    private boolean isAreaPlaceable(final BlockPos blockPos) {
        final Iterator<Entity> iterator = Auto32k.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(blockPos)).iterator();
        while (iterator.hasNext()) {
            if (iterator.next() instanceof EntityLivingBase) {
                return false;
            }
        }
        if (!Auto32k.mc.world.getBlockState(blockPos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!Auto32k.mc.world.getBlockState(blockPos.add(0, 1, 0)).getMaterial().isReplaceable()) {
            return false;
        }
        if (Auto32k.mc.world.getBlockState(blockPos.add(0, -1, 0)).getBlock() instanceof BlockAir) {
            return false;
        }
        if (Auto32k.mc.world.getBlockState(blockPos.add(0, -1, 0)).getBlock() instanceof BlockLiquid) {
            return false;
        }
        if (Auto32k.mc.player.getPositionVector().distanceTo(new Vec3d((Vec3i)blockPos)) > this.placeRange.getValue()) {
            return false;
        }
        final Block getBlock = Auto32k.mc.world.getBlockState(blockPos.add(0, -1, 0)).getBlock();
        return !Auto32k.blackList.contains(getBlock) && !Auto32k.shulkerList.contains(getBlock) && Auto32k.mc.player.getPositionVector().distanceTo(new Vec3d((Vec3i)blockPos).addVector(0.0, 1.0, 0.0)) <= this.placeRange.getValue();
    }
}
