//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.entity.*;
import org.lwjgl.opengl.*;
import me.noble.client.util.*;
import net.minecraft.util.math.*;
import java.util.*;
import me.noble.client.event.events.*;
import java.util.function.*;

@Module.Info(name = "Trajectories", category = Module.Category.RENDER, description = "Draws lines to where trajectories are going to fall")
public class Trajectories extends Module
{
    HueCycler cycler;
    ArrayList<Vec3d> positions;
    
    private static boolean lambda$onWorldRender$0(final Entity entity) {
        return entity instanceof EntityLivingBase;
    }
    
    private void lambda$onWorldRender$2(final EntityLivingBase entityLivingBase) {
        this.positions.clear();
        final TrajectoryCalculator.ThrowingType throwType = TrajectoryCalculator.getThrowType(entityLivingBase);
        if (throwType == TrajectoryCalculator.ThrowingType.NONE) {
            return;
        }
        final TrajectoryCalculator.FlightPath flightPath = new TrajectoryCalculator.FlightPath(entityLivingBase, throwType);
        while (!flightPath.isCollided()) {
            flightPath.onUpdate();
            this.positions.add(flightPath.position);
        }
        BlockPos getBlockPos = null;
        if (flightPath.getCollidingTarget() != null) {
            getBlockPos = flightPath.getCollidingTarget().getBlockPos();
        }
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        if (getBlockPos != null) {
            KamiTessellator.prepare(7);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.3f);
            KamiTessellator.drawBox(getBlockPos, 872415231, GeometryMasks.FACEMAP.get(flightPath.getCollidingTarget().sideHit));
            KamiTessellator.release();
        }
        if (this.positions.isEmpty()) {
            return;
        }
        GL11.glDisable(3042);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glLineWidth(2.0f);
        if (getBlockPos != null) {
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
        }
        else {
            this.cycler.setNext();
        }
        GL11.glBegin(1);
        final Vec3d vec3d = this.positions.get(0);
        GL11.glVertex3d(vec3d.xCoord - Trajectories.mc.getRenderManager().renderPosX, vec3d.yCoord - Trajectories.mc.getRenderManager().renderPosY, vec3d.zCoord - Trajectories.mc.getRenderManager().renderPosZ);
        for (final Vec3d vec3d2 : this.positions) {
            GL11.glVertex3d(vec3d2.xCoord - Trajectories.mc.getRenderManager().renderPosX, vec3d2.yCoord - Trajectories.mc.getRenderManager().renderPosY, vec3d2.zCoord - Trajectories.mc.getRenderManager().renderPosZ);
            GL11.glVertex3d(vec3d2.xCoord - Trajectories.mc.getRenderManager().renderPosX, vec3d2.yCoord - Trajectories.mc.getRenderManager().renderPosY, vec3d2.zCoord - Trajectories.mc.getRenderManager().renderPosZ);
            if (getBlockPos == null) {
                this.cycler.setNext();
            }
        }
        GL11.glEnd();
        GL11.glEnable(3042);
        GL11.glEnable(3553);
        this.cycler.reset();
    }
    
    public Trajectories() {
        this.positions = new ArrayList<Vec3d>();
        this.cycler = new HueCycler(100);
    }
    
    private static EntityLivingBase lambda$onWorldRender$1(final Entity entity) {
        return (EntityLivingBase)entity;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        try {
            Trajectories.mc.world.loadedEntityList.stream().filter(Trajectories::lambda$onWorldRender$0).map(Trajectories::lambda$onWorldRender$1).forEach(this::lambda$onWorldRender$2);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
