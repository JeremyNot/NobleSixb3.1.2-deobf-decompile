//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import me.noble.client.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import me.noble.client.module.*;
import me.noble.client.command.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.item.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import me.noble.client.setting.*;

@Module.Info(name = "AutoTrap3", category = Module.Category.COMBAT, description = "Traps players near you with obby")
public class AutoTrap3 extends Module
{
    private int lastHotbarSlot;
    private boolean firstRun;
    private String lastTickTargetName;
    private boolean isSneaking;
    private EntityPlayer closestTarget;
    private final Vec3d[] offsetsDefault;
    private Setting<Boolean> rotate;
    private int playerHotbarSlot;
    private Setting<Boolean> announceUsage;
    private Setting<Integer> blockPerTick;
    private int offsetStep;
    private Setting<Double> range;
    
    private void findClosestTarget() {
        final List playerEntities = Wrapper.getWorld().playerEntities;
        this.closestTarget = null;
        for (final EntityPlayer entityPlayer : playerEntities) {
            if (entityPlayer == AutoTrap3.mc.player) {
                continue;
            }
            if (Friends.isFriend(entityPlayer.getName())) {
                continue;
            }
            if (!EntityUtil.isLiving((Entity)entityPlayer)) {
                continue;
            }
            if (entityPlayer.getHealth() <= 0.0f) {
                continue;
            }
            if (this.closestTarget == null) {
                this.closestTarget = entityPlayer;
            }
            else {
                if (Wrapper.getPlayer().getDistanceToEntity((Entity)entityPlayer) >= Wrapper.getPlayer().getDistanceToEntity((Entity)this.closestTarget)) {
                    continue;
                }
                this.closestTarget = entityPlayer;
            }
        }
    }
    
    private boolean placeBlock(final BlockPos blockPos) {
        if (!AutoTrap3.mc.world.getBlockState(blockPos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!BlockInteractionHelper.checkForNeighbours(blockPos)) {
            return false;
        }
        final Vec3d vec3d = new Vec3d(Wrapper.getPlayer().posX, Wrapper.getPlayer().posY + Wrapper.getPlayer().getEyeHeight(), Wrapper.getPlayer().posZ);
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            final EnumFacing getOpposite = enumFacing.getOpposite();
            if (AutoTrap3.mc.world.getBlockState(offset).getBlock().canCollideCheck(AutoTrap3.mc.world.getBlockState(offset), false)) {
                final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
                if (vec3d.distanceTo(add) <= this.range.getValue()) {
                    final int obiInHotbar = this.findObiInHotbar();
                    if (obiInHotbar == -1) {
                        this.disable();
                        return false;
                    }
                    if (this.lastHotbarSlot != obiInHotbar) {
                        Wrapper.getPlayer().inventory.currentItem = obiInHotbar;
                        this.lastHotbarSlot = obiInHotbar;
                    }
                    final Block getBlock = AutoTrap3.mc.world.getBlockState(offset).getBlock();
                    if (BlockInteractionHelper.blackList.contains(getBlock) || BlockInteractionHelper.shulkerList.contains(getBlock)) {
                        AutoTrap3.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap3.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                        this.isSneaking = true;
                    }
                    if (this.rotate.getValue()) {
                        BlockInteractionHelper.faceVectorPacketInstant(add);
                    }
                    AutoTrap3.mc.playerController.processRightClickBlock(AutoTrap3.mc.player, AutoTrap3.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
                    AutoTrap3.mc.player.swingArm(EnumHand.MAIN_HAND);
                    return true;
                }
            }
        }
        return false;
    }
    
    public void onUpdate() {
        if (AutoTrap3.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        this.findClosestTarget();
        if (this.closestTarget == null) {
            if (this.firstRun) {
                this.firstRun = false;
                if (this.announceUsage.getValue()) {
                    Command.sendChatMessage("[AutoTrap3] Enabled, waiting for target.");
                }
            }
            return;
        }
        if (this.firstRun) {
            this.firstRun = false;
            this.lastTickTargetName = this.closestTarget.getName();
            if (this.announceUsage.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap3] Enabled, target: ").append(this.lastTickTargetName)));
            }
        }
        else if (!this.lastTickTargetName.equals(this.closestTarget.getName())) {
            this.lastTickTargetName = this.closestTarget.getName();
            this.offsetStep = 0;
            if (this.announceUsage.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap3] New target: ").append(this.lastTickTargetName)));
            }
        }
        final ArrayList<Object> list = new ArrayList<Object>();
        Collections.addAll(list, this.offsetsDefault);
        int i = 0;
        while (i < this.blockPerTick.getValue()) {
            if (this.offsetStep >= list.size()) {
                this.offsetStep = 0;
                break;
            }
            final BlockPos blockPos = new BlockPos((Vec3d)list.get(this.offsetStep));
            final BlockPos add = new BlockPos(this.closestTarget.getPositionVector()).down().add(blockPos.x, blockPos.y, blockPos.z);
            boolean b = true;
            if (!Wrapper.getWorld().getBlockState(add).getMaterial().isReplaceable()) {
                b = false;
            }
            for (final Entity entity : AutoTrap3.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(add))) {
                if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                    b = false;
                    break;
                }
            }
            if (b && this.placeBlock(add)) {
                ++i;
            }
            ++this.offsetStep;
        }
        if (i > 0) {
            if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                Wrapper.getPlayer().inventory.currentItem = this.playerHotbarSlot;
                this.lastHotbarSlot = this.playerHotbarSlot;
            }
            if (this.isSneaking) {
                AutoTrap3.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap3.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.isSneaking = false;
            }
        }
    }
    
    protected void onEnable() {
        if (AutoTrap3.mc.player == null) {
            this.disable();
            return;
        }
        this.firstRun = true;
        this.playerHotbarSlot = Wrapper.getPlayer().inventory.currentItem;
        this.lastHotbarSlot = -1;
    }
    
    private int findObiInHotbar() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = Wrapper.getPlayer().inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a && getStackInSlot.getItem() instanceof ItemBlock && ((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockObsidian) {
                n = i;
                break;
            }
        }
        return n;
    }
    
    public AutoTrap3() {
        this.offsetsDefault = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
        this.range = (Setting<Double>)this.register((Setting)Settings.d("Range", 5.5));
        this.blockPerTick = (Setting<Integer>)this.register((Setting)Settings.i("Blocks per Tick", 4));
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", true));
        this.announceUsage = (Setting<Boolean>)this.register((Setting)Settings.b("Announce Usage", true));
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.isSneaking = false;
        this.offsetStep = 0;
    }
    
    protected void onDisable() {
        if (AutoTrap3.mc.player == null) {
            return;
        }
        if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            Wrapper.getPlayer().inventory.currentItem = this.playerHotbarSlot;
        }
        if (this.isSneaking) {
            AutoTrap3.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap3.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage("[AutoTrap3] Disabled!");
        }
    }
}
