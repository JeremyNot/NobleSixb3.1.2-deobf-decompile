//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.setting.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import java.util.function.*;
import net.minecraft.init.*;
import me.noble.client.module.modules.combat.*;
import me.noble.client.module.*;

@Module.Info(name = "OffhandGap", category = Module.Category.NOBLE, description = "Auto Offhand Gapple")
public class OffhandGap extends Module
{
    private Setting<Boolean> totemOnDisable;
    private int gapples;
    private Setting<Boolean> soft;
    private Setting<TotemMode> totemMode;
    private boolean moving;
    private boolean returnI;
    
    private boolean lambda$new$0(final Object o) {
        return this.totemOnDisable.getValue();
    }
    
    public OffhandGap() {
        this.moving = false;
        this.returnI = false;
        this.soft = (Setting<Boolean>)this.register((Setting)Settings.b("Soft", false));
        this.totemOnDisable = (Setting<Boolean>)this.register((Setting)Settings.b("TotemOnDisable", true));
        this.totemMode = (Setting<TotemMode>)this.register((Setting)Settings.enumBuilder(TotemMode.class).withName("TotemMode").withValue(TotemMode.KAMI).withVisibility(this::lambda$new$0).build());
    }
    
    public void onUpdate() {
        if (OffhandGap.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        if (this.returnI) {
            int n = -1;
            for (int i = 0; i < 45; ++i) {
                if (OffhandGap.mc.player.inventory.getStackInSlot(i).field_190928_g) {
                    n = i;
                    break;
                }
            }
            if (n == -1) {
                return;
            }
            OffhandGap.mc.playerController.windowClick(0, (n < 9) ? (n + 36) : n, 0, ClickType.PICKUP, (EntityPlayer)OffhandGap.mc.player);
            this.returnI = false;
        }
        this.gapples = OffhandGap.mc.player.inventory.mainInventory.stream().filter(OffhandGap::lambda$onUpdate$1).mapToInt(ItemStack::func_190916_E).sum();
        if (OffhandGap.mc.player.getHeldItemOffhand().getItem() == Items.GOLDEN_APPLE) {
            ++this.gapples;
        }
        else {
            if (this.soft.getValue() && !OffhandGap.mc.player.getHeldItemOffhand().field_190928_g) {
                return;
            }
            if (this.moving) {
                OffhandGap.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)OffhandGap.mc.player);
                this.moving = false;
                if (!OffhandGap.mc.player.inventory.itemStack.func_190926_b()) {
                    this.returnI = true;
                }
                return;
            }
            if (OffhandGap.mc.player.inventory.itemStack.func_190926_b()) {
                if (this.gapples == 0) {
                    return;
                }
                int n2 = -1;
                for (int j = 0; j < 45; ++j) {
                    if (OffhandGap.mc.player.inventory.getStackInSlot(j).getItem() == Items.GOLDEN_APPLE) {
                        n2 = j;
                        break;
                    }
                }
                if (n2 == -1) {
                    return;
                }
                OffhandGap.mc.playerController.windowClick(0, (n2 < 9) ? (n2 + 36) : n2, 0, ClickType.PICKUP, (EntityPlayer)OffhandGap.mc.player);
                this.moving = true;
            }
            else if (!this.soft.getValue()) {
                int n3 = -1;
                for (int k = 0; k < 45; ++k) {
                    if (OffhandGap.mc.player.inventory.getStackInSlot(k).field_190928_g) {
                        n3 = k;
                        break;
                    }
                }
                if (n3 == -1) {
                    return;
                }
                OffhandGap.mc.playerController.windowClick(0, (n3 < 9) ? (n3 + 36) : n3, 0, ClickType.PICKUP, (EntityPlayer)OffhandGap.mc.player);
            }
        }
    }
    
    public void onDisable() {
        if (!this.totemOnDisable.getValue()) {
            return;
        }
        if (this.totemMode.getValue().equals(TotemMode.KAMI)) {
            final AutoTotem autoTotem = (AutoTotem)ModuleManager.getModuleByName("AutoTotem");
            autoTotem.disableSoft();
            if (autoTotem.isDisabled()) {
                autoTotem.enable();
            }
        }
        if (this.totemMode.getValue().equals(TotemMode.ASIMOV)) {
            final AutoTotemTEST autoTotemTEST = (AutoTotemTEST)ModuleManager.getModuleByName("AutoTotemTEST");
            autoTotemTEST.disableSoft();
            if (autoTotemTEST.isDisabled()) {
                autoTotemTEST.enable();
            }
        }
    }
    
    public String getHudInfo() {
        return String.valueOf(this.gapples);
    }
    
    private static boolean lambda$onUpdate$1(final ItemStack itemStack) {
        return itemStack.getItem() == Items.GOLDEN_APPLE;
    }
    
    public void onEnable() {
        if (ModuleManager.getModuleByName("AutoTotem").isEnabled()) {
            ModuleManager.getModuleByName("AutoTotem").disable();
        }
        if (ModuleManager.getModuleByName("AutoTotemTEST").isEnabled()) {
            ModuleManager.getModuleByName("AutoTotemTEST").disable();
        }
    }
    
    private enum TotemMode
    {
        ASIMOV;
        
        private static final TotemMode[] $VALUES;
        
        KAMI;
        
        static {
            $VALUES = new TotemMode[] { TotemMode.KAMI, TotemMode.ASIMOV };
        }
    }
}
