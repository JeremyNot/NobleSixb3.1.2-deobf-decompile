//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import net.minecraftforge.client.event.*;
import me.zero.alpine.listener.*;
import net.minecraft.util.*;
import java.util.function.*;

@Module.Info(name = "NoSlowDown", category = Module.Category.MOVEMENT, description = "Prevents being slowed down when using an item or going through cobwebs")
public class NoSlowDown extends Module
{
    @EventHandler
    private Listener<InputUpdateEvent> eventListener;
    
    private static void lambda$new$0(final InputUpdateEvent inputUpdateEvent) {
        if (NoSlowDown.mc.player.isHandActive() && !NoSlowDown.mc.player.isRiding()) {
            final MovementInput movementInput = inputUpdateEvent.getMovementInput();
            movementInput.moveStrafe *= 5.0f;
            final MovementInput movementInput2 = inputUpdateEvent.getMovementInput();
            movementInput2.field_192832_b *= 5.0f;
        }
    }
    
    public NoSlowDown() {
        this.eventListener = new Listener<InputUpdateEvent>(NoSlowDown::lambda$new$0, (Predicate<InputUpdateEvent>[])new Predicate[0]);
    }
}
