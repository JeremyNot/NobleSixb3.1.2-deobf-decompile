//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import java.util.function.*;
import me.noble.client.command.*;
import me.noble.client.util.*;
import net.minecraft.tileentity.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

@Module.Info(name = "ConsoleSpam", description = "Spams Spigot consoles by sending invalid UpdateSign packets", category = Module.Category.MISC)
public class ConsoleSpam extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> sendListener;
    
    public ConsoleSpam() {
        this.sendListener = new Listener<PacketEvent.Send>(ConsoleSpam::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    public void onEnable() {
        Command.sendChatMessage("[ConsoleSpam] Every time you right click a sign, a warning will appear in console.");
        Command.sendChatMessage("[ConsoleSpam] Use an autoclicker to automate this process.");
    }
    
    private static void lambda$new$0(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            Wrapper.getPlayer().connection.sendPacket((Packet)new CPacketUpdateSign(((CPacketPlayerTryUseItemOnBlock)send.getPacket()).getPos(), new TileEntitySign().signText));
        }
    }
}
