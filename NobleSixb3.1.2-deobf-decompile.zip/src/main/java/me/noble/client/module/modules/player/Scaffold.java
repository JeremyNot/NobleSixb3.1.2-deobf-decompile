//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import net.minecraftforge.client.event.*;
import me.zero.alpine.listener.*;
import net.minecraft.util.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;
import java.util.function.*;
import me.noble.client.module.*;
import net.minecraft.entity.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.item.*;
import me.noble.client.util.*;
import net.minecraft.block.*;
import net.minecraft.util.math.*;

@Module.Info(name = "Scaffold", category = Module.Category.PLAYER, description = "Places blocks under you")
public class Scaffold extends Module
{
    boolean shouldSlow;
    private Setting legitBridge;
    private static Scaffold INSTANCE;
    @EventHandler
    private Listener<InputUpdateEvent> eventListener;
    private Setting autoPlace;
    private Setting<Integer> future;
    
    private void lambda$new$0(final InputUpdateEvent inputUpdateEvent) {
        if (this.legitBridge.getValue() && this.shouldSlow) {
            final MovementInput movementInput = inputUpdateEvent.getMovementInput();
            movementInput.moveStrafe *= 0.2f;
            final MovementInput movementInput2 = inputUpdateEvent.getMovementInput();
            movementInput2.field_192832_b *= 0.2f;
        }
    }
    
    public static boolean shouldScaffold() {
        return Scaffold.INSTANCE.isEnabled();
    }
    
    public Scaffold() {
        this.future = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Ticks").withMinimum(0).withMaximum(60).withValue(2));
        this.legitBridge = this.register((Setting)Settings.b("Legit Bridge", false));
        this.autoPlace = this.register((Setting)Settings.b("AutoPlace", false));
        this.shouldSlow = false;
        this.eventListener = new Listener<InputUpdateEvent>(this::lambda$new$0, (Predicate<InputUpdateEvent>[])new Predicate[0]);
        Scaffold.INSTANCE = this;
    }
    
    public void onUpdate() {
        this.shouldSlow = false;
        if (this.isDisabled() || Scaffold.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        Vec3d vec3d = EntityUtil.getInterpolatedPos((Entity)Scaffold.mc.player, this.future.getValue());
        if (this.legitBridge.getValue()) {
            vec3d = EntityUtil.getInterpolatedPos((Entity)Scaffold.mc.player, 0.0f);
        }
        final BlockPos down = new BlockPos(vec3d).down();
        final BlockPos down2 = down.down();
        if (Wrapper.getWorld().getBlockState(new BlockPos(EntityUtil.getInterpolatedPos((Entity)Scaffold.mc.player, 2.0f)).down()).getMaterial().isReplaceable() && this.legitBridge.getValue() && Scaffold.mc.player.onGround) {
            this.shouldSlow = true;
            Scaffold.mc.player.movementInput.sneak = true;
            Scaffold.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Scaffold.mc.player, CPacketEntityAction.Action.START_SNEAKING));
        }
        if (!Wrapper.getWorld().getBlockState(down).getMaterial().isReplaceable()) {
            return;
        }
        int currentItem = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = Wrapper.getPlayer().inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    final Block getBlock = ((ItemBlock)getStackInSlot.getItem()).getBlock();
                    if (!BlockInteractionHelper.blackList.contains(getBlock)) {
                        if (!(getBlock instanceof BlockContainer)) {
                            if (Block.getBlockFromItem(getStackInSlot.getItem()).getDefaultState().isFullBlock()) {
                                if (!(((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockFalling) || !Wrapper.getWorld().getBlockState(down2).getMaterial().isReplaceable()) {
                                    currentItem = i;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (currentItem == -1) {
            return;
        }
        final int currentItem2 = Wrapper.getPlayer().inventory.currentItem;
        Wrapper.getPlayer().inventory.currentItem = currentItem;
        if (!BlockInteractionHelper.checkForNeighbours(down)) {
            return;
        }
        if (this.autoPlace.getValue()) {
            BlockInteractionHelper.placeBlockScaffold(down);
        }
        Scaffold.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Scaffold.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
        this.shouldSlow = false;
        Wrapper.getPlayer().inventory.currentItem = currentItem2;
    }
}
