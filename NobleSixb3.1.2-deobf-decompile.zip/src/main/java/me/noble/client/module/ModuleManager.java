//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module;

import net.minecraftforge.client.event.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import me.noble.client.event.events.*;
import net.minecraft.client.renderer.*;
import me.noble.client.module.modules.*;
import me.noble.client.util.*;
import me.noble.client.*;
import java.util.*;
import java.util.function.*;
import java.lang.reflect.*;

public class ModuleManager
{
    static HashMap<String, Integer> lookup;
    public static ArrayList<Module> modules;
    
    public static void onUpdate() {
        ModuleManager.modules.stream().filter((Predicate<? super Object>)ModuleManager::lambda$onUpdate$1).forEach(Module::onUpdate);
    }
    
    private static boolean lambda$onUpdate$1(final Module module) {
        return module.alwaysListening || module.isEnabled();
    }
    
    public static ArrayList<Module> getModules() {
        return ModuleManager.modules;
    }
    
    public static void onWorldRender(final RenderWorldLastEvent renderWorldLastEvent) {
        Minecraft.getMinecraft().mcProfiler.startSection("kami");
        Minecraft.getMinecraft().mcProfiler.startSection("setup");
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        GlStateManager.disableDepth();
        GlStateManager.glLineWidth(1.0f);
        final RenderEvent renderEvent = new RenderEvent((Tessellator)KamiTessellator.INSTANCE, EntityUtil.getInterpolatedPos((Entity)Wrapper.getPlayer(), renderWorldLastEvent.getPartialTicks()));
        renderEvent.resetTranslation();
        Minecraft.getMinecraft().mcProfiler.endSection();
        ModuleManager.modules.stream().filter((Predicate<? super Object>)ModuleManager::lambda$onWorldRender$3).forEach((Consumer<? super Object>)ModuleManager::lambda$onWorldRender$4);
        Minecraft.getMinecraft().mcProfiler.startSection("release");
        GlStateManager.glLineWidth(1.0f);
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        KamiTessellator.releaseGL();
        Minecraft.getMinecraft().mcProfiler.endSection();
    }
    
    public static Module getModuleByName(final String s) {
        final Integer n = ModuleManager.lookup.get(s.toLowerCase());
        if (n == null) {
            throw new IllegalArgumentException("getModuleByName() failed. Are you calling this too early? Is the module spelled correctly? Please check!!!!");
        }
        return ModuleManager.modules.get(n);
    }
    
    public static void initialize() {
        ClassFinder.findClasses(ClickGUI.class.getPackage().getName(), Module.class).forEach(ModuleManager::lambda$initialize$0);
        NobleMod.log.info("Modules initialised");
        getModules().sort(Comparator.comparing((Function<? super Module, ? extends Comparable>)Module::getOriginalName));
        updateLookup();
    }
    
    public static void onBind(final int n) {
        if (n == 0) {
            return;
        }
        ModuleManager.modules.forEach(ModuleManager::lambda$onBind$5);
    }
    
    static {
        ModuleManager.modules = new ArrayList<Module>();
        ModuleManager.lookup = new HashMap<String, Integer>();
    }
    
    private static void lambda$onBind$5(final int n, final Module module) {
        if (module.getBind().isDown(n)) {
            module.toggle();
        }
    }
    
    public static void updateLookup() {
        ModuleManager.lookup.clear();
        for (int i = 0; i < ModuleManager.modules.size(); ++i) {
            ModuleManager.lookup.put(ModuleManager.modules.get(i).getOriginalName().toLowerCase(), i);
        }
    }
    
    private static void lambda$onWorldRender$4(final RenderEvent renderEvent, final Module module) {
        Minecraft.getMinecraft().mcProfiler.startSection(module.getOriginalName());
        module.onWorldRender(renderEvent);
        Minecraft.getMinecraft().mcProfiler.endSection();
    }
    
    private static void lambda$initialize$0(final Class clazz) {
        try {
            ModuleManager.modules.add(clazz.getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]));
        }
        catch (InvocationTargetException ex) {
            ex.getCause().printStackTrace();
            System.err.println(String.valueOf(new StringBuilder().append("Couldn't initiate module ").append(clazz.getSimpleName()).append("! Err: ").append(ex.getClass().getSimpleName()).append(", message: ").append(ex.getMessage())));
        }
        catch (Exception ex2) {
            ex2.printStackTrace();
            System.err.println(String.valueOf(new StringBuilder().append("Couldn't initiate module ").append(clazz.getSimpleName()).append("! Err: ").append(ex2.getClass().getSimpleName()).append(", message: ").append(ex2.getMessage())));
        }
    }
    
    private static boolean lambda$onWorldRender$3(final Module module) {
        return module.alwaysListening || module.isEnabled();
    }
    
    public static boolean isModuleEnabled(final String s) {
        final Module moduleByName = getModuleByName(s);
        return moduleByName != null && moduleByName.isEnabled();
    }
    
    public static void onRender() {
        ModuleManager.modules.stream().filter((Predicate<? super Object>)ModuleManager::lambda$onRender$2).forEach(Module::onRender);
    }
    
    private static boolean lambda$onRender$2(final Module module) {
        return module.alwaysListening || module.isEnabled();
    }
}
