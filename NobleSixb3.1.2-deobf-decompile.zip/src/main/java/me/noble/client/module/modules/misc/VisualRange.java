//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import me.noble.client.command.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import me.noble.client.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import me.noble.client.util.*;
import com.mojang.realmsclient.gui.*;
import java.util.*;

@Module.Info(name = "VisualRange", description = "Reports Players in VisualRange", category = Module.Category.MISC)
public class VisualRange extends Module
{
    private Setting<Boolean> publicChat;
    private List<String> knownPlayers;
    private Setting<Boolean> leaving;
    
    public VisualRange() {
        this.publicChat = (Setting<Boolean>)this.register((Setting)Settings.b("PublicChat", false));
        this.leaving = (Setting<Boolean>)this.register((Setting)Settings.b("Leaving", false));
    }
    
    private void sendNotification(final String s) {
        Command.sendChatMessage(s);
    }
    
    public void onEnable() {
        this.knownPlayers = new ArrayList<String>();
    }
    
    public void onUpdate() {
        if (VisualRange.mc.player == null) {
            return;
        }
        final ArrayList<String> list = new ArrayList<String>();
        for (final Entity entity : VisualRange.mc.world.getLoadedEntityList()) {
            if (entity instanceof EntityPlayer) {
                list.add(entity.getName());
            }
        }
        if (list.size() > 0) {
            for (final String s : list) {
                if (s.equals(VisualRange.mc.player.getName())) {
                    continue;
                }
                if (!this.knownPlayers.contains(s)) {
                    this.knownPlayers.add(s);
                    if (this.publicChat.getValue()) {
                        VisualRange.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(String.valueOf(new StringBuilder().append("Oh hey, there is ").append(s).append(" in my range! This announcement was presented by: ").append(NobleMod.KAMI_KANJI))));
                    }
                    else if (Friends.isFriend(s)) {
                        this.sendNotification(String.valueOf(new StringBuilder().append("[VisualRange] ").append(ChatFormatting.GREEN.toString()).append(s).append(ChatFormatting.RESET.toString()).append(" entered the Battlefield!")));
                    }
                    else {
                        this.sendNotification(String.valueOf(new StringBuilder().append("[VisualRange] ").append(ChatFormatting.RED.toString()).append(s).append(ChatFormatting.RESET.toString()).append(" entered the Battlefield!")));
                    }
                    return;
                }
            }
        }
        if (this.knownPlayers.size() > 0) {
            for (final String s2 : this.knownPlayers) {
                if (!list.contains(s2)) {
                    this.knownPlayers.remove(s2);
                    if (this.leaving.getValue()) {
                        if (this.publicChat.getValue()) {
                            VisualRange.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(String.valueOf(new StringBuilder().append("I cant see ").append(s2).append(" anymore! This announcement was presented by: ").append(NobleMod.KAMI_KANJI))));
                        }
                        else if (Friends.isFriend(s2)) {
                            this.sendNotification(String.valueOf(new StringBuilder().append("[VisualRange] ").append(ChatFormatting.GREEN.toString()).append(s2).append(ChatFormatting.RESET.toString()).append(" left the Battlefield!")));
                        }
                        else {
                            this.sendNotification(String.valueOf(new StringBuilder().append("[VisualRange] ").append(ChatFormatting.RED.toString()).append(s2).append(ChatFormatting.RESET.toString()).append(" left the Battlefield!")));
                        }
                    }
                }
            }
        }
    }
}
