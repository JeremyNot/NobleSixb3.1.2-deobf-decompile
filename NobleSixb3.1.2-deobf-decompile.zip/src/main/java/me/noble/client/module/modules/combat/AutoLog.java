//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraftforge.event.entity.living.*;
import me.zero.alpine.listener.*;
import net.minecraftforge.event.entity.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import me.noble.client.module.*;
import net.minecraft.client.*;
import net.minecraft.network.play.server.*;
import net.minecraft.util.text.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(name = "AutoLog", description = "Automatically log when in danger or on low health", category = Module.Category.COMBAT)
public class AutoLog extends Module
{
    @EventHandler
    private Listener<LivingDamageEvent> livingDamageEventListener;
    @EventHandler
    private Listener<EntityJoinWorldEvent> entityJoinWorldEventListener;
    private Setting<Integer> health;
    long lastLog;
    private boolean shouldLog;
    
    private void lambda$new$1(final EntityJoinWorldEvent entityJoinWorldEvent) {
        if (AutoLog.mc.player == null) {
            return;
        }
        if (entityJoinWorldEvent.getEntity() instanceof EntityEnderCrystal && AutoLog.mc.player.getHealth() - CrystalAura.calculateDamage((EntityEnderCrystal)entityJoinWorldEvent.getEntity(), (Entity)AutoLog.mc.player) < this.health.getValue()) {
            this.log();
        }
    }
    
    private void log() {
        ModuleManager.getModuleByName("AutoReconnect").disable();
        this.shouldLog = true;
        this.lastLog = System.currentTimeMillis();
    }
    
    private void lambda$new$0(final LivingDamageEvent livingDamageEvent) {
        if (AutoLog.mc.player == null) {
            return;
        }
        if (livingDamageEvent.getEntity() == AutoLog.mc.player && AutoLog.mc.player.getHealth() - livingDamageEvent.getAmount() < this.health.getValue()) {
            this.log();
        }
    }
    
    public void onUpdate() {
        if (this.shouldLog) {
            this.shouldLog = false;
            if (System.currentTimeMillis() - this.lastLog < 2000L) {
                return;
            }
            Minecraft.getMinecraft().getConnection().handleDisconnect(new SPacketDisconnect((ITextComponent)new TextComponentString("AutoLogged")));
        }
    }
    
    public AutoLog() {
        this.health = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Health").withRange(0, 36).withValue(6).build());
        this.shouldLog = false;
        this.lastLog = System.currentTimeMillis();
        this.livingDamageEventListener = new Listener<LivingDamageEvent>(this::lambda$new$0, (Predicate<LivingDamageEvent>[])new Predicate[0]);
        this.entityJoinWorldEventListener = new Listener<EntityJoinWorldEvent>(this::lambda$new$1, (Predicate<EntityJoinWorldEvent>[])new Predicate[0]);
    }
}
