//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.*;
import net.minecraft.network.play.client.*;
import me.noble.client.setting.*;
import me.noble.client.command.*;
import me.noble.client.setting.builder.*;
import java.util.function.*;

@Module.Info(name = "ChatSuffix", category = Module.Category.CHAT, description = "Adds a watermark to the end of your message to let others know you're using KAMI Blue", showOnArray = Module.ShowOnArray.OFF)
public class ChatSuffix extends Module
{
    public Setting<Boolean> startupGlobal;
    @EventHandler
    public Listener<PacketEvent.Send> listener;
    private Setting<DecoMode> decoMode;
    private Setting<Boolean> commands;
    public Setting<TextMode> textMode;
    public Setting<String> customText;
    
    private String getFull(final DecoMode decoMode) {
        switch (decoMode) {
            case NONE: {
                return String.valueOf(new StringBuilder().append(" ").append(this.getText(this.textMode.getValue())));
            }
            case CLASSIC: {
                return String.valueOf(new StringBuilder().append(" ").append(NobleMod.quoteLeft).append(" ").append(this.getText(this.textMode.getValue())).append(" ").append(NobleMod.quoteRight));
            }
            case SEPARATOR: {
                return String.valueOf(new StringBuilder().append(" ").append(NobleMod.separator).append(" ").append(this.getText(this.textMode.getValue())));
            }
            default: {
                return "";
            }
        }
    }
    
    private void lambda$new$1(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketChatMessage) {
            final String getMessage = ((CPacketChatMessage)send.getPacket()).getMessage();
            if (!this.commands.getValue()) {
                if (getMessage.startsWith("/")) {
                    return;
                }
                if (getMessage.startsWith(",")) {
                    return;
                }
                if (getMessage.startsWith(".")) {
                    return;
                }
                if (getMessage.startsWith("-")) {
                    return;
                }
                if (getMessage.startsWith(";")) {
                    return;
                }
                if (getMessage.startsWith("?")) {
                    return;
                }
                if (getMessage.startsWith("*")) {
                    return;
                }
                if (getMessage.startsWith("^")) {
                    return;
                }
                if (getMessage.startsWith("&")) {
                    return;
                }
            }
            String message = String.valueOf(new StringBuilder().append(getMessage).append(this.getFull(this.decoMode.getValue())));
            if (message.length() >= 256) {
                message = message.substring(0, 256);
            }
            ((CPacketChatMessage)send.getPacket()).message = message;
        }
    }
    
    public ChatSuffix() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", true));
        this.textMode = (Setting<TextMode>)this.register((Setting)Settings.e("Message", TextMode.WEBSITE));
        this.decoMode = (Setting<DecoMode>)this.register((Setting)Settings.e("Separator", DecoMode.NONE));
        this.commands = (Setting<Boolean>)this.register((Setting)Settings.b("Commands", false));
        this.customText = (Setting<String>)this.register((SettingBuilder)Settings.stringBuilder("Custom Text").withValue(String.valueOf(new StringBuilder().append("Use &7").append(Command.getCommandPrefix()).append("&rcustomchat to modify this"))).withConsumer(ChatSuffix::lambda$new$0));
        this.listener = new Listener<PacketEvent.Send>(this::lambda$new$1, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private static void lambda$new$0(final String s, final String s2) {
    }
    
    private String getText(final TextMode textMode) {
        switch (textMode) {
            case NAME: {
                return NobleMod.KAMI_BLUE;
            }
            case ONTOP: {
                return NobleMod.KAMI_ONTOP;
            }
            case WEBSITE: {
                return NobleMod.KAMI_WEBSITE;
            }
            case JAPANESE: {
                return NobleMod.KAMI_JAPANESE_ONTOP;
            }
            case CUSTOM: {
                return this.customText.getValue();
            }
            default: {
                return "";
            }
        }
    }
    
    private enum DecoMode
    {
        CLASSIC, 
        NONE;
        
        private static final DecoMode[] $VALUES;
        
        SEPARATOR;
        
        static {
            $VALUES = new DecoMode[] { DecoMode.SEPARATOR, DecoMode.CLASSIC, DecoMode.NONE };
        }
    }
    
    public enum TextMode
    {
        private static final TextMode[] $VALUES;
        
        ONTOP, 
        NAME, 
        CUSTOM, 
        WEBSITE, 
        JAPANESE;
        
        static {
            $VALUES = new TextMode[] { TextMode.NAME, TextMode.ONTOP, TextMode.WEBSITE, TextMode.JAPANESE, TextMode.CUSTOM };
        }
    }
}
