//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import net.minecraft.client.renderer.entity.layers.*;
import net.minecraft.client.entity.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.item.*;

public class LayerCape implements LayerRenderer<AbstractClientPlayer>
{
    private final RenderPlayer playerRenderer;
    
    public void doRenderLayer(final EntityLivingBase entityLivingBase, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7) {
        this.doRenderLayer((AbstractClientPlayer)entityLivingBase, n, n2, n3, n4, n5, n6, n7);
    }
    
    public void doRenderLayer(final AbstractClientPlayer abstractClientPlayer, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7) {
        final ResourceLocation capeResource = Capes.getCapeResource(abstractClientPlayer);
        final ItemStack getItemStackFromSlot = abstractClientPlayer.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
        if (!abstractClientPlayer.hasPlayerInfo() || abstractClientPlayer.isInvisible() || !abstractClientPlayer.isWearing(EnumPlayerModelParts.CAPE) || getItemStackFromSlot.getItem() == Items.ELYTRA || capeResource == null) {
            return;
        }
        float n8 = 0.14f;
        float n9 = 0.0f;
        if (abstractClientPlayer.isSneaking()) {
            n8 = 0.1f;
            n9 = 0.09f;
        }
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        this.playerRenderer.bindTexture(capeResource);
        GlStateManager.pushMatrix();
        GlStateManager.translate(0.0f, n9, n8);
        final double n10 = abstractClientPlayer.prevChasingPosX + (abstractClientPlayer.chasingPosX - abstractClientPlayer.prevChasingPosX) * new Float(n3) - (abstractClientPlayer.prevPosX + (abstractClientPlayer.posX - abstractClientPlayer.prevPosX) * new Float(n3));
        final double n11 = abstractClientPlayer.prevChasingPosY + (abstractClientPlayer.chasingPosY - abstractClientPlayer.prevChasingPosY) * new Float(n3) - (abstractClientPlayer.prevPosY + (abstractClientPlayer.posY - abstractClientPlayer.prevPosY) * new Float(n3));
        final double n12 = abstractClientPlayer.prevChasingPosZ + (abstractClientPlayer.chasingPosZ - abstractClientPlayer.prevChasingPosZ) * new Float(n3) - (abstractClientPlayer.prevPosZ + (abstractClientPlayer.posZ - abstractClientPlayer.prevPosZ) * new Float(n3));
        final float n13 = abstractClientPlayer.prevRenderYawOffset + (abstractClientPlayer.renderYawOffset - abstractClientPlayer.prevRenderYawOffset) * n3;
        final double doubleValue = new Float(MathHelper.sin(n13 * 0.01745329f));
        final double doubleValue2 = new Float(-MathHelper.cos(n13 * 0.01745329f));
        final float clamp = MathHelper.clamp(new Double(n11).floatValue() * 10.0f, 3.0f, 32.0f);
        float n14 = new Double(n10 * doubleValue + n12 * doubleValue2).floatValue() * 100.0f;
        final float n15 = new Double(n10 * doubleValue2 - n12 * doubleValue).floatValue() * 100.0f;
        if (n14 < 0.0f) {
            n14 = 0.0f;
        }
        float n16 = clamp + MathHelper.sin((abstractClientPlayer.prevDistanceWalkedModified + (abstractClientPlayer.distanceWalkedModified - abstractClientPlayer.prevDistanceWalkedModified) * n3) * 6.0f) * 32.0f * (abstractClientPlayer.prevCameraYaw + (abstractClientPlayer.cameraYaw - abstractClientPlayer.prevCameraYaw) * n3);
        if (abstractClientPlayer.isSneaking()) {
            n16 += 20.0f;
        }
        GlStateManager.rotate(5.0f + n14 / 2.0f + n16, 1.0f, 0.0f, 0.0f);
        GlStateManager.rotate(n15 / 2.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.rotate(-n15 / 2.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(180.0f, 0.0f, 1.0f, 0.0f);
        this.playerRenderer.getMainModel().renderCape(0.0625f);
        GlStateManager.popMatrix();
    }
    
    public boolean shouldCombineTextures() {
        return false;
    }
    
    public LayerCape(final RenderPlayer playerRenderer) {
        this.playerRenderer = playerRenderer;
    }
}
