//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import net.minecraft.client.entity.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.client.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import java.util.*;
import java.util.function.*;

@Module.Info(name = "Blink", category = Module.Category.PLAYER, description = "Cancels server side packets")
public class Blink extends Module
{
    private EntityOtherPlayerMP clonedPlayer;
    @EventHandler
    public Listener<PacketEvent.Send> listener;
    Queue<CPacketPlayer> packets;
    
    protected void onEnable() {
        if (Blink.mc.player != null) {
            (this.clonedPlayer = new EntityOtherPlayerMP((World)Blink.mc.world, Blink.mc.getSession().getProfile())).copyLocationAndAnglesFrom((Entity)Blink.mc.player);
            this.clonedPlayer.rotationYawHead = Blink.mc.player.rotationYawHead;
            Blink.mc.world.addEntityToWorld(-100, (Entity)this.clonedPlayer);
        }
    }
    
    public String getHudInfo() {
        return String.valueOf(this.packets.size());
    }
    
    protected void onDisable() {
        while (!this.packets.isEmpty()) {
            Blink.mc.player.connection.sendPacket((Packet)this.packets.poll());
        }
        if (Blink.mc.player != null) {
            Blink.mc.world.removeEntityFromWorld(-100);
            this.clonedPlayer = null;
        }
    }
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (this.isEnabled() && send.getPacket() instanceof CPacketPlayer) {
            send.cancel();
            this.packets.add((CPacketPlayer)send.getPacket());
        }
    }
    
    public Blink() {
        this.packets = new LinkedList<CPacketPlayer>();
        this.listener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
}
