//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import io.netty.util.internal.*;
import me.noble.client.event.events.*;
import java.util.function.*;
import me.noble.client.setting.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import me.noble.client.module.modules.combat.*;
import me.noble.client.util.*;
import java.util.*;
import java.awt.*;

@Module.Info(name = "VoidESP", category = Module.Category.RENDER, description = "Show void holes")
public class VoidESP extends Module
{
    private ConcurrentSet<BlockPos> voidHoles;
    private Setting<HoleMode> holeMode;
    private Setting<RenderMode> renderMode;
    private Setting<Integer> range;
    private Setting<Integer> red;
    private Setting<Integer> activateAtY;
    private Setting<Integer> green;
    private Setting<Integer> blue;
    private Setting<Integer> alpha;
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (VoidESP.mc.player == null || this.voidHoles == null || this.voidHoles.isEmpty()) {
            return;
        }
        KamiTessellator.prepare(7);
        this.voidHoles.forEach((Consumer)this::lambda$onWorldRender$0);
        KamiTessellator.release();
    }
    
    public VoidESP() {
        this.range = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Range").withMinimum(1).withValue(8).withMaximum(32).build());
        this.activateAtY = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("ActivateAtY").withMinimum(1).withValue(32).withMaximum(512).build());
        this.holeMode = (Setting<HoleMode>)this.register((Setting)Settings.e("HoleMode", HoleMode.SIDES));
        this.renderMode = (Setting<RenderMode>)this.register((Setting)Settings.e("RenderMode", RenderMode.DOWN));
        this.red = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Red").withMinimum(0).withValue(255).withMaximum(255).build());
        this.green = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Green").withMinimum(0).withValue(0).withMaximum(255).build());
        this.blue = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Blue").withMinimum(0).withValue(0).withMaximum(255).build());
        this.alpha = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Alpha").withMinimum(0).withValue(128).withMaximum(255).build());
    }
    
    private boolean isAnyBedrock(final BlockPos blockPos, final BlockPos[] array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            if (VoidESP.mc.world.getBlockState(blockPos.add((Vec3i)array[i])).getBlock().equals(Blocks.BEDROCK)) {
                return true;
            }
        }
        return false;
    }
    
    public void onUpdate() {
        if (VoidESP.mc.player == null) {
            return;
        }
        if (VoidESP.mc.player.dimension == 1) {
            return;
        }
        if (VoidESP.mc.player.getPosition().y > this.activateAtY.getValue()) {
            return;
        }
        if (this.voidHoles == null) {
            this.voidHoles = (ConcurrentSet<BlockPos>)new ConcurrentSet();
        }
        else {
            this.voidHoles.clear();
        }
        for (final BlockPos blockPos : BlockInteractionHelper.getCircle(CrystalAura.getPlayerPos(), 0, this.range.getValue(), false)) {
            if (VoidESP.mc.world.getBlockState(blockPos).getBlock().equals(Blocks.BEDROCK)) {
                continue;
            }
            if (this.isAnyBedrock(blockPos, Offsets.center)) {
                continue;
            }
            boolean b = false;
            if (!this.isAnyBedrock(blockPos, Offsets.above)) {
                b = true;
            }
            if (this.holeMode.getValue().equals(HoleMode.ABOVE)) {
                if (!b) {
                    continue;
                }
                this.voidHoles.add((Object)blockPos);
            }
            else {
                boolean b2 = false;
                if (!this.isAnyBedrock(blockPos, Offsets.north)) {
                    b2 = true;
                }
                if (!this.isAnyBedrock(blockPos, Offsets.east)) {
                    b2 = true;
                }
                if (!this.isAnyBedrock(blockPos, Offsets.south)) {
                    b2 = true;
                }
                if (!this.isAnyBedrock(blockPos, Offsets.west)) {
                    b2 = true;
                }
                if (!this.holeMode.getValue().equals(HoleMode.SIDES) || (!b && !b2)) {
                    continue;
                }
                this.voidHoles.add((Object)blockPos);
            }
        }
    }
    
    private void lambda$onWorldRender$0(final BlockPos blockPos) {
        this.drawBlock(blockPos, this.red.getValue(), this.green.getValue(), this.blue.getValue());
    }
    
    private void drawBlock(final BlockPos blockPos, final int n, final int n2, final int n3) {
        final Color color = new Color(n, n2, n3, this.alpha.getValue());
        int n4 = 0;
        if (this.renderMode.getValue().equals(RenderMode.BLOCK)) {
            n4 = 63;
        }
        if (this.renderMode.getValue().equals(RenderMode.DOWN)) {
            n4 = 1;
        }
        KamiTessellator.drawBox(blockPos, color.getRGB(), n4);
    }
    
    public String getHudInfo() {
        return this.holeMode.getValue().toString();
    }
    
    private static class Offsets
    {
        static final BlockPos[] above;
        static final BlockPos[] north;
        static final BlockPos[] aboveStep2;
        static final BlockPos[] east;
        static final BlockPos[] aboveStep1;
        static final BlockPos[] south;
        static final BlockPos[] center;
        static final BlockPos[] west;
        
        static {
            center = new BlockPos[] { new BlockPos(0, 1, 0), new BlockPos(0, 2, 0) };
            above = new BlockPos[] { new BlockPos(0, 3, 0), new BlockPos(0, 4, 0) };
            aboveStep1 = new BlockPos[] { new BlockPos(0, 3, 0) };
            aboveStep2 = new BlockPos[] { new BlockPos(0, 4, 0) };
            north = new BlockPos[] { new BlockPos(0, 1, -1), new BlockPos(0, 2, -1) };
            east = new BlockPos[] { new BlockPos(1, 1, 0), new BlockPos(1, 2, 0) };
            south = new BlockPos[] { new BlockPos(0, 1, 1), new BlockPos(0, 2, 1) };
            west = new BlockPos[] { new BlockPos(-1, 1, 0), new BlockPos(-1, 2, 0) };
        }
    }
    
    private enum HoleMode
    {
        ABOVE, 
        SIDES;
        
        private static final HoleMode[] $VALUES;
        
        static {
            $VALUES = new HoleMode[] { HoleMode.SIDES, HoleMode.ABOVE };
        }
    }
    
    private enum RenderMode
    {
        BLOCK, 
        DOWN;
        
        private static final RenderMode[] $VALUES;
        
        static {
            $VALUES = new RenderMode[] { RenderMode.DOWN, RenderMode.BLOCK };
        }
    }
}
