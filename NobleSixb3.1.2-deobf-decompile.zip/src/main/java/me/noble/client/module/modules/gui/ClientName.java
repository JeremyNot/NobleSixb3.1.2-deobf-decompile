//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import me.noble.client.command.*;
import com.frontear.hephaestus.managers.*;
import me.noble.client.setting.*;

@Module.Info(name = "ClientName", category = Module.Category.GUI)
public class ClientName extends Module
{
    public Setting<Boolean> startupGlobal;
    
    protected void onEnable() {
        if (ModuleManager.isModuleEnabled("ClientName")) {
            Command.sendChatMessage("[ClientName] NobleSix is GOD!");
            UIManager.onenabled = true;
        }
    }
    
    protected void onDisable() {
        Command.sendChatMessage("[ClientName] NobleSix is GOD!");
        UIManager.onenabled = false;
    }
    
    public ClientName() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", true));
    }
}
