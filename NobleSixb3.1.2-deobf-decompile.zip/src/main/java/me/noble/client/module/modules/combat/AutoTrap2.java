//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.entity.player.*;
import me.noble.client.setting.*;
import me.noble.client.module.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.entity.item.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.network.play.client.*;
import me.noble.client.module.modules.player.*;
import me.noble.client.util.*;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.block.*;

@Module.Info(name = "AutoTrap2", category = Module.Category.COMBAT, description = "Traps your enemies in obsidian")
public class AutoTrap2 extends Module
{
    private int offsetStep;
    private String lastTargetName;
    private EntityPlayer closestTarget;
    private int lastHotbarSlot;
    private Setting<Integer> tickDelay;
    private int delayStep;
    private boolean firstRun;
    private Setting<Boolean> activeInFreecam;
    private Setting<Boolean> noGlitchBlocks;
    private boolean missingObiDisable;
    private boolean isSneaking;
    private Setting<Boolean> rotate;
    private int playerHotbarSlot;
    private Setting<Integer> blocksPerTick;
    private Setting<Boolean> infoMessage;
    private Setting<Cage> cage;
    private Setting<Double> range;
    
    public AutoTrap2() {
        this.range = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Range").withMinimum(3.5).withValue(5.5).withMaximum(10.0).build());
        this.blocksPerTick = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("BlocksPerTick").withMinimum(1).withValue(2).withMaximum(23).build());
        this.tickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TickDelay").withMinimum(0).withValue(2).withMaximum(10).build());
        this.cage = (Setting<Cage>)this.register((Setting)Settings.e("Cage", Cage.TRAP));
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", false));
        this.noGlitchBlocks = (Setting<Boolean>)this.register((Setting)Settings.b("NoGlitchBlocks", true));
        this.activeInFreecam = (Setting<Boolean>)this.register((Setting)Settings.b("Active In Freecam", true));
        this.infoMessage = (Setting<Boolean>)this.register((Setting)Settings.b("Debug", false));
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.isSneaking = false;
        this.delayStep = 0;
        this.offsetStep = 0;
        this.missingObiDisable = false;
    }
    
    public String getHudInfo() {
        if (this.closestTarget != null) {
            return this.closestTarget.getName().toUpperCase();
        }
        return "NO TARGET";
    }
    
    private static EnumFacing getPlaceableSide(final BlockPos blockPos) {
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            if (AutoTrap2.mc.world.getBlockState(offset).getBlock().canCollideCheck(AutoTrap2.mc.world.getBlockState(offset), false)) {
                if (!AutoTrap2.mc.world.getBlockState(offset).getMaterial().isReplaceable()) {
                    return enumFacing;
                }
            }
        }
        return null;
    }
    
    public void onUpdate() {
        if (AutoTrap2.mc.player == null) {
            return;
        }
        if (!this.activeInFreecam.getValue() && ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (this.firstRun) {
            if (this.findObiInHotbar() == -1) {
                if (this.infoMessage.getValue()) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap2] ").append(ChatFormatting.RED).append("Disabled").append(ChatFormatting.RESET).append(", Obsidian missing!")));
                }
                this.disable();
                return;
            }
        }
        else {
            if (this.delayStep < this.tickDelay.getValue()) {
                ++this.delayStep;
                return;
            }
            this.delayStep = 0;
        }
        this.findClosestTarget();
        if (this.closestTarget == null) {
            return;
        }
        if (this.firstRun) {
            this.firstRun = false;
            this.lastTargetName = this.closestTarget.getName();
        }
        else if (!this.lastTargetName.equals(this.closestTarget.getName())) {
            this.offsetStep = 0;
            this.lastTargetName = this.closestTarget.getName();
        }
        final ArrayList<Object> list = new ArrayList<Object>();
        if (this.cage.getValue().equals(Cage.TRAP)) {
            Collections.addAll(list, Offsets.access$000());
        }
        if (this.cage.getValue().equals(Cage.CRYSTALEXA)) {
            Collections.addAll(list, Offsets.access$100());
        }
        if (this.cage.getValue().equals(Cage.CRYSTALFULL)) {
            Collections.addAll(list, Offsets.access$200());
        }
        int i = 0;
        while (i < this.blocksPerTick.getValue()) {
            if (this.offsetStep >= list.size()) {
                this.offsetStep = 0;
                break;
            }
            final BlockPos blockPos = new BlockPos((Vec3d)list.get(this.offsetStep));
            if (this.placeBlockInRange(new BlockPos(this.closestTarget.getPositionVector()).down().add(blockPos.x, blockPos.y, blockPos.z), this.range.getValue())) {
                ++i;
            }
            ++this.offsetStep;
        }
        if (i > 0) {
            if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                AutoTrap2.mc.player.inventory.currentItem = this.playerHotbarSlot;
                this.lastHotbarSlot = this.playerHotbarSlot;
            }
            if (this.isSneaking) {
                AutoTrap2.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap2.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.isSneaking = false;
            }
        }
        if (this.missingObiDisable) {
            this.missingObiDisable = false;
            if (this.infoMessage.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap2] ").append(ChatFormatting.RED).append("Disabled").append(ChatFormatting.RESET).append(", Obsidian missing!")));
            }
            this.disable();
        }
    }
    
    private boolean placeBlockInRange(final BlockPos blockPos, final double n) {
        final Block getBlock = AutoTrap2.mc.world.getBlockState(blockPos).getBlock();
        if (!(getBlock instanceof BlockAir) && !(getBlock instanceof BlockLiquid)) {
            return false;
        }
        for (final Entity entity : AutoTrap2.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(blockPos))) {
            if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                return false;
            }
        }
        final EnumFacing placeableSide = getPlaceableSide(blockPos);
        if (placeableSide == null) {
            return false;
        }
        final BlockPos offset = blockPos.offset(placeableSide);
        final EnumFacing getOpposite = placeableSide.getOpposite();
        if (!BlockInteractionHelper.canBeClicked(offset)) {
            return false;
        }
        final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
        final Block getBlock2 = AutoTrap2.mc.world.getBlockState(offset).getBlock();
        if (AutoTrap2.mc.player.getPositionVector().distanceTo(add) > n) {
            return false;
        }
        final int obiInHotbar = this.findObiInHotbar();
        if (obiInHotbar == -1) {
            this.missingObiDisable = true;
            return false;
        }
        if (this.lastHotbarSlot != obiInHotbar) {
            AutoTrap2.mc.player.inventory.currentItem = obiInHotbar;
            this.lastHotbarSlot = obiInHotbar;
        }
        if ((!this.isSneaking && BlockInteractionHelper.blackList.contains(getBlock2)) || BlockInteractionHelper.shulkerList.contains(getBlock2)) {
            AutoTrap2.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap2.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            this.isSneaking = true;
        }
        if (this.rotate.getValue()) {
            BlockInteractionHelper.faceVectorPacketInstant(add);
        }
        AutoTrap2.mc.playerController.processRightClickBlock(AutoTrap2.mc.player, AutoTrap2.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
        AutoTrap2.mc.player.swingArm(EnumHand.MAIN_HAND);
        AutoTrap2.mc.rightClickDelayTimer = 4;
        if (this.noGlitchBlocks.getValue() && !AutoTrap2.mc.playerController.getCurrentGameType().equals((Object)GameType.CREATIVE)) {
            AutoTrap2.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, offset, getOpposite));
        }
        if (ModuleManager.getModuleByName("NoBreakAnimation").isEnabled()) {
            ((NoBreakAnimation)ModuleManager.getModuleByName("NoBreakAnimation")).resetMining();
        }
        return true;
    }
    
    protected void onDisable() {
        if (AutoTrap2.mc.player == null) {
            return;
        }
        if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            AutoTrap2.mc.player.inventory.currentItem = this.playerHotbarSlot;
        }
        if (this.isSneaking) {
            AutoTrap2.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap2.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.missingObiDisable = false;
    }
    
    private void findClosestTarget() {
        final List playerEntities = AutoTrap2.mc.world.playerEntities;
        this.closestTarget = null;
        for (final EntityPlayer entityPlayer : playerEntities) {
            if (entityPlayer == AutoTrap2.mc.player) {
                continue;
            }
            if (AutoTrap2.mc.player.getDistanceToEntity((Entity)entityPlayer) > this.range.getValue() + 3.0) {
                continue;
            }
            if (!EntityUtil.isLiving((Entity)entityPlayer)) {
                continue;
            }
            if (entityPlayer.getHealth() <= 0.0f) {
                continue;
            }
            if (Friends.isFriend(entityPlayer.getName())) {
                continue;
            }
            if (this.closestTarget == null) {
                this.closestTarget = entityPlayer;
            }
            else {
                if (AutoTrap2.mc.player.getDistanceToEntity((Entity)entityPlayer) >= AutoTrap2.mc.player.getDistanceToEntity((Entity)this.closestTarget)) {
                    continue;
                }
                this.closestTarget = entityPlayer;
            }
        }
    }
    
    protected void onEnable() {
        if (AutoTrap2.mc.player == null) {
            return;
        }
        this.firstRun = true;
        this.playerHotbarSlot = AutoTrap2.mc.player.inventory.currentItem;
        this.lastHotbarSlot = -1;
    }
    
    private int findObiInHotbar() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = AutoTrap2.mc.player.inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    if (((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockObsidian) {
                        n = i;
                        break;
                    }
                }
            }
        }
        return n;
    }
    
    private enum Cage
    {
        TRAP, 
        CRYSTALEXA;
        
        private static final Cage[] $VALUES;
        
        CRYSTALFULL;
        
        static {
            $VALUES = new Cage[] { Cage.TRAP, Cage.CRYSTALEXA, Cage.CRYSTALFULL };
        }
    }
    
    private static class Offsets
    {
        private static final Vec3d[] TRAP;
        private static final Vec3d[] CRYSTALFULL;
        private static final Vec3d[] CRYSTALEXA;
        
        static Vec3d[] access$000() {
            return Offsets.TRAP;
        }
        
        static Vec3d[] access$100() {
            return Offsets.CRYSTALEXA;
        }
        
        static Vec3d[] access$200() {
            return Offsets.CRYSTALFULL;
        }
        
        static {
            TRAP = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
            CRYSTALEXA = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(-1.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 1.0), new Vec3d(1.0, 2.0, -1.0), new Vec3d(-1.0, 2.0, 1.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
            CRYSTALFULL = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(-1.0, 0.0, 1.0), new Vec3d(1.0, 0.0, -1.0), new Vec3d(-1.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 1.0), new Vec3d(-1.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 1.0), new Vec3d(1.0, 1.0, -1.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(-1.0, 2.0, 1.0), new Vec3d(1.0, 2.0, -1.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
        }
    }
}
