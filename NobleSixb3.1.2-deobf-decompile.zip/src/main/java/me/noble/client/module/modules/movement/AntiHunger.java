//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.client.*;
import java.util.function.*;

@Module.Info(name = "AntiHunger", category = Module.Category.MOVEMENT, description = "Reduces hunger lost when moving around")
public class AntiHunger extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> packetListener;
    
    private static void lambda$new$0(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketPlayer) {
            ((CPacketPlayer)send.getPacket()).onGround = false;
        }
    }
    
    public AntiHunger() {
        this.packetListener = new Listener<PacketEvent.Send>(AntiHunger::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
}
