//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.server.*;
import net.minecraft.util.*;
import net.minecraft.init.*;
import java.util.function.*;

@Module.Info(name = "NoSoundLag", category = Module.Category.MISC, description = "Prevents lag caused by sound machines")
public class NoSoundLag extends Module
{
    @EventHandler
    Listener<PacketEvent.Receive> receiveListener;
    
    private static void lambda$new$0(final PacketEvent.Receive receive) {
        if (NoSoundLag.mc.player == null) {
            return;
        }
        if (receive.getPacket() instanceof SPacketSoundEffect) {
            final SPacketSoundEffect sPacketSoundEffect = (SPacketSoundEffect)receive.getPacket();
            if (sPacketSoundEffect.getCategory() == SoundCategory.PLAYERS && sPacketSoundEffect.getSound() == SoundEvents.ITEM_ARMOR_EQUIP_GENERIC) {
                receive.cancel();
            }
        }
    }
    
    public NoSoundLag() {
        this.receiveListener = new Listener<PacketEvent.Receive>(NoSoundLag::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
}
