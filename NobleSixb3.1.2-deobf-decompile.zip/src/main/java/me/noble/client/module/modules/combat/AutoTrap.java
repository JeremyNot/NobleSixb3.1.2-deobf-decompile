//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import net.minecraft.util.math.*;
import net.minecraft.network.*;
import net.minecraft.world.*;
import net.minecraft.network.play.client.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.exploits.*;
import net.minecraft.util.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import me.noble.client.util.*;
import java.util.*;
import me.noble.client.setting.*;

@Module.Info(name = "AutoTrap", category = Module.Category.COMBAT)
public class AutoTrap extends Module
{
    private int delayStep;
    private Setting<Boolean> noGlitchBlocks;
    private Setting<Boolean> rotate;
    private int playerHotbarSlot;
    private Setting<Boolean> activeInFreecam;
    private boolean firstRun;
    private Setting<Boolean> announceUsage;
    private Setting<Integer> tickDelay;
    private Setting<Double> range;
    private String lastTickTargetName;
    private int lastHotbarSlot;
    private int offsetStep;
    private Setting<Cage> cage;
    private boolean isSneaking;
    private Setting<Integer> blocksPerTick;
    private EntityPlayer closestTarget;
    
    private boolean placeBlockInRange(final BlockPos blockPos, final double n) {
        final Block getBlock = AutoTrap.mc.world.getBlockState(blockPos).getBlock();
        if (!(getBlock instanceof BlockAir) && !(getBlock instanceof BlockLiquid)) {
            return false;
        }
        for (final Entity entity : AutoTrap.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(blockPos))) {
            if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                return false;
            }
        }
        final EnumFacing placeableSide = BlockInteractionHelper.getPlaceableSide(blockPos);
        if (placeableSide == null) {
            return false;
        }
        final BlockPos offset = blockPos.offset(placeableSide);
        final EnumFacing getOpposite = placeableSide.getOpposite();
        if (!BlockInteractionHelper.canBeClicked(offset)) {
            return false;
        }
        final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
        final Block getBlock2 = AutoTrap.mc.world.getBlockState(offset).getBlock();
        if (AutoTrap.mc.player.getPositionVector().distanceTo(add) > n) {
            return false;
        }
        final int obiInHotbar = this.findObiInHotbar();
        if (obiInHotbar == -1) {
            this.disable();
        }
        if (this.lastHotbarSlot != obiInHotbar) {
            AutoTrap.mc.player.inventory.currentItem = obiInHotbar;
            this.lastHotbarSlot = obiInHotbar;
        }
        if ((!this.isSneaking && BlockInteractionHelper.blackList.contains(getBlock2)) || BlockInteractionHelper.shulkerList.contains(getBlock2)) {
            AutoTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            this.isSneaking = true;
        }
        if (this.rotate.getValue()) {
            BlockInteractionHelper.faceVectorPacketInstant(add);
        }
        AutoTrap.mc.playerController.processRightClickBlock(AutoTrap.mc.player, AutoTrap.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
        AutoTrap.mc.player.swingArm(EnumHand.MAIN_HAND);
        AutoTrap.mc.rightClickDelayTimer = 4;
        if (this.noGlitchBlocks.getValue() && !AutoTrap.mc.playerController.getCurrentGameType().equals((Object)GameType.CREATIVE)) {
            AutoTrap.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, offset, getOpposite));
            if (ModuleManager.getModuleByName("NoBreakAnimation").isEnabled()) {
                ((NoBreakAnimation)ModuleManager.getModuleByName("NoBreakAnimation")).resetMining();
            }
        }
        return true;
    }
    
    protected void onEnable() {
        if (AutoTrap.mc.player == null) {
            this.disable();
            return;
        }
        this.firstRun = true;
        this.playerHotbarSlot = AutoTrap.mc.player.inventory.currentItem;
        this.lastHotbarSlot = -1;
    }
    
    public String getHudInfo() {
        if (this.closestTarget != null) {
            return this.closestTarget.getName().toUpperCase();
        }
        return "NO TARGET";
    }
    
    public void onUpdate() {
        if (AutoTrap.mc.player == null) {
            return;
        }
        if (!this.activeInFreecam.getValue() && ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (!this.firstRun) {
            if (this.delayStep < this.tickDelay.getValue()) {
                ++this.delayStep;
                return;
            }
            this.delayStep = 0;
        }
        this.findClosestTarget();
        if (this.closestTarget == null) {
            if (this.firstRun) {
                this.firstRun = false;
                if (this.announceUsage.getValue()) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap] ").append(ChatFormatting.GREEN.toString()).append("Enabled").append(ChatFormatting.RESET.toString()).append(", waiting for target.")));
                }
            }
            return;
        }
        if (this.firstRun) {
            this.firstRun = false;
            this.lastTickTargetName = this.closestTarget.getName();
            if (this.announceUsage.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap] ").append(ChatFormatting.GREEN.toString()).append("Enabled").append(ChatFormatting.RESET.toString()).append(", target: ").append(this.lastTickTargetName)));
            }
        }
        else if (!this.lastTickTargetName.equals(this.closestTarget.getName())) {
            this.lastTickTargetName = this.closestTarget.getName();
            this.offsetStep = 0;
            if (this.announceUsage.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap] New target: ").append(this.lastTickTargetName)));
            }
        }
        final ArrayList<Object> list = new ArrayList<Object>();
        if (this.cage.getValue().equals(Cage.TRAP)) {
            Collections.addAll(list, Offsets.access$000());
        }
        if (this.cage.getValue().equals(Cage.TRAPFULLROOF)) {
            Collections.addAll(list, Offsets.access$100());
        }
        if (this.cage.getValue().equals(Cage.CRYSTALEXA)) {
            Collections.addAll(list, Offsets.access$200());
        }
        if (this.cage.getValue().equals(Cage.CRYSTAL)) {
            Collections.addAll(list, Offsets.access$300());
        }
        if (this.cage.getValue().equals(Cage.CRYSTALFULLROOF)) {
            Collections.addAll(list, Offsets.access$400());
        }
        int i = 0;
        while (i < this.blocksPerTick.getValue()) {
            if (this.offsetStep >= list.size()) {
                this.offsetStep = 0;
                break;
            }
            final BlockPos blockPos = new BlockPos((Vec3d)list.get(this.offsetStep));
            if (this.placeBlockInRange(new BlockPos(this.closestTarget.getPositionVector()).down().add(blockPos.x, blockPos.y, blockPos.z), this.range.getValue())) {
                ++i;
            }
            ++this.offsetStep;
        }
        if (i > 0) {
            if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                AutoTrap.mc.player.inventory.currentItem = this.playerHotbarSlot;
                this.lastHotbarSlot = this.playerHotbarSlot;
            }
            if (this.isSneaking) {
                AutoTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.isSneaking = false;
            }
        }
    }
    
    private int findObiInHotbar() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = AutoTrap.mc.player.inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    if (((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockObsidian) {
                        n = i;
                        break;
                    }
                }
            }
        }
        return n;
    }
    
    private void findClosestTarget() {
        final List playerEntities = AutoTrap.mc.world.playerEntities;
        this.closestTarget = null;
        for (final EntityPlayer entityPlayer : playerEntities) {
            if (entityPlayer == AutoTrap.mc.player) {
                continue;
            }
            if (Friends.isFriend(entityPlayer.getName())) {
                continue;
            }
            if (!EntityUtil.isLiving((Entity)entityPlayer)) {
                continue;
            }
            if (entityPlayer.getHealth() <= 0.0f) {
                continue;
            }
            if (this.closestTarget == null) {
                this.closestTarget = entityPlayer;
            }
            else {
                if (AutoTrap.mc.player.getDistanceToEntity((Entity)entityPlayer) >= AutoTrap.mc.player.getDistanceToEntity((Entity)this.closestTarget)) {
                    continue;
                }
                this.closestTarget = entityPlayer;
            }
        }
    }
    
    public AutoTrap() {
        this.range = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Range").withMinimum(3.5).withValue(4.5).withMaximum(32.0).build());
        this.blocksPerTick = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("BlocksPerTick").withMinimum(1).withValue(2).withMaximum(23).build());
        this.tickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TickDelay").withMinimum(0).withValue(2).withMaximum(10).build());
        this.cage = (Setting<Cage>)this.register((Setting)Settings.e("Cage", Cage.TRAP));
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", false));
        this.noGlitchBlocks = (Setting<Boolean>)this.register((Setting)Settings.b("NoGlitchBlocks", true));
        this.activeInFreecam = (Setting<Boolean>)this.register((Setting)Settings.b("ActiveInFreecam", true));
        this.announceUsage = (Setting<Boolean>)this.register((Setting)Settings.b("AnnounceUsage", true));
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.delayStep = 0;
        this.isSneaking = false;
        this.offsetStep = 0;
    }
    
    protected void onDisable() {
        if (AutoTrap.mc.player == null) {
            return;
        }
        if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            AutoTrap.mc.player.inventory.currentItem = this.playerHotbarSlot;
        }
        if (this.isSneaking) {
            AutoTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoTrap.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoTrap] ").append(ChatFormatting.RED.toString()).append("Disabled").append(ChatFormatting.RESET.toString()).append("!")));
        }
    }
    
    private enum Cage
    {
        CRYSTALEXA, 
        CRYSTAL, 
        TRAP, 
        CRYSTALFULLROOF;
        
        private static final Cage[] $VALUES;
        
        TRAPFULLROOF;
        
        static {
            $VALUES = new Cage[] { Cage.TRAP, Cage.TRAPFULLROOF, Cage.CRYSTALEXA, Cage.CRYSTAL, Cage.CRYSTALFULLROOF };
        }
    }
    
    private static class Offsets
    {
        private static final Vec3d[] CRYSTALFULLROOF;
        private static final Vec3d[] CRYSTAL;
        private static final Vec3d[] TRAP;
        private static final Vec3d[] CRYSTALEXA;
        private static final Vec3d[] TRAPFULLROOF;
        
        static Vec3d[] access$100() {
            return Offsets.TRAPFULLROOF;
        }
        
        static Vec3d[] access$300() {
            return Offsets.CRYSTAL;
        }
        
        static Vec3d[] access$200() {
            return Offsets.CRYSTALEXA;
        }
        
        static Vec3d[] access$400() {
            return Offsets.CRYSTALFULLROOF;
        }
        
        static {
            TRAP = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
            TRAPFULLROOF = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 1.0), new Vec3d(-1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 0.0) };
            CRYSTALEXA = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(-1.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 1.0), new Vec3d(1.0, 2.0, -1.0), new Vec3d(-1.0, 2.0, 1.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
            CRYSTAL = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(-1.0, 0.0, 1.0), new Vec3d(1.0, 0.0, -1.0), new Vec3d(-1.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 1.0), new Vec3d(-1.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 1.0), new Vec3d(1.0, 1.0, -1.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(-1.0, 2.0, 1.0), new Vec3d(1.0, 2.0, -1.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0) };
            CRYSTALFULLROOF = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(-1.0, 0.0, 1.0), new Vec3d(1.0, 0.0, -1.0), new Vec3d(-1.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 1.0), new Vec3d(-1.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 1.0), new Vec3d(1.0, 1.0, -1.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(-1.0, 2.0, 1.0), new Vec3d(1.0, 2.0, -1.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 1.0), new Vec3d(-1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 0.0) };
        }
        
        static Vec3d[] access$000() {
            return Offsets.TRAP;
        }
    }
}
