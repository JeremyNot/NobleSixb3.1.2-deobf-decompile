//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.item.*;

@Module.Info(category = Module.Category.COMBAT, description = "Changes delay when using items", name = "FastUse")
public class Fastuse extends Module
{
    private Setting<Integer> delay;
    private static long time;
    private Setting<Mode> mode;
    
    static {
        Fastuse.time = 0L;
    }
    
    public Fastuse() {
        this.delay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Delay").withMinimum(0).withMaximum(20).withValue(0).build());
        this.mode = (Setting<Mode>)this.register((Setting)Settings.e("Mode", Mode.BOTH));
    }
    
    public void onUpdate() {
        if (this.delay.getValue() > 0) {
            if (Fastuse.time > 0L) {
                --Fastuse.time;
                Fastuse.mc.rightClickDelayTimer = 1;
                return;
            }
            Fastuse.time = Math.round((float)(2 * Math.round(this.delay.getValue() / 2.0f)));
        }
        if (Fastuse.mc.player == null) {
            return;
        }
        final Item getItem = Fastuse.mc.player.getHeldItemMainhand().getItem();
        final Item getItem2 = Fastuse.mc.player.getHeldItemOffhand().getItem();
        final boolean b = getItem instanceof ItemExpBottle;
        final boolean b2 = getItem2 instanceof ItemExpBottle;
        final boolean b3 = getItem instanceof ItemEndCrystal;
        final boolean b4 = getItem2 instanceof ItemEndCrystal;
        switch (this.mode.getValue()) {
            case ALL: {
                Fastuse.mc.rightClickDelayTimer = 0;
            }
            case BOTH: {
                if (b || b2 || b3 || b4) {
                    Fastuse.mc.rightClickDelayTimer = 0;
                }
            }
            case EXP: {
                if (b || b2) {
                    Fastuse.mc.rightClickDelayTimer = 0;
                }
            }
            case CRYSTAL: {
                if (b3 || b4) {
                    Fastuse.mc.rightClickDelayTimer = 0;
                    break;
                }
                break;
            }
        }
    }
    
    public void onDisable() {
        Fastuse.mc.rightClickDelayTimer = 4;
    }
    
    private enum Mode
    {
        BOTH;
        
        private static final Mode[] $VALUES;
        
        EXP, 
        ALL, 
        CRYSTAL;
        
        static {
            $VALUES = new Mode[] { Mode.ALL, Mode.BOTH, Mode.EXP, Mode.CRYSTAL };
        }
    }
}
