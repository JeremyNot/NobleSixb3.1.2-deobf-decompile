//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import net.minecraftforge.client.event.*;
import me.zero.alpine.listener.*;
import me.noble.client.setting.*;
import java.util.function.*;
import com.mojang.realmsclient.gui.*;
import java.text.*;
import java.util.*;
import net.minecraft.util.text.*;

@Module.Info(name = "ChatTimeStamps", category = Module.Category.CHAT)
public class ChatTimeStamps extends Module
{
    @EventHandler
    public Listener<ClientChatReceivedEvent> listener;
    private Setting<Boolean> deco;
    
    public ChatTimeStamps() {
        this.deco = (Setting<Boolean>)this.register((Setting)Settings.b("Deco", true));
        this.listener = new Listener<ClientChatReceivedEvent>(this::lambda$new$0, (Predicate<ClientChatReceivedEvent>[])new Predicate[0]);
    }
    
    private void lambda$new$0(final ClientChatReceivedEvent clientChatReceivedEvent) {
        final TextComponentString message = new TextComponentString(String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append(this.deco.getValue() ? "<" : "").append(new SimpleDateFormat("k:mm").format(new Date())).append(this.deco.getValue() ? ">" : "").append(ChatFormatting.RESET).append(" ")));
        message.appendSibling(clientChatReceivedEvent.getMessage());
        clientChatReceivedEvent.setMessage((ITextComponent)message);
    }
}
