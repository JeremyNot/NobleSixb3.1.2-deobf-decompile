//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.zero.alpine.listener.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraft.block.state.*;
import net.minecraft.init.*;
import net.minecraft.enchantment.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import java.util.function.*;

@Module.Info(name = "AutoTool", description = "Automatically switch to the best tools when mining or attacking", category = Module.Category.MISC)
public class AutoTool extends Module
{
    @EventHandler
    private Listener<PlayerInteractEvent.LeftClickBlock> leftClickListener;
    @EventHandler
    private Listener<AttackEntityEvent> attackListener;
    
    private void equipBestTool(final IBlockState blockState) {
        int n = -1;
        double n2 = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = AutoTool.mc.player.inventory.getStackInSlot(i);
            if (!getStackInSlot.field_190928_g) {
                final float getStrVsBlock = getStackInSlot.getStrVsBlock(blockState);
                if (getStrVsBlock > 1.0f) {
                    final int getEnchantmentLevel;
                    final float n3 = (float)(getStrVsBlock + (((getEnchantmentLevel = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, getStackInSlot)) > 0) ? (Math.pow(getEnchantmentLevel, 2.0) + 1.0) : 0.0));
                    if (n3 > n2) {
                        n2 = n3;
                        n = i;
                    }
                }
            }
        }
        if (n != -1) {
            equip(n);
        }
    }
    
    public static void equipBestWeapon() {
        int n = -1;
        double n2 = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = AutoTool.mc.player.inventory.getStackInSlot(i);
            if (!getStackInSlot.field_190928_g) {
                if (getStackInSlot.getItem() instanceof ItemTool) {
                    final double n3 = ((ItemTool)getStackInSlot.getItem()).damageVsEntity + (double)EnchantmentHelper.getModifierForCreature(getStackInSlot, EnumCreatureAttribute.UNDEFINED);
                    if (n3 > n2) {
                        n2 = n3;
                        n = i;
                    }
                }
                else if (getStackInSlot.getItem() instanceof ItemSword) {
                    final double n4 = ((ItemSword)getStackInSlot.getItem()).getDamageVsEntity() + (double)EnchantmentHelper.getModifierForCreature(getStackInSlot, EnumCreatureAttribute.UNDEFINED);
                    if (n4 > n2) {
                        n2 = n4;
                        n = i;
                    }
                }
            }
        }
        if (n != -1) {
            equip(n);
        }
    }
    
    private static void lambda$new$1(final AttackEntityEvent attackEntityEvent) {
        equipBestWeapon();
    }
    
    public AutoTool() {
        this.leftClickListener = new Listener<PlayerInteractEvent.LeftClickBlock>(this::lambda$new$0, (Predicate<PlayerInteractEvent.LeftClickBlock>[])new Predicate[0]);
        this.attackListener = new Listener<AttackEntityEvent>(AutoTool::lambda$new$1, (Predicate<AttackEntityEvent>[])new Predicate[0]);
    }
    
    private void lambda$new$0(final PlayerInteractEvent.LeftClickBlock leftClickBlock) {
        this.equipBestTool(AutoTool.mc.world.getBlockState(leftClickBlock.getPos()));
    }
    
    private static void equip(final int currentItem) {
        AutoTool.mc.player.inventory.currentItem = currentItem;
        AutoTool.mc.playerController.syncCurrentPlayItem();
    }
}
