//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.entity.*;
import net.minecraft.network.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import me.noble.client.module.*;
import net.minecraft.entity.item.*;
import me.noble.client.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.network.play.client.*;
import me.noble.client.module.modules.exploits.*;
import java.util.*;
import net.minecraft.util.*;
import me.noble.client.setting.*;
import net.minecraft.item.*;
import net.minecraft.block.*;

@Module.Info(name = "Surround3", category = Module.Category.COMBAT)
public class Surround3 extends Module
{
    private boolean isSneaking;
    private int offsetStep;
    private int lastHotbarSlot;
    private Setting<Integer> timeoutTicks;
    private int playerHotbarSlot;
    private Setting<Boolean> triggerable;
    private Setting<Mode> mode;
    private Setting<Boolean> rotate;
    private Setting<Boolean> noGlitchBlocks;
    private Setting<Integer> blocksPerTick;
    private int delayStep;
    private Setting<Integer> tickDelay;
    private boolean firstRun;
    private int totalTicksRunning;
    private Setting<Boolean> announceUsage;
    
    protected void onDisable() {
        if (Surround3.mc.player == null) {
            return;
        }
        if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            Surround3.mc.player.inventory.currentItem = this.playerHotbarSlot;
        }
        if (this.isSneaking) {
            Surround3.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Surround3.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround3] ").append(ChatFormatting.RED.toString()).append("Disabled!")));
        }
    }
    
    public void onUpdate() {
        if (Surround3.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (this.triggerable.getValue() && this.totalTicksRunning >= this.timeoutTicks.getValue()) {
            this.totalTicksRunning = 0;
            this.disable();
            return;
        }
        if (!this.firstRun) {
            if (this.delayStep < this.tickDelay.getValue()) {
                ++this.delayStep;
                return;
            }
            this.delayStep = 0;
        }
        if (this.firstRun) {
            this.firstRun = false;
        }
        int i = 0;
        while (i < this.blocksPerTick.getValue()) {
            Vec3d[] array = new Vec3d[0];
            int n = 0;
            if (this.mode.getValue().equals(Mode.FULL)) {
                array = Offsets.access$000();
                n = Offsets.access$000().length;
            }
            if (this.mode.getValue().equals(Mode.SURROUND)) {
                array = Offsets.access$100();
                n = Offsets.access$100().length;
            }
            if (this.offsetStep >= n) {
                this.offsetStep = 0;
                break;
            }
            final BlockPos blockPos = new BlockPos(array[this.offsetStep]);
            if (this.placeBlock(new BlockPos(Surround3.mc.player.getPositionVector()).add(blockPos.x, blockPos.y, blockPos.z))) {
                ++i;
            }
            ++this.offsetStep;
        }
        if (i > 0) {
            if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                Surround3.mc.player.inventory.currentItem = this.playerHotbarSlot;
                this.lastHotbarSlot = this.playerHotbarSlot;
            }
            if (this.isSneaking) {
                Surround3.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Surround3.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.isSneaking = false;
            }
        }
        ++this.totalTicksRunning;
    }
    
    private boolean placeBlock(final BlockPos blockPos) {
        final Block getBlock = Surround3.mc.world.getBlockState(blockPos).getBlock();
        if (!(getBlock instanceof BlockAir) && !(getBlock instanceof BlockLiquid)) {
            return false;
        }
        for (final Entity entity : Surround3.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(blockPos))) {
            if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                return false;
            }
        }
        final EnumFacing placeableSide = BlockInteractionHelper.getPlaceableSide(blockPos);
        if (placeableSide == null) {
            return false;
        }
        final BlockPos offset = blockPos.offset(placeableSide);
        final EnumFacing getOpposite = placeableSide.getOpposite();
        if (!BlockInteractionHelper.canBeClicked(offset)) {
            return false;
        }
        final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
        final Block getBlock2 = Surround3.mc.world.getBlockState(offset).getBlock();
        final int obiInHotbar = this.findObiInHotbar();
        if (obiInHotbar == -1) {
            this.disable();
        }
        if (this.lastHotbarSlot != obiInHotbar) {
            Surround3.mc.player.inventory.currentItem = obiInHotbar;
            this.lastHotbarSlot = obiInHotbar;
        }
        if ((!this.isSneaking && BlockInteractionHelper.blackList.contains(getBlock2)) || BlockInteractionHelper.shulkerList.contains(getBlock2)) {
            Surround3.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Surround3.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            this.isSneaking = true;
        }
        if (this.rotate.getValue()) {
            BlockInteractionHelper.faceVectorPacketInstant(add);
        }
        Surround3.mc.playerController.processRightClickBlock(Surround3.mc.player, Surround3.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
        Surround3.mc.player.swingArm(EnumHand.MAIN_HAND);
        Surround3.mc.rightClickDelayTimer = 4;
        if (this.noGlitchBlocks.getValue() && !Surround3.mc.playerController.getCurrentGameType().equals((Object)GameType.CREATIVE)) {
            Surround3.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, offset, getOpposite));
            if (ModuleManager.getModuleByName("NoBreakAnimation").isEnabled()) {
                ((NoBreakAnimation)ModuleManager.getModuleByName("NoBreakAnimation")).resetMining();
            }
        }
        return true;
    }
    
    public Surround3() {
        this.mode = (Setting<Mode>)this.register((Setting)Settings.e("Mode", Mode.FULL));
        this.triggerable = (Setting<Boolean>)this.register((Setting)Settings.b("Triggerable", true));
        this.timeoutTicks = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TimeoutTicks").withMinimum(1).withValue(40).withMaximum(100).withVisibility(this::lambda$new$0).build());
        this.blocksPerTick = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("BlocksPerTick").withMinimum(1).withValue(4).withMaximum(9).build());
        this.tickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TickDelay").withMinimum(0).withValue(0).withMaximum(10).build());
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", true));
        this.noGlitchBlocks = (Setting<Boolean>)this.register((Setting)Settings.b("NoGlitchBlocks", true));
        this.announceUsage = (Setting<Boolean>)this.register((Setting)Settings.b("AnnounceUsage", true));
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.offsetStep = 0;
        this.delayStep = 0;
        this.totalTicksRunning = 0;
        this.isSneaking = false;
    }
    
    private int findObiInHotbar() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = Surround3.mc.player.inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    if (((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockObsidian) {
                        n = i;
                        break;
                    }
                }
            }
        }
        return n;
    }
    
    protected void onEnable() {
        if (Surround3.mc.player == null) {
            this.disable();
            return;
        }
        this.firstRun = true;
        this.playerHotbarSlot = Surround3.mc.player.inventory.currentItem;
        this.lastHotbarSlot = -1;
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround3] ").append(ChatFormatting.GREEN.toString()).append("Enabled!")));
        }
    }
    
    private boolean lambda$new$0(final Integer n) {
        return this.triggerable.getValue();
    }
    
    private static class Offsets
    {
        private static final Vec3d[] FULL;
        private static final Vec3d[] SURROUND;
        
        static {
            SURROUND = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0) };
            FULL = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0), new Vec3d(0.0, -1.0, 0.0) };
        }
        
        static Vec3d[] access$000() {
            return Offsets.FULL;
        }
        
        static Vec3d[] access$100() {
            return Offsets.SURROUND;
        }
    }
    
    private enum Mode
    {
        SURROUND;
        
        private static final Mode[] $VALUES;
        
        FULL;
        
        static {
            $VALUES = new Mode[] { Mode.SURROUND, Mode.FULL };
        }
    }
}
