//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import me.noble.client.setting.*;

@Module.Info(name = "PrefixChat", category = Module.Category.GUI, description = "Opens chat with prefix inside when prefix is pressed.")
public class PrefixChat extends Module
{
    public Setting<Boolean> startupGlobal;
    
    public PrefixChat() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", true));
    }
}
