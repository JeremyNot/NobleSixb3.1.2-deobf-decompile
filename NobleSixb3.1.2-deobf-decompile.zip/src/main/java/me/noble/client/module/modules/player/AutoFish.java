//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.server.*;
import net.minecraft.init.*;
import java.util.function.*;

@Module.Info(name = "AutoFish", category = Module.Category.MISC, description = "Automatically catch fish")
public class AutoFish extends Module
{
    @EventHandler
    private Listener<PacketEvent.Receive> receiveListener;
    
    private static void lambda$new$1(final PacketEvent.Receive receive) {
        if (AutoFish.mc.player != null && (AutoFish.mc.player.getHeldItemMainhand().getItem() == Items.FISHING_ROD || AutoFish.mc.player.getHeldItemOffhand().getItem() == Items.FISHING_ROD) && receive.getPacket() instanceof SPacketSoundEffect && SoundEvents.ENTITY_BOBBER_SPLASH.equals(((SPacketSoundEffect)receive.getPacket()).getSound())) {
            new Thread(AutoFish::lambda$null$0).start();
        }
    }
    
    public AutoFish() {
        this.receiveListener = new Listener<PacketEvent.Receive>(AutoFish::lambda$new$1, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    private static void lambda$null$0() {
        try {
            Thread.sleep(200L);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        AutoFish.mc.rightClickMouse();
        try {
            Thread.sleep(200L);
        }
        catch (InterruptedException ex2) {
            ex2.printStackTrace();
        }
        AutoFish.mc.rightClickMouse();
    }
}
