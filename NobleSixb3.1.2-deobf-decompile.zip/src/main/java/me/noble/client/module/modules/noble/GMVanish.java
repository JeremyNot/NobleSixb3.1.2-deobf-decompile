//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import net.minecraft.entity.*;
import me.noble.client.module.*;
import net.minecraft.client.network.*;
import java.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

@Module.Info(name = "NobleVanish", category = Module.Category.NOBLE, description = "Godmode Vanish")
public class GMVanish extends Module
{
    public Entity entity;
    
    public void onUpdate() {
        if (this.isDisabled() || GMVanish.mc.player == null || ModuleManager.isModuleEnabled("NobleFreecam")) {
            return;
        }
        if (this.entity != null) {
            this.entity.posX = GMVanish.mc.player.posX;
            this.entity.posY = GMVanish.mc.player.posY;
            this.entity.posZ = GMVanish.mc.player.posZ;
            try {
                Objects.requireNonNull(GMVanish.mc.getConnection()).sendPacket((Packet)new CPacketVehicleMove(this.entity));
            }
            catch (Exception ex) {
                System.out.println("ERROR: Dude we kinda have a problem here:");
                ex.printStackTrace();
            }
        }
    }
    
    public void onEnable() {
        if (GMVanish.mc.player == null || GMVanish.mc.player.getRidingEntity() == null) {
            this.disable();
            return;
        }
        this.entity = GMVanish.mc.player.getRidingEntity();
        GMVanish.mc.player.dismountRidingEntity();
        GMVanish.mc.world.removeEntity(this.entity);
    }
}
