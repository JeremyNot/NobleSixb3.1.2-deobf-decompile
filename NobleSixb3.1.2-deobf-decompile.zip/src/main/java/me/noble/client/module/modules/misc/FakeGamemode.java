//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import net.minecraft.world.*;
import me.noble.client.setting.*;
import net.minecraft.client.*;
import me.noble.client.command.*;

@Module.Info(name = "FakeGamemode", description = "Fakes your current gamemode client side", category = Module.Category.MISC)
public class FakeGamemode extends Module
{
    private Setting<GamemodeChanged> gamemode;
    private GameType gameType;
    private Setting<Boolean> disable2b;
    
    public void onEnable() {
        if (FakeGamemode.mc.player == null) {
            this.disable();
            return;
        }
        this.gameType = FakeGamemode.mc.playerController.getCurrentGameType();
    }
    
    public FakeGamemode() {
        this.gamemode = (Setting<GamemodeChanged>)this.register((Setting)Settings.e("Mode", GamemodeChanged.CREATIVE));
        this.disable2b = (Setting<Boolean>)this.register((Setting)Settings.b("AntiKick 2b2t", true));
    }
    
    public void onUpdate() {
        if (FakeGamemode.mc.player == null) {
            return;
        }
        if (Minecraft.getMinecraft().getCurrentServerData() == null || (Minecraft.getMinecraft().getCurrentServerData() != null && Minecraft.getMinecraft().getCurrentServerData().serverIP.equalsIgnoreCase("2b2t.org"))) {
            if (FakeGamemode.mc.player.dimension == 1 && this.disable2b.getValue()) {
                Command.sendWarningMessage("[FakeGamemode] Using this on 2b2t queue might get you kicked, please disable the AntiKick option if you're sure");
                this.disable();
            }
            return;
        }
        if (this.gamemode.getValue().equals(GamemodeChanged.CREATIVE)) {
            FakeGamemode.mc.playerController.setGameType(this.gameType);
            FakeGamemode.mc.playerController.setGameType(GameType.CREATIVE);
        }
        else if (this.gamemode.getValue().equals(GamemodeChanged.SURVIVAL)) {
            FakeGamemode.mc.playerController.setGameType(this.gameType);
            FakeGamemode.mc.playerController.setGameType(GameType.SURVIVAL);
        }
        else if (this.gamemode.getValue().equals(GamemodeChanged.ADVENTURE)) {
            FakeGamemode.mc.playerController.setGameType(this.gameType);
            FakeGamemode.mc.playerController.setGameType(GameType.ADVENTURE);
        }
        else if (this.gamemode.getValue().equals(GamemodeChanged.SPECTATOR)) {
            FakeGamemode.mc.playerController.setGameType(this.gameType);
            FakeGamemode.mc.playerController.setGameType(GameType.SPECTATOR);
        }
    }
    
    public void onDisable() {
        if (FakeGamemode.mc.player == null) {
            return;
        }
        FakeGamemode.mc.playerController.setGameType(this.gameType);
    }
    
    private enum GamemodeChanged
    {
        CREATIVE, 
        SPECTATOR, 
        SURVIVAL, 
        ADVENTURE;
        
        private static final GamemodeChanged[] $VALUES;
        
        static {
            $VALUES = new GamemodeChanged[] { GamemodeChanged.SURVIVAL, GamemodeChanged.CREATIVE, GamemodeChanged.ADVENTURE, GamemodeChanged.SPECTATOR };
        }
    }
}
