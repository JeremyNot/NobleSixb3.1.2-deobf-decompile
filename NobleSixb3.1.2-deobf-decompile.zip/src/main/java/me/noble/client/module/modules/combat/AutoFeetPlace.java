//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import me.noble.client.util.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.player.*;
import java.util.*;
import net.minecraft.util.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import me.noble.client.setting.*;

@Module.Info(name = "AutoFeetPlace", category = Module.Category.COMBAT, description = "Continually places obsidian around your feet")
public class AutoFeetPlace extends Module
{
    private Setting<Integer> tickDelay;
    private boolean firstRun;
    private int offsetStep;
    private Setting<Boolean> triggerable;
    private boolean isSneaking;
    private boolean missingObiDisable;
    private Setting<Boolean> disableNone;
    private int delayStep;
    private Setting<Integer> blocksPerTick;
    private Setting<Integer> timeoutTicks;
    private int playerHotbarSlot;
    private Setting<Mode> mode;
    private Setting<Boolean> infoMessage;
    private int lastHotbarSlot;
    private int totalTicksRunning;
    private Setting<Boolean> rotate;
    
    private boolean placeBlock(final BlockPos blockPos) {
        final Block getBlock = AutoFeetPlace.mc.world.getBlockState(blockPos).getBlock();
        if (!(getBlock instanceof BlockAir) && !(getBlock instanceof BlockLiquid)) {
            return false;
        }
        for (final Entity entity : AutoFeetPlace.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(blockPos))) {
            if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                return false;
            }
        }
        final EnumFacing placeableSide = getPlaceableSide(blockPos);
        if (placeableSide == null) {
            return false;
        }
        final BlockPos offset = blockPos.offset(placeableSide);
        final EnumFacing getOpposite = placeableSide.getOpposite();
        if (!BlockInteractionHelper.canBeClicked(offset)) {
            return false;
        }
        final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
        final Block getBlock2 = AutoFeetPlace.mc.world.getBlockState(offset).getBlock();
        final int obiInHotbar = this.findObiInHotbar();
        if (obiInHotbar == -1) {
            this.missingObiDisable = true;
            return false;
        }
        if (this.lastHotbarSlot != obiInHotbar) {
            AutoFeetPlace.mc.player.inventory.currentItem = obiInHotbar;
            this.lastHotbarSlot = obiInHotbar;
        }
        if ((!this.isSneaking && BlockInteractionHelper.blackList.contains(getBlock2)) || BlockInteractionHelper.shulkerList.contains(getBlock2)) {
            AutoFeetPlace.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoFeetPlace.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            this.isSneaking = true;
        }
        if (this.rotate.getValue()) {
            BlockInteractionHelper.faceVectorPacketInstant(add);
        }
        AutoFeetPlace.mc.playerController.processRightClickBlock(AutoFeetPlace.mc.player, AutoFeetPlace.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
        AutoFeetPlace.mc.player.swingArm(EnumHand.MAIN_HAND);
        AutoFeetPlace.mc.rightClickDelayTimer = 4;
        if (ModuleManager.getModuleByName("NoBreakAnimation").isEnabled()) {
            ((NoBreakAnimation)ModuleManager.getModuleByName("NoBreakAnimation")).resetMining();
        }
        return true;
    }
    
    protected void onDisable() {
        if (AutoFeetPlace.mc.player == null) {
            return;
        }
        if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            AutoFeetPlace.mc.player.inventory.currentItem = this.playerHotbarSlot;
        }
        if (this.isSneaking) {
            AutoFeetPlace.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoFeetPlace.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.missingObiDisable = false;
    }
    
    private static EnumFacing getPlaceableSide(final BlockPos blockPos) {
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            if (AutoFeetPlace.mc.world.getBlockState(offset).getBlock().canCollideCheck(AutoFeetPlace.mc.world.getBlockState(offset), false)) {
                if (!AutoFeetPlace.mc.world.getBlockState(offset).getMaterial().isReplaceable()) {
                    return enumFacing;
                }
            }
        }
        return null;
    }
    
    private boolean lambda$new$0(final Integer n) {
        return this.triggerable.getValue();
    }
    
    public void onUpdate() {
        if (AutoFeetPlace.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (this.triggerable.getValue() && this.totalTicksRunning >= this.timeoutTicks.getValue()) {
            this.totalTicksRunning = 0;
            this.disable();
            return;
        }
        if (!this.firstRun) {
            if (this.delayStep < this.tickDelay.getValue()) {
                ++this.delayStep;
                return;
            }
            this.delayStep = 0;
        }
        if (this.firstRun) {
            this.firstRun = false;
            if (this.findObiInHotbar() == -1) {
                this.missingObiDisable = true;
            }
        }
        Vec3d[] array = new Vec3d[0];
        int n = 0;
        if (this.mode.getValue().equals(Mode.FULL)) {
            array = Offsets.access$000();
            n = Offsets.access$000().length;
        }
        if (this.mode.getValue().equals(Mode.SURROUND)) {
            array = Offsets.access$100();
            n = Offsets.access$100().length;
        }
        int i = 0;
        while (i < this.blocksPerTick.getValue()) {
            if (this.offsetStep >= n) {
                this.offsetStep = 0;
                break;
            }
            final BlockPos blockPos = new BlockPos(array[this.offsetStep]);
            if (this.placeBlock(new BlockPos(AutoFeetPlace.mc.player.getPositionVector()).add(blockPos.x, blockPos.y, blockPos.z))) {
                ++i;
            }
            ++this.offsetStep;
        }
        if (i > 0) {
            if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                AutoFeetPlace.mc.player.inventory.currentItem = this.playerHotbarSlot;
                this.lastHotbarSlot = this.playerHotbarSlot;
            }
            if (this.isSneaking) {
                AutoFeetPlace.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoFeetPlace.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.isSneaking = false;
            }
        }
        ++this.totalTicksRunning;
        if (this.missingObiDisable && this.disableNone.getValue()) {
            this.missingObiDisable = false;
            if (this.infoMessage.getValue()) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoFeetPlace] ").append(ChatFormatting.RED).append("Disabled").append(ChatFormatting.RESET).append(", Obsidian missing!")));
            }
            this.disable();
        }
    }
    
    private int findObiInHotbar() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = AutoFeetPlace.mc.player.inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    if (((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockObsidian) {
                        n = i;
                        break;
                    }
                }
            }
        }
        return n;
    }
    
    protected void onEnable() {
        if (AutoFeetPlace.mc.player == null) {
            this.disable();
            return;
        }
        this.firstRun = true;
        this.playerHotbarSlot = AutoFeetPlace.mc.player.inventory.currentItem;
        this.lastHotbarSlot = -1;
    }
    
    public AutoFeetPlace() {
        this.mode = (Setting<Mode>)this.register((Setting)Settings.e("Mode", Mode.FULL));
        this.triggerable = (Setting<Boolean>)this.register((Setting)Settings.b("Triggerable", true));
        this.disableNone = (Setting<Boolean>)this.register((Setting)Settings.b("DisableNoObby", true));
        this.timeoutTicks = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TimeoutTicks").withMinimum(1).withValue(40).withMaximum(100).withVisibility(this::lambda$new$0).build());
        this.blocksPerTick = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("BlocksPerTick").withMinimum(1).withValue(4).withMaximum(9).build());
        this.tickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("TickDelay").withMinimum(0).withValue(0).withMaximum(10).build());
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", true));
        this.infoMessage = (Setting<Boolean>)this.register((Setting)Settings.b("InfoMessage", false));
        this.offsetStep = 0;
        this.delayStep = 0;
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.isSneaking = false;
        this.totalTicksRunning = 0;
        this.missingObiDisable = false;
    }
    
    private static class Offsets
    {
        private static final Vec3d[] FULL;
        private static final Vec3d[] SURROUND;
        
        static Vec3d[] access$000() {
            return Offsets.FULL;
        }
        
        static {
            SURROUND = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0) };
            FULL = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0), new Vec3d(0.0, -1.0, 0.0) };
        }
        
        static Vec3d[] access$100() {
            return Offsets.SURROUND;
        }
    }
    
    private enum Mode
    {
        SURROUND, 
        FULL;
        
        private static final Mode[] $VALUES;
        
        static {
            $VALUES = new Mode[] { Mode.SURROUND, Mode.FULL };
        }
    }
}
