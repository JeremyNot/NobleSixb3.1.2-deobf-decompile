//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.noble.client.util.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import net.minecraft.init.*;
import me.noble.client.setting.*;

@Module.Info(name = "HopperNuker", category = Module.Category.COMBAT)
public class HopperNuker extends Module
{
    private Setting<Double> range;
    private int oldSlot;
    private Setting<Boolean> pickswitch;
    private boolean isMining;
    
    public void onUpdate() {
        final BlockPos nearestHopper = this.getNearestHopper();
        if (nearestHopper != null) {
            if (!this.isMining) {
                this.oldSlot = Wrapper.getPlayer().inventory.currentItem;
                this.isMining = true;
            }
            final float[] calcAngle = BlockInteractionHelper.calcAngle(Wrapper.getPlayer().getPositionEyes(Wrapper.getMinecraft().getRenderPartialTicks()), new Vec3d((double)(nearestHopper.getX() + 0.5f), (double)(nearestHopper.getY() + 0.5f), (double)(nearestHopper.getZ() + 0.5f)));
            Wrapper.getPlayer().rotationYaw = calcAngle[0];
            Wrapper.getPlayer().rotationYawHead = calcAngle[0];
            Wrapper.getPlayer().rotationPitch = calcAngle[1];
            if (this.canBreak(nearestHopper)) {
                if (this.pickswitch.getValue()) {
                    int currentItem = -1;
                    for (int i = 0; i < 9; ++i) {
                        final ItemStack getStackInSlot = Wrapper.getPlayer().inventory.getStackInSlot(i);
                        if (getStackInSlot != ItemStack.field_190927_a) {
                            if (getStackInSlot.getItem() instanceof ItemPickaxe) {
                                currentItem = i;
                                break;
                            }
                        }
                    }
                    if (currentItem != -1) {
                        Wrapper.getPlayer().inventory.currentItem = currentItem;
                    }
                }
                Wrapper.getMinecraft().playerController.onPlayerDamageBlock(nearestHopper, Wrapper.getPlayer().getHorizontalFacing());
                Wrapper.getPlayer().swingArm(EnumHand.MAIN_HAND);
            }
        }
        else if (this.pickswitch.getValue() && this.oldSlot != -1) {
            Wrapper.getPlayer().inventory.currentItem = this.oldSlot;
            this.oldSlot = -1;
            this.isMining = false;
        }
    }
    
    private boolean canBreak(final BlockPos blockPos) {
        final IBlockState getBlockState = Wrapper.getWorld().getBlockState(blockPos);
        return getBlockState.getBlock().getBlockHardness(getBlockState, Wrapper.getWorld(), blockPos) != -1.0f;
    }
    
    private BlockPos getNearestHopper() {
        Double value = this.range.getValue();
        BlockPos blockPos = null;
        for (Double value2 = value; value2 >= -value; --value2) {
            for (Double value3 = value; value3 >= -value; --value3) {
                for (Double value4 = value; value4 >= -value; --value4) {
                    final BlockPos blockPos2 = new BlockPos(Wrapper.getPlayer().posX + value2, Wrapper.getPlayer().posY + value3, Wrapper.getPlayer().posZ + value4);
                    final double getDistance = Wrapper.getPlayer().getDistance((double)blockPos2.getX(), (double)blockPos2.getY(), (double)blockPos2.getZ());
                    if (getDistance <= value && Wrapper.getWorld().getBlockState(blockPos2).getBlock() == Blocks.HOPPER && this.canBreak(blockPos2) && blockPos2.getY() >= Wrapper.getPlayer().posY) {
                        value = getDistance;
                        blockPos = blockPos2;
                    }
                }
            }
        }
        return blockPos;
    }
    
    public HopperNuker() {
        this.range = (Setting<Double>)this.register((Setting)Settings.d("Range", 5.5));
        this.pickswitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch", false));
        this.oldSlot = -1;
        this.isMining = false;
    }
}
