//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;

@Module.Info(name = "Timer", category = Module.Category.PLAYER, description = "Changes your client tick speed")
public class Timer extends Module
{
    private Setting<Float> speed;
    
    public void onUpdate() {
        Timer.mc.timer.field_194149_e = 50.0f / this.speed.getValue();
    }
    
    public Timer() {
        this.speed = (Setting<Float>)this.register((SettingBuilder)Settings.floatBuilder("Speed").withMinimum(1.0f).withMaximum(11.0f).withValue(2.0f));
    }
    
    public void onDisable() {
        Timer.mc.timer.field_194149_e = 50.0f;
    }
}
