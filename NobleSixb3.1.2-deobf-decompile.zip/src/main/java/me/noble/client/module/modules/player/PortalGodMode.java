//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.client.*;
import java.util.function.*;

@Module.Info(name = "PortalGodMode", category = Module.Category.PLAYER, description = "Don't take damage in portals")
public class PortalGodMode extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> listener;
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (this.isEnabled() && send.getPacket() instanceof CPacketConfirmTeleport) {
            send.cancel();
        }
    }
    
    public PortalGodMode() {
        this.listener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
}
