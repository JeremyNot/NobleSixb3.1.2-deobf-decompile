//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import me.noble.client.util.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;

@Module.Info(name = "TimerSpeed", description = "Automatically change your timer to go fast", category = Module.Category.MOVEMENT)
public class TimerSpeed extends Module
{
    private Setting<Float> fastSpeed;
    private Setting<Float> attemptSpeed;
    private Setting<Float> maxSpeed;
    private static float curSpeed;
    private float tickDelay;
    private Setting<Float> minimumSpeed;
    
    public static String returnGui() {
        return String.valueOf(new StringBuilder().append("").append(InfoCalculator.round(TimerSpeed.curSpeed, 2)));
    }
    
    public void onDisable() {
        TimerSpeed.mc.timer.field_194149_e = 50.0f;
    }
    
    public void onUpdate() {
        if (this.tickDelay == this.minimumSpeed.getValue()) {
            TimerSpeed.curSpeed = this.fastSpeed.getValue();
            TimerSpeed.mc.timer.field_194149_e = 50.0f / this.fastSpeed.getValue();
        }
        if (this.tickDelay >= this.maxSpeed.getValue()) {
            this.tickDelay = 0.0f;
            TimerSpeed.curSpeed = this.attemptSpeed.getValue();
            TimerSpeed.mc.timer.field_194149_e = 50.0f / this.attemptSpeed.getValue();
        }
        ++this.tickDelay;
    }
    
    static {
        TimerSpeed.curSpeed = 0.0f;
    }
    
    public TimerSpeed() {
        this.tickDelay = 0.0f;
        this.minimumSpeed = (Setting<Float>)this.register((SettingBuilder)Settings.floatBuilder("Minimum Speed").withMinimum(0.1f).withMaximum(10.0f).withValue(4.0f));
        this.maxSpeed = (Setting<Float>)this.register((SettingBuilder)Settings.floatBuilder("Max Speed").withMinimum(0.1f).withMaximum(10.0f).withValue(7.0f));
        this.attemptSpeed = (Setting<Float>)this.register((SettingBuilder)Settings.floatBuilder("Attempt Speed").withMinimum(1.0f).withMaximum(10.0f).withValue(4.2f));
        this.fastSpeed = (Setting<Float>)this.register((SettingBuilder)Settings.floatBuilder("Fast Speed").withMinimum(1.0f).withMaximum(10.0f).withValue(5.0f));
    }
}
