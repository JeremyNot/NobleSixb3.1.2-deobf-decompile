//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import java.text.*;
import me.noble.client.module.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import java.math.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import me.noble.client.util.*;
import me.noble.client.command.*;
import net.minecraft.util.math.*;
import me.noble.client.setting.*;

@Module.Info(name = "DispenserMeta", category = Module.Category.COMBAT, description = "Do not use with any AntiGhostBlock Mod!")
public class DispenserMeta extends Module
{
    private int obiSlot;
    private int hopperSlot;
    private boolean isSneaking;
    private Setting<Boolean> grabItem;
    private int stage;
    private Setting<Boolean> autoEnableHitAura;
    private BlockPos placeTarget;
    private int shulkerSlot;
    private int redstoneSlot;
    private Setting<Boolean> debugMessages;
    private static final DecimalFormat df;
    private Setting<Boolean> rotate;
    private int dispenserSlot;
    private Setting<Boolean> autoEnableBypass;
    
    static {
        df = new DecimalFormat("#.#");
    }
    
    public void onUpdate() {
        if (DispenserMeta.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (this.stage == 0) {
            DispenserMeta.mc.player.inventory.currentItem = this.obiSlot;
            this.placeBlock(new BlockPos((Vec3i)this.placeTarget), EnumFacing.DOWN);
            DispenserMeta.mc.player.inventory.currentItem = this.dispenserSlot;
            this.placeBlock(new BlockPos((Vec3i)this.placeTarget.add(0, 1, 0)), EnumFacing.DOWN);
            DispenserMeta.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)DispenserMeta.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
            DispenserMeta.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placeTarget.add(0, 1, 0), EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.stage = 1;
            return;
        }
        if (this.stage == 1) {
            if (!(DispenserMeta.mc.currentScreen instanceof GuiContainer)) {
                return;
            }
            DispenserMeta.mc.playerController.windowClick(DispenserMeta.mc.player.openContainer.windowId, 1, this.shulkerSlot, ClickType.SWAP, (EntityPlayer)DispenserMeta.mc.player);
            DispenserMeta.mc.player.closeScreen();
            DispenserMeta.mc.player.inventory.currentItem = this.redstoneSlot;
            this.placeBlock(new BlockPos((Vec3i)this.placeTarget.add(0, 2, 0)), EnumFacing.DOWN);
            this.stage = 2;
        }
        else {
            if (this.stage != 2) {
                if (this.stage == 3) {
                    if (!(DispenserMeta.mc.currentScreen instanceof GuiContainer)) {
                        return;
                    }
                    if (((GuiContainer)DispenserMeta.mc.currentScreen).inventorySlots.getSlot(0).getStack().field_190928_g) {
                        return;
                    }
                    DispenserMeta.mc.playerController.windowClick(DispenserMeta.mc.player.openContainer.windowId, 0, DispenserMeta.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)DispenserMeta.mc.player);
                    if (this.autoEnableHitAura.getValue()) {
                        ModuleManager.getModuleByName("Aura").enable();
                    }
                    this.disable();
                }
                return;
            }
            final Block getBlock = DispenserMeta.mc.world.getBlockState(this.placeTarget.offset(DispenserMeta.mc.player.getHorizontalFacing().getOpposite()).up()).getBlock();
            if (getBlock instanceof BlockAir || getBlock instanceof BlockLiquid) {
                return;
            }
            DispenserMeta.mc.player.inventory.currentItem = this.hopperSlot;
            this.placeBlock(new BlockPos((Vec3i)this.placeTarget.offset(DispenserMeta.mc.player.getHorizontalFacing().getOpposite())), DispenserMeta.mc.player.getHorizontalFacing());
            DispenserMeta.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)DispenserMeta.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
            DispenserMeta.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placeTarget.offset(DispenserMeta.mc.player.getHorizontalFacing().getOpposite()), EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            DispenserMeta.mc.player.inventory.currentItem = this.shulkerSlot;
            if (!this.grabItem.getValue()) {
                this.disable();
                return;
            }
            this.stage = 3;
        }
    }
    
    protected void onEnable() {
        if (DispenserMeta.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            this.disable();
            return;
        }
        DispenserMeta.df.setRoundingMode(RoundingMode.CEILING);
        this.stage = 0;
        this.placeTarget = null;
        this.obiSlot = -1;
        this.dispenserSlot = -1;
        this.shulkerSlot = -1;
        this.redstoneSlot = -1;
        this.hopperSlot = -1;
        this.isSneaking = false;
        for (int redstoneSlot = 0; redstoneSlot < 9 && (this.obiSlot == -1 || this.dispenserSlot == -1 || this.shulkerSlot == -1 || this.redstoneSlot == -1 || this.hopperSlot == -1); ++redstoneSlot) {
            final ItemStack getStackInSlot = DispenserMeta.mc.player.inventory.getStackInSlot(redstoneSlot);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (getStackInSlot.getItem() instanceof ItemBlock) {
                    final Block getBlock = ((ItemBlock)getStackInSlot.getItem()).getBlock();
                    if (getBlock == Blocks.HOPPER) {
                        this.hopperSlot = redstoneSlot;
                    }
                    else if (BlockInteractionHelper.shulkerList.contains(getBlock)) {
                        this.shulkerSlot = redstoneSlot;
                    }
                    else if (getBlock == Blocks.OBSIDIAN) {
                        this.obiSlot = redstoneSlot;
                    }
                    else if (getBlock == Blocks.DISPENSER) {
                        this.dispenserSlot = redstoneSlot;
                    }
                    else if (getBlock == Blocks.REDSTONE_BLOCK) {
                        this.redstoneSlot = redstoneSlot;
                    }
                }
            }
        }
        if (this.obiSlot == -1 || this.dispenserSlot == -1 || this.shulkerSlot == -1 || this.redstoneSlot == -1 || this.hopperSlot == -1) {
            if (this.debugMessages.getValue()) {
                Command.sendChatMessage("[Auto32k] Items missing, disabling.");
            }
            this.disable();
            return;
        }
        if (DispenserMeta.mc.objectMouseOver == null || DispenserMeta.mc.objectMouseOver.getBlockPos() == null || DispenserMeta.mc.objectMouseOver.getBlockPos().up() == null) {
            if (this.debugMessages.getValue()) {
                Command.sendChatMessage("[Auto32k] Not a valid place target, disabling.");
            }
            this.disable();
            return;
        }
        this.placeTarget = DispenserMeta.mc.objectMouseOver.getBlockPos().up();
        if (this.autoEnableBypass.getValue()) {
            ModuleManager.getModuleByName("IllegalItemBypass").enable();
        }
        if (this.debugMessages.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Auto32k] Place Target: ").append(this.placeTarget.x).append(" ").append(this.placeTarget.y).append(" ").append(this.placeTarget.z).append(" Distance: ").append(DispenserMeta.df.format(DispenserMeta.mc.player.getPositionVector().distanceTo(new Vec3d((Vec3i)this.placeTarget))))));
        }
    }
    
    private void placeBlock(final BlockPos blockPos, final EnumFacing enumFacing) {
        final BlockPos offset = blockPos.offset(enumFacing);
        final EnumFacing getOpposite = enumFacing.getOpposite();
        if (!this.isSneaking) {
            DispenserMeta.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)DispenserMeta.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            this.isSneaking = true;
        }
        final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
        if (this.rotate.getValue()) {
            BlockInteractionHelper.faceVectorPacketInstant(add);
        }
        DispenserMeta.mc.playerController.processRightClickBlock(DispenserMeta.mc.player, DispenserMeta.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
        DispenserMeta.mc.player.swingArm(EnumHand.MAIN_HAND);
    }
    
    public DispenserMeta() {
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", false));
        this.grabItem = (Setting<Boolean>)this.register((Setting)Settings.b("Grab Item", false));
        this.autoEnableHitAura = (Setting<Boolean>)this.register((Setting)Settings.b("Auto enable Hit Aura", false));
        this.autoEnableBypass = (Setting<Boolean>)this.register((Setting)Settings.b("Auto enable Illegals Bypass", false));
        this.debugMessages = (Setting<Boolean>)this.register((Setting)Settings.b("Debug Messages", false));
    }
}
