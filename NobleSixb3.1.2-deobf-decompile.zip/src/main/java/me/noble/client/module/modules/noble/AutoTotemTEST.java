//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.item.*;
import java.util.concurrent.atomic.*;
import net.minecraft.init.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import java.util.*;
import java.util.function.*;

@Module.Info(name = "AutoTotemTEST", category = Module.Category.NOBLE, description = "Auto Totem")
public class AutoTotemTEST extends Module
{
    private int preferredTotemSlot;
    private Setting<Boolean> soft;
    private int numOfTotems;
    private Setting<Boolean> pauseInInventory;
    private Setting<Boolean> pauseInContainers;
    
    public void disableSoft() {
        this.soft.setValue(false);
    }
    
    public AutoTotemTEST() {
        this.soft = (Setting<Boolean>)this.register((Setting)Settings.b("Soft", false));
        this.pauseInContainers = (Setting<Boolean>)this.register((Setting)Settings.b("PauseInContainers", true));
        this.pauseInInventory = (Setting<Boolean>)this.register((Setting)Settings.b("PauseInInventory", true));
    }
    
    private static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        return getInventorySlots(9, 44);
    }
    
    private void lambda$findTotems$0(final AtomicInteger atomicInteger, final Integer n, final ItemStack itemStack) {
        int func_190916_E = 0;
        if (itemStack.getItem().equals(Items.field_190929_cY)) {
            func_190916_E = itemStack.func_190916_E();
            if (atomicInteger.get() < func_190916_E) {
                atomicInteger.set(func_190916_E);
                this.preferredTotemSlot = n;
            }
        }
        this.numOfTotems += func_190916_E;
    }
    
    public void onUpdate() {
        if (AutoTotemTEST.mc.player == null) {
            return;
        }
        if (!this.findTotems()) {
            return;
        }
        if (this.pauseInContainers.getValue() && AutoTotemTEST.mc.currentScreen instanceof GuiContainer && !(AutoTotemTEST.mc.currentScreen instanceof GuiInventory)) {
            return;
        }
        if (this.pauseInInventory.getValue() && AutoTotemTEST.mc.currentScreen instanceof GuiInventory && AutoTotemTEST.mc.currentScreen instanceof GuiInventory) {
            return;
        }
        if (this.soft.getValue()) {
            if (AutoTotemTEST.mc.player.getHeldItemOffhand().getItem().equals(Items.field_190931_a)) {
                AutoTotemTEST.mc.playerController.windowClick(0, this.preferredTotemSlot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemTEST.mc.player);
                AutoTotemTEST.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemTEST.mc.player);
                AutoTotemTEST.mc.playerController.updateController();
            }
        }
        else if (!AutoTotemTEST.mc.player.getHeldItemOffhand().getItem().equals(Items.field_190929_cY)) {
            boolean b = false;
            if (AutoTotemTEST.mc.player.getHeldItemOffhand().getItem().equals(Items.field_190931_a)) {
                b = true;
            }
            AutoTotemTEST.mc.playerController.windowClick(0, this.preferredTotemSlot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemTEST.mc.player);
            AutoTotemTEST.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemTEST.mc.player);
            if (!b) {
                AutoTotemTEST.mc.playerController.windowClick(0, this.preferredTotemSlot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemTEST.mc.player);
            }
            AutoTotemTEST.mc.playerController.updateController();
        }
    }
    
    private static Map<Integer, ItemStack> getInventorySlots(int i, final int n) {
        final HashMap<Integer, Object> hashMap = (HashMap<Integer, Object>)new HashMap<Integer, ItemStack>();
        while (i <= n) {
            hashMap.put(i, AutoTotemTEST.mc.player.inventoryContainer.getInventory().get(i));
            ++i;
        }
        return (Map<Integer, ItemStack>)hashMap;
    }
    
    private boolean findTotems() {
        this.numOfTotems = 0;
        final AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.set(Integer.MIN_VALUE);
        getInventoryAndHotbarSlots().forEach((BiConsumer<? super Integer, ? super ItemStack>)this::lambda$findTotems$0);
        if (AutoTotemTEST.mc.player.getHeldItemOffhand().getItem().equals(Items.field_190929_cY)) {
            this.numOfTotems += AutoTotemTEST.mc.player.getHeldItemOffhand().func_190916_E();
        }
        return this.numOfTotems != 0;
    }
}
