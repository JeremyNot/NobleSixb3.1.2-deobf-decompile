//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;

@Module.Info(name = "AutoJump", category = Module.Category.MOVEMENT, description = "Automatically jumps if possible")
public class AutoJump extends Module
{
    public void onUpdate() {
        if (AutoJump.mc.player.isInWater() || AutoJump.mc.player.isInLava()) {
            AutoJump.mc.player.motionY = 0.1;
        }
        else if (AutoJump.mc.player.onGround) {
            AutoJump.mc.player.jump();
        }
    }
}
