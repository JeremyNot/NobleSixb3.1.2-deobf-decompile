//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import net.minecraft.entity.*;
import me.zero.alpine.listener.*;
import net.minecraftforge.client.event.*;
import me.noble.client.event.events.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;
import net.minecraft.world.*;
import net.minecraft.client.entity.*;

@Module.Info(name = "Freecam2", category = Module.Category.PLAYER, description = "Leave your body and trascend into the realm of the gods")
public class Freecam2 extends Module
{
    private float yaw;
    private double posY;
    private double posZ;
    private Entity ridingEntity;
    @EventHandler
    private Listener<PlayerMoveEvent> moveListener;
    private double posX;
    private boolean isRidingEntity;
    private float pitch;
    @EventHandler
    private Listener<PlayerSPPushOutOfBlocksEvent> pushListener;
    private EntityOtherPlayerMP clonedPlayer;
    @EventHandler
    private Listener<PacketEvent.Send> sendListener;
    private Setting<Integer> speed;
    
    public Freecam2() {
        this.speed = (Setting<Integer>)this.register((Setting)Settings.i("Speed", 5));
        this.moveListener = new Listener<PlayerMoveEvent>(Freecam2::lambda$new$0, (Predicate<PlayerMoveEvent>[])new Predicate[0]);
        this.pushListener = new Listener<PlayerSPPushOutOfBlocksEvent>(Freecam2::lambda$new$1, (Predicate<PlayerSPPushOutOfBlocksEvent>[])new Predicate[0]);
        this.sendListener = new Listener<PacketEvent.Send>(Freecam2::lambda$new$2, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private static void lambda$new$0(final PlayerMoveEvent playerMoveEvent) {
        Freecam2.mc.player.noClip = true;
    }
    
    private static void lambda$new$2(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketPlayer || send.getPacket() instanceof CPacketInput) {
            send.cancel();
        }
    }
    
    protected void onEnable() {
        if (Freecam2.mc.player != null) {
            this.isRidingEntity = (Freecam2.mc.player.getRidingEntity() != null);
            if (Freecam2.mc.player.getRidingEntity() == null) {
                this.posX = Freecam2.mc.player.posX;
                this.posY = Freecam2.mc.player.posY;
                this.posZ = Freecam2.mc.player.posZ;
            }
            else {
                this.ridingEntity = Freecam2.mc.player.getRidingEntity();
                Freecam2.mc.player.dismountRidingEntity();
            }
            this.pitch = Freecam2.mc.player.rotationPitch;
            this.yaw = Freecam2.mc.player.rotationYaw;
            (this.clonedPlayer = new EntityOtherPlayerMP((World)Freecam2.mc.world, Freecam2.mc.getSession().getProfile())).copyLocationAndAnglesFrom((Entity)Freecam2.mc.player);
            this.clonedPlayer.rotationYawHead = Freecam2.mc.player.rotationYawHead;
            Freecam2.mc.world.addEntityToWorld(-100, (Entity)this.clonedPlayer);
            Freecam2.mc.player.capabilities.isFlying = true;
            Freecam2.mc.player.capabilities.setFlySpeed(this.speed.getValue() / 100.0f);
            Freecam2.mc.player.noClip = true;
        }
    }
    
    public void onUpdate() {
        Freecam2.mc.player.capabilities.isFlying = true;
        Freecam2.mc.player.capabilities.setFlySpeed(this.speed.getValue() / 100.0f);
        Freecam2.mc.player.noClip = true;
        Freecam2.mc.player.onGround = false;
        Freecam2.mc.player.fallDistance = 0.0f;
    }
    
    private static void lambda$new$1(final PlayerSPPushOutOfBlocksEvent playerSPPushOutOfBlocksEvent) {
        playerSPPushOutOfBlocksEvent.setCanceled(true);
    }
    
    protected void onDisable() {
        if (Freecam2.mc.player != null) {
            Freecam2.mc.player.setPositionAndRotation(this.posX, this.posY, this.posZ, this.yaw, this.pitch);
            Freecam2.mc.world.removeEntityFromWorld(-100);
            this.clonedPlayer = null;
            this.posZ = 0.0;
            this.posY = 0.0;
            this.posX = 0.0;
            this.yaw = 0.0f;
            this.pitch = 0.0f;
            Freecam2.mc.player.capabilities.isFlying = false;
            Freecam2.mc.player.capabilities.setFlySpeed(0.05f);
            Freecam2.mc.player.noClip = false;
            final EntityPlayerSP player = Freecam2.mc.player;
            final EntityPlayerSP player2 = Freecam2.mc.player;
            Freecam2.mc.player.motionZ = 0.0;
            player2.motionY = 0.0;
            player.motionX = 0.0;
            if (this.isRidingEntity) {
                Freecam2.mc.player.startRiding(this.ridingEntity, true);
            }
        }
    }
}
