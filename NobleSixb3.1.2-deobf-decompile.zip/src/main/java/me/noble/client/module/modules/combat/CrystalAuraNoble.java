//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import net.minecraft.entity.player.*;
import me.zero.alpine.listener.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import net.minecraft.entity.item.*;
import me.noble.client.event.events.*;
import me.noble.client.setting.*;
import net.minecraft.world.*;
import java.awt.*;
import java.util.function.*;
import net.minecraft.item.*;
import java.util.stream.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.chat.*;
import net.minecraft.network.*;
import net.minecraft.client.entity.*;
import net.minecraft.init.*;
import me.noble.client.util.*;
import java.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.enchantment.*;
import net.minecraft.util.math.*;

@Module.Info(name = "CrystalAuraHeph", category = Module.Category.COMBAT)
public class CrystalAuraNoble extends Module
{
    private Setting<Integer> red;
    private EntityPlayer target;
    private boolean switchCooldown;
    private Setting<Boolean> place;
    private Setting<Double> hitRange;
    private Setting<Boolean> announceUsage;
    private static boolean togglePitch;
    private BlockPos renderBlock;
    private Setting<Boolean> explode;
    private Setting<Double> placeRange;
    private Setting<Integer> blue;
    private int newSlot;
    private Setting<Boolean> antiWeakness;
    private Setting<Boolean> spoofRotations;
    private Setting<Double> minDamage;
    private Setting<Integer> green;
    private Setting<Boolean> rayTraceHit;
    private Setting<RenderMode> renderMode;
    @EventHandler
    private Listener<PacketEvent.Send> packetListener;
    private static double yaw;
    private Setting<Integer> hitTickDelay;
    private boolean isAttacking;
    private Setting<Boolean> autoSwitch;
    private static boolean isSpoofingAngles;
    private static double pitch;
    private int hitDelayCounter;
    private int oldSlot;
    private Setting<Integer> alpha;
    
    public void onDisable() {
        this.renderBlock = null;
        this.target = null;
        resetRotation();
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[CrystalAuraHeph] ").append(ChatFormatting.RED.toString()).append("Disabled!")));
        }
    }
    
    private static void resetRotation() {
        if (CrystalAuraNoble.isSpoofingAngles) {
            CrystalAuraNoble.yaw = CrystalAuraNoble.mc.player.rotationYaw;
            CrystalAuraNoble.pitch = CrystalAuraNoble.mc.player.rotationPitch;
            CrystalAuraNoble.isSpoofingAngles = false;
        }
    }
    
    private boolean rayTraceHitCheck(final EntityEnderCrystal entityEnderCrystal) {
        return !this.rayTraceHit.getValue() || CrystalAuraNoble.mc.player.canEntityBeSeen((Entity)entityEnderCrystal);
    }
    
    private static boolean lambda$onUpdate$1(final Entity entity) {
        return entity instanceof EntityEnderCrystal;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (this.renderBlock != null && !this.renderMode.getValue().equals(RenderMode.NONE)) {
            this.drawBlock(this.renderBlock, this.red.getValue(), this.green.getValue(), this.blue.getValue());
        }
    }
    
    private static void setYawAndPitch(final float n, final float n2) {
        CrystalAuraNoble.yaw = n;
        CrystalAuraNoble.pitch = n2;
        CrystalAuraNoble.isSpoofingAngles = true;
    }
    
    private static EntityEnderCrystal lambda$onUpdate$2(final Entity entity) {
        return (EntityEnderCrystal)entity;
    }
    
    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(CrystalAuraNoble.mc.player.posX), Math.floor(CrystalAuraNoble.mc.player.posY), Math.floor(CrystalAuraNoble.mc.player.posZ));
    }
    
    private static float getDamageMultiplied(final float n) {
        final int getDifficultyId = CrystalAuraNoble.mc.world.getDifficulty().getDifficultyId();
        return n * ((getDifficultyId == 0) ? 0.0f : ((getDifficultyId == 2) ? 1.0f : ((getDifficultyId == 1) ? 0.5f : 1.5f)));
    }
    
    public String getHudInfo() {
        if (this.target == null) {
            return "";
        }
        return this.target.getName().toUpperCase();
    }
    
    public CrystalAuraNoble() {
        this.place = (Setting<Boolean>)this.register((Setting)Settings.b("Place", true));
        this.explode = (Setting<Boolean>)this.register((Setting)Settings.b("Explode", true));
        this.autoSwitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch", true));
        this.antiWeakness = (Setting<Boolean>)this.register((Setting)Settings.b("Anti Weakness", true));
        this.spoofRotations = (Setting<Boolean>)this.register((Setting)Settings.b("Spoof Rotations", false));
        this.rayTraceHit = (Setting<Boolean>)this.register((Setting)Settings.b("RayTraceHit", false));
        this.renderMode = (Setting<RenderMode>)this.register((Setting)Settings.e("Render Mode", RenderMode.UP));
        this.hitTickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Hit Delay").withMinimum(0).withValue(4).withMaximum(20).build());
        this.hitRange = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Hit Range").withMinimum(0.0).withValue(5.5).build());
        this.placeRange = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Place Range").withMinimum(0.0).withValue(3.5).build());
        this.minDamage = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Min Damage").withMinimum(0.0).withValue(2.0).withMaximum(20.0).build());
        this.red = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Red").withMinimum(0).withValue(104).withMaximum(255).build());
        this.green = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Green").withMinimum(0).withValue(12).withMaximum(255).build());
        this.blue = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Blue").withMinimum(0).withValue(35).withMaximum(255).build());
        this.alpha = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Alpha").withMinimum(0).withValue(169).withMaximum(255).build());
        this.announceUsage = (Setting<Boolean>)this.register((Setting)Settings.b("EZZZZZZZZZZZZ", true));
        this.switchCooldown = false;
        this.isAttacking = false;
        this.oldSlot = -1;
        this.packetListener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    static float calculateDamage(final double n, final double n2, final double n3, final Entity entity) {
        final float n4 = 12.0f;
        final double n5 = (1.0 - entity.getDistance(n, n2, n3) / n4) * entity.world.getBlockDensity(new Vec3d(n, n2, n3), entity.getEntityBoundingBox());
        final float n6 = (float)(int)((n5 * n5 + n5) / 2.0 * 7.0 * n4 + 1.0);
        double n7 = 1.0;
        if (entity instanceof EntityLivingBase) {
            n7 = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(n6), new Explosion((World)CrystalAuraNoble.mc.world, (Entity)null, n, n2, n3, 6.0f, false, true));
        }
        return (float)n7;
    }
    
    private void lookAtPacket(final double n, final double n2, final double n3, final EntityPlayer entityPlayer) {
        final double[] calculateLook = EntityUtil.calculateLookAt(n, n2, n3, entityPlayer);
        setYawAndPitch((float)calculateLook[0], (float)calculateLook[1]);
    }
    
    static {
        CrystalAuraNoble.togglePitch = false;
    }
    
    private static int lambda$onUpdate$5(final Entity entity, final Entity entity2) {
        return Float.compare(CrystalAuraNoble.mc.player.getDistanceToEntity(entity), CrystalAuraNoble.mc.player.getDistanceToEntity(entity2));
    }
    
    private void drawBlock(final BlockPos blockPos, final int n, final int n2, final int n3) {
        final Color color = new Color(n, n2, n3, this.alpha.getValue());
        KamiTessellator.prepare(7);
        if (this.renderMode.getValue().equals(RenderMode.UP)) {
            KamiTessellator.drawBox(blockPos, color.getRGB(), 2);
        }
        else if (this.renderMode.getValue().equals(RenderMode.BLOCK)) {
            KamiTessellator.drawBox(blockPos, color.getRGB(), 63);
        }
        KamiTessellator.release();
    }
    
    public void onUpdate() {
        if (CrystalAuraNoble.mc.player == null) {
            return;
        }
        final EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal)CrystalAuraNoble.mc.world.loadedEntityList.stream().filter(CrystalAuraNoble::lambda$onUpdate$1).map(CrystalAuraNoble::lambda$onUpdate$2).min(Comparator.comparing((Function<? super T, ? extends Comparable>)CrystalAuraNoble::lambda$onUpdate$3)).orElse(null);
        if (this.explode.getValue() && entityEnderCrystal != null && CrystalAuraNoble.mc.player.getDistanceToEntity((Entity)entityEnderCrystal) <= this.hitRange.getValue() && this.rayTraceHitCheck(entityEnderCrystal)) {
            if (this.hitDelayCounter >= this.hitTickDelay.getValue()) {
                this.hitDelayCounter = 0;
                if (this.antiWeakness.getValue() && CrystalAuraNoble.mc.player.isPotionActive(MobEffects.WEAKNESS)) {
                    if (!this.isAttacking) {
                        this.oldSlot = CrystalAuraNoble.mc.player.inventory.currentItem;
                        this.isAttacking = true;
                    }
                    this.newSlot = -1;
                    for (int i = 0; i < 9; ++i) {
                        final ItemStack getStackInSlot = CrystalAuraNoble.mc.player.inventory.getStackInSlot(i);
                        if (getStackInSlot != ItemStack.field_190927_a) {
                            if (getStackInSlot.getItem() instanceof ItemSword) {
                                this.newSlot = i;
                                break;
                            }
                            if (getStackInSlot.getItem() instanceof ItemTool) {
                                this.newSlot = i;
                                break;
                            }
                        }
                    }
                    if (this.newSlot != -1) {
                        CrystalAuraNoble.mc.player.inventory.currentItem = this.newSlot;
                        this.switchCooldown = true;
                    }
                }
                this.lookAtPacket(entityEnderCrystal.posX, entityEnderCrystal.posY, entityEnderCrystal.posZ, (EntityPlayer)CrystalAuraNoble.mc.player);
                CrystalAuraNoble.mc.playerController.attackEntity((EntityPlayer)CrystalAuraNoble.mc.player, (Entity)entityEnderCrystal);
                CrystalAuraNoble.mc.player.swingArm(EnumHand.MAIN_HAND);
                return;
            }
            ++this.hitDelayCounter;
        }
        else {
            resetRotation();
            if (this.oldSlot != -1) {
                CrystalAuraNoble.mc.player.inventory.currentItem = this.oldSlot;
                this.oldSlot = -1;
            }
            this.isAttacking = false;
            int currentItem = (CrystalAuraNoble.mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) ? CrystalAuraNoble.mc.player.inventory.currentItem : -1;
            if (currentItem == -1) {
                for (int j = 0; j < 9; ++j) {
                    if (CrystalAuraNoble.mc.player.inventory.getStackInSlot(j).getItem() == Items.END_CRYSTAL) {
                        currentItem = j;
                        break;
                    }
                }
            }
            boolean b = false;
            if (CrystalAuraNoble.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
                b = true;
            }
            else if (currentItem == -1) {
                return;
            }
            final List list = (List)CrystalAuraNoble.mc.world.playerEntities.stream().filter(CrystalAuraNoble::lambda$onUpdate$4).sorted(CrystalAuraNoble::lambda$onUpdate$5).collect(Collectors.toList());
            final List<BlockPos> crystalBlocks = this.findCrystalBlocks();
            BlockPos renderBlock = null;
            double n = 0.0;
            this.target = null;
            for (final Entity entity : list) {
                if (entity == CrystalAuraNoble.mc.player) {
                    continue;
                }
                if (!(entity instanceof EntityPlayer)) {
                    continue;
                }
                final EntityPlayer target = (EntityPlayer)entity;
                if (target.isDead) {
                    continue;
                }
                if (target.getHealth() <= 0.0f) {
                    continue;
                }
                for (final BlockPos blockPos : crystalBlocks) {
                    if (target.getDistanceSq(blockPos) >= 169.0) {
                        continue;
                    }
                    final double n2 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, (Entity)target);
                    final double n3 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, (Entity)CrystalAuraNoble.mc.player);
                    final float n4 = target.getHealth() + target.getAbsorptionAmount();
                    final float n5 = CrystalAuraNoble.mc.player.getHealth() + CrystalAuraNoble.mc.player.getAbsorptionAmount();
                    if (n2 < this.minDamage.getValue()) {
                        continue;
                    }
                    if (n3 >= n5 - 0.5) {
                        continue;
                    }
                    if (n3 > n2 && n2 < n4) {
                        continue;
                    }
                    if (n2 <= n) {
                        continue;
                    }
                    renderBlock = blockPos;
                    n = n2;
                    this.target = target;
                }
                if (this.target != null) {
                    break;
                }
            }
            if (this.target == null) {
                this.renderBlock = null;
                resetRotation();
                return;
            }
            this.renderBlock = renderBlock;
            if (ModuleManager.getModuleByName("AutoGG").isEnabled()) {
                ((AutoGG)ModuleManager.getModuleByName("AutoGG")).addTargetedPlayer(this.target.getName());
            }
            if (this.place.getValue()) {
                if (!b && CrystalAuraNoble.mc.player.inventory.currentItem != currentItem) {
                    if (this.autoSwitch.getValue()) {
                        CrystalAuraNoble.mc.player.inventory.currentItem = currentItem;
                        resetRotation();
                        this.switchCooldown = true;
                    }
                    return;
                }
                this.lookAtPacket(renderBlock.x + 0.5, renderBlock.y - 0.5, renderBlock.z + 0.5, (EntityPlayer)CrystalAuraNoble.mc.player);
                final RayTraceResult rayTraceBlocks = CrystalAuraNoble.mc.world.rayTraceBlocks(new Vec3d(CrystalAuraNoble.mc.player.posX, CrystalAuraNoble.mc.player.posY + CrystalAuraNoble.mc.player.getEyeHeight(), CrystalAuraNoble.mc.player.posZ), new Vec3d(renderBlock.x + 0.5, renderBlock.y - 0.5, renderBlock.z + 0.5));
                EnumFacing enumFacing;
                if (rayTraceBlocks == null || rayTraceBlocks.sideHit == null) {
                    enumFacing = EnumFacing.UP;
                }
                else {
                    enumFacing = rayTraceBlocks.sideHit;
                }
                if (this.switchCooldown) {
                    this.switchCooldown = false;
                    return;
                }
                CrystalAuraNoble.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(renderBlock, enumFacing, b ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            }
            if (this.spoofRotations.getValue() && CrystalAuraNoble.isSpoofingAngles) {
                if (CrystalAuraNoble.togglePitch) {
                    final EntityPlayerSP player = CrystalAuraNoble.mc.player;
                    player.rotationPitch += (float)4.0E-4;
                    CrystalAuraNoble.togglePitch = false;
                }
                else {
                    final EntityPlayerSP player2 = CrystalAuraNoble.mc.player;
                    player2.rotationPitch -= (float)4.0E-4;
                    CrystalAuraNoble.togglePitch = true;
                }
            }
        }
    }
    
    private static boolean lambda$onUpdate$4(final EntityPlayer entityPlayer) {
        return !Friends.isFriend(entityPlayer.getName());
    }
    
    private boolean canPlaceCrystal(final BlockPos blockPos) {
        final BlockPos add = blockPos.add(0, 1, 0);
        final BlockPos add2 = blockPos.add(0, 2, 0);
        return (CrystalAuraNoble.mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || CrystalAuraNoble.mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && CrystalAuraNoble.mc.world.getBlockState(add).getBlock() == Blocks.AIR && CrystalAuraNoble.mc.world.getBlockState(add2).getBlock() == Blocks.AIR && CrystalAuraNoble.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add)).isEmpty() && CrystalAuraNoble.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add2)).isEmpty();
    }
    
    private List<BlockPos> findCrystalBlocks() {
        final NonNullList func_191196_a = NonNullList.func_191196_a();
        func_191196_a.addAll((Collection)BlockInteractionHelper.getSphere(getPlayerPos(), this.placeRange.getValue().floatValue(), this.placeRange.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::canPlaceCrystal).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return (List<BlockPos>)func_191196_a;
    }
    
    private static Float lambda$onUpdate$3(final EntityEnderCrystal entityEnderCrystal) {
        return CrystalAuraNoble.mc.player.getDistanceToEntity((Entity)entityEnderCrystal);
    }
    
    public void onEnable() {
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[CrystalAuraHeph] ").append(ChatFormatting.GREEN.toString()).append("Enabled!")));
        }
        this.hitDelayCounter = 0;
    }
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (!this.spoofRotations.getValue()) {
            return;
        }
        final Packet packet = send.getPacket();
        if (packet instanceof CPacketPlayer && CrystalAuraNoble.isSpoofingAngles) {
            ((CPacketPlayer)packet).yaw = (float)CrystalAuraNoble.yaw;
            ((CPacketPlayer)packet).pitch = (float)CrystalAuraNoble.pitch;
        }
    }
    
    private static float getBlastReduction(final EntityLivingBase entityLivingBase, float n, final Explosion explosion) {
        if (entityLivingBase instanceof EntityPlayer) {
            final EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            final DamageSource causeExplosionDamage = DamageSource.causeExplosionDamage(explosion);
            n = CombatRules.getDamageAfterAbsorb(n, (float)entityPlayer.getTotalArmorValue(), (float)entityPlayer.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            n *= 1.0f - MathHelper.clamp((float)EnchantmentHelper.getEnchantmentModifierDamage(entityPlayer.getArmorInventoryList(), causeExplosionDamage), 0.0f, 20.0f) / 25.0f;
            if (entityLivingBase.isPotionActive(MobEffects.RESISTANCE)) {
                n -= n / 4.0f;
            }
            return n;
        }
        n = CombatRules.getDamageAfterAbsorb(n, (float)entityLivingBase.getTotalArmorValue(), (float)entityLivingBase.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
        return n;
    }
    
    private enum RenderMode
    {
        BLOCK, 
        NONE, 
        UP;
        
        private static final RenderMode[] $VALUES;
        
        static {
            $VALUES = new RenderMode[] { RenderMode.UP, RenderMode.BLOCK, RenderMode.NONE };
        }
    }
}
