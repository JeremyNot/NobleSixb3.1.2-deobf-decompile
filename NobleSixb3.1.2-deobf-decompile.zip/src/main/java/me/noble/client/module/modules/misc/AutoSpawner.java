//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import me.noble.client.module.modules.combat.*;
import me.noble.client.module.*;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.block.state.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.block.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.item.*;

@Module.Info(name = "AutoSpawner", category = Module.Category.MISC, description = "Automatically spawns Withers, Iron Golems and Snowmen")
public class AutoSpawner extends Module
{
    private int headSlot;
    private boolean rotationPlaceableX;
    private static boolean isSneaking;
    private Setting<Integer> delay;
    private Setting<UseMode> useMode;
    private Setting<Boolean> notifications;
    private boolean rotationPlaceableZ;
    private Setting<Float> placeRange;
    private Setting<Boolean> rotate;
    private Setting<Boolean> party;
    private int delayStep;
    private BlockPos placeTarget;
    private Setting<EntityMode> entityMode;
    private Setting<Boolean> partyWithers;
    private int buildStage;
    private int bodySlot;
    
    private boolean lambda$new$1(final Object o) {
        return !this.party.getValue();
    }
    
    public String getHudInfo() {
        if (!this.party.getValue()) {
            return this.entityMode.getValue().toString();
        }
        if (this.partyWithers.getValue()) {
            return "PARTY WITHER";
        }
        return "PARTY";
    }
    
    private boolean testIronGolemStructure() {
        boolean b = true;
        this.rotationPlaceableX = true;
        this.rotationPlaceableZ = true;
        boolean b2 = false;
        if (AutoSpawner.mc.world.getBlockState(this.placeTarget) == null) {
            return false;
        }
        final Block getBlock = AutoSpawner.mc.world.getBlockState(this.placeTarget).getBlock();
        if (getBlock instanceof BlockTallGrass || getBlock instanceof BlockDeadBush) {
            b2 = true;
        }
        if (getPlaceableSide(this.placeTarget.up()) == null) {
            return false;
        }
        final BlockPos[] access$000 = BodyParts.access$000();
        for (int length = access$000.length, i = 0; i < length; ++i) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$000[i]))) {
                b = false;
            }
        }
        for (final BlockPos blockPos : BodyParts.access$100()) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos)) || this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos.down()))) {
                this.rotationPlaceableX = false;
            }
        }
        for (final BlockPos blockPos2 : BodyParts.access$200()) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos2)) || this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos2.down()))) {
                this.rotationPlaceableZ = false;
            }
        }
        final BlockPos[] access$4 = BodyParts.access$500();
        for (int length4 = access$4.length, l = 0; l < length4; ++l) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$4[l]))) {
                b = false;
            }
        }
        return !b2 && b && (this.rotationPlaceableX || this.rotationPlaceableZ);
    }
    
    private boolean testStructure() {
        if (this.entityMode.getValue().equals(EntityMode.WITHER)) {
            return this.testWitherStructure();
        }
        if (this.entityMode.getValue().equals(EntityMode.IRON)) {
            return this.testIronGolemStructure();
        }
        return this.entityMode.getValue().equals(EntityMode.SNOW) && this.testSnowGolemStructure();
    }
    
    private boolean testSnowGolemStructure() {
        boolean b = true;
        boolean b2 = false;
        if (AutoSpawner.mc.world.getBlockState(this.placeTarget) == null) {
            return false;
        }
        final Block getBlock = AutoSpawner.mc.world.getBlockState(this.placeTarget).getBlock();
        if (getBlock instanceof BlockTallGrass || getBlock instanceof BlockDeadBush) {
            b2 = true;
        }
        if (getPlaceableSide(this.placeTarget.up()) == null) {
            return false;
        }
        final BlockPos[] access$000 = BodyParts.access$000();
        for (int length = access$000.length, i = 0; i < length; ++i) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$000[i]))) {
                b = false;
            }
        }
        final BlockPos[] access$2 = BodyParts.access$500();
        for (int length2 = access$2.length, j = 0; j < length2; ++j) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$2[j]))) {
                b = false;
            }
        }
        return !b2 && b;
    }
    
    private static void placeBlock(final BlockPos blockPos, final boolean b) {
        final EnumFacing placeableSide = getPlaceableSide(blockPos);
        if (placeableSide == null) {
            return;
        }
        final BlockPos offset = blockPos.offset(placeableSide);
        final EnumFacing getOpposite = placeableSide.getOpposite();
        final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
        final Block getBlock = AutoSpawner.mc.world.getBlockState(offset).getBlock();
        if (!AutoSpawner.isSneaking && (BlockInteractionHelper.blackList.contains(getBlock) || BlockInteractionHelper.shulkerList.contains(getBlock))) {
            AutoSpawner.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoSpawner.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            AutoSpawner.isSneaking = true;
        }
        if (b) {
            BlockInteractionHelper.faceVectorPacketInstant(add);
        }
        AutoSpawner.mc.playerController.processRightClickBlock(AutoSpawner.mc.player, AutoSpawner.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
        AutoSpawner.mc.player.swingArm(EnumHand.MAIN_HAND);
        AutoSpawner.mc.rightClickDelayTimer = 4;
    }
    
    public void onUpdate() {
        if (AutoSpawner.mc.player == null) {
            return;
        }
        if (this.buildStage == 1) {
            AutoSpawner.isSneaking = false;
            this.rotationPlaceableX = false;
            this.rotationPlaceableZ = false;
            if (this.party.getValue()) {
                final Random random = new Random();
                int n;
                if (this.partyWithers.getValue()) {
                    n = random.nextInt(3);
                }
                else {
                    n = random.nextInt(2);
                }
                if (n == 0) {
                    this.entityMode.setValue(EntityMode.SNOW);
                }
                else if (n == 1) {
                    this.entityMode.setValue(EntityMode.IRON);
                }
                else if (n == 2) {
                    this.entityMode.setValue(EntityMode.WITHER);
                }
            }
            if (!this.checkBlocksInHotbar()) {
                if (!this.party.getValue()) {
                    if (this.notifications.getValue()) {
                        Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoSpawner] ").append(ChatFormatting.RED.toString()).append("Blocks missing for: ").append(ChatFormatting.RESET.toString()).append(this.entityMode.getValue().toString()).append(ChatFormatting.RED.toString()).append(", disabling.")));
                    }
                    this.disable();
                }
                return;
            }
            final List sphere = ((CrystalAura)ModuleManager.getModuleByName("CrystalAura")).getSphere(AutoSpawner.mc.player.getPosition().down(), (float)this.placeRange.getValue(), this.placeRange.getValue().intValue(), false, true, 0);
            boolean b = true;
            final Iterator<BlockPos> iterator = sphere.iterator();
            while (iterator.hasNext()) {
                this.placeTarget = iterator.next().down();
                if (this.testStructure()) {
                    b = false;
                    break;
                }
            }
            if (b) {
                if (this.useMode.getValue().equals(UseMode.SINGLE)) {
                    if (this.notifications.getValue()) {
                        Command.sendChatMessage(String.valueOf(new StringBuilder().append("[AutoSpawner] ").append(ChatFormatting.RED.toString()).append("Position not valid, disabling.")));
                    }
                    this.disable();
                }
                return;
            }
            AutoSpawner.mc.player.inventory.currentItem = this.bodySlot;
            final BlockPos[] access$000 = BodyParts.access$000();
            for (int length = access$000.length, i = 0; i < length; ++i) {
                placeBlock(this.placeTarget.add((Vec3i)access$000[i]), this.rotate.getValue());
            }
            if (this.entityMode.getValue().equals(EntityMode.WITHER) || this.entityMode.getValue().equals(EntityMode.IRON)) {
                if (this.rotationPlaceableX) {
                    final BlockPos[] access$2 = BodyParts.access$100();
                    for (int length2 = access$2.length, j = 0; j < length2; ++j) {
                        placeBlock(this.placeTarget.add((Vec3i)access$2[j]), this.rotate.getValue());
                    }
                }
                else if (this.rotationPlaceableZ) {
                    final BlockPos[] access$3 = BodyParts.access$200();
                    for (int length3 = access$3.length, k = 0; k < length3; ++k) {
                        placeBlock(this.placeTarget.add((Vec3i)access$3[k]), this.rotate.getValue());
                    }
                }
            }
            this.buildStage = 2;
        }
        else if (this.buildStage == 2) {
            AutoSpawner.mc.player.inventory.currentItem = this.headSlot;
            if (this.entityMode.getValue().equals(EntityMode.WITHER)) {
                if (this.rotationPlaceableX) {
                    final BlockPos[] access$4 = BodyParts.access$300();
                    for (int length4 = access$4.length, l = 0; l < length4; ++l) {
                        placeBlock(this.placeTarget.add((Vec3i)access$4[l]), this.rotate.getValue());
                    }
                }
                else if (this.rotationPlaceableZ) {
                    final BlockPos[] access$5 = BodyParts.access$400();
                    for (int length5 = access$5.length, n2 = 0; n2 < length5; ++n2) {
                        placeBlock(this.placeTarget.add((Vec3i)access$5[n2]), this.rotate.getValue());
                    }
                }
            }
            if (this.entityMode.getValue().equals(EntityMode.IRON) || this.entityMode.getValue().equals(EntityMode.SNOW)) {
                final BlockPos[] access$6 = BodyParts.access$500();
                for (int length6 = access$6.length, n3 = 0; n3 < length6; ++n3) {
                    placeBlock(this.placeTarget.add((Vec3i)access$6[n3]), this.rotate.getValue());
                }
            }
            if (AutoSpawner.isSneaking) {
                AutoSpawner.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)AutoSpawner.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                AutoSpawner.isSneaking = false;
            }
            if (this.useMode.getValue().equals(UseMode.SINGLE)) {
                this.disable();
            }
            this.buildStage = 3;
        }
        else if (this.buildStage == 3) {
            if (this.delayStep < this.delay.getValue()) {
                ++this.delayStep;
            }
            else {
                this.delayStep = 1;
                this.buildStage = 1;
            }
        }
    }
    
    private boolean testWitherStructure() {
        boolean b = true;
        this.rotationPlaceableX = true;
        this.rotationPlaceableZ = true;
        boolean b2 = false;
        if (AutoSpawner.mc.world.getBlockState(this.placeTarget) == null) {
            return false;
        }
        final Block getBlock = AutoSpawner.mc.world.getBlockState(this.placeTarget).getBlock();
        if (getBlock instanceof BlockTallGrass || getBlock instanceof BlockDeadBush) {
            b2 = true;
        }
        if (getPlaceableSide(this.placeTarget.up()) == null) {
            return false;
        }
        final BlockPos[] access$000 = BodyParts.access$000();
        for (int length = access$000.length, i = 0; i < length; ++i) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$000[i]))) {
                b = false;
            }
        }
        for (final BlockPos blockPos : BodyParts.access$100()) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos)) || this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos.down()))) {
                this.rotationPlaceableX = false;
            }
        }
        for (final BlockPos blockPos2 : BodyParts.access$200()) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos2)) || this.placingIsBlocked(this.placeTarget.add((Vec3i)blockPos2.down()))) {
                this.rotationPlaceableZ = false;
            }
        }
        final BlockPos[] access$4 = BodyParts.access$300();
        for (int length4 = access$4.length, l = 0; l < length4; ++l) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$4[l]))) {
                this.rotationPlaceableX = false;
            }
        }
        final BlockPos[] access$5 = BodyParts.access$400();
        for (int length5 = access$5.length, n = 0; n < length5; ++n) {
            if (this.placingIsBlocked(this.placeTarget.add((Vec3i)access$5[n]))) {
                this.rotationPlaceableZ = false;
            }
        }
        return !b2 && b && (this.rotationPlaceableX || this.rotationPlaceableZ);
    }
    
    private boolean checkBlocksInHotbar() {
        this.headSlot = -1;
        this.bodySlot = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = AutoSpawner.mc.player.inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a) {
                if (this.entityMode.getValue().equals(EntityMode.WITHER)) {
                    if (getStackInSlot.getItem() == Items.SKULL && getStackInSlot.getItemDamage() == 1) {
                        if (AutoSpawner.mc.player.inventory.getStackInSlot(i).stackSize >= 3) {
                            this.headSlot = i;
                        }
                        continue;
                    }
                    else {
                        if (!(getStackInSlot.getItem() instanceof ItemBlock)) {
                            continue;
                        }
                        if (((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockSoulSand && AutoSpawner.mc.player.inventory.getStackInSlot(i).stackSize >= 4) {
                            this.bodySlot = i;
                        }
                    }
                }
                if (this.entityMode.getValue().equals(EntityMode.IRON)) {
                    if (!(getStackInSlot.getItem() instanceof ItemBlock)) {
                        continue;
                    }
                    final Block getBlock = ((ItemBlock)getStackInSlot.getItem()).getBlock();
                    if ((getBlock == Blocks.LIT_PUMPKIN || getBlock == Blocks.PUMPKIN) && AutoSpawner.mc.player.inventory.getStackInSlot(i).stackSize >= 1) {
                        this.headSlot = i;
                    }
                    if (getBlock == Blocks.IRON_BLOCK && AutoSpawner.mc.player.inventory.getStackInSlot(i).stackSize >= 4) {
                        this.bodySlot = i;
                    }
                }
                if (this.entityMode.getValue().equals(EntityMode.SNOW)) {
                    if (getStackInSlot.getItem() instanceof ItemBlock) {
                        final Block getBlock2 = ((ItemBlock)getStackInSlot.getItem()).getBlock();
                        if ((getBlock2 == Blocks.LIT_PUMPKIN || getBlock2 == Blocks.PUMPKIN) && AutoSpawner.mc.player.inventory.getStackInSlot(i).stackSize >= 1) {
                            this.headSlot = i;
                        }
                        if (getBlock2 == Blocks.SNOW && AutoSpawner.mc.player.inventory.getStackInSlot(i).stackSize >= 2) {
                            this.bodySlot = i;
                        }
                    }
                }
            }
        }
        return this.bodySlot != -1 && this.headSlot != -1;
    }
    
    private static EnumFacing getPlaceableSide(final BlockPos blockPos) {
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            if (AutoSpawner.mc.world.getBlockState(offset).getBlock().canCollideCheck(AutoSpawner.mc.world.getBlockState(offset), false)) {
                final IBlockState getBlockState = AutoSpawner.mc.world.getBlockState(offset);
                if (!getBlockState.getMaterial().isReplaceable() && !(getBlockState.getBlock() instanceof BlockTallGrass) && !(getBlockState.getBlock() instanceof BlockDeadBush)) {
                    return enumFacing;
                }
            }
        }
        return null;
    }
    
    private boolean lambda$new$0(final Boolean b) {
        return this.party.getValue();
    }
    
    protected void onEnable() {
        if (AutoSpawner.mc.player == null) {
            this.disable();
            return;
        }
        this.buildStage = 1;
        this.delayStep = 1;
    }
    
    public AutoSpawner() {
        this.useMode = (Setting<UseMode>)this.register((Setting)Settings.e("Use Mode", UseMode.SPAM));
        this.party = (Setting<Boolean>)this.register((Setting)Settings.b("Party", false));
        this.partyWithers = (Setting<Boolean>)this.register((Setting)Settings.booleanBuilder("Withers").withValue(false).withVisibility(this::lambda$new$0).build());
        this.entityMode = (Setting<EntityMode>)this.register((Setting)Settings.enumBuilder(EntityMode.class).withName("Entity Mode").withValue(EntityMode.SNOW).withVisibility(this::lambda$new$1).build());
        this.placeRange = (Setting<Float>)this.register((Setting)Settings.floatBuilder("Place Range").withMinimum(2.0f).withValue(3.5f).withMaximum(10.0f).build());
        this.delay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Delay").withMinimum(12).withValue(20).withMaximum(100).withVisibility(this::lambda$new$2).build());
        this.rotate = (Setting<Boolean>)this.register((Setting)Settings.b("Rotate", true));
        this.notifications = (Setting<Boolean>)this.register((Setting)Settings.b("Notifications", false));
    }
    
    private boolean placingIsBlocked(final BlockPos blockPos) {
        if (!(AutoSpawner.mc.world.getBlockState(blockPos).getBlock() instanceof BlockAir)) {
            return true;
        }
        for (final Entity entity : AutoSpawner.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(blockPos))) {
            if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean lambda$new$2(final Integer n) {
        return this.useMode.getValue().equals(UseMode.SPAM);
    }
    
    private static class BodyParts
    {
        private static final BlockPos[] headsX;
        private static final BlockPos[] headsZ;
        private static final BlockPos[] head;
        private static final BlockPos[] ArmsX;
        private static final BlockPos[] ArmsZ;
        private static final BlockPos[] bodyBase;
        
        static BlockPos[] access$000() {
            return BodyParts.bodyBase;
        }
        
        static BlockPos[] access$200() {
            return BodyParts.ArmsZ;
        }
        
        static BlockPos[] access$100() {
            return BodyParts.ArmsX;
        }
        
        static BlockPos[] access$300() {
            return BodyParts.headsX;
        }
        
        static BlockPos[] access$500() {
            return BodyParts.head;
        }
        
        static BlockPos[] access$400() {
            return BodyParts.headsZ;
        }
        
        static {
            bodyBase = new BlockPos[] { new BlockPos(0, 1, 0), new BlockPos(0, 2, 0) };
            ArmsX = new BlockPos[] { new BlockPos(-1, 2, 0), new BlockPos(1, 2, 0) };
            ArmsZ = new BlockPos[] { new BlockPos(0, 2, -1), new BlockPos(0, 2, 1) };
            headsX = new BlockPos[] { new BlockPos(0, 3, 0), new BlockPos(-1, 3, 0), new BlockPos(1, 3, 0) };
            headsZ = new BlockPos[] { new BlockPos(0, 3, 0), new BlockPos(0, 3, -1), new BlockPos(0, 3, 1) };
            head = new BlockPos[] { new BlockPos(0, 3, 0) };
        }
    }
    
    private enum UseMode
    {
        SINGLE;
        
        private static final UseMode[] $VALUES;
        
        SPAM;
        
        static {
            $VALUES = new UseMode[] { UseMode.SINGLE, UseMode.SPAM };
        }
    }
    
    private enum EntityMode
    {
        WITHER;
        
        private static final EntityMode[] $VALUES;
        
        IRON, 
        SNOW;
        
        static {
            $VALUES = new EntityMode[] { EntityMode.SNOW, EntityMode.IRON, EntityMode.WITHER };
        }
    }
}
