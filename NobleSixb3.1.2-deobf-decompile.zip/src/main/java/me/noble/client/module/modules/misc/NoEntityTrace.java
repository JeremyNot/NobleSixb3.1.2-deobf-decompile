//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.setting.*;

@Module.Info(name = "NoEntityTrace", category = Module.Category.MISC, description = "Blocks entities from stopping you from mining")
public class NoEntityTrace extends Module
{
    private Setting<TraceMode> mode;
    private static NoEntityTrace INSTANCE;
    
    public static boolean shouldBlock() {
        return NoEntityTrace.INSTANCE.isEnabled() && (NoEntityTrace.INSTANCE.mode.getValue() == TraceMode.STATIC || NoEntityTrace.mc.playerController.isHittingBlock);
    }
    
    public NoEntityTrace() {
        this.mode = (Setting<TraceMode>)this.register((Setting)Settings.e("Mode", TraceMode.DYNAMIC));
        NoEntityTrace.INSTANCE = this;
    }
    
    private enum TraceMode
    {
        STATIC;
        
        private static final TraceMode[] $VALUES;
        
        DYNAMIC;
        
        static {
            $VALUES = new TraceMode[] { TraceMode.STATIC, TraceMode.DYNAMIC };
        }
    }
}
