//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import me.zero.alpine.listener.*;
import me.noble.client.event.events.*;
import me.noble.client.setting.*;
import java.util.function.*;
import me.noble.client.event.*;
import net.minecraft.network.play.server.*;

@Module.Info(name = "Velocity", description = "Modify knockback impact", category = Module.Category.MOVEMENT)
public class Velocity extends Module
{
    @EventHandler
    private Listener<PacketEvent.Receive> packetEventListener;
    private Setting<Float> horizontal;
    @EventHandler
    private Listener<EntityEvent.EntityCollision> entityCollisionListener;
    private Setting<Float> vertical;
    
    public Velocity() {
        this.horizontal = (Setting<Float>)this.register((Setting)Settings.f("Horizontal", 0.0f));
        this.vertical = (Setting<Float>)this.register((Setting)Settings.f("Vertical", 0.0f));
        this.packetEventListener = new Listener<PacketEvent.Receive>(this::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        this.entityCollisionListener = new Listener<EntityEvent.EntityCollision>(this::lambda$new$1, (Predicate<EntityEvent.EntityCollision>[])new Predicate[0]);
    }
    
    private void lambda$new$1(final EntityEvent.EntityCollision entityCollision) {
        if (entityCollision.getEntity() == Velocity.mc.player) {
            if (this.horizontal.getValue() == 0.0f && this.vertical.getValue() == 0.0f) {
                entityCollision.cancel();
                return;
            }
            entityCollision.setX(-entityCollision.getX() * this.horizontal.getValue());
            entityCollision.setY(0.0);
            entityCollision.setZ(-entityCollision.getZ() * this.horizontal.getValue());
        }
    }
    
    private void lambda$new$0(final PacketEvent.Receive receive) {
        if (receive.getEra() == KamiEvent.Era.PRE) {
            if (receive.getPacket() instanceof SPacketEntityVelocity) {
                final SPacketEntityVelocity sPacketEntityVelocity = (SPacketEntityVelocity)receive.getPacket();
                if (sPacketEntityVelocity.getEntityID() == Velocity.mc.player.entityId) {
                    if (this.horizontal.getValue() == 0.0f && this.vertical.getValue() == 0.0f) {
                        receive.cancel();
                    }
                    final SPacketEntityVelocity sPacketEntityVelocity2 = sPacketEntityVelocity;
                    sPacketEntityVelocity2.motionX *= (int)(Object)this.horizontal.getValue();
                    final SPacketEntityVelocity sPacketEntityVelocity3 = sPacketEntityVelocity;
                    sPacketEntityVelocity3.motionY *= (int)(Object)this.vertical.getValue();
                    final SPacketEntityVelocity sPacketEntityVelocity4 = sPacketEntityVelocity;
                    sPacketEntityVelocity4.motionZ *= (int)(Object)this.horizontal.getValue();
                }
            }
            else if (receive.getPacket() instanceof SPacketExplosion) {
                if (this.horizontal.getValue() == 0.0f && this.vertical.getValue() == 0.0f) {
                    receive.cancel();
                }
                final SPacketExplosion sPacketExplosion2;
                final SPacketExplosion sPacketExplosion = sPacketExplosion2 = (SPacketExplosion)receive.getPacket();
                sPacketExplosion2.motionX *= this.horizontal.getValue();
                final SPacketExplosion sPacketExplosion3 = sPacketExplosion;
                sPacketExplosion3.motionY *= this.vertical.getValue();
                final SPacketExplosion sPacketExplosion4 = sPacketExplosion;
                sPacketExplosion4.motionZ *= this.horizontal.getValue();
            }
        }
    }
}
