//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.util.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.init.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.client.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(category = Module.Category.PLAYER, description = "Prevents fall damage", name = "NoFall")
public class NoFall extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> sendListener;
    private Setting<Boolean> pickup;
    private Setting<FallMode> fallMode;
    private long last;
    private Setting<Integer> distance;
    
    public void onUpdate() {
        if (this.fallMode.getValue().equals(FallMode.BUCKET) && NoFall.mc.player.fallDistance >= this.distance.getValue() && !EntityUtil.isAboveWater((Entity)NoFall.mc.player) && System.currentTimeMillis() - this.last > 100L) {
            final Vec3d getPositionVector = NoFall.mc.player.getPositionVector();
            final RayTraceResult rayTraceBlocks = NoFall.mc.world.rayTraceBlocks(getPositionVector, getPositionVector.addVector(0.0, -5.329999923706055, 0.0), true, true, false);
            if (rayTraceBlocks != null && rayTraceBlocks.typeOfHit == RayTraceResult.Type.BLOCK) {
                EnumHand enumHand = EnumHand.MAIN_HAND;
                if (NoFall.mc.player.getHeldItemOffhand().getItem() == Items.WATER_BUCKET) {
                    enumHand = EnumHand.OFF_HAND;
                }
                else if (NoFall.mc.player.getHeldItemMainhand().getItem() != Items.WATER_BUCKET) {
                    for (int i = 0; i < 9; ++i) {
                        if (NoFall.mc.player.inventory.getStackInSlot(i).getItem() == Items.WATER_BUCKET) {
                            NoFall.mc.player.inventory.currentItem = i;
                            NoFall.mc.player.rotationPitch = 90.0f;
                            this.last = System.currentTimeMillis();
                            return;
                        }
                    }
                    return;
                }
                NoFall.mc.player.rotationPitch = 90.0f;
                NoFall.mc.playerController.processRightClick((EntityPlayer)NoFall.mc.player, (World)NoFall.mc.world, enumHand);
                true;
            }
            System.out.println("KAMI BLUE: Ran this");
            if (this.pickup.getValue()) {
                System.out.println("KAMI BLUE: Ran this");
                final Vec3d getPositionVector2 = NoFall.mc.player.getPositionVector();
                final RayTraceResult rayTraceBlocks2 = NoFall.mc.world.rayTraceBlocks(getPositionVector2, getPositionVector2.addVector(0.0, -1.5, 0.0), false, true, false);
                if (rayTraceBlocks2 != null && rayTraceBlocks2.typeOfHit != RayTraceResult.Type.BLOCK) {
                    System.out.println("KAMI BLUE: Ran this");
                    EnumHand enumHand2 = EnumHand.MAIN_HAND;
                    if (NoFall.mc.player.getHeldItemOffhand().getItem() == Items.BUCKET) {
                        enumHand2 = EnumHand.OFF_HAND;
                    }
                    else if (NoFall.mc.player.getHeldItemMainhand().getItem() != Items.BUCKET) {
                        for (int j = 0; j < 9; ++j) {
                            if (NoFall.mc.player.inventory.getStackInSlot(j).getItem() == Items.BUCKET) {
                                NoFall.mc.player.inventory.currentItem = j;
                                NoFall.mc.player.rotationPitch = 90.0f;
                                this.last = System.currentTimeMillis();
                                return;
                            }
                        }
                        return;
                    }
                    NoFall.mc.player.rotationPitch = 90.0f;
                    NoFall.mc.playerController.processRightClick((EntityPlayer)NoFall.mc.player, (World)NoFall.mc.world, enumHand2);
                    false;
                }
            }
        }
    }
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (this.fallMode.getValue().equals(FallMode.PACKET) && send.getPacket() instanceof CPacketPlayer) {
            ((CPacketPlayer)send.getPacket()).onGround = true;
        }
    }
    
    public NoFall() {
        this.fallMode = (Setting<FallMode>)this.register((Setting)Settings.e("Mode", FallMode.PACKET));
        this.pickup = (Setting<Boolean>)this.register((Setting)Settings.b("Pickup", true));
        this.distance = (Setting<Integer>)this.register((Setting)Settings.i("Distance", 3));
        this.last = 0L;
        this.sendListener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private enum FallMode
    {
        BUCKET, 
        PACKET;
        
        private static final FallMode[] $VALUES;
        
        static {
            $VALUES = new FallMode[] { FallMode.BUCKET, FallMode.PACKET };
        }
    }
}
