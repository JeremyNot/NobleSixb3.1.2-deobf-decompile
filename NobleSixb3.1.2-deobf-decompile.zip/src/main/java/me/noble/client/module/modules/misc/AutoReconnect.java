//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.client.gui.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.client.multiplayer.*;

@Module.Info(name = "AutoReconnect", description = "Automatically reconnects after being disconnected", category = Module.Category.MISC, alwaysListening = true, showOnArray = Module.ShowOnArray.OFF)
public class AutoReconnect extends Module
{
    private static ServerData cServer;
    @EventHandler
    public Listener<GuiScreenEvent.Closed> closedListener;
    @EventHandler
    public Listener<GuiScreenEvent.Displayed> displayedListener;
    private Setting<Integer> seconds;
    
    private void lambda$new$1(final GuiScreenEvent.Displayed displayed) {
        if (this.isEnabled() && displayed.getScreen() instanceof GuiDisconnected && (AutoReconnect.cServer != null || AutoReconnect.mc.currentServerData != null)) {
            displayed.setScreen((GuiScreen)new KamiGuiDisconnected((GuiDisconnected)displayed.getScreen()));
        }
    }
    
    public AutoReconnect() {
        this.seconds = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Seconds").withValue(5).withMinimum(0).build());
        this.closedListener = new Listener<GuiScreenEvent.Closed>(AutoReconnect::lambda$new$0, (Predicate<GuiScreenEvent.Closed>[])new Predicate[0]);
        this.displayedListener = new Listener<GuiScreenEvent.Displayed>(this::lambda$new$1, (Predicate<GuiScreenEvent.Displayed>[])new Predicate[0]);
    }
    
    static ServerData access$100() {
        return AutoReconnect.cServer;
    }
    
    private static void lambda$new$0(final GuiScreenEvent.Closed closed) {
        if (closed.getScreen() instanceof GuiConnecting) {
            AutoReconnect.cServer = AutoReconnect.mc.currentServerData;
        }
    }
    
    static Setting access$000(final AutoReconnect autoReconnect) {
        return autoReconnect.seconds;
    }
    
    private class KamiGuiDisconnected extends GuiDisconnected
    {
        final AutoReconnect this$0;
        int millis;
        long cTime;
        
        public void updateScreen() {
            if (this.millis <= 0) {
                this.mc.displayGuiScreen((GuiScreen)new GuiConnecting(this.parentScreen, this.mc, (AutoReconnect.access$100() == null) ? this.mc.currentServerData : AutoReconnect.access$100()));
            }
        }
        
        public void drawScreen(final int n, final int n2, final float n3) {
            super.drawScreen(n, n2, n3);
            final long currentTimeMillis = System.currentTimeMillis();
            this.millis -= (int)(currentTimeMillis - this.cTime);
            this.cTime = currentTimeMillis;
            final String value = String.valueOf(new StringBuilder().append("Reconnecting in ").append(Math.max(0.0, Math.floor(this.millis / 100.0) / 10.0)).append("s"));
            this.fontRendererObj.drawString(value, (float)(this.width / 2 - this.fontRendererObj.getStringWidth(value) / 2), (float)(this.height - 16), 16777215, true);
        }
        
        public KamiGuiDisconnected(final AutoReconnect this$0, final GuiDisconnected guiDisconnected) {
            this.this$0 = this$0;
            super(guiDisconnected.parentScreen, guiDisconnected.reason, guiDisconnected.message);
            this.millis = AutoReconnect.access$000(this.this$0).getValue() * 1000;
            this.cTime = System.currentTimeMillis();
        }
    }
}
