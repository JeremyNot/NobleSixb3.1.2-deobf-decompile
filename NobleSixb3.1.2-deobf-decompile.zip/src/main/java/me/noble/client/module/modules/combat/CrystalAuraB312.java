//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.zero.alpine.listener.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;
import me.noble.client.event.events.*;
import me.noble.client.command.*;
import java.util.stream.*;
import net.minecraft.network.*;
import java.util.function.*;
import me.noble.client.util.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.client.entity.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.enchantment.*;
import net.minecraft.util.math.*;
import net.minecraft.potion.*;

@Module.Info(name = "CrystalAuraGloom", category = Module.Category.COMBAT)
public class CrystalAuraB312 extends Module
{
    private Setting<Integer> Alpha;
    private static boolean togglePitch;
    private Setting<Boolean> autoSwitch;
    private Setting<Double> Bdelay;
    private Setting<Integer> MinDmg;
    private int newSlot;
    private Setting<Boolean> explode;
    private static double pitch;
    private int placements;
    private boolean switchCooldown;
    private static boolean isSpoofingAngles;
    private Setting<Integer> Red;
    private Setting<Boolean> thing;
    private Setting<Boolean> players;
    private Entity renderEnt;
    private Setting<Boolean> alert;
    private Setting<Integer> Green;
    private int oldSlot;
    private Setting<Boolean> antiWeakness;
    private boolean isAttacking;
    private Setting<Integer> Blue;
    private Setting<Double> range;
    private Setting<Double> distance;
    private Setting<Boolean> place;
    private static double yaw;
    private Setting<Boolean> raytrace;
    private long systemTime;
    @EventHandler
    private Listener<PacketEvent.Send> packetListener;
    private BlockPos render;
    private Setting<Double> Pdelay;
    
    private void lookAtPacket(final double n, final double n2, final double n3, final EntityPlayer entityPlayer) {
        final double[] calculateLook = EntityUtil.calculateLookAt(n, n2, n3, entityPlayer);
        setYawAndPitch((float)calculateLook[0], (float)calculateLook[1]);
    }
    
    private static boolean lambda$onUpdate$4(final EntityPlayer entityPlayer) {
        return !Friends.isFriend(entityPlayer.getName());
    }
    
    private static boolean lambda$onUpdate$1(final Entity entity) {
        return entity instanceof EntityEnderCrystal;
    }
    
    private boolean canPlaceCrystal(final BlockPos blockPos) {
        final BlockPos add = blockPos.add(0, 1, 0);
        final BlockPos add2 = blockPos.add(0, 2, 0);
        return (CrystalAuraB312.mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || CrystalAuraB312.mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && CrystalAuraB312.mc.world.getBlockState(add).getBlock() == Blocks.AIR && CrystalAuraB312.mc.world.getBlockState(add2).getBlock() == Blocks.AIR && CrystalAuraB312.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add)).isEmpty() && CrystalAuraB312.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add2)).isEmpty();
    }
    
    public static float calculateDamage(final double n, final double n2, final double n3, final Entity entity) {
        final double n4 = (1.0 - entity.getDistance(n, n2, n3) / 12.0) * entity.world.getBlockDensity(new Vec3d(n, n2, n3), entity.getEntityBoundingBox());
        final float n5 = (float)(int)((n4 * n4 + n4) / 2.0 * 7.0 * 12.0 + 1.0);
        double n6 = 1.0;
        if (entity instanceof EntityLivingBase) {
            n6 = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(n5), new Explosion((World)CrystalAuraB312.mc.world, (Entity)null, n, n2, n3, 6.0f, false, true));
        }
        return (float)n6;
    }
    
    private static Entity lambda$onUpdate$2(final Entity entity) {
        return entity;
    }
    
    private static void setYawAndPitch(final float n, final float n2) {
        CrystalAuraB312.yaw = n;
        CrystalAuraB312.pitch = n2;
        CrystalAuraB312.isSpoofingAngles = true;
    }
    
    private static float getDamageMultiplied(final float n) {
        final int getDifficultyId = CrystalAuraB312.mc.world.getDifficulty().getDifficultyId();
        return n * ((getDifficultyId == 0) ? 0.0f : ((getDifficultyId == 2) ? 1.0f : ((getDifficultyId == 1) ? 0.5f : 1.5f)));
    }
    
    public CrystalAuraB312() {
        this.autoSwitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch"));
        this.players = (Setting<Boolean>)this.register((Setting)Settings.b("Players"));
        this.place = (Setting<Boolean>)this.register((Setting)Settings.b("Place", true));
        this.raytrace = (Setting<Boolean>)this.register((Setting)Settings.b("RayTrace", false));
        this.explode = (Setting<Boolean>)this.register((Setting)Settings.b("Explode", true));
        this.thing = (Setting<Boolean>)this.register((Setting)Settings.b("MutltiPlace", true));
        this.range = (Setting<Double>)this.register((Setting)Settings.d("Range", 6.0));
        this.antiWeakness = (Setting<Boolean>)this.register((Setting)Settings.b("Anti Weakness", false));
        this.Pdelay = (Setting<Double>)this.register((Setting)Settings.d("Place Delay", 0.5));
        this.Bdelay = (Setting<Double>)this.register((Setting)Settings.d("Break Delay", 0.5));
        this.distance = (Setting<Double>)this.register((Setting)Settings.d("Enemy Distance", 6.0));
        this.alert = (Setting<Boolean>)this.register((Setting)Settings.b("Chat Alert", true));
        this.MinDmg = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Min Dmg").withMinimum(0).withMaximum(16).withValue(2));
        this.Red = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Red").withMinimum(0).withMaximum(255).withValue(255));
        this.Green = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Green").withMinimum(0).withMaximum(255).withValue(0));
        this.Blue = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Blue").withMinimum(0).withMaximum(255).withValue(255));
        this.Alpha = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Alpha").withMinimum(0).withMaximum(70).withValue(45));
        this.systemTime = -1L;
        this.switchCooldown = false;
        this.isAttacking = false;
        this.oldSlot = -1;
        this.packetListener = new Listener<PacketEvent.Send>(CrystalAuraB312::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    static {
        CrystalAuraB312.togglePitch = false;
    }
    
    private static Float lambda$onUpdate$3(final Entity entity) {
        return CrystalAuraB312.mc.player.getDistanceToEntity(entity);
    }
    
    public static float calculateDamage(final EntityEnderCrystal entityEnderCrystal, final Entity entity) {
        return calculateDamage(entityEnderCrystal.posX, entityEnderCrystal.posY, entityEnderCrystal.posZ, entity);
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (this.render != null) {
            KamiTessellator.prepare(7);
            KamiTessellator.drawBox(this.render, this.Red.getValue(), this.Green.getValue(), this.Blue.getValue(), this.Alpha.getValue(), 63);
            KamiTessellator.release();
        }
    }
    
    public void onDisable() {
        if (this.alert.getValue()) {
            Command.sendChatMessage(" ��fCrystalAuraGloom ��cOFF");
        }
        this.render = null;
        this.renderEnt = null;
        resetRotation();
    }
    
    public List<BlockPos> getSphere(final BlockPos blockPos, final float n, final int n2, final boolean b, final boolean b2, final int n3) {
        final ArrayList<BlockPos> list = new ArrayList<BlockPos>();
        final int getX = blockPos.getX();
        final int getY = blockPos.getY();
        final int getZ = blockPos.getZ();
        for (int n4 = getX - (int)n; n4 <= getX + n; ++n4) {
            for (int n5 = getZ - (int)n; n5 <= getZ + n; ++n5) {
                for (int n6 = b2 ? (getY - (int)n) : getY; n6 < (b2 ? (getY + n) : ((float)(getY + n2))); ++n6) {
                    final double n7 = (getX - n4) * (getX - n4) + (getZ - n5) * (getZ - n5) + (b2 ? ((getY - n6) * (getY - n6)) : 0);
                    if (n7 < n * n && (!b || n7 >= (n - 1.0f) * (n - 1.0f))) {
                        list.add(new BlockPos(n4, n6 + n3, n5));
                    }
                }
            }
        }
        return list;
    }
    
    private List<BlockPos> findCrystalBlocks() {
        final NonNullList func_191196_a = NonNullList.func_191196_a();
        func_191196_a.addAll((Collection)this.getSphere(getPlayerPos(), this.range.getValue().floatValue(), this.range.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::canPlaceCrystal).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return (List<BlockPos>)func_191196_a;
    }
    
    private static void lambda$new$0(final PacketEvent.Send send) {
        final Packet packet = send.getPacket();
        if (packet instanceof CPacketPlayer && CrystalAuraB312.isSpoofingAngles) {
            ((CPacketPlayer)packet).yaw = (float)CrystalAuraB312.yaw;
            ((CPacketPlayer)packet).pitch = (float)CrystalAuraB312.pitch;
        }
    }
    
    private static void resetRotation() {
        if (CrystalAuraB312.isSpoofingAngles) {
            CrystalAuraB312.yaw = CrystalAuraB312.mc.player.rotationYaw;
            CrystalAuraB312.pitch = CrystalAuraB312.mc.player.rotationPitch;
            CrystalAuraB312.isSpoofingAngles = false;
        }
    }
    
    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(CrystalAuraB312.mc.player.posX), Math.floor(CrystalAuraB312.mc.player.posY), Math.floor(CrystalAuraB312.mc.player.posZ));
    }
    
    public void onUpdate() {
        final EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal)CrystalAuraB312.mc.world.loadedEntityList.stream().filter(CrystalAuraB312::lambda$onUpdate$1).map(CrystalAuraB312::lambda$onUpdate$2).min(Comparator.comparing((Function<? super T, ? extends Comparable>)CrystalAuraB312::lambda$onUpdate$3)).orElse(null);
        if (this.explode.getValue() && entityEnderCrystal != null && CrystalAuraB312.mc.player.getDistanceToEntity((Entity)entityEnderCrystal) <= this.range.getValue()) {
            if (System.nanoTime() / 1000000L - this.systemTime >= this.Bdelay.getValue()) {
                if (this.antiWeakness.getValue() && CrystalAuraB312.mc.player.isPotionActive(MobEffects.WEAKNESS)) {
                    if (!this.isAttacking) {
                        this.oldSlot = Wrapper.getPlayer().inventory.currentItem;
                        this.isAttacking = true;
                    }
                    this.newSlot = -1;
                    for (int i = 0; i < 9; ++i) {
                        final ItemStack getStackInSlot = Wrapper.getPlayer().inventory.getStackInSlot(i);
                        if (getStackInSlot != ItemStack.field_190927_a) {
                            if (getStackInSlot.getItem() instanceof ItemSword) {
                                this.newSlot = i;
                                break;
                            }
                            if (getStackInSlot.getItem() instanceof ItemTool) {
                                this.newSlot = i;
                                break;
                            }
                        }
                    }
                    if (this.newSlot != -1) {
                        Wrapper.getPlayer().inventory.currentItem = this.newSlot;
                        this.switchCooldown = true;
                    }
                }
                this.lookAtPacket(entityEnderCrystal.posX, entityEnderCrystal.posY, entityEnderCrystal.posZ, (EntityPlayer)CrystalAuraB312.mc.player);
                CrystalAuraB312.mc.playerController.attackEntity((EntityPlayer)CrystalAuraB312.mc.player, (Entity)entityEnderCrystal);
                CrystalAuraB312.mc.player.swingArm(EnumHand.MAIN_HAND);
                this.systemTime = System.nanoTime() / 1000000L;
            }
            if (!this.thing.getValue()) {
                return;
            }
            if (this.placements == 3) {
                this.placements = 0;
                return;
            }
        }
        else {
            resetRotation();
            if (this.oldSlot != -1) {
                Wrapper.getPlayer().inventory.currentItem = this.oldSlot;
                this.oldSlot = -1;
            }
            this.isAttacking = false;
        }
        int currentItem = (CrystalAuraB312.mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) ? CrystalAuraB312.mc.player.inventory.currentItem : -1;
        if (currentItem == -1) {
            for (int j = 0; j < 9; ++j) {
                if (CrystalAuraB312.mc.player.inventory.getStackInSlot(j).getItem() == Items.END_CRYSTAL) {
                    currentItem = j;
                    break;
                }
            }
        }
        boolean b = false;
        if (CrystalAuraB312.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
            b = true;
        }
        else if (currentItem == -1) {
            return;
        }
        final List<BlockPos> crystalBlocks = this.findCrystalBlocks();
        final ArrayList<Entity> list = new ArrayList<Entity>();
        if (this.players.getValue()) {
            list.addAll((Collection<?>)CrystalAuraB312.mc.world.playerEntities.stream().filter(CrystalAuraB312::lambda$onUpdate$4).collect(Collectors.toList()));
        }
        BlockPos render = null;
        double n = 0.5;
        for (final Entity renderEnt : list) {
            if (renderEnt != CrystalAuraB312.mc.player) {
                if (((EntityLivingBase)renderEnt).getHealth() <= 0.0f) {
                    continue;
                }
                for (final BlockPos blockPos : crystalBlocks) {
                    if (renderEnt.getDistanceSq(blockPos) >= this.distance.getValue() * this.distance.getValue()) {
                        continue;
                    }
                    final double n2 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, renderEnt);
                    if (n2 <= n) {
                        continue;
                    }
                    final double n3 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, (Entity)CrystalAuraB312.mc.player);
                    if (n3 > n2 && n2 >= ((EntityLivingBase)renderEnt).getHealth()) {
                        continue;
                    }
                    if (n3 - 0.5 > CrystalAuraB312.mc.player.getHealth()) {
                        continue;
                    }
                    if (n2 < this.MinDmg.getValue()) {
                        continue;
                    }
                    n = n2;
                    render = blockPos;
                    this.renderEnt = renderEnt;
                }
            }
        }
        if (n == 0.5) {
            this.render = null;
            this.renderEnt = null;
            resetRotation();
            return;
        }
        this.render = render;
        if (this.place.getValue()) {
            if (!b && CrystalAuraB312.mc.player.inventory.currentItem != currentItem) {
                if (this.autoSwitch.getValue()) {
                    CrystalAuraB312.mc.player.inventory.currentItem = currentItem;
                    resetRotation();
                    this.switchCooldown = true;
                }
                return;
            }
            this.lookAtPacket(render.x + 0.5, render.y - 0.5, render.z + 0.5, (EntityPlayer)CrystalAuraB312.mc.player);
            EnumFacing enumFacing;
            if (this.raytrace.getValue()) {
                final RayTraceResult rayTraceBlocks = CrystalAuraB312.mc.world.rayTraceBlocks(new Vec3d(CrystalAuraB312.mc.player.posX, CrystalAuraB312.mc.player.posY + CrystalAuraB312.mc.player.getEyeHeight(), CrystalAuraB312.mc.player.posZ), new Vec3d(render.x + 0.5, render.y - 0.5, render.z + 0.5));
                if (rayTraceBlocks == null || rayTraceBlocks.sideHit == null) {
                    enumFacing = EnumFacing.UP;
                }
                else {
                    enumFacing = rayTraceBlocks.sideHit;
                }
            }
            else {
                enumFacing = EnumFacing.DOWN;
            }
            if (this.switchCooldown) {
                this.switchCooldown = false;
                return;
            }
            if (System.nanoTime() / 1000000L - this.systemTime >= this.Pdelay.getValue()) {
                CrystalAuraB312.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(render, enumFacing, b ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
                ++this.placements;
                this.systemTime = System.nanoTime() / 1000000L;
            }
        }
        if (CrystalAuraB312.isSpoofingAngles) {
            if (CrystalAuraB312.togglePitch) {
                final EntityPlayerSP player = CrystalAuraB312.mc.player;
                player.rotationPitch += 4.0E-4f;
                CrystalAuraB312.togglePitch = false;
            }
            else {
                final EntityPlayerSP player2 = CrystalAuraB312.mc.player;
                player2.rotationPitch -= 4.0E-4f;
                CrystalAuraB312.togglePitch = true;
            }
        }
    }
    
    public static float getBlastReduction(final EntityLivingBase entityLivingBase, float n, final Explosion explosion) {
        if (entityLivingBase instanceof EntityPlayer) {
            final EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            final DamageSource causeExplosionDamage = DamageSource.causeExplosionDamage(explosion);
            n = CombatRules.getDamageAfterAbsorb(n, (float)entityPlayer.getTotalArmorValue(), (float)entityPlayer.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            n *= 1.0f - MathHelper.clamp((float)EnchantmentHelper.getEnchantmentModifierDamage(entityPlayer.getArmorInventoryList(), causeExplosionDamage), 0.0f, 20.0f) / 25.0f;
            if (entityLivingBase.isPotionActive(Potion.getPotionById(11))) {
                n -= n / 4.0f;
            }
            n = Math.max(n, 0.0f);
            return n;
        }
        n = CombatRules.getDamageAfterAbsorb(n, (float)entityLivingBase.getTotalArmorValue(), (float)entityLivingBase.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
        return n;
    }
    
    protected void onEnable() {
        if (this.alert.getValue()) {
            Command.sendChatMessage(" ��fCrystalAuraGloom ��aON");
        }
    }
}
