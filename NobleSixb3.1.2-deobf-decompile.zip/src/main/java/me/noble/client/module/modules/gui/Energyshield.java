//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.gui.kami.*;
import me.noble.client.module.*;
import me.noble.client.*;
import me.noble.client.command.*;
import java.io.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.util.*;
import me.noble.client.gui.rgui.component.container.*;
import java.util.*;
import me.noble.client.setting.*;

@Module.Info(name = "Energyshield", category = Module.Category.GUI, description = "You are a spartan now", showOnArray = Module.ShowOnArray.OFF)
public class Energyshield extends Module
{
    private Setting<ViewMode> viewMode;
    KamiGUI kamiGUI;
    
    public void onRender() {
        if (this.invPos(3) == 1) {
            if (this.viewMode.getValue().equals(ViewMode.REACH)) {
                this.energyRender(this.invPos(0), this.invPos(1));
                this.boxRender(this.invPos(0), this.invPos(1));
            }
            else if (this.viewMode.getValue().equals(ViewMode.HALOCE)) {
                this.energyRenderCE(this.invPos(0), this.invPos(1));
                this.boxRenderCE(this.invPos(0), this.invPos(1));
            }
            else {
                this.energyRender(this.invPos(0), this.invPos(1));
                this.boxRender(this.invPos(0), this.invPos(1));
            }
            if (Energyshield.mc.player.getHealth() == 20.0f && ModuleManager.getModuleByName("AutoSaveConfig").isEnabled()) {
                try {
                    NobleMod.saveConfigurationUnsafe();
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("Failed to save! ").append(ex.getMessage())));
                }
            }
        }
    }
    
    private static void preenergyRenderCE() {
        GL11.glPushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
    }
    
    private static void preBoxRender() {
        GL11.glPushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
    }
    
    private ResourceLocation getBoxCE() {
        if (Energyshield.mc.player.getHealth() >= 20.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb20.png");
        }
        if (Energyshield.mc.player.getHealth() >= 19.0f && Energyshield.mc.player.getHealth() < 20.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb20.png");
        }
        if (Energyshield.mc.player.getHealth() >= 17.0f && Energyshield.mc.player.getHealth() < 19.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb19.png");
        }
        if (Energyshield.mc.player.getHealth() >= 15.0f && Energyshield.mc.player.getHealth() < 17.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb17.png");
        }
        if (Energyshield.mc.player.getHealth() >= 13.0f && Energyshield.mc.player.getHealth() < 15.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb15.png");
        }
        if (Energyshield.mc.player.getHealth() >= 11.0f && Energyshield.mc.player.getHealth() < 13.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb13.png");
        }
        if (Energyshield.mc.player.getHealth() >= 9.0f && Energyshield.mc.player.getHealth() < 11.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb11.png");
        }
        if (Energyshield.mc.player.getHealth() >= 7.0f && Energyshield.mc.player.getHealth() < 9.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb9.png");
        }
        if (Energyshield.mc.player.getHealth() >= 5.0f && Energyshield.mc.player.getHealth() < 7.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb7.png");
        }
        if (Energyshield.mc.player.getHealth() >= 3.0f && Energyshield.mc.player.getHealth() < 5.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb5.png");
        }
        if (Energyshield.mc.player.getHealth() >= 1.0f && Energyshield.mc.player.getHealth() < 3.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb3.png");
        }
        if (Energyshield.mc.player.getHealth() > 0.0f && Energyshield.mc.player.getHealth() < 1.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb1.png");
        }
        if (Energyshield.mc.player.getHealth() == 0.0f) {
            return new ResourceLocation("textures/gui/energyshield/ceb0.png");
        }
        return new ResourceLocation("textures/gui/energyshield/ceb0.png");
    }
    
    private static void postenergyRender() {
        GlStateManager.disableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }
    
    public void onDisable() {
        this.enable();
    }
    
    private int invPos(final int n) {
        this.kamiGUI = NobleMod.getInstance().getGuiManager();
        if (this.kamiGUI != null) {
            for (final Frame frame : ContainerHelper.getAllChildren((Class)Frame.class, (Container)this.kamiGUI)) {
                if (!frame.getTitle().equalsIgnoreCase("Spartan Energyshield")) {
                    continue;
                }
                switch (n) {
                    case 0: {
                        return frame.getX();
                    }
                    case 1: {
                        return frame.getY();
                    }
                    case 3: {
                        if (frame.isPinned()) {
                            return 1;
                        }
                        return 0;
                    }
                    default: {
                        return 0;
                    }
                }
            }
        }
        return 0;
    }
    
    private void boxRender(final int n, final int n2) {
        preBoxRender();
        Energyshield.mc.renderEngine.bindTexture(this.getBox());
        Energyshield.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 255, 100);
        postBoxRender();
    }
    
    public Energyshield() {
        this.viewMode = (Setting<ViewMode>)this.register((Setting)Settings.e("Appearance", ViewMode.REACH));
        this.kamiGUI = NobleMod.getInstance().getGuiManager();
    }
    
    private void energyRenderCE(final int n, final int n2) {
        preenergyRenderCE();
        Energyshield.mc.renderEngine.bindTexture(this.getenergyCE());
        Energyshield.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 255, 100);
        postenergyRenderCE();
    }
    
    private static void postBoxRender() {
        GlStateManager.disableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }
    
    private static void postBoxRenderCE() {
        GlStateManager.disableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }
    
    private static void preBoxRenderCE() {
        GL11.glPushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
    }
    
    private ResourceLocation getBox() {
        if (Energyshield.mc.player.getHealth() >= 20.0f) {
            return new ResourceLocation("textures/gui/energyshield/20.png");
        }
        if (Energyshield.mc.player.getHealth() >= 19.0f && Energyshield.mc.player.getHealth() < 20.0f) {
            return new ResourceLocation("textures/gui/energyshield/19.png");
        }
        if (Energyshield.mc.player.getHealth() >= 17.0f && Energyshield.mc.player.getHealth() < 19.0f) {
            return new ResourceLocation("textures/gui/energyshield/17.png");
        }
        if (Energyshield.mc.player.getHealth() >= 15.0f && Energyshield.mc.player.getHealth() < 17.0f) {
            return new ResourceLocation("textures/gui/energyshield/15.png");
        }
        if (Energyshield.mc.player.getHealth() >= 13.0f && Energyshield.mc.player.getHealth() < 15.0f) {
            return new ResourceLocation("textures/gui/energyshield/13.png");
        }
        if (Energyshield.mc.player.getHealth() >= 11.0f && Energyshield.mc.player.getHealth() < 13.0f) {
            return new ResourceLocation("textures/gui/energyshield/11.png");
        }
        if (Energyshield.mc.player.getHealth() >= 9.0f && Energyshield.mc.player.getHealth() < 11.0f) {
            return new ResourceLocation("textures/gui/energyshield/9.png");
        }
        if (Energyshield.mc.player.getHealth() >= 7.0f && Energyshield.mc.player.getHealth() < 9.0f) {
            return new ResourceLocation("textures/gui/energyshield/7.png");
        }
        if (Energyshield.mc.player.getHealth() >= 5.0f && Energyshield.mc.player.getHealth() < 7.0f) {
            return new ResourceLocation("textures/gui/energyshield/5.png");
        }
        if (Energyshield.mc.player.getHealth() >= 3.0f && Energyshield.mc.player.getHealth() < 5.0f) {
            return new ResourceLocation("textures/gui/energyshield/3.png");
        }
        if (Energyshield.mc.player.getHealth() > 0.0f && Energyshield.mc.player.getHealth() < 3.0f) {
            return new ResourceLocation("textures/gui/energyshield/1.png");
        }
        if (Energyshield.mc.player.getHealth() == 0.0f) {
            return new ResourceLocation("textures/gui/energyshield/0.png");
        }
        return new ResourceLocation("textures/gui/energyshield/0.png");
    }
    
    private void boxRenderCE(final int n, final int n2) {
        preBoxRenderCE();
        Energyshield.mc.renderEngine.bindTexture(this.getBoxCE());
        Energyshield.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 255, 100);
        postBoxRenderCE();
    }
    
    private static void preenergyRender() {
        GL11.glPushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
    }
    
    private void energyRender(final int n, final int n2) {
        preenergyRender();
        Energyshield.mc.renderEngine.bindTexture(this.getenergy());
        Energyshield.mc.ingameGUI.drawTexturedModalRect(n, n2, 7, 17, 255, 100);
        postenergyRender();
    }
    
    private ResourceLocation getenergy() {
        if (Energyshield.mc.player.getAbsorptionAmount() >= 16.0f) {
            return new ResourceLocation("textures/gui/energyshield/e16.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 15.0f && Energyshield.mc.player.getAbsorptionAmount() < 16.0f) {
            return new ResourceLocation("textures/gui/energyshield/e15.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 13.0f && Energyshield.mc.player.getAbsorptionAmount() < 15.0f) {
            return new ResourceLocation("textures/gui/energyshield/e13.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 11.0f && Energyshield.mc.player.getAbsorptionAmount() < 13.0f) {
            return new ResourceLocation("textures/gui/energyshield/e11.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 9.0f && Energyshield.mc.player.getAbsorptionAmount() < 11.0f) {
            return new ResourceLocation("textures/gui/energyshield/e9.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 7.0f && Energyshield.mc.player.getAbsorptionAmount() < 9.0f) {
            return new ResourceLocation("textures/gui/energyshield/e7.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 5.0f && Energyshield.mc.player.getAbsorptionAmount() < 7.0f) {
            return new ResourceLocation("textures/gui/energyshield/e5.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 3.0f && Energyshield.mc.player.getAbsorptionAmount() < 5.0f) {
            return new ResourceLocation("textures/gui/energyshield/e3.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 1.0f && Energyshield.mc.player.getAbsorptionAmount() < 3.0f) {
            return new ResourceLocation("textures/gui/energyshield/e1.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 0.0f && Energyshield.mc.player.getAbsorptionAmount() < 1.0f) {
            return new ResourceLocation("textures/gui/energyshield/e0.png");
        }
        return new ResourceLocation("textures/gui/energyshield/e0.png");
    }
    
    private ResourceLocation getenergyCE() {
        if (Energyshield.mc.player.getAbsorptionAmount() >= 16.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee16.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 15.0f && Energyshield.mc.player.getAbsorptionAmount() < 16.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee15.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 13.0f && Energyshield.mc.player.getAbsorptionAmount() < 15.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee13.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 11.0f && Energyshield.mc.player.getAbsorptionAmount() < 13.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee11.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 9.0f && Energyshield.mc.player.getAbsorptionAmount() < 11.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee9.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 7.0f && Energyshield.mc.player.getAbsorptionAmount() < 9.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee7.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 5.0f && Energyshield.mc.player.getAbsorptionAmount() < 7.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee5.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 3.0f && Energyshield.mc.player.getAbsorptionAmount() < 5.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee3.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 1.0f && Energyshield.mc.player.getAbsorptionAmount() < 3.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee1.png");
        }
        if (Energyshield.mc.player.getAbsorptionAmount() >= 0.0f && Energyshield.mc.player.getAbsorptionAmount() < 1.0f) {
            return new ResourceLocation("textures/gui/energyshield/cee0.png");
        }
        return new ResourceLocation("textures/gui/energyshield/cee0.png");
    }
    
    private static void postenergyRenderCE() {
        GlStateManager.disableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }
    
    private enum ViewMode
    {
        HALOCE;
        
        private static final ViewMode[] $VALUES;
        
        REACH;
        
        static {
            $VALUES = new ViewMode[] { ViewMode.REACH, ViewMode.HALOCE };
        }
    }
}
