//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import me.noble.client.command.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.util.math.*;
import net.minecraft.client.entity.*;
import me.noble.client.setting.*;

@Module.Info(name = "ElytraFlight", description = "Modifies elytras to fly at custom velocities and fall speeds", category = Module.Category.MOVEMENT)
public class ElytraFlight extends Module
{
    private Setting<Float> upSpeed;
    private Setting<Float> speed;
    private Setting<ElytraFlightMode> mode;
    private Setting<Float> fallSpeed;
    private Setting<Float> downSpeed;
    private Setting<Boolean> defaultSetting;
    private Setting<Float> fallSpeedHighway;
    
    public void onUpdate() {
        if (this.defaultSetting.getValue()) {
            this.speed.setValue(1.8f);
            this.fallSpeedHighway.setValue(5.0000002E-5f);
            this.defaultSetting.setValue(false);
            Command.sendChatMessage("[ElytraFlight] Set to defaults!");
        }
        if (ElytraFlight.mc.player.capabilities.isFlying) {
            if (this.mode.getValue().equals(ElytraFlightMode.HIGHWAY)) {
                ElytraFlight.mc.player.setVelocity(0.0, 0.0, 0.0);
                ElytraFlight.mc.player.setPosition(ElytraFlight.mc.player.posX, ElytraFlight.mc.player.posY - this.fallSpeedHighway.getValue(), ElytraFlight.mc.player.posZ);
                ElytraFlight.mc.player.capabilities.setFlySpeed((float)this.speed.getValue());
                ElytraFlight.mc.player.setSprinting(false);
            }
            else {
                ElytraFlight.mc.player.setVelocity(0.0, 0.0, 0.0);
                ElytraFlight.mc.player.capabilities.setFlySpeed(0.915f);
                ElytraFlight.mc.player.setPosition(ElytraFlight.mc.player.posX, ElytraFlight.mc.player.posY - this.fallSpeed.getValue(), ElytraFlight.mc.player.posZ);
            }
        }
        if (ElytraFlight.mc.player.onGround) {
            ElytraFlight.mc.player.capabilities.allowFlying = false;
        }
        if (!ElytraFlight.mc.player.isElytraFlying()) {
            return;
        }
        switch (this.mode.getValue()) {
            case BOOST: {
                if (ElytraFlight.mc.player.isInWater()) {
                    ElytraFlight.mc.getConnection().sendPacket((Packet)new CPacketEntityAction((Entity)ElytraFlight.mc.player, CPacketEntityAction.Action.START_FALL_FLYING));
                    return;
                }
                if (ElytraFlight.mc.gameSettings.keyBindJump.isKeyDown()) {
                    final EntityPlayerSP player = ElytraFlight.mc.player;
                    player.motionY += this.upSpeed.getValue();
                }
                else if (ElytraFlight.mc.gameSettings.keyBindSneak.isKeyDown()) {
                    final EntityPlayerSP player2 = ElytraFlight.mc.player;
                    player2.motionY -= this.downSpeed.getValue();
                }
                if (ElytraFlight.mc.gameSettings.keyBindForward.isKeyDown()) {
                    final float n = (float)Math.toRadians(ElytraFlight.mc.player.rotationYaw);
                    final EntityPlayerSP player3 = ElytraFlight.mc.player;
                    player3.motionX -= MathHelper.sin(n) * 0.05f;
                    final EntityPlayerSP player4 = ElytraFlight.mc.player;
                    player4.motionZ += MathHelper.cos(n) * 0.05f;
                    break;
                }
                if (ElytraFlight.mc.gameSettings.keyBindBack.isKeyDown()) {
                    final float n2 = (float)Math.toRadians(ElytraFlight.mc.player.rotationYaw);
                    final EntityPlayerSP player5 = ElytraFlight.mc.player;
                    player5.motionX += MathHelper.sin(n2) * 0.05f;
                    final EntityPlayerSP player6 = ElytraFlight.mc.player;
                    player6.motionZ -= MathHelper.cos(n2) * 0.05f;
                    break;
                }
                break;
            }
            default: {
                ElytraFlight.mc.player.capabilities.setFlySpeed(0.915f);
                ElytraFlight.mc.player.capabilities.isFlying = true;
                if (ElytraFlight.mc.player.capabilities.isCreativeMode) {
                    return;
                }
                ElytraFlight.mc.player.capabilities.allowFlying = true;
                break;
            }
        }
    }
    
    protected void onDisable() {
        ElytraFlight.mc.player.capabilities.isFlying = false;
        ElytraFlight.mc.player.capabilities.setFlySpeed(0.05f);
        if (ElytraFlight.mc.player.capabilities.isCreativeMode) {
            return;
        }
        ElytraFlight.mc.player.capabilities.allowFlying = false;
    }
    
    public ElytraFlight() {
        this.mode = (Setting<ElytraFlightMode>)this.register((Setting)Settings.e("Mode", ElytraFlightMode.HIGHWAY));
        this.defaultSetting = (Setting<Boolean>)this.register((Setting)Settings.b("Defaults", false));
        this.speed = (Setting<Float>)this.register((Setting)Settings.f("Speed Highway", 1.8f));
        this.upSpeed = (Setting<Float>)this.register((Setting)Settings.f("Up Speed", 0.08f));
        this.downSpeed = (Setting<Float>)this.register((Setting)Settings.f("Down Speed", 0.04f));
        this.fallSpeedHighway = (Setting<Float>)this.register((Setting)Settings.f("Fall Speed Highway", 5.0000002E-5f));
        this.fallSpeed = (Setting<Float>)this.register((Setting)Settings.f("Fall Speed", -0.003f));
    }
    
    private enum ElytraFlightMode
    {
        FLY, 
        HIGHWAY, 
        BOOST;
        
        private static final ElytraFlightMode[] $VALUES;
        
        static {
            $VALUES = new ElytraFlightMode[] { ElytraFlightMode.BOOST, ElytraFlightMode.FLY, ElytraFlightMode.HIGHWAY };
        }
    }
}
