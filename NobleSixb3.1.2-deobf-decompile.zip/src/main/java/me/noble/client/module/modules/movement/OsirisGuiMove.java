//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import net.minecraft.client.gui.*;
import org.lwjgl.input.*;
import net.minecraft.client.entity.*;

@Module.Info(name = "OsirisGuiMove", category = Module.Category.MOVEMENT)
public class OsirisGuiMove extends Module
{
    public void onUpdate() {
        if (OsirisGuiMove.mc.currentScreen != null && !(OsirisGuiMove.mc.currentScreen instanceof GuiChat)) {
            if (Keyboard.isKeyDown(200)) {
                final EntityPlayerSP player = OsirisGuiMove.mc.player;
                player.rotationPitch -= 5.0f;
            }
            if (Keyboard.isKeyDown(208)) {
                final EntityPlayerSP player2 = OsirisGuiMove.mc.player;
                player2.rotationPitch += 5.0f;
            }
            if (Keyboard.isKeyDown(205)) {
                final EntityPlayerSP player3 = OsirisGuiMove.mc.player;
                player3.rotationYaw += 5.0f;
            }
            if (Keyboard.isKeyDown(203)) {
                final EntityPlayerSP player4 = OsirisGuiMove.mc.player;
                player4.rotationYaw -= 5.0f;
            }
            if (OsirisGuiMove.mc.player.rotationPitch > 90.0f) {
                OsirisGuiMove.mc.player.rotationPitch = 90.0f;
            }
            if (OsirisGuiMove.mc.player.rotationPitch < -90.0f) {
                OsirisGuiMove.mc.player.rotationPitch = -90.0f;
            }
        }
    }
}
