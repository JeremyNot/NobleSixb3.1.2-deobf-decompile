//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.command.*;
import net.minecraft.client.gui.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(name = "AutoRespawn", description = "Automatically respawn after dying", category = Module.Category.MISC)
public class AutoRespawn extends Module
{
    private Setting<Boolean> respawn;
    @EventHandler
    public Listener<GuiScreenEvent.Displayed> listener;
    private Setting<Boolean> antiGlitchScreen;
    private Setting<Boolean> deathCoords;
    
    private void lambda$new$0(final GuiScreenEvent.Displayed displayed) {
        if (!(displayed.getScreen() instanceof GuiGameOver)) {
            return;
        }
        if (this.deathCoords.getValue() && AutoRespawn.mc.player.getHealth() <= 0.0f) {
            Command.sendChatMessage(String.format("You died at x %d y %d z %d", (int)AutoRespawn.mc.player.posX, (int)AutoRespawn.mc.player.posY, (int)AutoRespawn.mc.player.posZ));
        }
        if (this.respawn.getValue() || (this.antiGlitchScreen.getValue() && AutoRespawn.mc.player.getHealth() > 0.0f)) {
            AutoRespawn.mc.player.respawnPlayer();
            AutoRespawn.mc.displayGuiScreen((GuiScreen)null);
        }
    }
    
    public AutoRespawn() {
        this.respawn = (Setting<Boolean>)this.register((Setting)Settings.b("Respawn", true));
        this.deathCoords = (Setting<Boolean>)this.register((Setting)Settings.b("DeathCoords", true));
        this.antiGlitchScreen = (Setting<Boolean>)this.register((Setting)Settings.b("Anti Glitch Screen", true));
        this.listener = new Listener<GuiScreenEvent.Displayed>(this::lambda$new$0, (Predicate<GuiScreenEvent.Displayed>[])new Predicate[0]);
    }
}
