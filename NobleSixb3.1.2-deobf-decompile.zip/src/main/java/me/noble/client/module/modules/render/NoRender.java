//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraftforge.client.event.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.*;

@Module.Info(name = "NoRender", category = Module.Category.RENDER, description = "Ignore entity spawn packets")
public class NoRender extends Module
{
    private Setting<Boolean> explosion;
    @EventHandler
    public Listener<PacketEvent.Receive> receiveListener;
    private Setting<Boolean> gentity;
    private Setting<Boolean> object;
    private Setting<Boolean> paint;
    private Setting<Boolean> mob;
    private Setting<Boolean> xp;
    @EventHandler
    public Listener<RenderBlockOverlayEvent> blockOverlayEventListener;
    private Setting<Boolean> sand;
    private Setting<Boolean> fire;
    
    private void lambda$new$1(final RenderBlockOverlayEvent renderBlockOverlayEvent) {
        if (this.fire.getValue() && renderBlockOverlayEvent.getOverlayType() == RenderBlockOverlayEvent.OverlayType.FIRE) {
            renderBlockOverlayEvent.setCanceled(true);
        }
    }
    
    public NoRender() {
        this.mob = (Setting<Boolean>)this.register((Setting)Settings.b("Mob", false));
        this.sand = (Setting<Boolean>)this.register((Setting)Settings.b("Sand", false));
        this.gentity = (Setting<Boolean>)this.register((Setting)Settings.b("GEntity", false));
        this.object = (Setting<Boolean>)this.register((Setting)Settings.b("Object", false));
        this.xp = (Setting<Boolean>)this.register((Setting)Settings.b("XP", false));
        this.paint = (Setting<Boolean>)this.register((Setting)Settings.b("Paintings", false));
        this.fire = (Setting<Boolean>)this.register((Setting)Settings.b("Fire"));
        this.explosion = (Setting<Boolean>)this.register((Setting)Settings.b("Explosions"));
        this.receiveListener = new Listener<PacketEvent.Receive>(this::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        this.blockOverlayEventListener = new Listener<RenderBlockOverlayEvent>(this::lambda$new$1, (Predicate<RenderBlockOverlayEvent>[])new Predicate[0]);
    }
    
    private void lambda$new$0(final PacketEvent.Receive receive) {
        final Packet packet = receive.getPacket();
        if ((packet instanceof SPacketSpawnMob && this.mob.getValue()) || (packet instanceof SPacketSpawnGlobalEntity && this.gentity.getValue()) || (packet instanceof SPacketSpawnObject && this.object.getValue()) || (packet instanceof SPacketSpawnExperienceOrb && this.xp.getValue()) || (packet instanceof SPacketSpawnObject && this.sand.getValue()) || (packet instanceof SPacketExplosion && this.explosion.getValue()) || (packet instanceof SPacketSpawnPainting && this.paint.getValue())) {
            receive.cancel();
        }
    }
}
