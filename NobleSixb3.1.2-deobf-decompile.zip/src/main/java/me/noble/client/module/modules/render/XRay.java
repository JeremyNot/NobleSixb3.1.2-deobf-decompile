//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.block.*;
import net.minecraft.block.state.*;
import net.minecraftforge.event.*;
import net.minecraft.block.material.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraftforge.registries.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import java.util.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;

@Mod.EventBusSubscriber(modid = "acenoblesix")
@Module.Info(name = "XRay", category = Module.Category.RENDER, description = "See through common blocks!")
public class XRay extends Module
{
    private static final String DEFAULT_XRAY_CONFIG;
    private static Set<Block> hiddenBlocks;
    private Setting<String> hiddenBlockNames;
    private static boolean invertStatic;
    public static Block transparentBlock;
    private static IBlockState transparentState;
    public Setting<Boolean> invert;
    private Setting<Boolean> outlines;
    private static boolean outlinesStatic;
    
    public void extDefaults() {
        this.extClear();
        this.extAdd("minecraft:grass,minecraft:dirt,minecraft:netherrack,minecraft:gravel,minecraft:sand,minecraft:stone");
    }
    
    public void extSet(final String s) {
        this.extClear();
        this.extAdd(s);
    }
    
    @SubscribeEvent
    public static void registerBlocks(final RegistryEvent.Register<Block> register) {
        (XRay.transparentBlock = new Block(Material.GLASS) {
            public BlockRenderLayer getBlockLayer() {
                return BlockRenderLayer.CUTOUT;
            }
            
            public boolean isOpaqueCube(final IBlockState blockState) {
                return false;
            }
            
            public boolean shouldSideBeRendered(final IBlockState blockState, final IBlockAccess blockAccess, final BlockPos blockPos, final EnumFacing enumFacing) {
                final IBlockState getBlockState = blockAccess.getBlockState(blockPos.offset(enumFacing));
                return getBlockState.getBlock() != this && !getBlockState.isOpaqueCube();
            }
        }).setRegistryName("noble_xray_transparent");
        XRay.transparentState = XRay.transparentBlock.getDefaultState();
        register.getRegistry().registerAll((IForgeRegistryEntry[])new Block[] { XRay.transparentBlock });
    }
    
    static {
        DEFAULT_XRAY_CONFIG = "minecraft:grass,minecraft:dirt,minecraft:netherrack,minecraft:gravel,minecraft:sand,minecraft:stone";
        XRay.hiddenBlocks = Collections.synchronizedSet(new HashSet<Block>());
        XRay.outlinesStatic = true;
    }
    
    public void extClear() {
        this.hiddenBlockNames.setValue("");
    }
    
    private void lambda$new$0(final String s, final String s2) {
        this.refreshHiddenBlocksSet(s2);
        if (this.isEnabled()) {
            XRay.mc.renderGlobal.loadRenderers();
        }
    }
    
    @SubscribeEvent
    public static void registerItems(final RegistryEvent.Register<Item> register) {
        register.getRegistry().registerAll((IForgeRegistryEntry[])new Item[] { (Item)new ItemBlock(XRay.transparentBlock).setRegistryName(XRay.transparentBlock.getRegistryName()) });
    }
    
    public void extAdd(final String s) {
        this.hiddenBlockNames.setValue(String.valueOf(new StringBuilder().append(this.extGetInternal(null)).append(", ").append(s)));
    }
    
    private void lambda$new$1(final Boolean b, final Boolean b2) {
        XRay.invertStatic = b2;
        if (this.isEnabled()) {
            XRay.mc.renderGlobal.loadRenderers();
        }
    }
    
    protected void onEnable() {
        XRay.mc.renderGlobal.loadRenderers();
    }
    
    public static IBlockState transform(final IBlockState blockState) {
        boolean contains = XRay.hiddenBlocks.contains(blockState.getBlock());
        if (XRay.invertStatic) {
            contains = !contains;
        }
        if (contains) {
            IBlockState blockState2 = Blocks.AIR.getDefaultState();
            if (XRay.outlinesStatic && XRay.transparentState != null) {
                blockState2 = XRay.transparentState;
            }
            return blockState2;
        }
        return blockState;
    }
    
    private String extGetInternal(final Block block) {
        final StringBuilder sb = new StringBuilder();
        int n = 0;
        for (final Block block2 : XRay.hiddenBlocks) {
            if (block2 == block) {
                continue;
            }
            if (n != 0) {
                sb.append(", ");
            }
            n = 1;
            sb.append(Block.REGISTRY.getNameForObject((Object)block2));
        }
        return String.valueOf(sb);
    }
    
    public void extRemove(final String s) {
        this.hiddenBlockNames.setValue(this.extGetInternal(Block.getBlockFromName(s)));
    }
    
    protected void onDisable() {
        XRay.mc.renderGlobal.loadRenderers();
    }
    
    private void lambda$new$2(final Boolean b, final Boolean b2) {
        XRay.outlinesStatic = b2;
        if (this.isEnabled()) {
            XRay.mc.renderGlobal.loadRenderers();
        }
    }
    
    private void refreshHiddenBlocksSet(final String s) {
        XRay.hiddenBlocks.clear();
        final String[] split = s.split(",");
        for (int length = split.length, i = 0; i < length; ++i) {
            final Block getBlockFromName = Block.getBlockFromName(split[i].trim());
            if (getBlockFromName != null) {
                XRay.hiddenBlocks.add(getBlockFromName);
            }
        }
    }
    
    public String extGet() {
        return this.extGetInternal(null);
    }
    
    public XRay() {
        this.hiddenBlockNames = (Setting<String>)this.register((SettingBuilder)Settings.stringBuilder("HiddenBlocks").withValue("minecraft:grass,minecraft:dirt,minecraft:netherrack,minecraft:gravel,minecraft:sand,minecraft:stone").withConsumer(this::lambda$new$0));
        this.invert = (Setting<Boolean>)this.register((SettingBuilder)Settings.booleanBuilder("Invert").withValue(false).withConsumer(this::lambda$new$1));
        this.outlines = (Setting<Boolean>)this.register((SettingBuilder)Settings.booleanBuilder("Outlines").withValue(false).withConsumer(this::lambda$new$2));
        XRay.invertStatic = this.invert.getValue();
        XRay.outlinesStatic = this.outlines.getValue();
        this.refreshHiddenBlocksSet(this.hiddenBlockNames.getValue());
    }
}
