//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;

@Module.Info(name = "ShulkerPreview", category = Module.Category.RENDER, description = "Previews shulkers in the game GUI")
public class ShulkerPreview extends Module
{
}
