//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import me.noble.client.setting.*;

@Module.Info(name = "AntiFog", description = "Disables or reduces fog", category = Module.Category.RENDER)
public class AntiFog extends Module
{
    public static Setting<VisionMode> mode;
    private static AntiFog INSTANCE;
    
    static {
        AntiFog.mode = Settings.e("Mode", VisionMode.NOFOG);
        AntiFog.INSTANCE = new AntiFog();
    }
    
    public AntiFog() {
        (AntiFog.INSTANCE = this).register((Setting)AntiFog.mode);
    }
    
    public static boolean enabled() {
        return AntiFog.INSTANCE.isEnabled();
    }
    
    public enum VisionMode
    {
        private static final VisionMode[] $VALUES;
        
        NOFOG, 
        AIR;
        
        static {
            $VALUES = new VisionMode[] { VisionMode.NOFOG, VisionMode.AIR };
        }
    }
}
