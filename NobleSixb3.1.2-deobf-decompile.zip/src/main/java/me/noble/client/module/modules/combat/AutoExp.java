//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.init.*;
import me.noble.client.setting.*;
import java.util.function.*;
import me.noble.client.command.*;

@Module.Info(name = "AutoExp", category = Module.Category.COMBAT, description = "Automatically mends armour")
public class AutoExp extends Module
{
    private Setting<Boolean> autoSwitch;
    private Setting<Boolean> autoThrow;
    @EventHandler
    private Listener<PacketEvent.Receive> receiveListener;
    private int initHotbarSlot;
    private Setting<Boolean> autoDisable;
    
    private int findXpPots() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            if (AutoExp.mc.player.inventory.getStackInSlot(i).getItem() == Items.EXPERIENCE_BOTTLE) {
                n = i;
                break;
            }
        }
        return n;
    }
    
    protected void onEnable() {
        if (AutoExp.mc.player == null) {
            return;
        }
        if (this.autoSwitch.getValue()) {
            this.initHotbarSlot = AutoExp.mc.player.inventory.currentItem;
        }
    }
    
    private boolean lambda$new$0(final Boolean b) {
        return this.autoSwitch.getValue();
    }
    
    private static void lambda$new$1(final PacketEvent.Receive receive) {
        if (AutoExp.mc.player != null && AutoExp.mc.player.getHeldItemMainhand().getItem() == Items.EXPERIENCE_BOTTLE) {
            AutoExp.mc.rightClickDelayTimer = 0;
        }
    }
    
    public AutoExp() {
        this.autoThrow = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Throw", true));
        this.autoSwitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch", true));
        this.autoDisable = (Setting<Boolean>)this.register((Setting)Settings.booleanBuilder("Auto Disable").withValue(true).withVisibility(this::lambda$new$0).build());
        this.initHotbarSlot = -1;
        this.receiveListener = new Listener<PacketEvent.Receive>(AutoExp::lambda$new$1, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    public void onUpdate() {
        if (AutoExp.mc.player == null) {
            return;
        }
        if (this.autoSwitch.getValue() && AutoExp.mc.player.getHeldItemMainhand().getItem() != Items.EXPERIENCE_BOTTLE) {
            final int xpPots = this.findXpPots();
            if (xpPots == -1) {
                if (this.autoDisable.getValue()) {
                    Command.sendWarningMessage("[AutoExp] No XP in hotbar, disabling");
                    this.disable();
                }
                return;
            }
            AutoExp.mc.player.inventory.currentItem = xpPots;
        }
        if (this.autoThrow.getValue() && AutoExp.mc.player.getHeldItemMainhand().getItem() == Items.EXPERIENCE_BOTTLE) {
            AutoExp.mc.rightClickMouse();
        }
    }
    
    protected void onDisable() {
        if (AutoExp.mc.player == null) {
            return;
        }
        if (this.autoSwitch.getValue() && this.initHotbarSlot != -1 && this.initHotbarSlot != AutoExp.mc.player.inventory.currentItem) {
            AutoExp.mc.player.inventory.currentItem = this.initHotbarSlot;
        }
    }
}
