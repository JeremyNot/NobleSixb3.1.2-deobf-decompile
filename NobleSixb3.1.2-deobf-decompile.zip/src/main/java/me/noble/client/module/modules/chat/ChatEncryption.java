//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.util.*;
import me.noble.client.setting.*;
import net.minecraft.network.play.server.*;
import me.noble.client.*;
import java.util.regex.*;
import net.minecraft.network.play.client.*;
import me.noble.client.command.*;
import java.nio.*;
import java.util.function.*;
import java.util.stream.*;
import java.util.*;
import net.minecraft.util.text.*;

@Module.Info(name = "ChatEncryption", description = "Encrypts and decrypts chat messages (Delimiter %)", category = Module.Category.CHAT, showOnArray = Module.ShowOnArray.OFF)
public class ChatEncryption extends Module
{
    private Setting<Integer> key;
    private Setting<EncryptionMode> mode;
    private static final char[] ORIGIN_CHARS;
    @EventHandler
    private Listener<PacketEvent.Send> sendListener;
    private Setting<Boolean> delim;
    @EventHandler
    private Listener<PacketEvent.Receive> receiveListener;
    private final Pattern CHAT_PATTERN;
    
    private void lambda$null$0(final StringBuilder sb, final int n) {
        sb.append((char)(n + (ChatAllowedCharacters.isAllowedCharacter((char)(n + this.key.getValue())) ? this.key.getValue() : 0)));
    }
    
    public ChatEncryption() {
        this.mode = (Setting<EncryptionMode>)this.register((Setting)Settings.e("Mode", EncryptionMode.SHUFFLE));
        this.key = (Setting<Integer>)this.register((Setting)Settings.i("Key", 6));
        this.delim = (Setting<Boolean>)this.register((Setting)Settings.b("Delimiter", true));
        this.CHAT_PATTERN = Pattern.compile("<.*?> ");
        this.sendListener = new Listener<PacketEvent.Send>(this::lambda$new$1, (Predicate<PacketEvent.Send>[])new Predicate[0]);
        this.receiveListener = new Listener<PacketEvent.Receive>(this::lambda$new$3, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    private static Character lambda$generateShuffleMap$4(final int n) {
        return (char)n;
    }
    
    private static <K, V> Map<V, K> reverseMap(final Map<K, V> map) {
        return map.entrySet().stream().collect(Collectors.toMap((Function<? super Object, ? extends V>)Map.Entry::getValue, (Function<? super Object, ? extends K>)Map.Entry::getKey));
    }
    
    private String unshuffle(final int n, final String s) {
        final Map<Character, Character> generateShuffleMap = this.generateShuffleMap(n);
        final StringBuilder sb = new StringBuilder();
        this.swapCharacters(s, reverseMap(generateShuffleMap), sb);
        return String.valueOf(sb);
    }
    
    private void lambda$null$2(final StringBuilder sb, final int n) {
        sb.append((char)(n + (ChatAllowedCharacters.isAllowedCharacter((char)n) ? (-this.key.getValue()) : 0)));
    }
    
    private void lambda$new$3(final PacketEvent.Receive receive) {
        if (receive.getPacket() instanceof SPacketChat) {
            String s = ((SPacketChat)receive.getPacket()).getChatComponent().getUnformattedText();
            final Matcher matcher = this.CHAT_PATTERN.matcher(s);
            String substring = "unnamed";
            if (matcher.find()) {
                final String group = matcher.group();
                substring = group.substring(1, group.length() - 2);
                s = matcher.replaceFirst("");
            }
            final StringBuilder sb = new StringBuilder();
            switch (this.mode.getValue()) {
                case SHUFFLE: {
                    if (!s.endsWith("\ud83d\ude4d")) {
                        return;
                    }
                    sb.append(this.unshuffle(this.key.getValue(), s.substring(0, s.length() - 2)));
                    break;
                }
                case SHIFT: {
                    if (!s.endsWith("\ud83d\ude48")) {
                        return;
                    }
                    s.substring(0, s.length() - 2).chars().forEachOrdered(this::lambda$null$2);
                    break;
                }
            }
            ((SPacketChat)receive.getPacket()).chatComponent = (ITextComponent)new TextComponentString(String.valueOf(new StringBuilder().append(NobleMod.colour).append("b").append(substring).append(NobleMod.colour).append("r: ").append(String.valueOf(sb))));
        }
    }
    
    private void lambda$new$1(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketChatMessage) {
            String s = ((CPacketChatMessage)send.getPacket()).getMessage();
            if (this.delim.getValue()) {
                if (!s.startsWith("%")) {
                    return;
                }
                s = s.substring(1);
            }
            final StringBuilder sb = new StringBuilder();
            switch (this.mode.getValue()) {
                case SHUFFLE: {
                    sb.append(this.shuffle(this.key.getValue(), s));
                    sb.append("\ud83d\ude4d");
                    break;
                }
                case SHIFT: {
                    s.chars().forEachOrdered(this::lambda$null$0);
                    sb.append("\ud83d\ude48");
                    break;
                }
            }
            final String value = String.valueOf(sb);
            if (value.length() > 256) {
                Command.sendChatMessage("Encrypted message length was too long, couldn't send!");
                send.cancel();
                return;
            }
            ((CPacketChatMessage)send.getPacket()).message = value;
        }
    }
    
    private void swapCharacters(final String s, final Map<Character, Character> map, final StringBuilder sb) {
        CharBuffer.wrap(s.toCharArray()).chars().forEachOrdered(ChatEncryption::lambda$swapCharacters$5);
    }
    
    private Map<Character, Character> generateShuffleMap(final int n) {
        final Random random = new Random(n);
        final List<? super Object> list = CharBuffer.wrap(ChatEncryption.ORIGIN_CHARS).chars().mapToObj((IntFunction<?>)ChatEncryption::lambda$generateShuffleMap$4).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
        final ArrayList list2 = new ArrayList<Object>(list);
        Collections.shuffle(list2, random);
        final LinkedHashMap<Character, Character> linkedHashMap = new LinkedHashMap<Character, Character>();
        for (int i = 0; i < list.size(); ++i) {
            linkedHashMap.put(list.get(i), (Character)list2.get(i));
        }
        return linkedHashMap;
    }
    
    private static void lambda$swapCharacters$5(final Map map, final StringBuilder sb, final int n) {
        final char c = (char)n;
        if (map.containsKey(c)) {
            sb.append(map.get(c));
        }
        else {
            sb.append(c);
        }
    }
    
    private String shuffle(final int n, final String s) {
        final Map<Character, Character> generateShuffleMap = this.generateShuffleMap(n);
        final StringBuilder sb = new StringBuilder();
        this.swapCharacters(s, generateShuffleMap, sb);
        return String.valueOf(sb);
    }
    
    static {
        ORIGIN_CHARS = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '-', '_', '/', ';', '=', '?', '+', '?', '?', '*', '^', '\u00f9', '$', '!', '{', '}', '\'', '\"', '|', '&' };
    }
    
    private enum EncryptionMode
    {
        private static final EncryptionMode[] $VALUES;
        
        SHUFFLE, 
        SHIFT;
        
        static {
            $VALUES = new EncryptionMode[] { EncryptionMode.SHUFFLE, EncryptionMode.SHIFT };
        }
    }
}
