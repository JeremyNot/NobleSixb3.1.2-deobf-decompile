//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.util.*;
import me.noble.client.setting.*;
import net.minecraftforge.client.event.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import net.minecraft.world.*;
import me.noble.client.util.*;
import java.util.*;

@Module.Info(name = "BossStack", description = "Modify the boss health GUI to take up less space", category = Module.Category.MISC)
public class BossStack extends Module
{
    private static Setting<BossStackMode> mode;
    private static final ResourceLocation GUI_BARS_TEXTURES;
    private static Setting<Double> scale;
    
    static {
        BossStack.mode = Settings.e("Mode", BossStackMode.STACK);
        BossStack.scale = Settings.d("Scale", 0.5);
        GUI_BARS_TEXTURES = new ResourceLocation("textures/gui/bars.png");
    }
    
    public BossStack() {
        this.registerAll(new Setting[] { BossStack.mode, BossStack.scale });
    }
    
    public static void render(final RenderGameOverlayEvent.Post post) {
        if (BossStack.mode.getValue() == BossStackMode.MINIMIZE) {
            final Map mapBossInfos = Minecraft.getMinecraft().ingameGUI.getBossOverlay().mapBossInfos;
            if (mapBossInfos == null) {
                return;
            }
            final int getScaledWidth = new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth();
            int n = 12;
            final Iterator<Map.Entry<K, BossInfoClient>> iterator = mapBossInfos.entrySet().iterator();
            while (iterator.hasNext()) {
                final BossInfoClient bossInfoClient = iterator.next().getValue();
                final String getFormattedText = bossInfoClient.getName().getFormattedText();
                final int n2 = (int)(getScaledWidth / BossStack.scale.getValue() / 2.0 - 91.0);
                GL11.glScaled((double)BossStack.scale.getValue(), (double)BossStack.scale.getValue(), 1.0);
                if (!post.isCanceled()) {
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    Minecraft.getMinecraft().getTextureManager().bindTexture(BossStack.GUI_BARS_TEXTURES);
                    Minecraft.getMinecraft().ingameGUI.getBossOverlay().render(n2, n, (BossInfo)bossInfoClient);
                    Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(getFormattedText, (float)(getScaledWidth / BossStack.scale.getValue() / 2.0 - Minecraft.getMinecraft().fontRendererObj.getStringWidth(getFormattedText) / 2), (float)(n - 9), 16777215);
                }
                GL11.glScaled(1.0 / BossStack.scale.getValue(), 1.0 / BossStack.scale.getValue(), 1.0);
                n += 10 + Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT;
            }
        }
        else if (BossStack.mode.getValue() == BossStackMode.STACK) {
            final Map mapBossInfos2 = Minecraft.getMinecraft().ingameGUI.getBossOverlay().mapBossInfos;
            final HashMap<Object, Pair<Object, S>> hashMap = new HashMap<Object, Pair<Object, S>>();
            for (final Map.Entry<K, BossInfoClient> entry : mapBossInfos2.entrySet()) {
                final String getFormattedText2 = entry.getValue().getName().getFormattedText();
                if (hashMap.containsKey(getFormattedText2)) {
                    final Pair<Object, S> pair = hashMap.get(getFormattedText2);
                    hashMap.put(getFormattedText2, (Pair<Object, S>)new Pair<Object, Object>(pair.getKey(), (int)pair.getValue() + 1));
                }
                else {
                    hashMap.put(getFormattedText2, (Pair<Object, S>)new Pair<Object, Object>(entry.getValue(), (S)1));
                }
            }
            final int getScaledWidth2 = new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth();
            int n3 = 12;
            for (final Map.Entry<String, Pair<Object, S>> entry2 : hashMap.entrySet()) {
                final String s = entry2.getKey();
                final BossInfoClient bossInfoClient2 = entry2.getValue().getKey();
                final String value = String.valueOf(new StringBuilder().append(s).append(" x").append((int)entry2.getValue().getValue()));
                final int n4 = (int)(getScaledWidth2 / BossStack.scale.getValue() / 2.0 - 91.0);
                GL11.glScaled((double)BossStack.scale.getValue(), (double)BossStack.scale.getValue(), 1.0);
                if (!post.isCanceled()) {
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    Minecraft.getMinecraft().getTextureManager().bindTexture(BossStack.GUI_BARS_TEXTURES);
                    Minecraft.getMinecraft().ingameGUI.getBossOverlay().render(n4, n3, (BossInfo)bossInfoClient2);
                    Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(value, (float)(getScaledWidth2 / BossStack.scale.getValue() / 2.0 - Minecraft.getMinecraft().fontRendererObj.getStringWidth(value) / 2), (float)(n3 - 9), 16777215);
                }
                GL11.glScaled(1.0 / BossStack.scale.getValue(), 1.0 / BossStack.scale.getValue(), 1.0);
                n3 += 10 + Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT;
            }
        }
    }
    
    private enum BossStackMode
    {
        STACK, 
        REMOVE;
        
        private static final BossStackMode[] $VALUES;
        
        MINIMIZE;
        
        static {
            $VALUES = new BossStackMode[] { BossStackMode.REMOVE, BossStackMode.STACK, BossStackMode.MINIMIZE };
        }
    }
}
