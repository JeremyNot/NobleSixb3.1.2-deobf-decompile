//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.setting.*;
import net.minecraft.util.math.*;
import me.noble.client.command.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.nbt.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.misc.*;
import java.util.*;

@Module.Info(name = "Aura", category = Module.Category.COMBAT, description = "Hits entities around you")
public class Aura extends Module
{
    private Setting<HitMode> hitMode;
    private Setting<Boolean> autoWait;
    private Setting<Double> hitRange;
    private Setting<Boolean> attackAnimals;
    private Setting<WaitMode> waitMode;
    private Setting<Double> waitTick;
    private Setting<Boolean> attackPlayers;
    private Setting<SwitchMode> switchMode;
    private Setting<Boolean> infoMsg;
    private int waitCounter;
    private Setting<Boolean> attackMobs;
    private Setting<Boolean> ignoreWalls;
    
    public Aura() {
        this.attackPlayers = (Setting<Boolean>)this.register((Setting)Settings.b("Players", true));
        this.attackMobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
        this.attackAnimals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
        this.hitRange = (Setting<Double>)this.register((Setting)Settings.d("Hit Range", 5.5));
        this.ignoreWalls = (Setting<Boolean>)this.register((Setting)Settings.b("Ignore Walls", true));
        this.waitMode = (Setting<WaitMode>)this.register((Setting)Settings.e("Mode", WaitMode.TICK));
        this.waitTick = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Tick Delay").withMinimum(0.1).withValue(2.0).withMaximum(20.0).build());
        this.autoWait = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Tick Delay", true));
        this.switchMode = (Setting<SwitchMode>)this.register((Setting)Settings.e("Autoswitch", SwitchMode.ALL));
        this.hitMode = (Setting<HitMode>)this.register((Setting)Settings.e("Tool", HitMode.SWORD));
        this.infoMsg = (Setting<Boolean>)this.register((Setting)Settings.b("Info Message", true));
    }
    
    private boolean canEntityFeetBeSeen(final Entity entity) {
        return Aura.mc.world.rayTraceBlocks(new Vec3d(Aura.mc.player.posX, Aura.mc.player.posY + Aura.mc.player.getEyeHeight(), Aura.mc.player.posZ), new Vec3d(entity.posX, entity.posY, entity.posZ), false, true, false) == null;
    }
    
    public void onEnable() {
        if (Aura.mc.player == null) {
            return;
        }
        if (this.autoWait.getValue() && this.infoMsg.getValue()) {
            Command.sendWarningMessage("[Aura] When Auto Tick Delay is turned on whatever you give Tick Delay doesn't matter, it uses the current TPS instead");
        }
    }
    
    private boolean checkSharpness(final ItemStack itemStack) {
        if (itemStack.getTagCompound() == null) {
            return false;
        }
        if (itemStack.getItem().equals(Items.DIAMOND_AXE) && this.hitMode.getValue().equals(HitMode.SWORD)) {
            return false;
        }
        if (itemStack.getItem().equals(Items.DIAMOND_SWORD) && this.hitMode.getValue().equals(HitMode.AXE)) {
            return false;
        }
        final NBTTagList list = (NBTTagList)itemStack.getTagCompound().getTag("ench");
        if (list == null) {
            return false;
        }
        int i = 0;
        while (i < list.tagCount()) {
            final NBTTagCompound getCompoundTagAt = list.getCompoundTagAt(i);
            if (getCompoundTagAt.getInteger("id") == 16) {
                final int getInteger = getCompoundTagAt.getInteger("lvl");
                if (this.switchMode.getValue().equals(SwitchMode.Only32k)) {
                    if (getInteger >= 42) {
                        return true;
                    }
                    break;
                }
                else if (this.switchMode.getValue().equals(SwitchMode.ALL)) {
                    if (getInteger >= 4) {
                        return true;
                    }
                    break;
                }
                else {
                    if (this.switchMode.getValue().equals(SwitchMode.NONE)) {
                        return true;
                    }
                    break;
                }
            }
            else {
                ++i;
            }
        }
        return false;
    }
    
    public void onUpdate() {
        double n = 0.0;
        if (Aura.mc.player.isDead || Aura.mc.player == null) {
            return;
        }
        if (this.autoWait.getValue()) {
            n = 20.0 - Math.round(LagCompensator.INSTANCE.getTickRate() * 10.0f) / 10.0;
        }
        final boolean b = Aura.mc.player.getHeldItemOffhand().getItem().equals(Items.SHIELD) && Aura.mc.player.getActiveHand() == EnumHand.OFF_HAND;
        if (Aura.mc.player.isHandActive() && !b) {
            return;
        }
        if (this.waitMode.getValue().equals(WaitMode.CPS)) {
            if (Aura.mc.player.getCooledAttackStrength(this.getLagComp()) < 1.0f) {
                return;
            }
            if (Aura.mc.player.ticksExisted % 2 != 0) {
                return;
            }
        }
        if (this.autoWait.getValue()) {
            if (this.waitMode.getValue().equals(WaitMode.TICK) && n > 0.0) {
                if (this.waitCounter < n) {
                    ++this.waitCounter;
                    return;
                }
                this.waitCounter = 0;
            }
        }
        else if (this.waitMode.getValue().equals(WaitMode.TICK) && this.waitTick.getValue() > 0.0) {
            if (this.waitCounter < this.waitTick.getValue()) {
                ++this.waitCounter;
                return;
            }
            this.waitCounter = 0;
        }
        for (final Entity entity : Minecraft.getMinecraft().world.loadedEntityList) {
            if (!EntityUtil.isLiving(entity)) {
                continue;
            }
            if (entity == Aura.mc.player) {
                continue;
            }
            if (Aura.mc.player.getDistanceToEntity(entity) > this.hitRange.getValue()) {
                continue;
            }
            if (((EntityLivingBase)entity).getHealth() <= 0.0f) {
                continue;
            }
            if (this.waitMode.getValue().equals(WaitMode.CPS) && ((EntityLivingBase)entity).hurtTime != 0) {
                continue;
            }
            if (!this.ignoreWalls.getValue() && !Aura.mc.player.canEntityBeSeen(entity) && !this.canEntityFeetBeSeen(entity)) {
                continue;
            }
            if (this.attackPlayers.getValue() && entity instanceof EntityPlayer && !Friends.isFriend(entity.getName())) {
                this.attack(entity);
                return;
            }
            Label_0599: {
                if (EntityUtil.isPassive(entity)) {
                    if (this.attackAnimals.getValue()) {
                        break Label_0599;
                    }
                    continue;
                }
                else {
                    if (EntityUtil.isMobAggressive(entity) && this.attackMobs.getValue()) {
                        break Label_0599;
                    }
                    continue;
                }
                continue;
            }
            if ((!this.switchMode.getValue().equals(SwitchMode.Only32k) || this.switchMode.getValue().equals(SwitchMode.ALL)) && ModuleManager.isModuleEnabled("AutoTool")) {
                AutoTool.equipBestWeapon();
            }
            this.attack(entity);
        }
    }
    
    private float getLagComp() {
        if (this.waitMode.getValue().equals(WaitMode.CPS)) {
            return -(20.0f - LagCompensator.INSTANCE.getTickRate());
        }
        return 0.0f;
    }
    
    private void attack(final Entity entity) {
        int n = 0;
        if (this.checkSharpness(Aura.mc.player.getHeldItemMainhand())) {
            n = 1;
        }
        if ((this.switchMode.getValue().equals(SwitchMode.Only32k) || this.switchMode.getValue().equals(SwitchMode.ALL)) && n == 0) {
            int currentItem = -1;
            for (int i = 0; i < 9; ++i) {
                final ItemStack getStackInSlot = Aura.mc.player.inventory.getStackInSlot(i);
                if (getStackInSlot != ItemStack.field_190927_a) {
                    if (this.checkSharpness(getStackInSlot)) {
                        currentItem = i;
                        break;
                    }
                }
            }
            if (currentItem != -1) {
                Aura.mc.player.inventory.currentItem = currentItem;
                n = 1;
            }
        }
        if (this.switchMode.getValue().equals(SwitchMode.Only32k) && n == 0) {
            return;
        }
        Aura.mc.playerController.attackEntity((EntityPlayer)Aura.mc.player, entity);
        Aura.mc.player.swingArm(EnumHand.MAIN_HAND);
    }
    
    private enum SwitchMode
    {
        ALL, 
        NONE;
        
        private static final SwitchMode[] $VALUES;
        
        Only32k;
        
        static {
            $VALUES = new SwitchMode[] { SwitchMode.NONE, SwitchMode.ALL, SwitchMode.Only32k };
        }
    }
    
    private enum WaitMode
    {
        private static final WaitMode[] $VALUES;
        
        CPS, 
        TICK;
        
        static {
            $VALUES = new WaitMode[] { WaitMode.CPS, WaitMode.TICK };
        }
    }
    
    private enum HitMode
    {
        private static final HitMode[] $VALUES;
        
        AXE, 
        SWORD;
        
        static {
            $VALUES = new HitMode[] { HitMode.SWORD, HitMode.AXE };
        }
    }
}
