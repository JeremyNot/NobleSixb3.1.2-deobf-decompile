//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.zero.alpine.listener.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.*;
import java.util.stream.*;
import me.noble.client.event.events.*;
import me.noble.client.module.modules.render.*;
import me.noble.client.setting.*;
import net.minecraft.entity.*;
import net.minecraft.enchantment.*;
import net.minecraft.potion.*;
import net.minecraft.network.*;
import java.util.function.*;
import me.noble.client.util.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.client.entity.*;

@Module.Info(name = "CrystalAura", category = Module.Category.COMBAT, description = "Places End Crystals to kill enemies")
public class CrystalAura extends Module
{
    @EventHandler
    private Listener<PacketEvent.Send> packetListener;
    private long systemTime;
    private BlockPos render;
    private Setting<Boolean> animals;
    private Setting<Boolean> explode;
    private boolean switchCooldown;
    private static boolean togglePitch;
    private int oldSlot;
    private Setting<Boolean> players;
    private static double yaw;
    private static double pitch;
    private int newSlot;
    private Setting<Boolean> mobs;
    private Setting<Boolean> autoSwitch;
    private Entity renderEnt;
    private static boolean isSpoofingAngles;
    private Setting<Boolean> antiWeakness;
    private Setting<Boolean> place;
    private boolean isAttacking;
    private Setting<Double> range;
    
    private void lookAtPacket(final double n, final double n2, final double n3, final EntityPlayer entityPlayer) {
        final double[] calculateLook = EntityUtil.calculateLookAt(n, n2, n3, entityPlayer);
        setYawAndPitch((float)calculateLook[0], (float)calculateLook[1]);
    }
    
    private static boolean lambda$onUpdate$3(final EntityPlayer entityPlayer) {
        return !Friends.isFriend(entityPlayer.getName());
    }
    
    public List<BlockPos> getSphere(final BlockPos blockPos, final float n, final int n2, final boolean b, final boolean b2, final int n3) {
        final ArrayList<BlockPos> list = new ArrayList<BlockPos>();
        final int getX = blockPos.getX();
        final int getY = blockPos.getY();
        final int getZ = blockPos.getZ();
        for (int n4 = getX - (int)n; n4 <= getX + n; ++n4) {
            for (int n5 = getZ - (int)n; n5 <= getZ + n; ++n5) {
                for (int n6 = b2 ? (getY - (int)n) : getY; n6 < (b2 ? (getY + n) : ((float)(getY + n2))); ++n6) {
                    final double n7 = (getX - n4) * (getX - n4) + (getZ - n5) * (getZ - n5) + (b2 ? ((getY - n6) * (getY - n6)) : 0);
                    if (n7 < n * n && (!b || n7 >= (n - 1.0f) * (n - 1.0f))) {
                        list.add(new BlockPos(n4, n6 + n3, n5));
                    }
                }
            }
        }
        return list;
    }
    
    private static float getDamageMultiplied(final float n) {
        final int getDifficultyId = CrystalAura.mc.world.getDifficulty().getDifficultyId();
        return n * ((getDifficultyId == 0) ? 0.0f : ((getDifficultyId == 2) ? 1.0f : ((getDifficultyId == 1) ? 0.5f : 1.5f)));
    }
    
    private static boolean lambda$onUpdate$0(final Entity entity) {
        return entity instanceof EntityEnderCrystal;
    }
    
    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(CrystalAura.mc.player.posX), Math.floor(CrystalAura.mc.player.posY), Math.floor(CrystalAura.mc.player.posZ));
    }
    
    private boolean lambda$onUpdate$4(final Entity entity) {
        return EntityUtil.isLiving(entity) && (EntityUtil.isPassive(entity) ? this.animals.getValue() : this.mobs.getValue());
    }
    
    public void onDisable() {
        this.render = null;
        this.renderEnt = null;
        resetRotation();
    }
    
    public static float calculateDamage(final double n, final double n2, final double n3, final Entity entity) {
        final float n4 = 12.0f;
        final double n5 = (1.0 - entity.getDistance(n, n2, n3) / n4) * entity.world.getBlockDensity(new Vec3d(n, n2, n3), entity.getEntityBoundingBox());
        final float n6 = (float)(int)((n5 * n5 + n5) / 2.0 * 7.0 * n4 + 1.0);
        double n7 = 1.0;
        if (entity instanceof EntityLivingBase) {
            n7 = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(n6), new Explosion((World)CrystalAura.mc.world, (Entity)null, n, n2, n3, 6.0f, false, true));
        }
        return (float)n7;
    }
    
    private List<BlockPos> findCrystalBlocks() {
        final NonNullList func_191196_a = NonNullList.func_191196_a();
        func_191196_a.addAll((Collection)this.getSphere(getPlayerPos(), this.range.getValue().floatValue(), this.range.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::canPlaceCrystal).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return (List<BlockPos>)func_191196_a;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (this.render != null) {
            KamiTessellator.prepare(7);
            KamiTessellator.drawBox(this.render, 1157627903, 63);
            KamiTessellator.release();
            if (this.renderEnt != null) {
                final Vec3d interpolatedRenderPos = EntityUtil.getInterpolatedRenderPos(this.renderEnt, CrystalAura.mc.getRenderPartialTicks());
                Tracers.drawLineFromPosToPos(this.render.x - CrystalAura.mc.getRenderManager().renderPosX + 0.5, this.render.y - CrystalAura.mc.getRenderManager().renderPosY + 1.0, this.render.z - CrystalAura.mc.getRenderManager().renderPosZ + 0.5, interpolatedRenderPos.xCoord, interpolatedRenderPos.yCoord, interpolatedRenderPos.zCoord, this.renderEnt.getEyeHeight(), 1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
    }
    
    public CrystalAura() {
        this.autoSwitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch"));
        this.players = (Setting<Boolean>)this.register((Setting)Settings.b("Players"));
        this.mobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
        this.animals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
        this.place = (Setting<Boolean>)this.register((Setting)Settings.b("Place", false));
        this.explode = (Setting<Boolean>)this.register((Setting)Settings.b("Explode", false));
        this.range = (Setting<Double>)this.register((Setting)Settings.d("Range", 4.0));
        this.antiWeakness = (Setting<Boolean>)this.register((Setting)Settings.b("Anti Weakness", false));
        this.systemTime = -1L;
        this.switchCooldown = false;
        this.isAttacking = false;
        this.oldSlot = -1;
        this.packetListener = new Listener<PacketEvent.Send>(CrystalAura::lambda$new$5, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private static Float lambda$onUpdate$2(final EntityEnderCrystal entityEnderCrystal) {
        return CrystalAura.mc.player.getDistanceToEntity((Entity)entityEnderCrystal);
    }
    
    private boolean canPlaceCrystal(final BlockPos blockPos) {
        final BlockPos add = blockPos.add(0, 1, 0);
        final BlockPos add2 = blockPos.add(0, 2, 0);
        return (CrystalAura.mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || CrystalAura.mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && CrystalAura.mc.world.getBlockState(add).getBlock() == Blocks.AIR && CrystalAura.mc.world.getBlockState(add2).getBlock() == Blocks.AIR && CrystalAura.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add)).isEmpty() && CrystalAura.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add2)).isEmpty();
    }
    
    public static float getBlastReduction(final EntityLivingBase entityLivingBase, float n, final Explosion explosion) {
        if (entityLivingBase instanceof EntityPlayer) {
            final EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            final DamageSource causeExplosionDamage = DamageSource.causeExplosionDamage(explosion);
            n = CombatRules.getDamageAfterAbsorb(n, (float)entityPlayer.getTotalArmorValue(), (float)entityPlayer.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            n *= 1.0f - MathHelper.clamp((float)EnchantmentHelper.getEnchantmentModifierDamage(entityPlayer.getArmorInventoryList(), causeExplosionDamage), 0.0f, 20.0f) / 25.0f;
            if (entityLivingBase.isPotionActive(Potion.getPotionById(11))) {
                n -= n / 4.0f;
            }
            n = Math.max(n - entityPlayer.getAbsorptionAmount(), 0.0f);
            return n;
        }
        n = CombatRules.getDamageAfterAbsorb(n, (float)entityLivingBase.getTotalArmorValue(), (float)entityLivingBase.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
        return n;
    }
    
    private static void lambda$new$5(final PacketEvent.Send send) {
        final Packet packet = send.getPacket();
        if (packet instanceof CPacketPlayer && CrystalAura.isSpoofingAngles) {
            ((CPacketPlayer)packet).yaw = (float)CrystalAura.yaw;
            ((CPacketPlayer)packet).pitch = (float)CrystalAura.pitch;
        }
    }
    
    static {
        CrystalAura.togglePitch = false;
    }
    
    private static void resetRotation() {
        if (CrystalAura.isSpoofingAngles) {
            CrystalAura.yaw = CrystalAura.mc.player.rotationYaw;
            CrystalAura.pitch = CrystalAura.mc.player.rotationPitch;
            CrystalAura.isSpoofingAngles = false;
        }
    }
    
    public static float calculateDamage(final EntityEnderCrystal entityEnderCrystal, final Entity entity) {
        return calculateDamage(entityEnderCrystal.posX, entityEnderCrystal.posY, entityEnderCrystal.posZ, entity);
    }
    
    private static EntityEnderCrystal lambda$onUpdate$1(final Entity entity) {
        return (EntityEnderCrystal)entity;
    }
    
    public void onUpdate() {
        final EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal)CrystalAura.mc.world.loadedEntityList.stream().filter(CrystalAura::lambda$onUpdate$0).map(CrystalAura::lambda$onUpdate$1).min(Comparator.comparing((Function<? super T, ? extends Comparable>)CrystalAura::lambda$onUpdate$2)).orElse(null);
        if (this.explode.getValue() && entityEnderCrystal != null && CrystalAura.mc.player.getDistanceToEntity((Entity)entityEnderCrystal) <= this.range.getValue()) {
            if (System.nanoTime() / 1000000L - this.systemTime >= 250L) {
                if (this.antiWeakness.getValue() && CrystalAura.mc.player.isPotionActive(MobEffects.WEAKNESS)) {
                    if (!this.isAttacking) {
                        this.oldSlot = Wrapper.getPlayer().inventory.currentItem;
                        this.isAttacking = true;
                    }
                    this.newSlot = -1;
                    for (int i = 0; i < 9; ++i) {
                        final ItemStack getStackInSlot = Wrapper.getPlayer().inventory.getStackInSlot(i);
                        if (getStackInSlot != ItemStack.field_190927_a) {
                            if (getStackInSlot.getItem() instanceof ItemSword) {
                                this.newSlot = i;
                                break;
                            }
                            if (getStackInSlot.getItem() instanceof ItemTool) {
                                this.newSlot = i;
                                break;
                            }
                        }
                    }
                    if (this.newSlot != -1) {
                        Wrapper.getPlayer().inventory.currentItem = this.newSlot;
                        this.switchCooldown = true;
                    }
                }
                this.lookAtPacket(entityEnderCrystal.posX, entityEnderCrystal.posY, entityEnderCrystal.posZ, (EntityPlayer)CrystalAura.mc.player);
                CrystalAura.mc.playerController.attackEntity((EntityPlayer)CrystalAura.mc.player, (Entity)entityEnderCrystal);
                CrystalAura.mc.player.swingArm(EnumHand.MAIN_HAND);
                this.systemTime = System.nanoTime() / 1000000L;
            }
            return;
        }
        resetRotation();
        if (this.oldSlot != -1) {
            Wrapper.getPlayer().inventory.currentItem = this.oldSlot;
            this.oldSlot = -1;
        }
        this.isAttacking = false;
        int currentItem = (CrystalAura.mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) ? CrystalAura.mc.player.inventory.currentItem : -1;
        if (currentItem == -1) {
            for (int j = 0; j < 9; ++j) {
                if (CrystalAura.mc.player.inventory.getStackInSlot(j).getItem() == Items.END_CRYSTAL) {
                    currentItem = j;
                    break;
                }
            }
        }
        boolean b = false;
        if (CrystalAura.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
            b = true;
        }
        else if (currentItem == -1) {
            return;
        }
        final List<BlockPos> crystalBlocks = this.findCrystalBlocks();
        final ArrayList<Entity> list = new ArrayList<Entity>();
        if (this.players.getValue()) {
            list.addAll((Collection<?>)CrystalAura.mc.world.playerEntities.stream().filter(CrystalAura::lambda$onUpdate$3).collect(Collectors.toList()));
        }
        list.addAll((Collection<?>)CrystalAura.mc.world.loadedEntityList.stream().filter(this::lambda$onUpdate$4).collect(Collectors.toList()));
        BlockPos render = null;
        double n = 0.5;
        for (final Entity renderEnt : list) {
            if (renderEnt != CrystalAura.mc.player) {
                if (((EntityLivingBase)renderEnt).getHealth() <= 0.0f) {
                    continue;
                }
                for (final BlockPos blockPos : crystalBlocks) {
                    if (renderEnt.getDistanceSq(blockPos) >= 169.0) {
                        continue;
                    }
                    final double n2 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, renderEnt);
                    if (n2 <= n) {
                        continue;
                    }
                    final double n3 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, (Entity)CrystalAura.mc.player);
                    if (n3 > n2 && n2 >= ((EntityLivingBase)renderEnt).getHealth()) {
                        continue;
                    }
                    if (n3 - 0.5 > CrystalAura.mc.player.getHealth()) {
                        continue;
                    }
                    n = n2;
                    render = blockPos;
                    this.renderEnt = renderEnt;
                }
            }
        }
        if (n == 0.5) {
            this.render = null;
            this.renderEnt = null;
            resetRotation();
            return;
        }
        this.render = render;
        if (this.place.getValue()) {
            if (!b && CrystalAura.mc.player.inventory.currentItem != currentItem) {
                if (this.autoSwitch.getValue()) {
                    CrystalAura.mc.player.inventory.currentItem = currentItem;
                    resetRotation();
                    this.switchCooldown = true;
                }
                return;
            }
            this.lookAtPacket(render.x + 0.5, render.y - 0.5, render.z + 0.5, (EntityPlayer)CrystalAura.mc.player);
            final RayTraceResult rayTraceBlocks = CrystalAura.mc.world.rayTraceBlocks(new Vec3d(CrystalAura.mc.player.posX, CrystalAura.mc.player.posY + CrystalAura.mc.player.getEyeHeight(), CrystalAura.mc.player.posZ), new Vec3d(render.x + 0.5, render.y - 0.5, render.z + 0.5));
            EnumFacing enumFacing;
            if (rayTraceBlocks == null || rayTraceBlocks.sideHit == null) {
                enumFacing = EnumFacing.UP;
            }
            else {
                enumFacing = rayTraceBlocks.sideHit;
            }
            if (this.switchCooldown) {
                this.switchCooldown = false;
                return;
            }
            CrystalAura.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(render, enumFacing, b ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
        }
        if (CrystalAura.isSpoofingAngles) {
            if (CrystalAura.togglePitch) {
                final EntityPlayerSP player = CrystalAura.mc.player;
                player.rotationPitch += (float)4.0E-4;
                CrystalAura.togglePitch = false;
            }
            else {
                final EntityPlayerSP player2 = CrystalAura.mc.player;
                player2.rotationPitch -= (float)4.0E-4;
                CrystalAura.togglePitch = true;
            }
        }
    }
    
    private static void setYawAndPitch(final float n, final float n2) {
        CrystalAura.yaw = n;
        CrystalAura.pitch = n2;
        CrystalAura.isSpoofingAngles = true;
    }
}
