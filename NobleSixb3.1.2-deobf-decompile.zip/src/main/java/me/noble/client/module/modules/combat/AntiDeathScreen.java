//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.client.gui.*;
import java.util.function.*;

@Module.Info(name = "AntiDeathScreen", description = "Fixes random death screen glitches", category = Module.Category.COMBAT)
public class AntiDeathScreen extends Module
{
    @EventHandler
    public Listener<GuiScreenEvent.Displayed> listener;
    
    private static void lambda$new$0(final GuiScreenEvent.Displayed displayed) {
        if (!(displayed.getScreen() instanceof GuiGameOver)) {
            return;
        }
        if (AntiDeathScreen.mc.player.getHealth() > 0.0f) {
            AntiDeathScreen.mc.player.respawnPlayer();
            AntiDeathScreen.mc.displayGuiScreen((GuiScreen)null);
        }
    }
    
    public AntiDeathScreen() {
        this.listener = new Listener<GuiScreenEvent.Displayed>(AntiDeathScreen::lambda$new$0, (Predicate<GuiScreenEvent.Displayed>[])new Predicate[0]);
    }
}
