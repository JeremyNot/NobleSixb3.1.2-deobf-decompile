//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.movement;

import me.noble.client.module.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import org.lwjgl.input.*;
import net.minecraft.client.entity.*;

@Module.Info(name = "SeppukuGuiMove", category = Module.Category.MOVEMENT)
public class SeppukuGuiMove extends Module
{
    public void onUpdate() {
        final Minecraft getMinecraft = Minecraft.getMinecraft();
        if (getMinecraft.currentScreen instanceof GuiChat || getMinecraft.currentScreen == null) {
            return;
        }
        final int[] array = { getMinecraft.gameSettings.keyBindForward.getKeyCode(), getMinecraft.gameSettings.keyBindLeft.getKeyCode(), getMinecraft.gameSettings.keyBindRight.getKeyCode(), getMinecraft.gameSettings.keyBindBack.getKeyCode() };
        if (Keyboard.isKeyDown(getMinecraft.gameSettings.keyBindJump.getKeyCode())) {
            if (getMinecraft.player.isInLava() || getMinecraft.player.isInWater()) {
                final EntityPlayerSP player = getMinecraft.player;
                player.motionY += 0.039000000804662704;
            }
            else if (getMinecraft.player.onGround) {
                getMinecraft.player.jump();
            }
        }
    }
}
