//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.command.*;
import me.noble.client.*;
import me.noble.client.setting.*;

@Module.Info(name = "DiscordSettings", category = Module.Category.MISC, description = "Discord Rich Presence")
public class DiscordSettings extends Module
{
    private static long startTime;
    public Setting<LineInfo> line4Setting;
    public Setting<LineInfo> line3Setting;
    public Setting<LineInfo> line2Setting;
    public Setting<LineInfo> line1Setting;
    public Setting<Boolean> coordsConfirm;
    public Setting<Boolean> startupGlobal;
    
    public void onEnable() {
        DiscordPresence.start();
    }
    
    public void onUpdate() {
        if (DiscordSettings.startTime == 0L) {
            DiscordSettings.startTime = System.currentTimeMillis();
        }
        if (DiscordSettings.startTime + 10000L <= System.currentTimeMillis()) {
            if ((this.line1Setting.getValue().equals(LineInfo.COORDS) || this.line2Setting.getValue().equals(LineInfo.COORDS) || this.line3Setting.getValue().equals(LineInfo.COORDS) || this.line4Setting.getValue().equals(LineInfo.COORDS)) && !this.coordsConfirm.getValue() && DiscordSettings.mc.player != null) {
                Command.sendWarningMessage("[DiscordRPC] Warning: In order to use the coords option please enable the coords confirmation option. This will display your coords on the discord rpc. Do NOT use this if you do not want your coords displayed");
            }
            DiscordSettings.startTime = System.currentTimeMillis();
        }
    }
    
    public String getLine(final LineInfo lineInfo) {
        switch (lineInfo) {
            case VERSION: {
                return NobleMod.MODVER;
            }
            case WORLD: {
                if (DiscordSettings.mc.isIntegratedServerRunning()) {
                    return "Singleplayer";
                }
                if (DiscordSettings.mc.getCurrentServerData() != null) {
                    return "Multiplayer";
                }
                return "Main Menu";
            }
            case USERNAME: {
                if (DiscordSettings.mc.player != null) {
                    return DiscordSettings.mc.getSession().getUsername();
                }
                return "(Not logged in)";
            }
            case HEALTH: {
                if (DiscordSettings.mc.player != null) {
                    return String.valueOf(new StringBuilder().append("(").append((int)DiscordSettings.mc.player.getHealth()).append(" hp)"));
                }
                return "(No hp)";
            }
            case SERVERIP: {
                if (DiscordSettings.mc.getCurrentServerData() != null) {
                    return DiscordSettings.mc.getCurrentServerData().serverIP;
                }
                return "(Offline)";
            }
            case COORDS: {
                if (DiscordSettings.mc.player != null && this.coordsConfirm.getValue()) {
                    return String.valueOf(new StringBuilder().append("(").append((int)DiscordSettings.mc.player.posX).append(" ").append((int)DiscordSettings.mc.player.posY).append(" ").append((int)DiscordSettings.mc.player.posZ).append(")"));
                }
                return "(No coords)";
            }
            default: {
                return "";
            }
        }
    }
    
    public DiscordSettings() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", true));
        this.coordsConfirm = (Setting<Boolean>)this.register((Setting)Settings.b("Coords Confirm", false));
        this.line1Setting = (Setting<LineInfo>)this.register((Setting)Settings.e("Line 1 Left", LineInfo.VERSION));
        this.line3Setting = (Setting<LineInfo>)this.register((Setting)Settings.e("Line 1 Right", LineInfo.USERNAME));
        this.line2Setting = (Setting<LineInfo>)this.register((Setting)Settings.e("Line 2 Left", LineInfo.SERVERIP));
        this.line4Setting = (Setting<LineInfo>)this.register((Setting)Settings.e("Line 2 Right", LineInfo.HEALTH));
    }
    
    static {
        DiscordSettings.startTime = 0L;
    }
    
    public enum LineInfo
    {
        WORLD, 
        COORDS, 
        HEALTH, 
        USERNAME, 
        NONE, 
        VERSION;
        
        private static final LineInfo[] $VALUES;
        
        SERVERIP;
        
        static {
            $VALUES = new LineInfo[] { LineInfo.VERSION, LineInfo.WORLD, LineInfo.USERNAME, LineInfo.HEALTH, LineInfo.SERVERIP, LineInfo.COORDS, LineInfo.NONE };
        }
    }
}
