//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.client.*;
import me.noble.client.event.events.*;
import java.util.function.*;
import me.noble.client.setting.*;
import me.noble.client.*;
import net.minecraft.entity.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.util.math.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.init.*;
import java.awt.*;
import me.noble.client.util.*;
import net.minecraft.enchantment.*;

@Module.Info(name = "Nametags", description = "Draws descriptive nametags above entities", category = Module.Category.RENDER)
public class Nametags extends Module
{
    private Setting<Boolean> mobs;
    private Setting<Boolean> animals;
    RenderItem itemRenderer;
    static final Minecraft mc;
    private Setting<Double> range;
    private Setting<Boolean> armor;
    private Setting<Float> scale;
    private Setting<Boolean> players;
    private Setting<Boolean> health;
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (Nametags.mc.getRenderManager().options == null) {
            return;
        }
        GlStateManager.enableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        Minecraft.getMinecraft().world.loadedEntityList.stream().filter(EntityUtil::isLiving).filter(Nametags::lambda$onWorldRender$0).filter(this::lambda$onWorldRender$1).filter(this::lambda$onWorldRender$2).sorted(Comparator.comparing((Function<? super T, ? extends Comparable>)Nametags::lambda$onWorldRender$3)).forEach(this::drawNametag);
        GlStateManager.disableTexture2D();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
    }
    
    private boolean lambda$onWorldRender$1(final Entity entity) {
        return (entity instanceof EntityPlayer) ? (this.players.getValue() && Nametags.mc.player != entity) : (EntityUtil.isPassive(entity) ? this.animals.getValue() : ((boolean)this.mobs.getValue()));
    }
    
    public Nametags() {
        this.players = (Setting<Boolean>)this.register((Setting)Settings.b("Players", true));
        this.animals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
        this.mobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
        this.range = (Setting<Double>)this.register((Setting)Settings.d("Range", 200.0));
        this.scale = (Setting<Float>)this.register((Setting)Settings.floatBuilder("Scale").withMinimum(0.5f).withMaximum(10.0f).withValue(2.5f).build());
        this.health = (Setting<Boolean>)this.register((Setting)Settings.b("Health", true));
        this.armor = (Setting<Boolean>)this.register((Setting)Settings.b("Armor", true));
        this.itemRenderer = Nametags.mc.getRenderItem();
    }
    
    private boolean lambda$onWorldRender$2(final Entity entity) {
        return Nametags.mc.player.getDistanceToEntity(entity) < this.range.getValue();
    }
    
    private static Float lambda$onWorldRender$3(final Entity entity) {
        return -Nametags.mc.player.getDistanceToEntity(entity);
    }
    
    static {
        mc = Minecraft.getMinecraft();
    }
    
    private void drawNametag(final Entity entity) {
        GlStateManager.pushMatrix();
        final Vec3d interpolatedRenderPos = EntityUtil.getInterpolatedRenderPos(entity, Nametags.mc.getRenderPartialTicks());
        final float n = entity.height + 0.5f - (entity.isSneaking() ? 0.25f : 0.0f);
        final double xCoord = interpolatedRenderPos.xCoord;
        final double n2 = interpolatedRenderPos.yCoord + n;
        final double zCoord = interpolatedRenderPos.zCoord;
        final float playerViewY = Nametags.mc.getRenderManager().playerViewY;
        final float playerViewX = Nametags.mc.getRenderManager().playerViewX;
        final boolean b = Nametags.mc.getRenderManager().options.thirdPersonView == 2;
        GlStateManager.translate(xCoord, n2, zCoord);
        GlStateManager.rotate(-playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate((b ? -1 : 1) * playerViewX, 1.0f, 0.0f, 0.0f);
        final float n3 = Nametags.mc.player.getDistanceToEntity(entity) / 8.0f * (float)Math.pow(1.258925437927246, this.scale.getValue());
        GlStateManager.scale(n3, n3, n3);
        final FontRenderer fontRendererObj = Nametags.mc.fontRendererObj;
        GlStateManager.scale(-0.025f, -0.025f, 0.025f);
        final String value = String.valueOf(new StringBuilder().append(entity.getName()).append(this.health.getValue() ? String.valueOf(new StringBuilder().append(" ").append(NobleMod.colour).append("a").append(Math.round(((EntityLivingBase)entity).getHealth() + ((entity instanceof EntityPlayer) ? ((EntityPlayer)entity).getAbsorptionAmount() : 0.0f)))) : ""));
        final int n4 = fontRendererObj.getStringWidth(value) / 2;
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.disableTexture2D();
        final Tessellator getInstance = Tessellator.getInstance();
        final BufferBuilder getBuffer = getInstance.getBuffer();
        GlStateManager.disableDepth();
        GL11.glTranslatef(0.0f, -20.0f, 0.0f);
        getBuffer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        getBuffer.pos((double)(-n4 - 1), 8.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.5f).endVertex();
        getBuffer.pos((double)(-n4 - 1), 19.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.5f).endVertex();
        getBuffer.pos((double)(n4 + 1), 19.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.5f).endVertex();
        getBuffer.pos((double)(n4 + 1), 8.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.5f).endVertex();
        getInstance.draw();
        getBuffer.begin(2, DefaultVertexFormats.POSITION_COLOR);
        getBuffer.pos((double)(-n4 - 1), 8.0, 0.0).color(0.1f, 0.1f, 0.1f, 0.1f).endVertex();
        getBuffer.pos((double)(-n4 - 1), 19.0, 0.0).color(0.1f, 0.1f, 0.1f, 0.1f).endVertex();
        getBuffer.pos((double)(n4 + 1), 19.0, 0.0).color(0.1f, 0.1f, 0.1f, 0.1f).endVertex();
        getBuffer.pos((double)(n4 + 1), 8.0, 0.0).color(0.1f, 0.1f, 0.1f, 0.1f).endVertex();
        getInstance.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.glNormal3f(0.0f, 1.0f, 0.0f);
        if (!entity.isSneaking()) {
            fontRendererObj.drawString(value, -n4, 10, (entity instanceof EntityPlayer) ? (Friends.isFriend(entity.getName()) ? 49151 : 16777215) : 16777215);
        }
        else {
            fontRendererObj.drawString(value, -n4, 10, 16755200);
        }
        if (entity instanceof EntityPlayer && this.armor.getValue()) {
            this.renderArmor((EntityPlayer)entity, 0, -(fontRendererObj.FONT_HEIGHT + 1) - 20);
        }
        GlStateManager.glNormal3f(0.0f, 0.0f, 0.0f);
        GL11.glTranslatef(0.0f, 20.0f, 0.0f);
        GlStateManager.scale(-40.0f, -40.0f, 40.0f);
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }
    
    private static boolean lambda$onWorldRender$0(final Entity entity) {
        return !EntityUtil.isFakeLocalPlayer(entity);
    }
    
    public void renderArmor(final EntityPlayer entityPlayer, int n, final int n2) {
        final InventoryPlayer inventory = entityPlayer.inventory;
        final ItemStack getHeldItemMainhand = entityPlayer.getHeldItemMainhand();
        final ItemStack armorItemInSlot = inventory.armorItemInSlot(0);
        final ItemStack armorItemInSlot2 = inventory.armorItemInSlot(1);
        final ItemStack armorItemInSlot3 = inventory.armorItemInSlot(2);
        final ItemStack armorItemInSlot4 = inventory.armorItemInSlot(3);
        final ItemStack getHeldItemOffhand = entityPlayer.getHeldItemOffhand();
        ItemStack[] array;
        if (getHeldItemMainhand != null && getHeldItemOffhand != null) {
            array = new ItemStack[] { getHeldItemMainhand, armorItemInSlot4, armorItemInSlot3, armorItemInSlot2, armorItemInSlot, getHeldItemOffhand };
        }
        else if (getHeldItemMainhand != null && getHeldItemOffhand == null) {
            array = new ItemStack[] { getHeldItemMainhand, armorItemInSlot4, armorItemInSlot3, armorItemInSlot2, armorItemInSlot };
        }
        else if (getHeldItemMainhand == null && getHeldItemOffhand != null) {
            array = new ItemStack[] { armorItemInSlot4, armorItemInSlot3, armorItemInSlot2, armorItemInSlot, getHeldItemOffhand };
        }
        else {
            array = new ItemStack[] { armorItemInSlot4, armorItemInSlot3, armorItemInSlot2, armorItemInSlot };
        }
        final ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        ItemStack[] array2;
        for (int length = (array2 = array).length, i = 0; i < length; ++i) {
            final ItemStack itemStack = array2[i];
            if (itemStack != null && itemStack.getItem() != null) {
                list.add(itemStack);
            }
        }
        n -= 16 * list.size() / 2;
        GlStateManager.disableDepth();
        final Iterator<Object> iterator = list.iterator();
        while (iterator.hasNext()) {
            this.renderItem(iterator.next(), n, n2);
            n += 16;
        }
        GlStateManager.enableDepth();
    }
    
    public void renderItem(final ItemStack itemStack, final int n, int n2) {
        final FontRenderer fontRendererObj = Nametags.mc.fontRendererObj;
        final RenderItem getRenderItem = Nametags.mc.getRenderItem();
        final EnchantEntry[] array = { new EnchantEntry(Enchantments.PROTECTION, "Pro"), new EnchantEntry(Enchantments.THORNS, "Thr"), new EnchantEntry(Enchantments.SHARPNESS, "Sha"), new EnchantEntry(Enchantments.FIRE_ASPECT, "Fia"), new EnchantEntry(Enchantments.KNOCKBACK, "Knb"), new EnchantEntry(Enchantments.UNBREAKING, "Unb"), new EnchantEntry(Enchantments.POWER, "Pow"), new EnchantEntry(Enchantments.FIRE_PROTECTION, "Fpr"), new EnchantEntry(Enchantments.FEATHER_FALLING, "Fea"), new EnchantEntry(Enchantments.BLAST_PROTECTION, "Bla"), new EnchantEntry(Enchantments.PROJECTILE_PROTECTION, "Ppr"), new EnchantEntry(Enchantments.RESPIRATION, "Res"), new EnchantEntry(Enchantments.AQUA_AFFINITY, "Aqu"), new EnchantEntry(Enchantments.DEPTH_STRIDER, "Dep"), new EnchantEntry(Enchantments.FROST_WALKER, "Fro"), new EnchantEntry(Enchantments.field_190941_k, "Bin"), new EnchantEntry(Enchantments.SMITE, "Smi"), new EnchantEntry(Enchantments.BANE_OF_ARTHROPODS, "Ban"), new EnchantEntry(Enchantments.LOOTING, "Loo"), new EnchantEntry(Enchantments.field_191530_r, "Swe"), new EnchantEntry(Enchantments.EFFICIENCY, "Eff"), new EnchantEntry(Enchantments.SILK_TOUCH, "Sil"), new EnchantEntry(Enchantments.FORTUNE, "For"), new EnchantEntry(Enchantments.FLAME, "Fla"), new EnchantEntry(Enchantments.LUCK_OF_THE_SEA, "Luc"), new EnchantEntry(Enchantments.LURE, "Lur"), new EnchantEntry(Enchantments.MENDING, "Men"), new EnchantEntry(Enchantments.field_190940_C, "Van"), new EnchantEntry(Enchantments.PUNCH, "Pun") };
        GlStateManager.pushMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)(n - 3), (float)(n2 + 8), 0.0f);
        GlStateManager.scale(0.3f, 0.3f, 0.3f);
        GlStateManager.popMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        getRenderItem.zLevel = -100.0f;
        GlStateManager.disableDepth();
        getRenderItem.renderItemIntoGUI(itemStack, n, n2);
        getRenderItem.renderItemOverlayIntoGUI(fontRendererObj, itemStack, n, n2, (String)null);
        GlStateManager.enableDepth();
        GlStateManager.scale(0.75f, 0.75f, 0.75f);
        if (itemStack.isItemStackDamageable()) {
            this.drawDamage(itemStack, n, n2);
        }
        GlStateManager.scale(1.33f, 1.33f, 1.33f);
        EnchantEntry[] array2;
        for (int length = (array2 = array).length, i = 0; i < length; ++i) {
            final EnchantEntry enchantEntry = array2[i];
            final int getEnchantmentLevel = EnchantmentHelper.getEnchantmentLevel(enchantEntry.getEnchant(), itemStack);
            String value = String.valueOf(new StringBuilder().append("").append(getEnchantmentLevel));
            if (getEnchantmentLevel > 10) {
                value = "10+";
            }
            if (getEnchantmentLevel > 0) {
                GlStateManager.translate((float)(n - 1), (float)(n2 + 2), 0.0f);
                GlStateManager.scale(0.42f, 0.42f, 0.42f);
                GlStateManager.disableDepth();
                GlStateManager.disableLighting();
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                fontRendererObj.drawString(String.valueOf(new StringBuilder().append("��f").append(enchantEntry.getName()).append(" ").append(value)), (float)(20 - fontRendererObj.getStringWidth(String.valueOf(new StringBuilder().append("��f").append(enchantEntry.getName()).append(" ").append(value))) / 2), 0.0f, Color.WHITE.getRGB(), true);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.scale(2.42f, 2.42f, 2.42f);
                GlStateManager.translate((float)(-n + 1), (float)(-n2), 0.0f);
                n2 += (int)((fontRendererObj.FONT_HEIGHT + 3) * 0.28f);
            }
        }
        getRenderItem.zLevel = 0.0f;
        RenderHelper.disableStandardItemLighting();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.disableLighting();
        GlStateManager.popMatrix();
    }
    
    public void drawDamage(final ItemStack itemStack, final int n, final int n2) {
        final float n3 = (itemStack.getMaxDamage() - (float)itemStack.getItemDamage()) / itemStack.getMaxDamage();
        final float n4 = 1.0f - n3;
        final int n5 = 100 - (int)(n4 * 100.0f);
        GlStateManager.disableDepth();
        Nametags.mc.fontRendererObj.drawStringWithShadow(String.valueOf(new StringBuilder().append(n5).append("")), (float)(n + 8 - Nametags.mc.fontRendererObj.getStringWidth(String.valueOf(new StringBuilder().append(n5).append(""))) / 2), (float)(n2 - 11), ColourHolder.toHex((int)(n4 * 255.0f), (int)(n3 * 255.0f), 0));
        GlStateManager.enableDepth();
    }
    
    public static class EnchantEntry
    {
        private String name;
        private Enchantment enchant;
        
        public String getName() {
            return this.name;
        }
        
        public EnchantEntry(final Enchantment enchant, final String name) {
            this.enchant = enchant;
            this.name = name;
        }
        
        public Enchantment getEnchant() {
            return this.enchant;
        }
    }
}
