//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import net.minecraft.util.math.*;
import me.noble.client.command.*;

@Module.Info(name = "Teleport", description = "Library for teleport command", category = Module.Category.MISC)
public class Teleport extends Module
{
    private long lastTp;
    public static Vec3d finalPos;
    private Vec3d lastPos;
    public static double blocksPerTeleport;
    
    public void onUpdate() {
        if (Teleport.finalPos == null) {
            Command.sendErrorMessage("Position not set, use .tp");
            this.disable();
            return;
        }
        final Vec3d normalize = Teleport.finalPos.subtract(Teleport.mc.player.posX, Teleport.mc.player.posY, Teleport.mc.player.posZ).normalize();
        if (Teleport.mc.world.isBlockLoaded(Teleport.mc.player.getPosition())) {
            this.lastPos = new Vec3d(Teleport.mc.player.posX, Teleport.mc.player.posY, Teleport.mc.player.posZ);
            if (Teleport.finalPos.distanceTo(new Vec3d(Teleport.mc.player.posX, Teleport.mc.player.posY, Teleport.mc.player.posZ)) < 0.3 || Teleport.blocksPerTeleport == 0.0) {
                Command.sendChatMessage("Teleport Finished!");
                this.disable();
            }
            else {
                Teleport.mc.player.setVelocity(0.0, 0.0, 0.0);
            }
            if (Teleport.finalPos.distanceTo(new Vec3d(Teleport.mc.player.posX, Teleport.mc.player.posY, Teleport.mc.player.posZ)) >= Teleport.blocksPerTeleport) {
                final Vec3d scale = normalize.scale(Teleport.blocksPerTeleport);
                Teleport.mc.player.setPosition(Teleport.mc.player.posX + scale.xCoord, Teleport.mc.player.posY + scale.yCoord, Teleport.mc.player.posZ + scale.zCoord);
            }
            else {
                final Vec3d scale2 = normalize.scale(Teleport.finalPos.distanceTo(new Vec3d(Teleport.mc.player.posX, Teleport.mc.player.posY, Teleport.mc.player.posZ)));
                Teleport.mc.player.setPosition(Teleport.mc.player.posX + scale2.xCoord, Teleport.mc.player.posY + scale2.yCoord, Teleport.mc.player.posZ + scale2.zCoord);
                this.disable();
            }
            this.lastTp = System.currentTimeMillis();
        }
        else if (this.lastTp + 2000L > System.currentTimeMillis()) {
            Teleport.mc.player.setPosition(this.lastPos.xCoord, this.lastPos.yCoord, this.lastPos.zCoord);
        }
    }
}
