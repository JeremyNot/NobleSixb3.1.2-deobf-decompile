//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.module.*;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.item.*;
import net.minecraft.util.*;
import me.noble.client.setting.*;

@Module.Info(name = "NobleEntitySpeed", category = Module.Category.NOBLE, description = "Godmode EntitySpeed")
public class GMEntitySpeed extends Module
{
    private Setting<Double> gmentityspeed;
    
    public void onUpdate() {
        try {
            if (GMEntitySpeed.mc.player.getRidingEntity() != null) {
                speedEntity(GMEntitySpeed.mc.player.getRidingEntity(), this.gmentityspeed.getValue());
            }
        }
        catch (Exception ex) {
            System.out.println("ERROR: Dude we kinda have a problem here:");
            ex.printStackTrace();
        }
    }
    
    private static void speedEntity(final Entity entity, final Double n) {
        if (entity instanceof EntityLlama) {
            entity.rotationYaw = GMEntitySpeed.mc.player.rotationYaw;
            ((EntityLlama)entity).rotationYawHead = GMEntitySpeed.mc.player.rotationYawHead;
        }
        final MovementInput movementInput = GMEntitySpeed.mc.player.movementInput;
        double n2 = movementInput.field_192832_b;
        double n3 = movementInput.moveStrafe;
        float rotationYaw = GMEntitySpeed.mc.player.rotationYaw;
        if (n2 == 0.0 && n3 == 0.0) {
            entity.motionX = 0.0;
            entity.motionZ = 0.0;
        }
        else {
            if (n2 != 0.0) {
                if (n3 > 0.0) {
                    rotationYaw += ((n2 > 0.0) ? -45 : 45);
                }
                else if (n3 < 0.0) {
                    rotationYaw += ((n2 > 0.0) ? 45 : -45);
                }
                n3 = 0.0;
                if (n2 > 0.0) {
                    n2 = 1.0;
                }
                else if (n2 < 0.0) {
                    n2 = -1.0;
                }
            }
            entity.motionX = n2 * n * Math.cos(Math.toRadians(rotationYaw + 90.0f)) + n3 * n * Math.sin(Math.toRadians(rotationYaw + 90.0f));
            entity.motionZ = n2 * n * Math.sin(Math.toRadians(rotationYaw + 90.0f)) - n3 * n * Math.cos(Math.toRadians(rotationYaw + 90.0f));
            if (entity instanceof EntityMinecart) {
                final EntityMinecart entityMinecart = (EntityMinecart)entity;
                entityMinecart.setVelocity(n2 * n * Math.cos(Math.toRadians(rotationYaw + 90.0f)) + n3 * n * Math.sin(Math.toRadians(rotationYaw + 90.0f)), entityMinecart.motionY, n2 * n * Math.sin(Math.toRadians(rotationYaw + 90.0f)) - n3 * n * Math.cos(Math.toRadians(rotationYaw + 90.0f)));
            }
        }
    }
    
    public GMEntitySpeed() {
        this.gmentityspeed = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Speed").withRange(0.1, 10.0).withValue(1.0).build());
    }
}
