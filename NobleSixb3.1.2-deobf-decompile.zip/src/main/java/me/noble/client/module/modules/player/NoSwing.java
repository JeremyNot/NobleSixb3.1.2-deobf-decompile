//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.client.*;
import java.util.function.*;

@Module.Info(name = "NoSwing", category = Module.Category.PLAYER, description = "Cancels server and client swinging packets")
public class NoSwing extends Module
{
    @EventHandler
    private Listener<PacketEvent.Send> listener;
    
    private static void lambda$new$0(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketAnimation) {
            send.cancel();
        }
    }
    
    public NoSwing() {
        this.listener = new Listener<PacketEvent.Send>(NoSwing::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
}
