//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import me.noble.client.setting.*;

@Module.Info(name = "CleanGUI", category = Module.Category.GUI, showOnArray = Module.ShowOnArray.OFF, description = "Modifies parts of the GUI to be transparent")
public class CleanGUI extends Module
{
    public Setting<Boolean> startupGlobal;
    private static CleanGUI INSTANCE;
    public Setting<Boolean> inventoryGlobal;
    public static Setting<Boolean> chatGlobal;
    
    public static boolean enabled() {
        return CleanGUI.INSTANCE.isEnabled();
    }
    
    public CleanGUI() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", false));
        this.inventoryGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Inventory", false));
        (CleanGUI.INSTANCE = this).register((Setting)CleanGUI.chatGlobal);
    }
    
    static {
        CleanGUI.chatGlobal = Settings.b("Chat", true);
        CleanGUI.INSTANCE = new CleanGUI();
    }
}
