//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import net.minecraft.entity.player.*;
import java.util.*;
import me.noble.client.setting.*;

@Module.Info(name = "SkinFlicker", description = "Toggle your skin layers rapidly for a cool skin effect", category = Module.Category.MISC)
public class SkinFlicker extends Module
{
    private int len;
    private static final EnumPlayerModelParts[] PARTS_HORIZONTAL;
    private Setting<Integer> slowness;
    private Setting<FlickerMode> mode;
    private Random r;
    private static final EnumPlayerModelParts[] PARTS_VERTICAL;
    
    public void onUpdate() {
        switch (this.mode.getValue()) {
            case RANDOM: {
                if (SkinFlicker.mc.player.ticksExisted % this.slowness.getValue() != 0) {
                    return;
                }
                SkinFlicker.mc.gameSettings.switchModelPartEnabled(EnumPlayerModelParts.values()[this.r.nextInt(this.len)]);
                break;
            }
            case VERTICAL:
            case HORIZONTAL: {
                int n = SkinFlicker.mc.player.ticksExisted / this.slowness.getValue() % (SkinFlicker.PARTS_HORIZONTAL.length * 2);
                boolean b = false;
                if (n >= SkinFlicker.PARTS_HORIZONTAL.length) {
                    b = true;
                    n -= SkinFlicker.PARTS_HORIZONTAL.length;
                }
                SkinFlicker.mc.gameSettings.setModelPartEnabled((this.mode.getValue() == FlickerMode.VERTICAL) ? SkinFlicker.PARTS_VERTICAL[n] : SkinFlicker.PARTS_HORIZONTAL[n], b);
                break;
            }
        }
    }
    
    static {
        PARTS_HORIZONTAL = new EnumPlayerModelParts[] { EnumPlayerModelParts.LEFT_SLEEVE, EnumPlayerModelParts.JACKET, EnumPlayerModelParts.HAT, EnumPlayerModelParts.LEFT_PANTS_LEG, EnumPlayerModelParts.RIGHT_PANTS_LEG, EnumPlayerModelParts.RIGHT_SLEEVE };
        PARTS_VERTICAL = new EnumPlayerModelParts[] { EnumPlayerModelParts.HAT, EnumPlayerModelParts.JACKET, EnumPlayerModelParts.LEFT_SLEEVE, EnumPlayerModelParts.RIGHT_SLEEVE, EnumPlayerModelParts.LEFT_PANTS_LEG, EnumPlayerModelParts.RIGHT_PANTS_LEG };
    }
    
    public SkinFlicker() {
        this.mode = (Setting<FlickerMode>)this.register((Setting)Settings.e("Mode", FlickerMode.HORIZONTAL));
        this.slowness = (Setting<Integer>)this.register((Setting)Settings.integerBuilder().withName("Slowness").withValue(2).withMinimum(1).build());
        this.r = new Random();
        this.len = EnumPlayerModelParts.values().length;
    }
    
    public enum FlickerMode
    {
        VERTICAL;
        
        private static final FlickerMode[] $VALUES;
        
        RANDOM, 
        HORIZONTAL;
        
        static {
            $VALUES = new FlickerMode[] { FlickerMode.HORIZONTAL, FlickerMode.VERTICAL, FlickerMode.RANDOM };
        }
    }
}
