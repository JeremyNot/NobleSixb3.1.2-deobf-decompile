//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import java.util.function.*;
import net.minecraft.client.*;
import me.noble.client.command.*;
import net.minecraft.network.play.client.*;
import me.noble.client.util.*;
import me.noble.client.*;
import net.minecraft.network.*;

@Module.Info(name = "FormatChat", description = "Add colour and linebreak support to upstream chat packets", category = Module.Category.CHAT)
public class FormatChat extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> sendListener;
    
    public FormatChat() {
        this.sendListener = new Listener<PacketEvent.Send>(FormatChat::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    public void onEnable() {
        if (Minecraft.getMinecraft().getCurrentServerData() == null) {
            Command.sendWarningMessage("[FormatChat] &6&lWarning: &r&6This does not work in singleplayer");
            this.disable();
        }
        else {
            Command.sendWarningMessage("[FormatChat] &6&lWarning: &r&6This will kick you on most servers!");
        }
    }
    
    private static void lambda$new$0(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketChatMessage) {
            final String message = ((CPacketChatMessage)send.getPacket()).message;
            if (message.contains("&") || message.contains("#n")) {
                Wrapper.getPlayer().connection.sendPacket((Packet)new CPacketChatMessage(message.replaceAll("&", String.valueOf(new StringBuilder().append(NobleMod.colour).append(""))).replaceAll("#n", "\n")));
                send.cancel();
            }
        }
    }
}
