//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.module.*;
import me.zero.alpine.listener.*;
import net.minecraftforge.client.event.*;
import net.minecraft.entity.*;
import me.noble.client.event.events.*;
import net.minecraft.world.*;
import net.minecraft.client.entity.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;

@Module.Info(name = "NobleFreecam", category = Module.Category.NOBLE, description = "Leave your body and trascend into the realm of the gods")
public class NobleFreecam extends Module
{
    private boolean isRidingEntity;
    @EventHandler
    private Listener<PacketEvent.Send> sendListener;
    private double posX;
    private EntityOtherPlayerMP clonedPlayer;
    private Setting<Integer> speed;
    private float yaw;
    @EventHandler
    private Listener<PlayerSPPushOutOfBlocksEvent> pushListener;
    private Entity ridingEntity;
    @EventHandler
    private Listener<PlayerMoveEvent> moveListener;
    private double posZ;
    private double posY;
    private float pitch;
    
    public void onUpdate() {
        NobleFreecam.mc.player.capabilities.isFlying = true;
        NobleFreecam.mc.player.capabilities.setFlySpeed(this.speed.getValue() / 100.0f);
        NobleFreecam.mc.player.noClip = true;
        NobleFreecam.mc.player.onGround = false;
        NobleFreecam.mc.player.fallDistance = 0.0f;
    }
    
    protected void onEnable() {
        if (NobleFreecam.mc.player != null) {
            this.isRidingEntity = (NobleFreecam.mc.player.getRidingEntity() != null);
            if (NobleFreecam.mc.player.getRidingEntity() == null) {
                this.posX = NobleFreecam.mc.player.posX;
                this.posY = NobleFreecam.mc.player.posY;
                this.posZ = NobleFreecam.mc.player.posZ;
            }
            else {
                this.ridingEntity = NobleFreecam.mc.player.getRidingEntity();
                NobleFreecam.mc.player.dismountRidingEntity();
            }
            this.pitch = NobleFreecam.mc.player.rotationPitch;
            this.yaw = NobleFreecam.mc.player.rotationYaw;
            (this.clonedPlayer = new EntityOtherPlayerMP((World)NobleFreecam.mc.world, NobleFreecam.mc.getSession().getProfile())).copyLocationAndAnglesFrom((Entity)NobleFreecam.mc.player);
            this.clonedPlayer.rotationYawHead = NobleFreecam.mc.player.rotationYawHead;
            NobleFreecam.mc.world.addEntityToWorld(-100, (Entity)this.clonedPlayer);
            NobleFreecam.mc.player.capabilities.isFlying = true;
            NobleFreecam.mc.player.capabilities.setFlySpeed(this.speed.getValue() / 100.0f);
            NobleFreecam.mc.player.noClip = true;
        }
    }
    
    private static void lambda$new$1(final PlayerSPPushOutOfBlocksEvent playerSPPushOutOfBlocksEvent) {
        playerSPPushOutOfBlocksEvent.setCanceled(true);
    }
    
    private static void lambda$new$0(final PlayerMoveEvent playerMoveEvent) {
        NobleFreecam.mc.player.noClip = true;
    }
    
    protected void onDisable() {
        if (NobleFreecam.mc.player != null) {
            NobleFreecam.mc.player.setPositionAndRotation(this.posX, this.posY, this.posZ, this.yaw, this.pitch);
            NobleFreecam.mc.world.removeEntityFromWorld(-100);
            this.clonedPlayer = null;
            final double posX = 0.0;
            this.posZ = posX;
            this.posY = posX;
            this.posX = posX;
            final float n = 0.0f;
            this.yaw = n;
            this.pitch = n;
            NobleFreecam.mc.player.capabilities.isFlying = false;
            NobleFreecam.mc.player.capabilities.setFlySpeed(0.05f);
            NobleFreecam.mc.player.noClip = false;
            final EntityPlayerSP player = NobleFreecam.mc.player;
            final EntityPlayerSP player2 = NobleFreecam.mc.player;
            final EntityPlayerSP player3 = NobleFreecam.mc.player;
            final double motionX = 0.0;
            player3.motionZ = motionX;
            player2.motionY = motionX;
            player.motionX = motionX;
            if (this.isRidingEntity) {
                NobleFreecam.mc.player.startRiding(this.ridingEntity, true);
            }
        }
    }
    
    public NobleFreecam() {
        this.speed = (Setting<Integer>)this.register((Setting)Settings.i("Speed", 25));
        this.moveListener = new Listener<PlayerMoveEvent>(NobleFreecam::lambda$new$0, (Predicate<PlayerMoveEvent>[])new Predicate[0]);
        this.pushListener = new Listener<PlayerSPPushOutOfBlocksEvent>(NobleFreecam::lambda$new$1, (Predicate<PlayerSPPushOutOfBlocksEvent>[])new Predicate[0]);
        this.sendListener = new Listener<PacketEvent.Send>(NobleFreecam::lambda$new$2, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private static void lambda$new$2(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketPlayer || send.getPacket() instanceof CPacketInput) {
            send.cancel();
        }
    }
}
