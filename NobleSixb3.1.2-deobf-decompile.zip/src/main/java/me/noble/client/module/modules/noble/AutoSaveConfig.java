//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.module.*;
import me.noble.client.setting.*;

@Module.Info(name = "AutoSaveConfig", category = Module.Category.NOBLE)
public class AutoSaveConfig extends Module
{
    public Setting<Boolean> startupGlobal;
    
    public AutoSaveConfig() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", false));
    }
    
    protected void onDisable() {
    }
    
    protected void onEnable() {
    }
}
