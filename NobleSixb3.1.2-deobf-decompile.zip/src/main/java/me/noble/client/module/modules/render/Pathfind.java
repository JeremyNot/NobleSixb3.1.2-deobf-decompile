//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.entity.monster.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import me.noble.client.command.*;
import me.noble.client.event.events.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import java.util.function.*;
import java.util.*;
import net.minecraft.pathfinding.*;
import net.minecraft.init.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.*;
import net.minecraft.block.state.*;

@Module.Info(name = "Pathfind", category = Module.Category.MISC, description = "A path finder for AutoWalk")
public class Pathfind extends Module
{
    public static ArrayList<PathPoint> points;
    static PathPoint to;
    
    public static boolean createPath(final PathPoint to) {
        Pathfind.to = to;
        final AnchoredWalkNodeProcessor anchoredWalkNodeProcessor = new AnchoredWalkNodeProcessor(new PathPoint((int)Pathfind.mc.player.posX, (int)Pathfind.mc.player.posY, (int)Pathfind.mc.player.posZ));
        final EntityZombie entityZombie = new EntityZombie((World)Pathfind.mc.world);
        entityZombie.setPathPriority(PathNodeType.WATER, 16.0f);
        entityZombie.posX = Pathfind.mc.player.posX;
        entityZombie.posY = Pathfind.mc.player.posY;
        entityZombie.posZ = Pathfind.mc.player.posZ;
        final Path findPath = new PathFinder((NodeProcessor)anchoredWalkNodeProcessor).findPath((IBlockAccess)Pathfind.mc.world, (EntityLiving)entityZombie, new BlockPos(to.xCoord, to.yCoord, to.zCoord), Float.MAX_VALUE);
        entityZombie.setPathPriority(PathNodeType.WATER, 0.0f);
        if (findPath == null) {
            Command.sendChatMessage("Failed to create path!");
            return false;
        }
        Pathfind.points = new ArrayList<PathPoint>(Arrays.asList(findPath.points));
        return Pathfind.points.get(Pathfind.points.size() - 1).distanceTo(to) <= 1.0f;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (Pathfind.points.isEmpty()) {
            return;
        }
        GL11.glDisable(3042);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glLineWidth(1.5f);
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GlStateManager.disableDepth();
        GL11.glBegin(1);
        final PathPoint pathPoint = Pathfind.points.get(0);
        GL11.glVertex3d(pathPoint.xCoord - Pathfind.mc.getRenderManager().renderPosX + 0.5, pathPoint.yCoord - Pathfind.mc.getRenderManager().renderPosY, pathPoint.zCoord - Pathfind.mc.getRenderManager().renderPosZ + 0.5);
        for (int i = 0; i < Pathfind.points.size() - 1; ++i) {
            final PathPoint pathPoint2 = Pathfind.points.get(i);
            GL11.glVertex3d(pathPoint2.xCoord - Pathfind.mc.getRenderManager().renderPosX + 0.5, pathPoint2.yCoord - Pathfind.mc.getRenderManager().renderPosY, pathPoint2.zCoord - Pathfind.mc.getRenderManager().renderPosZ + 0.5);
            if (i != Pathfind.points.size() - 1) {
                GL11.glVertex3d(pathPoint2.xCoord - Pathfind.mc.getRenderManager().renderPosX + 0.5, pathPoint2.yCoord - Pathfind.mc.getRenderManager().renderPosY, pathPoint2.zCoord - Pathfind.mc.getRenderManager().renderPosZ + 0.5);
            }
        }
        GL11.glEnd();
        GlStateManager.enableDepth();
    }
    
    public void onUpdate() {
        final PathPoint pathPoint = Pathfind.points.stream().min(Comparator.comparing((Function<? super PathPoint, ? extends Comparable>)Pathfind::lambda$onUpdate$0)).orElse(null);
        if (pathPoint == null) {
            return;
        }
        if (Pathfind.mc.player.getDistance((double)pathPoint.xCoord, (double)pathPoint.yCoord, (double)pathPoint.zCoord) > 0.8) {
            return;
        }
        final Iterator<PathPoint> iterator = Pathfind.points.iterator();
        while (iterator.hasNext()) {
            if (iterator.next() == pathPoint) {
                iterator.remove();
                break;
            }
            iterator.remove();
        }
        if (Pathfind.points.size() <= 1 && Pathfind.to != null) {
            final boolean path = createPath(Pathfind.to);
            final boolean b = Pathfind.points.size() <= 4;
            if ((path && b) || b) {
                Pathfind.points.clear();
                Pathfind.to = null;
                if (path) {
                    Command.sendChatMessage("Arrived!");
                }
                else {
                    Command.sendChatMessage("Can't go on: pathfinder has hit dead end");
                }
            }
        }
    }
    
    private static Double lambda$onUpdate$0(final PathPoint pathPoint) {
        return Pathfind.mc.player.getDistance((double)pathPoint.xCoord, (double)pathPoint.yCoord, (double)pathPoint.zCoord);
    }
    
    static {
        Pathfind.points = new ArrayList<PathPoint>();
        Pathfind.to = null;
    }
    
    private static class AnchoredWalkNodeProcessor extends WalkNodeProcessor
    {
        PathPoint from;
        
        public PathNodeType getPathNodeType(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
            PathNodeType pathNodeType = this.getPathNodeTypeRaw(blockAccess, n, n2, n3);
            if (pathNodeType == PathNodeType.OPEN && n2 >= 1) {
                final Block getBlock = blockAccess.getBlockState(new BlockPos(n, n2 - 1, n3)).getBlock();
                final PathNodeType getPathNodeTypeRaw = this.getPathNodeTypeRaw(blockAccess, n, n2 - 1, n3);
                pathNodeType = ((getPathNodeTypeRaw != PathNodeType.WALKABLE && getPathNodeTypeRaw != PathNodeType.OPEN && getPathNodeTypeRaw != PathNodeType.LAVA) ? PathNodeType.WALKABLE : PathNodeType.OPEN);
                if (getPathNodeTypeRaw == PathNodeType.DAMAGE_FIRE || getBlock == Blocks.MAGMA) {
                    pathNodeType = PathNodeType.DAMAGE_FIRE;
                }
                if (getPathNodeTypeRaw == PathNodeType.DAMAGE_CACTUS) {
                    pathNodeType = PathNodeType.DAMAGE_CACTUS;
                }
            }
            return this.func_193578_a(blockAccess, n, n2, n3, pathNodeType);
        }
        
        protected PathNodeType getPathNodeTypeRaw(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
            final BlockPos blockPos = new BlockPos(n, n2, n3);
            final IBlockState getBlockState = blockAccess.getBlockState(blockPos);
            final Block getBlock = getBlockState.getBlock();
            final Material getMaterial = getBlockState.getMaterial();
            final PathNodeType aiPathNodeType = getBlock.getAiPathNodeType(getBlockState, blockAccess, blockPos);
            if (aiPathNodeType != null) {
                return aiPathNodeType;
            }
            if (getMaterial == Material.AIR) {
                return PathNodeType.OPEN;
            }
            if (getBlock == Blocks.TRAPDOOR || getBlock == Blocks.IRON_TRAPDOOR || getBlock == Blocks.WATERLILY) {
                return PathNodeType.TRAPDOOR;
            }
            if (getBlock == Blocks.FIRE) {
                return PathNodeType.DAMAGE_FIRE;
            }
            if (getBlock == Blocks.CACTUS) {
                return PathNodeType.DAMAGE_CACTUS;
            }
            if (getBlock instanceof BlockDoor && getMaterial == Material.WOOD && !(boolean)getBlockState.getValue((IProperty)BlockDoor.OPEN)) {
                return PathNodeType.DOOR_WOOD_CLOSED;
            }
            if (getBlock instanceof BlockDoor && getMaterial == Material.IRON && !(boolean)getBlockState.getValue((IProperty)BlockDoor.OPEN)) {
                return PathNodeType.DOOR_IRON_CLOSED;
            }
            if (getBlock instanceof BlockDoor && (boolean)getBlockState.getValue((IProperty)BlockDoor.OPEN)) {
                return PathNodeType.DOOR_OPEN;
            }
            if (getBlock instanceof BlockRailBase) {
                return PathNodeType.RAIL;
            }
            if (getBlock instanceof BlockFence || getBlock instanceof BlockWall || (getBlock instanceof BlockFenceGate && !(boolean)getBlockState.getValue((IProperty)BlockFenceGate.OPEN))) {
                return PathNodeType.FENCE;
            }
            if (getMaterial == Material.WATER) {
                return PathNodeType.WALKABLE;
            }
            if (getMaterial == Material.LAVA) {
                return PathNodeType.LAVA;
            }
            return getBlock.isPassable(blockAccess, blockPos) ? PathNodeType.OPEN : PathNodeType.BLOCKED;
        }
        
        public boolean getCanSwim() {
            return true;
        }
        
        public PathPoint getStart() {
            return this.from;
        }
        
        public AnchoredWalkNodeProcessor(final PathPoint from) {
            this.from = from;
        }
        
        public boolean getCanEnterDoors() {
            return true;
        }
    }
}
