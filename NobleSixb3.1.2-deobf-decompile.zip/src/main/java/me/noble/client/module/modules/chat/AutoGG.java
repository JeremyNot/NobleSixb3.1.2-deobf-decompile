//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import java.util.concurrent.*;
import net.minecraftforge.event.entity.living.*;
import me.noble.client.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import java.util.*;
import me.noble.client.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.entity.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(name = "AutoGG", category = Module.Category.CHAT, description = "Announce killed Players")
public class AutoGG extends Module
{
    private Setting<Integer> timeoutTicks;
    @EventHandler
    public Listener<PacketEvent.Send> sendListener;
    private ConcurrentHashMap<String, Integer> targetedPlayers;
    private Setting<Boolean> toxicMode;
    private Setting<Boolean> clientName;
    @EventHandler
    public Listener<LivingDeathEvent> livingDeathEventListener;
    
    public void onDisable() {
        this.targetedPlayers = null;
    }
    
    public void onUpdate() {
        if (this.isDisabled() || AutoGG.mc.player == null) {
            return;
        }
        if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap<String, Integer>();
        }
        for (final Entity entity : AutoGG.mc.world.getLoadedEntityList()) {
            if (!EntityUtil.isPlayer(entity)) {
                continue;
            }
            final EntityPlayer entityPlayer = (EntityPlayer)entity;
            if (entityPlayer.getHealth() > 0.0f) {
                continue;
            }
            final String getName = entityPlayer.getName();
            if (this.shouldAnnounce(getName)) {
                this.doAnnounce(getName);
                break;
            }
        }
        this.targetedPlayers.forEach(this::lambda$onUpdate$0);
    }
    
    private void lambda$onUpdate$0(final String s, final Integer n) {
        if (n <= 0) {
            this.targetedPlayers.remove(s);
        }
        else {
            this.targetedPlayers.put(s, n - 1);
        }
    }
    
    public void onEnable() {
        this.targetedPlayers = new ConcurrentHashMap<String, Integer>();
    }
    
    private void lambda$new$1(final PacketEvent.Send send) {
        if (AutoGG.mc.player == null) {
            return;
        }
        if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap<String, Integer>();
        }
        if (!(send.getPacket() instanceof CPacketUseEntity)) {
            return;
        }
        final CPacketUseEntity cPacketUseEntity = (CPacketUseEntity)send.getPacket();
        if (!cPacketUseEntity.getAction().equals((Object)CPacketUseEntity.Action.ATTACK)) {
            return;
        }
        final Entity getEntityFromWorld = cPacketUseEntity.getEntityFromWorld((World)AutoGG.mc.world);
        if (!EntityUtil.isPlayer(getEntityFromWorld)) {
            return;
        }
        this.addTargetedPlayer(getEntityFromWorld.getName());
    }
    
    public void addTargetedPlayer(final String s) {
        if (Objects.equals(s, AutoGG.mc.player.getName())) {
            return;
        }
        if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap<String, Integer>();
        }
        this.targetedPlayers.put(s, this.timeoutTicks.getValue());
    }
    
    private void doAnnounce(final String s) {
        this.targetedPlayers.remove(s);
        final StringBuilder sb = new StringBuilder();
        if (this.toxicMode.getValue()) {
            sb.append("EZZZ ");
        }
        else {
            sb.append("good fight ");
        }
        sb.append(s);
        sb.append("!");
        if (this.clientName.getValue()) {
            sb.append(" ");
            sb.append(NobleMod.MODNAME);
            sb.append(" owns me and all");
        }
        String s2 = String.valueOf(sb).replaceAll("��", "");
        if (s2.length() > 255) {
            s2 = s2.substring(0, 255);
        }
        AutoGG.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(s2));
    }
    
    private void lambda$new$2(final LivingDeathEvent livingDeathEvent) {
        if (AutoGG.mc.player == null) {
            return;
        }
        if (this.targetedPlayers == null) {
            this.targetedPlayers = new ConcurrentHashMap<String, Integer>();
        }
        final EntityLivingBase entityLiving = livingDeathEvent.getEntityLiving();
        if (entityLiving == null) {
            return;
        }
        if (!EntityUtil.isPlayer((Entity)entityLiving)) {
            return;
        }
        final EntityPlayer entityPlayer = (EntityPlayer)entityLiving;
        if (entityPlayer.getHealth() > 0.0f) {
            return;
        }
        final String getName = entityPlayer.getName();
        if (this.shouldAnnounce(getName)) {
            this.doAnnounce(getName);
        }
    }
    
    private boolean shouldAnnounce(final String s) {
        return this.targetedPlayers.containsKey(s);
    }
    
    public AutoGG() {
        this.targetedPlayers = null;
        this.toxicMode = (Setting<Boolean>)this.register((Setting)Settings.b("ToxicMode", false));
        this.clientName = (Setting<Boolean>)this.register((Setting)Settings.b("ClientName", true));
        this.timeoutTicks = (Setting<Integer>)this.register((Setting)Settings.i("TimeoutTicks", 20));
        this.sendListener = new Listener<PacketEvent.Send>(this::lambda$new$1, (Predicate<PacketEvent.Send>[])new Predicate[0]);
        this.livingDeathEventListener = new Listener<LivingDeathEvent>(this::lambda$new$2, (Predicate<LivingDeathEvent>[])new Predicate[0]);
    }
}
