//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.client.entity.*;
import me.noble.client.util.*;
import net.minecraft.entity.*;
import java.util.function.*;

@Module.Info(name = "AntiFriendHit", description = "Don't hit your friends", category = Module.Category.COMBAT, alwaysListening = true)
public class AntiFriendHit extends Module
{
    @EventHandler
    Listener<ClientPlayerAttackEvent> listener;
    
    private void lambda$new$0(final ClientPlayerAttackEvent clientPlayerAttackEvent) {
        if (!this.isEnabled()) {
            return;
        }
        final Entity entityHit = AntiFriendHit.mc.objectMouseOver.entityHit;
        if (entityHit instanceof EntityOtherPlayerMP && Friends.isFriend(entityHit.getName())) {
            clientPlayerAttackEvent.cancel();
        }
    }
    
    public AntiFriendHit() {
        this.listener = new Listener<ClientPlayerAttackEvent>(this::lambda$new$0, (Predicate<ClientPlayerAttackEvent>[])new Predicate[0]);
    }
}
