//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;

@Module.Info(name = "CameraClip", category = Module.Category.MISC, description = "Allows your 3rd person camera to pass through blocks", showOnArray = Module.ShowOnArray.OFF)
public class CameraClip extends Module
{
}
