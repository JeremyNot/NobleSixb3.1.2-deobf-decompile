//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import me.noble.client.util.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import me.noble.client.event.events.*;
import java.util.function.*;

@Module.Info(name = "Tracers", description = "Draws lines to other living entities", category = Module.Category.RENDER)
public class Tracers extends Module
{
    HueCycler cycler;
    private Setting<Double> range;
    private Setting<Boolean> animals;
    private Setting<Boolean> mobs;
    private Setting<Boolean> players;
    private Setting<Float> opacity;
    private Setting<Boolean> friends;
    
    public Tracers() {
        this.players = (Setting<Boolean>)this.register((Setting)Settings.b("Players", true));
        this.friends = (Setting<Boolean>)this.register((Setting)Settings.b("Friends", true));
        this.animals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
        this.mobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
        this.range = (Setting<Double>)this.register((Setting)Settings.d("Range", 200.0));
        this.opacity = (Setting<Float>)this.register((SettingBuilder)Settings.floatBuilder("Opacity").withRange(0.0f, 1.0f).withValue(1.0f));
        this.cycler = new HueCycler(3600);
    }
    
    public static double[] interpolate(final Entity entity) {
        return new double[] { interpolate(entity.posX, entity.lastTickPosX) - Tracers.mc.getRenderManager().renderPosX, interpolate(entity.posY, entity.lastTickPosY) - Tracers.mc.getRenderManager().renderPosY, interpolate(entity.posZ, entity.lastTickPosZ) - Tracers.mc.getRenderManager().renderPosZ };
    }
    
    public static void drawLine(final double n, final double n2, final double n3, final double n4, final float n5, final float n6, final float n7, final float n8) {
        final Vec3d rotateYaw = new Vec3d(0.0, 0.0, 1.0).rotatePitch(-(float)Math.toRadians(Minecraft.getMinecraft().player.rotationPitch)).rotateYaw(-(float)Math.toRadians(Minecraft.getMinecraft().player.rotationYaw));
        drawLineFromPosToPos(rotateYaw.xCoord, rotateYaw.yCoord + Tracers.mc.player.getEyeHeight(), rotateYaw.zCoord, n, n2, n3, n4, n5, n6, n7, n8);
    }
    
    private void lambda$onWorldRender$3(final Entity entity) {
        int n = this.getColour(entity);
        if (n == Integer.MIN_VALUE) {
            if (!this.friends.getValue()) {
                return;
            }
            n = this.cycler.current();
        }
        drawLineToEntity(entity, (n >>> 16 & 0xFF) / 255.0f, (n >>> 8 & 0xFF) / 255.0f, (n & 0xFF) / 255.0f, this.opacity.getValue());
    }
    
    public void onUpdate() {
        this.cycler.next();
    }
    
    private int getColour(final Entity entity) {
        if (entity instanceof EntityPlayer) {
            return Friends.isFriend(entity.getName()) ? Integer.MIN_VALUE : ColourUtils.Colors.WHITE;
        }
        if (EntityUtil.isPassive(entity)) {
            return ColourUtils.Colors.GREEN;
        }
        return ColourUtils.Colors.RED;
    }
    
    private boolean lambda$onWorldRender$1(final Entity entity) {
        return (entity instanceof EntityPlayer) ? (this.players.getValue() && Tracers.mc.player != entity) : (EntityUtil.isPassive(entity) ? this.animals.getValue() : ((boolean)this.mobs.getValue()));
    }
    
    private void drawRainbowToEntity(final Entity entity, final float n) {
        final Vec3d rotateYaw = new Vec3d(0.0, 0.0, 1.0).rotatePitch(-(float)Math.toRadians(Minecraft.getMinecraft().player.rotationPitch)).rotateYaw(-(float)Math.toRadians(Minecraft.getMinecraft().player.rotationYaw));
        final double[] interpolate = interpolate(entity);
        final double n2 = interpolate[0];
        final double n3 = interpolate[1];
        final double n4 = interpolate[2];
        final double xCoord = rotateYaw.xCoord;
        final double n5 = rotateYaw.yCoord + Tracers.mc.player.getEyeHeight();
        final double zCoord = rotateYaw.zCoord;
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glLineWidth(1.5f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        this.cycler.reset();
        this.cycler.setNext(n);
        GlStateManager.disableLighting();
        GL11.glLoadIdentity();
        Tracers.mc.entityRenderer.orientCamera(Tracers.mc.getRenderPartialTicks());
        GL11.glBegin(1);
        GL11.glVertex3d(n2, n3, n4);
        GL11.glVertex3d(xCoord, n5, zCoord);
        this.cycler.setNext(n);
        GL11.glVertex3d(xCoord, n5, zCoord);
        GL11.glVertex3d(xCoord, n5, zCoord);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glColor3d(1.0, 1.0, 1.0);
        GlStateManager.enableLighting();
    }
    
    public static double interpolate(final double n, final double n2) {
        return n2 + (n - n2) * Tracers.mc.getRenderPartialTicks();
    }
    
    public static void drawLineToEntity(final Entity entity, final float n, final float n2, final float n3, final float n4) {
        final double[] interpolate = interpolate(entity);
        drawLine(interpolate[0], interpolate[1], interpolate[2], entity.height, n, n2, n3, n4);
    }
    
    public static void drawLineFromPosToPos(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final float n8, final float n9, final float n10, final float n11) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glLineWidth(1.5f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glColor4f(n8, n9, n10, n11);
        GlStateManager.disableLighting();
        GL11.glLoadIdentity();
        Tracers.mc.entityRenderer.orientCamera(Tracers.mc.getRenderPartialTicks());
        GL11.glBegin(1);
        GL11.glVertex3d(n, n2, n3);
        GL11.glVertex3d(n4, n5, n6);
        GL11.glVertex3d(n4, n5, n6);
        GL11.glVertex3d(n4, n5 + n7, n6);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glColor3d(1.0, 1.0, 1.0);
        GlStateManager.enableLighting();
    }
    
    private boolean lambda$onWorldRender$2(final Entity entity) {
        return Tracers.mc.player.getDistanceToEntity(entity) < this.range.getValue();
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        GlStateManager.pushMatrix();
        Minecraft.getMinecraft().world.loadedEntityList.stream().filter(EntityUtil::isLiving).filter(Tracers::lambda$onWorldRender$0).filter(this::lambda$onWorldRender$1).filter(this::lambda$onWorldRender$2).forEach(this::lambda$onWorldRender$3);
        GlStateManager.popMatrix();
    }
    
    private static boolean lambda$onWorldRender$0(final Entity entity) {
        return !EntityUtil.isFakeLocalPlayer(entity);
    }
}
