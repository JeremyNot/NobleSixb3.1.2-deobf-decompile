//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.init.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(name = "FastExp", category = Module.Category.PLAYER, description = "Auto Switch to XP and throw fast")
public class FastExp extends Module
{
    @EventHandler
    private Listener<PacketEvent.Receive> receiveListener;
    private int initHotbarSlot;
    private Setting<Boolean> autoDisable;
    private Setting<Boolean> autoSwitch;
    private Setting<Boolean> autoThrow;
    
    public void onUpdate() {
        if (FastExp.mc.player == null) {
            return;
        }
        if (this.autoSwitch.getValue() && FastExp.mc.player.getHeldItemMainhand().getItem() != Items.EXPERIENCE_BOTTLE) {
            final int xpPots = this.findXpPots();
            if (xpPots == -1) {
                if (this.autoDisable.getValue()) {
                    this.disable();
                }
                return;
            }
            FastExp.mc.player.inventory.currentItem = xpPots;
        }
        if (this.autoThrow.getValue() && FastExp.mc.player.getHeldItemMainhand().getItem() == Items.EXPERIENCE_BOTTLE) {
            FastExp.mc.rightClickMouse();
        }
    }
    
    public FastExp() {
        this.autoThrow = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Throw", true));
        this.autoSwitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch", true));
        this.autoDisable = (Setting<Boolean>)this.register((Setting)Settings.booleanBuilder("Auto Disable").withValue(false).withVisibility(this::lambda$new$0).build());
        this.initHotbarSlot = -1;
        this.receiveListener = new Listener<PacketEvent.Receive>(FastExp::lambda$new$1, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    protected void onDisable() {
        if (FastExp.mc.player == null) {
            return;
        }
        if (this.autoSwitch.getValue() && this.initHotbarSlot != -1 && this.initHotbarSlot != FastExp.mc.player.inventory.currentItem) {
            FastExp.mc.player.inventory.currentItem = this.initHotbarSlot;
        }
    }
    
    private static void lambda$new$1(final PacketEvent.Receive receive) {
        if (FastExp.mc.player != null && FastExp.mc.player.getHeldItemMainhand().getItem() == Items.EXPERIENCE_BOTTLE) {
            FastExp.mc.rightClickDelayTimer = 0;
        }
    }
    
    protected void onEnable() {
        if (FastExp.mc.player == null) {
            return;
        }
        if (this.autoSwitch.getValue()) {
            this.initHotbarSlot = FastExp.mc.player.inventory.currentItem;
        }
    }
    
    private int findXpPots() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            if (FastExp.mc.player.inventory.getStackInSlot(i).getItem() == Items.EXPERIENCE_BOTTLE) {
                n = i;
                break;
            }
        }
        return n;
    }
    
    private boolean lambda$new$0(final Boolean b) {
        return this.autoSwitch.getValue();
    }
}
