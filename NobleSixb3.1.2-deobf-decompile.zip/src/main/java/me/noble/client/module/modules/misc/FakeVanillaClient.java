//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;

@Module.Info(name = "FakeVanillaClient", description = "Fakes a modless client when connecting", category = Module.Category.MISC)
public class FakeVanillaClient extends Module
{
}
