//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.client.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.client.gui.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.network.play.server.*;
import me.noble.client.command.*;

@Module.Info(name = "AntiChunkBan", description = "Prevents being kicked by overloaded chunks", category = Module.Category.MISC, showOnArray = Module.ShowOnArray.OFF)
public class AntiChunkBan extends Module
{
    private static long startTime;
    @EventHandler
    Listener<PacketEvent.Receive> receiveListener;
    private Setting<ModeThing> modeThing;
    private Setting<Boolean> disable;
    private Setting<Float> delayTime;
    private Setting<Boolean> warn;
    
    static {
        AntiChunkBan.startTime = 0L;
    }
    
    public void onUpdate() {
        if (AntiChunkBan.mc.player == null) {
            return;
        }
        if ((this.modeThing.getValue().equals(ModeThing.KILL) || this.modeThing.getValue().equals(ModeThing.BOTH)) && Minecraft.getMinecraft().getCurrentServerData() != null) {
            if (AntiChunkBan.startTime == 0L) {
                AntiChunkBan.startTime = System.currentTimeMillis();
            }
            if (AntiChunkBan.startTime + this.delayTime.getValue() <= System.currentTimeMillis()) {
                if (Minecraft.getMinecraft().getCurrentServerData() != null) {
                    Minecraft.getMinecraft().playerController.connection.sendPacket((Packet)new CPacketChatMessage("/kill"));
                }
                if (AntiChunkBan.mc.player.getHealth() <= 0.0f) {
                    AntiChunkBan.mc.player.respawnPlayer();
                    AntiChunkBan.mc.displayGuiScreen((GuiScreen)null);
                    if (this.disable.getValue()) {
                        this.disable();
                    }
                }
                AntiChunkBan.startTime = System.currentTimeMillis();
            }
        }
    }
    
    public AntiChunkBan() {
        this.modeThing = (Setting<ModeThing>)this.register((Setting)Settings.e("Mode", ModeThing.PACKET));
        this.delayTime = (Setting<Float>)this.register((Setting)Settings.f("Kill Delay", 10.0f));
        this.disable = (Setting<Boolean>)this.register((Setting)Settings.b("Disable After Kill", false));
        this.warn = (Setting<Boolean>)this.register((Setting)Settings.b("Warning", true));
        this.receiveListener = new Listener<PacketEvent.Receive>(this::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    private void lambda$new$0(final PacketEvent.Receive receive) {
        if (this.modeThing.getValue().equals(ModeThing.PACKET) || this.modeThing.getValue().equals(ModeThing.BOTH)) {
            if (AntiChunkBan.mc.player == null) {
                return;
            }
            if (receive.getPacket() instanceof SPacketChunkData) {
                receive.cancel();
            }
        }
    }
    
    public void onEnable() {
        if (AntiChunkBan.mc.player == null) {
            return;
        }
        Command.sendChatMessage("[AntiChunkBan] Note: this disables chunks loading in. If you want to be able to play normally you have to disable it");
    }
    
    private enum ModeThing
    {
        BOTH, 
        KILL, 
        PACKET;
        
        private static final ModeThing[] $VALUES;
        
        static {
            $VALUES = new ModeThing[] { ModeThing.PACKET, ModeThing.KILL, ModeThing.BOTH };
        }
    }
}
