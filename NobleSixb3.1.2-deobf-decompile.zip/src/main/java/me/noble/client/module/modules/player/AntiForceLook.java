//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.server.*;
import java.util.function.*;

@Module.Info(name = "AntiForceLook", category = Module.Category.PLAYER, description = "Stops server packets from turning your head")
public class AntiForceLook extends Module
{
    @EventHandler
    Listener<PacketEvent.Receive> receiveListener;
    
    private static void lambda$new$0(final PacketEvent.Receive receive) {
        if (AntiForceLook.mc.player == null) {
            return;
        }
        if (receive.getPacket() instanceof SPacketPlayerPosLook) {
            final SPacketPlayerPosLook sPacketPlayerPosLook = (SPacketPlayerPosLook)receive.getPacket();
            sPacketPlayerPosLook.yaw = AntiForceLook.mc.player.rotationYaw;
            sPacketPlayerPosLook.pitch = AntiForceLook.mc.player.rotationPitch;
        }
    }
    
    public AntiForceLook() {
        this.receiveListener = new Listener<PacketEvent.Receive>(AntiForceLook::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
}
