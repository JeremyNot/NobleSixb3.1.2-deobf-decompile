//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import me.noble.client.setting.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import java.util.function.*;

@Module.Info(name = "AutoTotemOld", category = Module.Category.COMBAT, description = "Refills your offhand with totems")
public class AutoTotemOld extends Module
{
    boolean moving;
    int totems;
    private Setting<Boolean> inv;
    boolean returnI;
    private Setting<Boolean> force;
    
    private static boolean lambda$onUpdate$0(final ItemStack itemStack) {
        return itemStack.getItem() == Items.field_190929_cY;
    }
    
    public String getHudInfo() {
        return String.valueOf(this.totems);
    }
    
    public AutoTotemOld() {
        this.moving = false;
        this.returnI = false;
        this.force = (Setting<Boolean>)this.register((Setting)Settings.b("Replace Offhand", false));
        this.inv = (Setting<Boolean>)this.register((Setting)Settings.b("Inventory", true));
    }
    
    public void onUpdate() {
        if (!this.inv.getValue() && AutoTotemOld.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        if (this.returnI) {
            int n = -1;
            for (int i = 0; i < 45; ++i) {
                if (AutoTotemOld.mc.player.inventory.getStackInSlot(i).field_190928_g) {
                    n = i;
                    break;
                }
            }
            if (n == -1) {
                return;
            }
            AutoTotemOld.mc.playerController.windowClick(0, (n < 9) ? (n + 36) : n, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemOld.mc.player);
            this.returnI = false;
        }
        this.totems = AutoTotemOld.mc.player.inventory.mainInventory.stream().filter(AutoTotemOld::lambda$onUpdate$0).mapToInt(ItemStack::func_190916_E).sum();
        if (AutoTotemOld.mc.player.getHeldItemOffhand().getItem() == Items.field_190929_cY) {
            ++this.totems;
        }
        else {
            if (!this.force.getValue() && !AutoTotemOld.mc.player.getHeldItemOffhand().field_190928_g) {
                return;
            }
            if (this.moving) {
                AutoTotemOld.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemOld.mc.player);
                this.moving = false;
                if (!AutoTotemOld.mc.player.inventory.itemStack.func_190926_b()) {
                    this.returnI = true;
                }
                return;
            }
            if (AutoTotemOld.mc.player.inventory.itemStack.func_190926_b()) {
                if (this.totems == 0) {
                    return;
                }
                int n2 = -1;
                for (int j = 0; j < 45; ++j) {
                    if (AutoTotemOld.mc.player.inventory.getStackInSlot(j).getItem() == Items.field_190929_cY) {
                        n2 = j;
                        break;
                    }
                }
                if (n2 == -1) {
                    return;
                }
                AutoTotemOld.mc.playerController.windowClick(0, (n2 < 9) ? (n2 + 36) : n2, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemOld.mc.player);
                this.moving = true;
            }
            else if (this.force.getValue()) {
                int n3 = -1;
                for (int k = 0; k < 45; ++k) {
                    if (AutoTotemOld.mc.player.inventory.getStackInSlot(k).field_190928_g) {
                        n3 = k;
                        break;
                    }
                }
                if (n3 == -1) {
                    return;
                }
                AutoTotemOld.mc.playerController.windowClick(0, (n3 < 9) ? (n3 + 36) : n3, 0, ClickType.PICKUP, (EntityPlayer)AutoTotemOld.mc.player);
            }
        }
    }
}
