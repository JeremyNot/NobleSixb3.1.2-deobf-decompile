//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.world.chunk.*;
import me.zero.alpine.listener.*;
import org.apache.commons.lang3.*;
import me.noble.client.*;
import me.noble.client.command.*;
import me.noble.client.event.events.*;
import org.lwjgl.opengl.*;
import me.noble.client.setting.*;
import java.util.function.*;
import java.text.*;
import java.util.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.io.*;
import net.minecraft.client.*;

@Module.Info(name = "ChunkFinder", description = "Highlights newly generated chunks", category = Module.Category.RENDER)
public class ChunkFinder extends Module
{
    private PrintWriter logWriter;
    private LastSetting lastSetting;
    private Setting<Boolean> saveInRegionFolder;
    static ArrayList<Chunk> chunks;
    private Setting<Boolean> saveNewChunks;
    private Setting<Integer> yOffset;
    @EventHandler
    public Listener<ChunkEvent> listener;
    private Setting<Boolean> relative;
    @EventHandler
    private Listener<net.minecraftforge.event.world.ChunkEvent.Unload> unloadListener;
    private int list;
    private static boolean dirty;
    private Setting<Boolean> alsoSaveNormalCoords;
    private Setting<Boolean> closeFile;
    private Setting<SaveOption> saveOption;
    
    private void lambda$new$4(final ChunkEvent chunkEvent) {
        if (!chunkEvent.getPacket().doChunkLoad()) {
            ChunkFinder.chunks.add(chunkEvent.getChunk());
            ChunkFinder.dirty = true;
            if (this.saveNewChunks.getValue()) {
                this.saveNewChunk(chunkEvent.getChunk());
            }
        }
    }
    
    private String getNHackInetName() {
        String s = ChunkFinder.mc.getCurrentServerData().serverIP;
        if (SystemUtils.IS_OS_WINDOWS) {
            s = s.replace(":", "_");
        }
        if (this.hasNoPort(s)) {
            s = String.valueOf(new StringBuilder().append(s).append("_25565"));
        }
        return s;
    }
    
    private void logWriterOpen() {
        final String string = this.getPath().toString();
        try {
            this.logWriter = new PrintWriter(new BufferedWriter(new FileWriter(string, true)), true);
            String value = "timestamp,ChunkX,ChunkZ";
            if (this.alsoSaveNormalCoords.getValue()) {
                value = String.valueOf(new StringBuilder().append(value).append(",x coordinate,z coordinate"));
            }
            this.logWriter.println(value);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            NobleMod.log.error(String.valueOf(new StringBuilder().append("some exception happened when trying to start the logging -> ").append(ex.getMessage())));
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("onLogStart: ").append(ex.getMessage())));
        }
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (ChunkFinder.dirty) {
            GL11.glNewList(this.list, 4864);
            GL11.glPushMatrix();
            GL11.glEnable(2848);
            GL11.glDisable(2929);
            GL11.glDisable(3553);
            GL11.glDepthMask(false);
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3042);
            GL11.glLineWidth(1.0f);
            for (final Chunk chunk : ChunkFinder.chunks) {
                final double n = chunk.xPosition * 16;
                final double n2 = 0.0;
                final double n3 = chunk.zPosition * 16;
                GL11.glColor3f(0.6f, 0.1f, 0.2f);
                GL11.glBegin(2);
                GL11.glVertex3d(n, n2, n3);
                GL11.glVertex3d(n + 16.0, n2, n3);
                GL11.glVertex3d(n + 16.0, n2, n3 + 16.0);
                GL11.glVertex3d(n, n2, n3 + 16.0);
                GL11.glVertex3d(n, n2, n3);
                GL11.glEnd();
            }
            GL11.glDisable(3042);
            GL11.glDepthMask(true);
            GL11.glEnable(3553);
            GL11.glEnable(2929);
            GL11.glDisable(2848);
            GL11.glPopMatrix();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEndList();
            ChunkFinder.dirty = false;
        }
        final double renderPosX = ChunkFinder.mc.getRenderManager().renderPosX;
        final double n4 = this.relative.getValue() ? 0.0 : (-ChunkFinder.mc.getRenderManager().renderPosY);
        final double renderPosZ = ChunkFinder.mc.getRenderManager().renderPosZ;
        GL11.glTranslated(-renderPosX, n4 + this.yOffset.getValue(), -renderPosZ);
        GL11.glCallList(this.list);
        GL11.glTranslated(renderPosX, -(n4 + this.yOffset.getValue()), renderPosZ);
    }
    
    protected void onDisable() {
        Command.sendChatMessage("onDisable");
        this.logWriterClose();
        ChunkFinder.chunks.clear();
    }
    
    static Setting access$100(final ChunkFinder chunkFinder) {
        return chunkFinder.saveOption;
    }
    
    private boolean isInteger(final String s) {
        try {
            Integer.parseInt(s);
        }
        catch (NumberFormatException | NullPointerException ex) {
            return false;
        }
        return true;
    }
    
    private String getNewChunkInfo(final Chunk chunk) {
        String s = String.format("%d,%d,%d", System.currentTimeMillis(), chunk.xPosition, chunk.zPosition);
        if (this.alsoSaveNormalCoords.getValue()) {
            s = String.valueOf(new StringBuilder().append(s).append(String.format(",%d,%d", chunk.xPosition * 16 + 8, chunk.zPosition * 16 + 8)));
        }
        return s;
    }
    
    public ChunkFinder() {
        this.yOffset = (Setting<Integer>)this.register((Setting)Settings.i("Y Offset", 0));
        this.relative = (Setting<Boolean>)this.register((Setting)Settings.b("Relative", true));
        this.saveNewChunks = (Setting<Boolean>)this.register((Setting)Settings.b("Save New Chunks", false));
        this.saveOption = (Setting<SaveOption>)this.register((Setting)Settings.enumBuilder(SaveOption.class).withValue(SaveOption.extraFolder).withName("Save Option").withVisibility(this::lambda$new$0).build());
        this.saveInRegionFolder = (Setting<Boolean>)this.register((Setting)Settings.booleanBuilder("In Region").withValue(false).withVisibility(this::lambda$new$1).build());
        this.alsoSaveNormalCoords = (Setting<Boolean>)this.register((Setting)Settings.booleanBuilder("Save Normal Coords").withValue(false).withVisibility(this::lambda$new$2).build());
        this.closeFile = (Setting<Boolean>)this.register((Setting)Settings.booleanBuilder("Close File").withValue(false).withVisibility(this::lambda$new$3).build());
        this.lastSetting = new LastSetting(null);
        this.list = GL11.glGenLists(1);
        this.listener = new Listener<ChunkEvent>(this::lambda$new$4, (Predicate<ChunkEvent>[])new Predicate[0]);
        this.unloadListener = new Listener<net.minecraftforge.event.world.ChunkEvent.Unload>(ChunkFinder::lambda$new$5, (Predicate<net.minecraftforge.event.world.ChunkEvent.Unload>[])new Predicate[0]);
    }
    
    private Path getPath() {
        File file = null;
        final int dimension = ChunkFinder.mc.player.dimension;
        if (ChunkFinder.mc.isSingleplayer()) {
            try {
                file = ChunkFinder.mc.getIntegratedServer().worldServerForDimension(dimension).getChunkSaveLocation();
            }
            catch (Exception ex) {
                ex.printStackTrace();
                NobleMod.log.error(String.valueOf(new StringBuilder().append("some exception happened when getting canonicalFile -> ").append(ex.getMessage())));
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("onGetPath: ").append(ex.getMessage())));
            }
            if (file.toPath().relativize(ChunkFinder.mc.mcDataDir.toPath()).getNameCount() != 2) {
                file = file.getParentFile();
            }
        }
        else {
            file = this.makeMultiplayerDirectory().toFile();
        }
        if (dimension != 0) {
            file = new File(file, String.valueOf(new StringBuilder().append("DIM").append(dimension)));
        }
        if (this.saveInRegionFolder.getValue()) {
            file = new File(file, "region");
        }
        final Path path = new File(new File(file, "newChunkLogs"), String.valueOf(new StringBuilder().append(ChunkFinder.mc.getSession().getUsername()).append("_").append(new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date())).append(".csv"))).toPath();
        try {
            if (!Files.exists(path, new LinkOption[0])) {
                Files.createDirectories(path.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
                Files.createFile(path, (FileAttribute<?>[])new FileAttribute[0]);
            }
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
            NobleMod.log.error(String.valueOf(new StringBuilder().append("some exception happened when trying to make the file -> ").append(ex2.getMessage())));
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("onCreateFile: ").append(ex2.getMessage())));
        }
        return path;
    }
    
    private Path makeMultiplayerDirectory() {
        final File mcDataDir = Minecraft.getMinecraft().mcDataDir;
        File file = null;
        switch (this.saveOption.getValue()) {
            case liteLoaderWdl: {
                file = new File(new File(mcDataDir, "saves"), ChunkFinder.mc.getCurrentServerData().serverName);
                break;
            }
            case nhackWdl: {
                final String nHackInetName = this.getNHackInetName();
                file = new File(new File(new File(mcDataDir, "config"), "wdl-saves"), nHackInetName);
                if (!file.exists()) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("nhack wdl directory doesnt exist: ").append(nHackInetName)));
                    Command.sendChatMessage("creating the directory now. It is recommended to update the ip");
                    break;
                }
                break;
            }
            default: {
                String s = String.valueOf(new StringBuilder().append(ChunkFinder.mc.getCurrentServerData().serverName).append("-").append(ChunkFinder.mc.getCurrentServerData().serverIP));
                if (SystemUtils.IS_OS_WINDOWS) {
                    s = s.replace(":", "_");
                }
                file = new File(new File(mcDataDir, "KAMI_NewChunks"), s);
                break;
            }
        }
        return file.toPath();
    }
    
    static Minecraft access$700() {
        return ChunkFinder.mc;
    }
    
    private boolean hasNoPort(final String s) {
        if (!s.contains("_")) {
            return true;
        }
        final String[] split = s.split("_");
        return !this.isInteger(split[split.length - 1]);
    }
    
    public void onUpdate() {
        if (!this.closeFile.getValue()) {
            return;
        }
        this.closeFile.setValue(false);
        Command.sendChatMessage("close file");
        this.logWriterClose();
    }
    
    private void saveNewChunk(final PrintWriter printWriter, final String s) {
        printWriter.println(s);
    }
    
    static Minecraft access$500() {
        return ChunkFinder.mc;
    }
    
    static Setting access$200(final ChunkFinder chunkFinder) {
        return chunkFinder.saveInRegionFolder;
    }
    
    private void logWriterClose() {
        if (this.logWriter != null) {
            this.logWriter.close();
            this.logWriter = null;
            this.lastSetting = new LastSetting(null);
        }
    }
    
    private static void lambda$new$5(final net.minecraftforge.event.world.ChunkEvent.Unload unload) {
        ChunkFinder.dirty = ChunkFinder.chunks.remove(unload.getChunk());
    }
    
    static {
        ChunkFinder.chunks = new ArrayList<Chunk>();
        ChunkFinder.dirty = true;
    }
    
    private boolean lambda$new$1(final Boolean b) {
        return this.saveNewChunks.getValue();
    }
    
    public void destroy() {
        GL11.glDeleteLists(1, 1);
    }
    
    private boolean lambda$new$0(final Object o) {
        return this.saveNewChunks.getValue();
    }
    
    private PrintWriter testAndGetLogWriter() {
        if (this.lastSetting.testChangeAndUpdate()) {
            this.logWriterClose();
            this.logWriterOpen();
        }
        return this.logWriter;
    }
    
    static Minecraft access$400() {
        return ChunkFinder.mc;
    }
    
    public void saveNewChunk(final Chunk chunk) {
        this.saveNewChunk(this.testAndGetLogWriter(), this.getNewChunkInfo(chunk));
    }
    
    private boolean lambda$new$2(final Boolean b) {
        return this.saveNewChunks.getValue();
    }
    
    static Setting access$300(final ChunkFinder chunkFinder) {
        return chunkFinder.alsoSaveNormalCoords;
    }
    
    static Minecraft access$600() {
        return ChunkFinder.mc;
    }
    
    private boolean lambda$new$3(final Boolean b) {
        return this.saveNewChunks.getValue();
    }
    
    private enum SaveOption
    {
        nhackWdl, 
        liteLoaderWdl, 
        extraFolder;
        
        private static final SaveOption[] $VALUES;
        
        static {
            $VALUES = new SaveOption[] { SaveOption.extraFolder, SaveOption.liteLoaderWdl, SaveOption.nhackWdl };
        }
    }
    
    private class LastSetting
    {
        SaveOption lastSaveOption;
        boolean lastInRegion;
        String ip;
        final ChunkFinder this$0;
        boolean lastSaveNormal;
        int dimension;
        
        LastSetting(final ChunkFinder chunkFinder, final ChunkFinder$1 object) {
            this(chunkFinder);
        }
        
        private void update() {
            this.lastSaveOption = ChunkFinder.access$100(this.this$0).getValue();
            this.lastInRegion = ChunkFinder.access$200(this.this$0).getValue();
            this.lastSaveNormal = ChunkFinder.access$300(this.this$0).getValue();
            this.dimension = ChunkFinder.access$600().player.dimension;
            this.ip = ChunkFinder.access$700().getCurrentServerData().serverIP;
        }
        
        private LastSetting(final ChunkFinder this$0) {
            this.this$0 = this$0;
        }
        
        public boolean testChangeAndUpdate() {
            if (this.testChange()) {
                this.update();
                return true;
            }
            return false;
        }
        
        public boolean testChange() {
            return ChunkFinder.access$100(this.this$0).getValue() != this.lastSaveOption || ChunkFinder.access$200(this.this$0).getValue() != this.lastInRegion || ChunkFinder.access$300(this.this$0).getValue() != this.lastSaveNormal || this.dimension != ChunkFinder.access$400().player.dimension || !ChunkFinder.access$500().getCurrentServerData().serverIP.equals(this.ip);
        }
    }
}
