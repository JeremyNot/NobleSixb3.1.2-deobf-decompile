//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import net.minecraft.util.math.*;
import me.noble.client.setting.*;

@Module.Info(name = "PitchLock", category = Module.Category.PLAYER, description = "Locks your camera pitch")
public class PitchLock extends Module
{
    private Setting<Integer> slice;
    private Setting<Float> pitch;
    private Setting<Boolean> auto;
    
    public void onUpdate() {
        if (this.slice.getValue() == 0) {
            return;
        }
        if (this.auto.getValue()) {
            final int n = 360 / this.slice.getValue();
            final float n2 = (float)(Math.round(PitchLock.mc.player.rotationPitch / n) * n);
            PitchLock.mc.player.rotationPitch = n2;
            if (PitchLock.mc.player.isRiding()) {
                PitchLock.mc.player.getRidingEntity().rotationPitch = n2;
            }
        }
        else {
            PitchLock.mc.player.rotationPitch = MathHelper.clamp(this.pitch.getValue() - 180.0f, -180.0f, 180.0f);
        }
    }
    
    public PitchLock() {
        this.auto = (Setting<Boolean>)this.register((Setting)Settings.b("Auto", true));
        this.pitch = (Setting<Float>)this.register((Setting)Settings.f("Pitch", 180.0f));
        this.slice = (Setting<Integer>)this.register((Setting)Settings.i("Slice", 8));
    }
}
