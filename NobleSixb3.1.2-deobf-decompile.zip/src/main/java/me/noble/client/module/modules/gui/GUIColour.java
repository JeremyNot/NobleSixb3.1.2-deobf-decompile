//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import me.noble.client.setting.*;

@Module.Info(name = "GUI Colour", description = "Change GUI Colours", category = Module.Category.GUI)
public class GUIColour extends Module
{
    public Setting<Integer> red;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Integer> green;
    
    public GUIColour() {
        this.red = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Red").withMinimum(0).withValue(13).withMaximum(255).build());
        this.green = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Green").withMinimum(0).withValue(150).withMaximum(255).build());
        this.blue = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Blue").withMinimum(0).withValue(13).withMaximum(255).build());
        this.alpha = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Alpha").withMinimum(0).withValue(117).withMaximum(255).build());
    }
}
