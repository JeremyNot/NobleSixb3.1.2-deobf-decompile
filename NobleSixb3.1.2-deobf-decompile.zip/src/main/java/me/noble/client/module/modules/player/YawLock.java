//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.player;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.util.math.*;

@Module.Info(name = "YawLock", category = Module.Category.PLAYER, description = "Locks your camera yaw")
public class YawLock extends Module
{
    private Setting<Boolean> auto;
    private Setting<Float> yaw;
    private Setting<Integer> slice;
    
    public YawLock() {
        this.auto = (Setting<Boolean>)this.register((Setting)Settings.b("Auto", true));
        this.yaw = (Setting<Float>)this.register((Setting)Settings.f("Yaw", 180.0f));
        this.slice = (Setting<Integer>)this.register((Setting)Settings.i("Slice", 8));
    }
    
    public void onUpdate() {
        if (this.slice.getValue() == 0) {
            return;
        }
        if (this.auto.getValue()) {
            final int n = 360 / this.slice.getValue();
            final float n2 = (float)(Math.round(YawLock.mc.player.rotationYaw / n) * n);
            YawLock.mc.player.rotationYaw = n2;
            if (YawLock.mc.player.isRiding()) {
                YawLock.mc.player.getRidingEntity().rotationYaw = n2;
            }
        }
        else {
            YawLock.mc.player.rotationYaw = MathHelper.clamp(this.yaw.getValue() - 180.0f, -180.0f, 180.0f);
        }
    }
}
