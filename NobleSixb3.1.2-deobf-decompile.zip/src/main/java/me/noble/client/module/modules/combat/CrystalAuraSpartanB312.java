//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.zero.alpine.listener.*;
import net.minecraft.entity.player.*;
import net.minecraft.enchantment.*;
import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.*;
import com.mojang.realmsclient.gui.*;
import me.noble.client.command.*;
import me.noble.client.event.events.*;
import net.minecraft.network.*;
import java.awt.*;
import java.util.stream.*;
import me.noble.client.util.*;
import java.util.function.*;
import net.minecraft.item.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.chat.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.client.entity.*;
import net.minecraft.init.*;
import net.minecraft.util.math.*;

@Module.Info(name = "CrystalAuraSpartanB312", category = Module.Category.COMBAT)
public class CrystalAuraSpartanB312 extends Module
{
    private Setting<Boolean> explode;
    private boolean isAttacking;
    private static double yaw;
    @EventHandler
    private Listener<PacketEvent.Send> packetListener;
    private Setting<RenderMode> renderMode;
    private Setting<Integer> hitTickDelay;
    private static boolean togglePitch;
    private int hitDelayCounter;
    private int oldSlot;
    private Setting<Boolean> antiWeakness;
    private int placements;
    private Setting<Integer> maxplacement;
    private Setting<Double> placeRange;
    private Setting<Boolean> rayTraceHit;
    private Setting<Boolean> autoSwitch;
    private Setting<Boolean> announceUsage;
    private Setting<Integer> nosuicide;
    private Setting<Boolean> safemode;
    private Setting<Integer> red;
    private static boolean isSpoofingAngles;
    private boolean switchCooldown;
    private Setting<Double> minDamage;
    private Setting<Boolean> multiplace;
    private static double pitch;
    private Setting<Double> hitRange;
    private BlockPos renderBlock;
    private int newSlot;
    private Setting<Boolean> place;
    private EntityPlayer target;
    private Setting<Integer> green;
    private Setting<Boolean> spoofRotations;
    private Setting<Integer> alpha;
    private Setting<Integer> blue;
    
    private static float getBlastReductiontwo(final EntityLivingBase entityLivingBase, float n, final Explosion explosion) {
        if (entityLivingBase instanceof EntityPlayer) {
            final EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            final DamageSource causeExplosionDamage = DamageSource.causeExplosionDamage(explosion);
            n = CombatRules.getDamageAfterAbsorb(n, (float)(entityPlayer.getTotalArmorValue() * 1.15), (float)entityPlayer.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            n *= 1.0f - MathHelper.clamp((float)EnchantmentHelper.getEnchantmentModifierDamage(entityPlayer.getArmorInventoryList(), causeExplosionDamage), 0.0f, 20.0f) / 25.0f;
            if (entityLivingBase.isPotionActive(MobEffects.RESISTANCE)) {
                n -= n / 4.0f;
            }
            return n;
        }
        n = CombatRules.getDamageAfterAbsorb(n, (float)(entityLivingBase.getTotalArmorValue() * 1.15), (float)entityLivingBase.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
        return n;
    }
    
    public CrystalAuraSpartanB312() {
        this.place = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Place", true));
        this.explode = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Explode", true));
        this.autoSwitch = (Setting<Boolean>)this.register((Setting)Settings.b("Auto Switch", true));
        this.antiWeakness = (Setting<Boolean>)this.register((Setting)Settings.b("Anti Weakness", true));
        this.safemode = (Setting<Boolean>)this.register((Setting)Settings.b("No Suicide", false));
        this.nosuicide = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("No Suicide Damage rate [70%+]").withMinimum(1).withValue(20).withMaximum(30).build());
        this.spoofRotations = (Setting<Boolean>)this.register((Setting)Settings.b("Spoof Rotations", false));
        this.rayTraceHit = (Setting<Boolean>)this.register((Setting)Settings.b("RayTraceHit", false));
        this.renderMode = (Setting<RenderMode>)this.register((Setting)Settings.e("Render Mode", RenderMode.UP));
        this.multiplace = (Setting<Boolean>)this.register((Setting)Settings.b("Multiplace", true));
        this.maxplacement = (Setting<Integer>)this.register((SettingBuilder)Settings.integerBuilder("Max Crystals per times").withMinimum(0).withMaximum(8).withValue(3));
        this.hitTickDelay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Hit Delay").withMinimum(0).withValue(4).withMaximum(20).build());
        this.hitRange = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Hit Range").withMinimum(0.0).withValue(5.5).build());
        this.placeRange = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Place Range").withMinimum(0.0).withValue(3.5).build());
        this.minDamage = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Min Damage").withMinimum(0.0).withValue(2.0).withMaximum(20.0).build());
        this.red = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Red").withMinimum(0).withValue(50).withMaximum(255).build());
        this.green = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Green").withMinimum(0).withValue(204).withMaximum(255).build());
        this.blue = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Blue").withMinimum(0).withValue(255).withMaximum(255).build());
        this.alpha = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Alpha").withMinimum(0).withValue(169).withMaximum(255).build());
        this.announceUsage = (Setting<Boolean>)this.register((Setting)Settings.b("NoblesSix is god", true));
        this.switchCooldown = false;
        this.isAttacking = false;
        this.oldSlot = -1;
        this.packetListener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(CrystalAuraSpartanB312.mc.player.posX), Math.floor(CrystalAuraSpartanB312.mc.player.posY), Math.floor(CrystalAuraSpartanB312.mc.player.posZ));
    }
    
    private static EntityEnderCrystal lambda$onUpdate$2(final Entity entity) {
        return (EntityEnderCrystal)entity;
    }
    
    private void lookAtPacket(final double n, final double n2, final double n3, final EntityPlayer entityPlayer) {
        final double[] calculateLook = EntityUtil.calculateLookAt(n, n2, n3, entityPlayer);
        setYawAndPitch((float)calculateLook[0], (float)calculateLook[1]);
    }
    
    private static Float lambda$onUpdate$3(final EntityEnderCrystal entityEnderCrystal) {
        return CrystalAuraSpartanB312.mc.player.getDistanceToEntity((Entity)entityEnderCrystal);
    }
    
    static float calculateDamage(final double n, final double n2, final double n3, final Entity entity) {
        final float n4 = 12.0f;
        final double n5 = (1.0 - entity.getDistance(n, n2, n3) / n4) * entity.world.getBlockDensity(new Vec3d(n, n2, n3), entity.getEntityBoundingBox());
        final float n6 = (float)(int)((n5 * n5 + n5) / 2.0 * 7.0 * n4 + 1.0);
        double n7 = 1.0;
        if (entity instanceof EntityLivingBase) {
            n7 = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(n6), new Explosion((World)CrystalAuraSpartanB312.mc.world, (Entity)null, n, n2, n3, 6.0f, false, true));
        }
        return (float)n7;
    }
    
    public void onEnable() {
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[CrystalAuraSpartanB312] ").append(ChatFormatting.GREEN.toString()).append("Enabled!")));
        }
        this.hitDelayCounter = 0;
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (this.renderBlock != null && !this.renderMode.getValue().equals(RenderMode.NONE)) {
            this.drawBlock(this.renderBlock, this.red.getValue(), this.green.getValue(), this.blue.getValue());
        }
    }
    
    public void onDisable() {
        this.renderBlock = null;
        this.target = null;
        resetRotation();
        if (this.announceUsage.getValue()) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[CrystalAuraSpartanB312] ").append(ChatFormatting.RED.toString()).append("Disabled!")));
        }
    }
    
    static float calculateDamagetwo(final double n, final double n2, final double n3, final Entity entity) {
        final float n4 = 12.0f;
        final double n5 = (1.0 - entity.getDistance(n, n2, n3) / n4) * entity.world.getBlockDensity(new Vec3d(n, n2, n3), entity.getEntityBoundingBox());
        final float n6 = (float)(int)((n5 * n5 + n5) / 2.0 * 7.0 * n4 + 1.0);
        double n7 = 1.0;
        if (entity instanceof EntityLivingBase) {
            n7 = getBlastReductiontwo((EntityLivingBase)entity, getDamageMultiplied(n6), new Explosion((World)CrystalAuraSpartanB312.mc.world, (Entity)null, n, n2, n3, 6.0f, false, true));
        }
        return (float)(n7 * 0.9);
    }
    
    private static float getDamageMultiplied(final float n) {
        final int getDifficultyId = CrystalAuraSpartanB312.mc.world.getDifficulty().getDifficultyId();
        return n * ((getDifficultyId == 0) ? 0.0f : ((getDifficultyId == 2) ? 1.0f : ((getDifficultyId == 1) ? 0.5f : 1.5f)));
    }
    
    private static void setYawAndPitch(final float n, final float n2) {
        CrystalAuraSpartanB312.yaw = n;
        CrystalAuraSpartanB312.pitch = n2;
        CrystalAuraSpartanB312.isSpoofingAngles = true;
    }
    
    private static boolean lambda$onUpdate$1(final Entity entity) {
        return entity instanceof EntityEnderCrystal;
    }
    
    private static void resetRotation() {
        if (CrystalAuraSpartanB312.isSpoofingAngles) {
            CrystalAuraSpartanB312.yaw = CrystalAuraSpartanB312.mc.player.rotationYaw;
            CrystalAuraSpartanB312.pitch = CrystalAuraSpartanB312.mc.player.rotationPitch;
            CrystalAuraSpartanB312.isSpoofingAngles = false;
        }
    }
    
    static {
        CrystalAuraSpartanB312.togglePitch = false;
    }
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (!this.spoofRotations.getValue()) {
            return;
        }
        final Packet packet = send.getPacket();
        if (packet instanceof CPacketPlayer && CrystalAuraSpartanB312.isSpoofingAngles) {
            ((CPacketPlayer)packet).yaw = (float)CrystalAuraSpartanB312.yaw;
            ((CPacketPlayer)packet).pitch = (float)CrystalAuraSpartanB312.pitch;
        }
    }
    
    private void drawBlock(final BlockPos blockPos, final int n, final int n2, final int n3) {
        final Color color = new Color(n, n2, n3, this.alpha.getValue());
        KamiTessellator.prepare(7);
        if (this.renderMode.getValue().equals(RenderMode.UP)) {
            KamiTessellator.drawBox(blockPos, color.getRGB(), 2);
        }
        else if (this.renderMode.getValue().equals(RenderMode.BLOCK)) {
            KamiTessellator.drawBox(blockPos, color.getRGB(), 63);
        }
        KamiTessellator.release();
    }
    
    private static float getBlastReduction(final EntityLivingBase entityLivingBase, float n, final Explosion explosion) {
        if (entityLivingBase instanceof EntityPlayer) {
            final EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            final DamageSource causeExplosionDamage = DamageSource.causeExplosionDamage(explosion);
            n = CombatRules.getDamageAfterAbsorb(n, (float)entityPlayer.getTotalArmorValue(), (float)entityPlayer.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            n *= 1.0f - MathHelper.clamp((float)EnchantmentHelper.getEnchantmentModifierDamage(entityPlayer.getArmorInventoryList(), causeExplosionDamage), 0.0f, 20.0f) / 25.0f;
            if (entityLivingBase.isPotionActive(MobEffects.RESISTANCE)) {
                n -= n / 4.0f;
            }
            return n;
        }
        n = CombatRules.getDamageAfterAbsorb(n, (float)entityLivingBase.getTotalArmorValue(), (float)entityLivingBase.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
        return n;
    }
    
    private List<BlockPos> findCrystalBlocks() {
        final NonNullList func_191196_a = NonNullList.func_191196_a();
        func_191196_a.addAll((Collection)BlockInteractionHelper.getSphere(getPlayerPos(), this.placeRange.getValue().floatValue(), this.placeRange.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::canPlaceCrystal).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return (List<BlockPos>)func_191196_a;
    }
    
    private static boolean lambda$onUpdate$4(final EntityPlayer entityPlayer) {
        return !Friends.isFriend(entityPlayer.getName());
    }
    
    private static int lambda$onUpdate$5(final Entity entity, final Entity entity2) {
        return Float.compare(CrystalAuraSpartanB312.mc.player.getDistanceToEntity(entity), CrystalAuraSpartanB312.mc.player.getDistanceToEntity(entity2));
    }
    
    public void onUpdate() {
        if (CrystalAuraSpartanB312.mc.player == null) {
            return;
        }
        final EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal)CrystalAuraSpartanB312.mc.world.loadedEntityList.stream().filter(CrystalAuraSpartanB312::lambda$onUpdate$1).map(CrystalAuraSpartanB312::lambda$onUpdate$2).min(Comparator.comparing((Function<? super T, ? extends Comparable>)CrystalAuraSpartanB312::lambda$onUpdate$3)).orElse(null);
        if (this.explode.getValue() && entityEnderCrystal != null && CrystalAuraSpartanB312.mc.player.getDistanceToEntity((Entity)entityEnderCrystal) <= this.hitRange.getValue() && this.rayTraceHitCheck(entityEnderCrystal)) {
            if (this.hitDelayCounter < this.hitTickDelay.getValue()) {
                ++this.hitDelayCounter;
                return;
            }
            this.hitDelayCounter = 0;
            if (this.antiWeakness.getValue() && CrystalAuraSpartanB312.mc.player.isPotionActive(MobEffects.WEAKNESS)) {
                if (!this.isAttacking) {
                    this.oldSlot = CrystalAuraSpartanB312.mc.player.inventory.currentItem;
                    this.isAttacking = true;
                }
                this.newSlot = -1;
                for (int i = 0; i < 9; ++i) {
                    final ItemStack getStackInSlot = CrystalAuraSpartanB312.mc.player.inventory.getStackInSlot(i);
                    if (getStackInSlot != ItemStack.field_190927_a) {
                        if (getStackInSlot.getItem() instanceof ItemSword) {
                            this.newSlot = i;
                            break;
                        }
                        if (getStackInSlot.getItem() instanceof ItemTool) {
                            this.newSlot = i;
                            break;
                        }
                    }
                }
                if (this.newSlot != -1) {
                    CrystalAuraSpartanB312.mc.player.inventory.currentItem = this.newSlot;
                    this.switchCooldown = true;
                }
            }
            this.lookAtPacket(entityEnderCrystal.posX, entityEnderCrystal.posY, entityEnderCrystal.posZ, (EntityPlayer)CrystalAuraSpartanB312.mc.player);
            final double n = calculateDamagetwo(entityEnderCrystal.posX + 0.5, entityEnderCrystal.posY + 1.0, entityEnderCrystal.posZ + 0.5, (Entity)CrystalAuraSpartanB312.mc.player) * (0.7 + this.nosuicide.getValue() / 100);
            final float n2 = CrystalAuraSpartanB312.mc.player.getHealth() + CrystalAuraSpartanB312.mc.player.getAbsorptionAmount();
            if (this.safemode.getValue() && n <= n2 - 0.5) {
                CrystalAuraSpartanB312.mc.playerController.attackEntity((EntityPlayer)CrystalAuraSpartanB312.mc.player, (Entity)entityEnderCrystal);
                CrystalAuraSpartanB312.mc.player.swingArm(EnumHand.MAIN_HAND);
            }
            else if (!this.safemode.getValue()) {
                CrystalAuraSpartanB312.mc.playerController.attackEntity((EntityPlayer)CrystalAuraSpartanB312.mc.player, (Entity)entityEnderCrystal);
                CrystalAuraSpartanB312.mc.player.swingArm(EnumHand.MAIN_HAND);
            }
            if (!this.multiplace.getValue()) {
                return;
            }
            if (this.placements == this.maxplacement.getValue()) {
                this.placements = 0;
                return;
            }
        }
        else {
            resetRotation();
            if (this.oldSlot != -1) {
                CrystalAuraSpartanB312.mc.player.inventory.currentItem = this.oldSlot;
                this.oldSlot = -1;
            }
            this.isAttacking = false;
        }
        int currentItem = (CrystalAuraSpartanB312.mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) ? CrystalAuraSpartanB312.mc.player.inventory.currentItem : -1;
        if (currentItem == -1) {
            for (int j = 0; j < 9; ++j) {
                if (CrystalAuraSpartanB312.mc.player.inventory.getStackInSlot(j).getItem() == Items.END_CRYSTAL) {
                    currentItem = j;
                    break;
                }
            }
        }
        boolean b = false;
        if (CrystalAuraSpartanB312.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
            b = true;
        }
        else if (currentItem == -1) {
            return;
        }
        final List list = (List)CrystalAuraSpartanB312.mc.world.playerEntities.stream().filter(CrystalAuraSpartanB312::lambda$onUpdate$4).sorted(CrystalAuraSpartanB312::lambda$onUpdate$5).collect(Collectors.toList());
        final List<BlockPos> crystalBlocks = this.findCrystalBlocks();
        BlockPos renderBlock = null;
        double n3 = 0.0;
        this.target = null;
        for (final Entity entity : list) {
            if (entity == CrystalAuraSpartanB312.mc.player) {
                continue;
            }
            if (!(entity instanceof EntityPlayer)) {
                continue;
            }
            final EntityPlayer target = (EntityPlayer)entity;
            if (target.isDead) {
                continue;
            }
            if (target.getHealth() <= 0.0f) {
                continue;
            }
            for (final BlockPos blockPos : crystalBlocks) {
                if (target.getDistanceSq(blockPos) >= 169.0) {
                    continue;
                }
                final double n4 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, (Entity)target);
                final double n5 = calculateDamage(blockPos.x + 0.5, blockPos.y + 1, blockPos.z + 0.5, (Entity)CrystalAuraSpartanB312.mc.player);
                final float n6 = target.getHealth() + target.getAbsorptionAmount();
                final float n7 = CrystalAuraSpartanB312.mc.player.getHealth() + CrystalAuraSpartanB312.mc.player.getAbsorptionAmount();
                if (n4 < this.minDamage.getValue()) {
                    continue;
                }
                if (n5 >= n7 - 0.5) {
                    continue;
                }
                if (n5 > n4 && n4 < n6) {
                    continue;
                }
                if (n4 <= n3) {
                    continue;
                }
                renderBlock = blockPos;
                n3 = n4;
                this.target = target;
            }
            if (this.target != null) {
                break;
            }
        }
        if (this.target == null) {
            this.renderBlock = null;
            resetRotation();
            return;
        }
        this.renderBlock = renderBlock;
        if (ModuleManager.getModuleByName("AutoGG").isEnabled()) {
            ((AutoGG)ModuleManager.getModuleByName("AutoGG")).addTargetedPlayer(this.target.getName());
        }
        if (this.place.getValue()) {
            if (!b && CrystalAuraSpartanB312.mc.player.inventory.currentItem != currentItem) {
                if (this.autoSwitch.getValue()) {
                    CrystalAuraSpartanB312.mc.player.inventory.currentItem = currentItem;
                    resetRotation();
                    this.switchCooldown = true;
                }
                return;
            }
            this.lookAtPacket(renderBlock.x + 0.5, renderBlock.y - 0.5, renderBlock.z + 0.5, (EntityPlayer)CrystalAuraSpartanB312.mc.player);
            final RayTraceResult rayTraceBlocks = CrystalAuraSpartanB312.mc.world.rayTraceBlocks(new Vec3d(CrystalAuraSpartanB312.mc.player.posX, CrystalAuraSpartanB312.mc.player.posY + CrystalAuraSpartanB312.mc.player.getEyeHeight(), CrystalAuraSpartanB312.mc.player.posZ), new Vec3d(renderBlock.x + 0.5, renderBlock.y - 0.5, renderBlock.z + 0.5));
            EnumFacing enumFacing;
            if (rayTraceBlocks == null || rayTraceBlocks.sideHit == null) {
                enumFacing = EnumFacing.UP;
            }
            else {
                enumFacing = rayTraceBlocks.sideHit;
            }
            if (this.switchCooldown) {
                this.switchCooldown = false;
                return;
            }
            CrystalAuraSpartanB312.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(renderBlock, enumFacing, b ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            ++this.placements;
        }
        if (this.spoofRotations.getValue() && CrystalAuraSpartanB312.isSpoofingAngles) {
            if (CrystalAuraSpartanB312.togglePitch) {
                final EntityPlayerSP player = CrystalAuraSpartanB312.mc.player;
                player.rotationPitch += (float)4.0E-4;
                CrystalAuraSpartanB312.togglePitch = false;
            }
            else {
                final EntityPlayerSP player2 = CrystalAuraSpartanB312.mc.player;
                player2.rotationPitch -= (float)4.0E-4;
                CrystalAuraSpartanB312.togglePitch = true;
            }
        }
    }
    
    public String getHudInfo() {
        if (this.target == null) {
            return "";
        }
        return this.target.getName().toUpperCase();
    }
    
    private boolean rayTraceHitCheck(final EntityEnderCrystal entityEnderCrystal) {
        return !this.rayTraceHit.getValue() || CrystalAuraSpartanB312.mc.player.canEntityBeSeen((Entity)entityEnderCrystal);
    }
    
    private boolean canPlaceCrystal(final BlockPos blockPos) {
        final BlockPos add = blockPos.add(0, 1, 0);
        final BlockPos add2 = blockPos.add(0, 2, 0);
        return (CrystalAuraSpartanB312.mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || CrystalAuraSpartanB312.mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && CrystalAuraSpartanB312.mc.world.getBlockState(add).getBlock() == Blocks.AIR && CrystalAuraSpartanB312.mc.world.getBlockState(add2).getBlock() == Blocks.AIR && CrystalAuraSpartanB312.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add)).isEmpty() && CrystalAuraSpartanB312.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(add2)).isEmpty();
    }
    
    private enum RenderMode
    {
        private static final RenderMode[] $VALUES;
        
        UP, 
        BLOCK, 
        NONE;
        
        static {
            $VALUES = new RenderMode[] { RenderMode.UP, RenderMode.BLOCK, RenderMode.NONE };
        }
    }
}
