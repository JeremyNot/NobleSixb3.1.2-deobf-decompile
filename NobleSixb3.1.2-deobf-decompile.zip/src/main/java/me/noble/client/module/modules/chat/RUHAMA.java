//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;

@Module.Info(name = "Suffix-Ruhama", category = Module.Category.CHAT, description = "Modifies your chat messages")
public class RUHAMA extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> listener;
    private Setting<Boolean> commands;
    private final String NOBLE_SUFFIX = " \u23d0 \u0280\u1d1c\u029c\u1d00\u1d0d\u1d00";
    
    public RUHAMA() {
        this.commands = (Setting<Boolean>)this.register((Setting)Settings.b("Commands", false));
        this.listener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketChatMessage) {
            final String getMessage = ((CPacketChatMessage)send.getPacket()).getMessage();
            if (getMessage.startsWith("/") && !this.commands.getValue()) {
                return;
            }
            String message = String.valueOf(new StringBuilder().append(getMessage).append(" \u23d0 \u0280\u1d1c\u029c\u1d00\u1d0d\u1d00"));
            if (message.length() >= 256) {
                message = message.substring(0, 256);
            }
            ((CPacketChatMessage)send.getPacket()).message = message;
        }
    }
}
