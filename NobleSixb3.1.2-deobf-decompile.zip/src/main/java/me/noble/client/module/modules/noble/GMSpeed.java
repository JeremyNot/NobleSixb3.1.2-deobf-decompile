//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.noble;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.client.entity.*;

@Module.Info(name = "NobleSpeed", category = Module.Category.NOBLE, description = "Godmode Speed")
public class GMSpeed extends Module
{
    private Setting<Double> gmspeed;
    
    public GMSpeed() {
        this.gmspeed = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Speed").withRange(0.1, 10.0).withValue(1.0).build());
    }
    
    public void onUpdate() {
        if ((GMSpeed.mc.player.field_191988_bg != 0.0f || GMSpeed.mc.player.moveStrafing != 0.0f) && !GMSpeed.mc.player.isSneaking() && GMSpeed.mc.player.onGround) {
            final EntityPlayerSP player = GMSpeed.mc.player;
            player.motionX *= this.gmspeed.getValue();
            final EntityPlayerSP player2 = GMSpeed.mc.player;
            player2.motionZ *= this.gmspeed.getValue();
        }
    }
}
