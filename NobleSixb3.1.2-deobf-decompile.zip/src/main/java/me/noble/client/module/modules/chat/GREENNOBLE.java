//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;

@Module.Info(name = "Suffix-Noble-Green", category = Module.Category.CHAT, description = "Modifies your chat messages")
public class GREENNOBLE extends Module
{
    private Setting<Boolean> commands;
    @EventHandler
    public Listener<PacketEvent.Send> listener;
    private final String NOBLE_SUFFIX = " &a> \u0274\u1d0f\u0299\u029f\u1d07s\u026ax.\u0274\u1d07\u1d1b ";
    
    public GREENNOBLE() {
        this.commands = (Setting<Boolean>)this.register((Setting)Settings.b("Commands", false));
        this.listener = new Listener<PacketEvent.Send>(this::lambda$new$0, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
    
    private void lambda$new$0(final PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketChatMessage) {
            final String getMessage = ((CPacketChatMessage)send.getPacket()).getMessage();
            if (getMessage.startsWith("/") && !this.commands.getValue()) {
                return;
            }
            String message = String.valueOf(new StringBuilder().append(getMessage).append(" &a> \u0274\u1d0f\u0299\u029f\u1d07s\u026ax.\u0274\u1d07\u1d1b "));
            if (message.length() >= 256) {
                message = message.substring(0, 256);
            }
            ((CPacketChatMessage)send.getPacket()).message = message;
        }
    }
}
