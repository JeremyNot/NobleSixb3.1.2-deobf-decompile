//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import java.util.concurrent.*;
import me.noble.client.event.events.*;
import me.noble.client.util.*;
import java.util.function.*;
import me.noble.client.module.modules.combat.*;
import me.noble.client.module.*;
import net.minecraft.init.*;
import net.minecraft.util.math.*;
import java.util.*;
import net.minecraft.block.*;
import java.awt.*;
import me.noble.client.setting.*;

@Module.Info(name = "HoleESP", category = Module.Category.RENDER, description = "Show safe holes for crystal pvp")
public class HoleESP extends Module
{
    private ConcurrentHashMap<BlockPos, Boolean> safeHoles;
    private Setting<Integer> g2;
    private Setting<Integer> r1;
    private Setting<RenderBlocks> renderBlocksSetting;
    private Setting<Integer> r2;
    private Setting<Integer> b1;
    private final BlockPos[] surroundOffset;
    private Setting<Integer> b2;
    private Setting<Double> renderDistance;
    private Setting<RenderMode> renderModeSetting;
    private Setting<Integer> g1;
    private Setting<Integer> a0;
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (HoleESP.mc.player == null || this.safeHoles == null) {
            return;
        }
        if (this.safeHoles.isEmpty()) {
            return;
        }
        KamiTessellator.prepare(7);
        this.safeHoles.forEach(this::lambda$onWorldRender$0);
        KamiTessellator.release();
    }
    
    public void onUpdate() {
        if (this.safeHoles == null) {
            this.safeHoles = new ConcurrentHashMap<BlockPos, Boolean>();
        }
        else {
            this.safeHoles.clear();
        }
        final int n = (int)Math.ceil(this.renderDistance.getValue());
        for (final BlockPos blockPos : ((CrystalAura)ModuleManager.getModuleByName("CrystalAura")).getSphere(CrystalAura.getPlayerPos(), (float)n, n, false, true, 0)) {
            if (!HoleESP.mc.world.getBlockState(blockPos).getBlock().equals(Blocks.AIR)) {
                continue;
            }
            if (!HoleESP.mc.world.getBlockState(blockPos.add(0, 1, 0)).getBlock().equals(Blocks.AIR)) {
                continue;
            }
            if (!HoleESP.mc.world.getBlockState(blockPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
                continue;
            }
            boolean b = true;
            boolean b2 = true;
            final BlockPos[] surroundOffset = this.surroundOffset;
            for (int length = surroundOffset.length, i = 0; i < length; ++i) {
                final Block getBlock = HoleESP.mc.world.getBlockState(blockPos.add((Vec3i)surroundOffset[i])).getBlock();
                if (getBlock != Blocks.BEDROCK) {
                    b2 = false;
                }
                if (getBlock != Blocks.BEDROCK && getBlock != Blocks.OBSIDIAN && getBlock != Blocks.ENDER_CHEST && getBlock != Blocks.ANVIL) {
                    b = false;
                    break;
                }
            }
            if (!b) {
                continue;
            }
            this.safeHoles.put(blockPos, b2);
        }
    }
    
    private void lambda$onWorldRender$0(final BlockPos blockPos, final Boolean b) {
        switch (this.renderBlocksSetting.getValue()) {
            case BOTH: {
                if (b) {
                    this.drawBox(blockPos, this.r2.getValue(), this.g2.getValue(), this.b2.getValue());
                    break;
                }
                this.drawBox(blockPos, this.r1.getValue(), this.g1.getValue(), this.b1.getValue());
                break;
            }
            case OBBY: {
                if (!b) {
                    this.drawBox(blockPos, this.r1.getValue(), this.g1.getValue(), this.b1.getValue());
                    break;
                }
                break;
            }
            case BEDROCK: {
                if (b) {
                    this.drawBox(blockPos, this.r2.getValue(), this.g2.getValue(), this.b2.getValue());
                    break;
                }
                break;
            }
        }
    }
    
    private void drawBox(final BlockPos blockPos, final int n, final int n2, final int n3) {
        final Color color = new Color(n, n2, n3, this.a0.getValue());
        if (this.renderModeSetting.getValue().equals(RenderMode.DOWN)) {
            KamiTessellator.drawBox(blockPos, color.getRGB(), 1);
        }
        else if (this.renderModeSetting.getValue().equals(RenderMode.BLOCK)) {
            KamiTessellator.drawBox(blockPos, color.getRGB(), 63);
        }
    }
    
    public HoleESP() {
        this.surroundOffset = new BlockPos[] { new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(-1, 0, 0) };
        this.renderDistance = (Setting<Double>)this.register((Setting)Settings.d("Render Distance", 8.0));
        this.a0 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Transparency").withMinimum(0).withValue(32).withMaximum(255).build());
        this.r1 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Red (Obby)").withMinimum(0).withValue(208).withMaximum(255).build());
        this.g1 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Green (Obby)").withMinimum(0).withValue(144).withMaximum(255).build());
        this.b1 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Blue (Obby)").withMinimum(0).withValue(255).withMaximum(255).build());
        this.r2 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Red (Bedrock)").withMinimum(0).withValue(144).withMaximum(255).build());
        this.g2 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Green (Bedrock)").withMinimum(0).withValue(144).withMaximum(255).build());
        this.b2 = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Blue (Bedrock)").withMinimum(0).withValue(255).withMaximum(255).build());
        this.renderModeSetting = (Setting<RenderMode>)this.register((Setting)Settings.e("Render Mode", RenderMode.BLOCK));
        this.renderBlocksSetting = (Setting<RenderBlocks>)this.register((Setting)Settings.e("Render", RenderBlocks.BOTH));
    }
    
    private enum RenderMode
    {
        BLOCK;
        
        private static final RenderMode[] $VALUES;
        
        DOWN;
        
        static {
            $VALUES = new RenderMode[] { RenderMode.DOWN, RenderMode.BLOCK };
        }
    }
    
    private enum RenderBlocks
    {
        OBBY;
        
        private static final RenderBlocks[] $VALUES;
        
        BEDROCK, 
        BOTH;
        
        static {
            $VALUES = new RenderBlocks[] { RenderBlocks.OBBY, RenderBlocks.BEDROCK, RenderBlocks.BOTH };
        }
    }
}
