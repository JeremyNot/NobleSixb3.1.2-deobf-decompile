//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import java.util.*;
import me.noble.client.setting.*;
import java.util.function.*;

@Module.Info(name = "FullBright", description = "Makes everything brighter!", category = Module.Category.RENDER)
public class Brightness extends Module
{
    private Setting<Boolean> transition;
    private static boolean inTransition;
    private Setting<Transition> mode;
    private Stack<Float> transitionStack;
    private static float currentBrightness;
    private Setting<Float> seconds;
    
    protected void onDisable() {
        this.setAlwaysListening(true);
        super.onDisable();
        this.addTransition(false);
    }
    
    private float sine(final float n) {
        return ((float)Math.sin(3.141592653589793 * n - 1.5707963267948966) + 1.0f) / 2.0f;
    }
    
    public Brightness() {
        this.transition = (Setting<Boolean>)this.register((Setting)Settings.b("Transition", true));
        this.seconds = (Setting<Float>)this.register((Setting)Settings.floatBuilder("Seconds").withMinimum(0.0f).withMaximum(10.0f).withValue(5.0f).withVisibility(this::lambda$new$0).build());
        this.mode = (Setting<Transition>)this.register((Setting)Settings.enumBuilder(Transition.class).withName("Mode").withValue(Transition.SINE).withVisibility(this::lambda$new$1).build());
        this.transitionStack = new Stack<Float>();
    }
    
    private float[] sine(final int n, final boolean b) {
        return this.createTransition(n, b, this::sine);
    }
    
    private float[] createTransition(final int n, final boolean b, final Function<Float, Float> function) {
        final float[] array = new float[n];
        for (int i = 0; i < n; ++i) {
            float floatValue = function.apply(i / (float)n);
            if (b) {
                floatValue = 1.0f - floatValue;
            }
            array[i] = floatValue;
        }
        return array;
    }
    
    public static float getCurrentBrightness() {
        return Brightness.currentBrightness;
    }
    
    private void addTransition(final boolean b) {
        if (this.transition.getValue()) {
            final int n = (int)(this.seconds.getValue() * 20.0f);
            float[] array = null;
            switch (this.mode.getValue()) {
                case LINEAR: {
                    array = this.linear(n, b);
                    break;
                }
                case SINE: {
                    array = this.sine(n, b);
                    break;
                }
                default: {
                    array = new float[] { 0.0f };
                    break;
                }
            }
            final float[] array2 = array;
            for (int length = array2.length, i = 0; i < length; ++i) {
                this.transitionStack.add(array2[i]);
            }
            Brightness.inTransition = true;
        }
    }
    
    private float[] linear(final int n, final boolean b) {
        return this.createTransition(n, b, Brightness::lambda$linear$2);
    }
    
    public static boolean isInTransition() {
        return Brightness.inTransition;
    }
    
    private boolean lambda$new$1(final Object o) {
        return this.transition.getValue();
    }
    
    public void onUpdate() {
        if (Brightness.inTransition) {
            if (this.transitionStack.isEmpty()) {
                this.setAlwaysListening(Brightness.inTransition = false);
                Brightness.currentBrightness = (this.isEnabled() ? 1.0f : 0.0f);
            }
            else {
                Brightness.currentBrightness = this.transitionStack.pop();
            }
        }
    }
    
    public static boolean shouldBeActive() {
        return isInTransition() || Brightness.currentBrightness == 1.0f;
    }
    
    protected void onEnable() {
        super.onEnable();
        this.addTransition(true);
    }
    
    private boolean lambda$new$0(final Float n) {
        return this.transition.getValue();
    }
    
    private static Float lambda$linear$2(final Float n) {
        return n;
    }
    
    static {
        Brightness.currentBrightness = 0.0f;
        Brightness.inTransition = false;
    }
    
    public enum Transition
    {
        private static final Transition[] $VALUES;
        
        LINEAR, 
        SINE;
        
        static {
            $VALUES = new Transition[] { Transition.LINEAR, Transition.SINE };
        }
    }
}
