//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;
import net.minecraft.item.*;
import me.noble.client.util.*;
import java.util.*;
import me.noble.client.setting.*;
import net.minecraft.client.*;
import net.minecraft.util.*;
import net.minecraft.world.*;

@Module.Info(name = "ArmourHUD", category = Module.Category.GUI, showOnArray = Module.ShowOnArray.OFF, description = "Displays your armour and it's durability on screen")
public class ArmourHUD extends Module
{
    private Setting<Boolean> damage;
    private static RenderItem itemRender;
    
    public void onRender() {
        GlStateManager.enableTexture2D();
        final ScaledResolution scaledResolution = new ScaledResolution(ArmourHUD.mc);
        final int n = scaledResolution.getScaledWidth() / 2;
        int n2 = 0;
        final int n3 = scaledResolution.getScaledHeight() - 55 - (ArmourHUD.mc.player.isInWater() ? 10 : 0);
        for (final ItemStack itemStack : this.getArmour()) {
            ++n2;
            if (itemStack.func_190926_b()) {
                continue;
            }
            final int n4 = n - 90 + (9 - n2) * 20 + 2;
            GlStateManager.enableDepth();
            ArmourHUD.itemRender.zLevel = 200.0f;
            ArmourHUD.itemRender.renderItemAndEffectIntoGUI(itemStack, n4, n3);
            ArmourHUD.itemRender.renderItemOverlayIntoGUI(ArmourHUD.mc.fontRendererObj, itemStack, n4, n3, "");
            ArmourHUD.itemRender.zLevel = 0.0f;
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            final String s = (itemStack.func_190916_E() > 1) ? String.valueOf(new StringBuilder().append(itemStack.func_190916_E()).append("")) : "";
            ArmourHUD.mc.fontRendererObj.drawStringWithShadow(s, (float)(n4 + 19 - 2 - ArmourHUD.mc.fontRendererObj.getStringWidth(s)), (float)(n3 + 9), 16777215);
            if (!this.damage.getValue()) {
                continue;
            }
            final float n5 = (itemStack.getMaxDamage() - (float)itemStack.getItemDamage()) / itemStack.getMaxDamage();
            final float n6 = 1.0f - n5;
            final int n7 = 100 - (int)(n6 * 100.0f);
            ArmourHUD.mc.fontRendererObj.drawStringWithShadow(String.valueOf(new StringBuilder().append(n7).append("")), (float)(n4 + 8 - ArmourHUD.mc.fontRendererObj.getStringWidth(String.valueOf(new StringBuilder().append(n7).append(""))) / 2), (float)(n3 - 11), ColourHolder.toHex((int)(n6 * 255.0f), (int)(n5 * 255.0f), 0));
        }
        GlStateManager.enableDepth();
        GlStateManager.disableLighting();
    }
    
    public ArmourHUD() {
        this.damage = (Setting<Boolean>)this.register((Setting)Settings.b("Damage", false));
    }
    
    static {
        ArmourHUD.itemRender = Minecraft.getMinecraft().getRenderItem();
    }
    
    private NonNullList<ItemStack> getArmour() {
        if (ArmourHUD.mc.playerController.getCurrentGameType().equals((Object)GameType.CREATIVE) || ArmourHUD.mc.playerController.getCurrentGameType().equals((Object)GameType.SPECTATOR)) {
            return (NonNullList<ItemStack>)NonNullList.func_191197_a(4, (Object)ItemStack.field_190927_a);
        }
        return (NonNullList<ItemStack>)ArmourHUD.mc.player.inventory.armorInventory;
    }
}
