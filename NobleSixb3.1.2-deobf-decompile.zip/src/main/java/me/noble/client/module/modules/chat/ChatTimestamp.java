//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.noble.client.module.*;
import me.noble.client.util.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.util.text.*;
import me.noble.client.command.*;
import net.minecraft.network.play.server.*;

@Module.Info(name = "ChatTimestamp", category = Module.Category.CHAT, description = "Shows the time a message was sent beside the message", showOnArray = Module.ShowOnArray.OFF)
public class ChatTimestamp extends Module
{
    private Setting<TimeUtil.TimeType> timeTypeSetting;
    private Setting<Boolean> doLocale;
    private Setting<ColourUtils.ColourCode> secondColour;
    @EventHandler
    public Listener<PacketEvent.Receive> listener;
    private Setting<ColourUtils.ColourCode> firstColour;
    private Setting<TimeUtil.TimeUnit> timeUnitSetting;
    
    public ChatTimestamp() {
        this.firstColour = (Setting<ColourUtils.ColourCode>)this.register((Setting)Settings.e("First Colour", ColourUtils.ColourCode.GREY));
        this.secondColour = (Setting<ColourUtils.ColourCode>)this.register((Setting)Settings.e("Second Colour", ColourUtils.ColourCode.WHITE));
        this.timeTypeSetting = (Setting<TimeUtil.TimeType>)this.register((Setting)Settings.e("Time Format", TimeUtil.TimeType.HHMM));
        this.timeUnitSetting = (Setting<TimeUtil.TimeUnit>)this.register((Setting)Settings.e("Time Unit", TimeUtil.TimeUnit.h12));
        this.doLocale = (Setting<Boolean>)this.register((Setting)Settings.b("Show AMPM", true));
        this.listener = new Listener<PacketEvent.Receive>(this::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    private boolean addTime(final String s) {
        Command.sendRawChatMessage(String.valueOf(new StringBuilder().append("<").append(TimeUtil.getFinalTime(this.secondColour.getValue(), this.firstColour.getValue(), this.timeUnitSetting.getValue(), this.timeTypeSetting.getValue(), this.doLocale.getValue())).append(TextFormatting.RESET).append("> ").append(s)));
        return true;
    }
    
    private void lambda$new$0(final PacketEvent.Receive receive) {
        if (ChatTimestamp.mc.player == null || this.isDisabled()) {
            return;
        }
        if (!(receive.getPacket() instanceof SPacketChat)) {
            return;
        }
        if (this.addTime(((SPacketChat)receive.getPacket()).getChatComponent().getUnformattedText())) {
            receive.cancel();
        }
    }
}
