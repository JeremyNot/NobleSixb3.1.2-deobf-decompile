//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.gui;

import me.noble.client.module.*;
import java.util.*;
import me.noble.client.*;
import me.noble.client.util.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import net.minecraft.util.text.*;
import me.noble.client.setting.*;
import me.noble.client.module.modules.movement.*;

@Module.Info(name = "InfoOverlay", category = Module.Category.GUI, description = "Configures the game information overlay", showOnArray = Module.ShowOnArray.OFF)
public class InfoOverlay extends Module
{
    private Setting<Boolean> timerSpeed;
    private Setting<ColourUtils.ColourCode> secondColour;
    private Setting<Boolean> ping;
    private Setting<Boolean> version;
    private Setting<Boolean> fps;
    private Setting<Boolean> durability;
    private Setting<Boolean> tps;
    private Setting<Boolean> memory;
    private Setting<TimeUtil.TimeUnit> timeUnitSetting;
    private Setting<Boolean> username;
    private Setting<SpeedUnit> speedUnit;
    private Setting<Boolean> speed;
    private Setting<Boolean> time;
    private Setting<ColourUtils.ColourCode> firstColour;
    private Setting<Boolean> doLocale;
    private Setting<TimeUtil.TimeType> timeTypeSetting;
    
    public ArrayList<String> infoContents() {
        final ArrayList<String> list = new ArrayList<String>();
        if (this.version.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(NobleMod.KAMI_KANJI).append(this.textColour(this.secondColour.getValue())).append(" ").append(NobleMod.MODVER)));
        }
        if (this.username.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append("Welcome").append(this.textColour(this.secondColour.getValue())).append(" ").append(InfoOverlay.mc.getSession().getUsername()).append("!")));
            Display.setTitle(String.valueOf(new StringBuilder().append("NobleSix ").append(NobleMod.MODVER).append(" - Welcome : ").append(InfoOverlay.mc.getSession().getUsername()).append(" - TPS:").append(InfoCalculator.tps()).append("  FPS:").append(Minecraft.debugFPS).append("  Ping:").append(InfoCalculator.ping()).append(" ms")));
        }
        if (this.time.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(TimeUtil.getFinalTime(this.secondColour.getValue(), this.firstColour.getValue(), this.timeUnitSetting.getValue(), this.timeTypeSetting.getValue(), this.doLocale.getValue())).append(TextFormatting.RESET)));
        }
        if (this.tps.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(InfoCalculator.tps()).append(this.textColour(this.secondColour.getValue())).append(" tps")));
        }
        if (this.fps.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(Minecraft.debugFPS).append(this.textColour(this.secondColour.getValue())).append(" fps")));
        }
        if (this.speed.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(InfoCalculator.speed()).append(this.textColour(this.secondColour.getValue())).append(" ").append(this.unitType(this.speedUnit.getValue()))));
        }
        if (this.timerSpeed.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(this.formatTimerSpeed()).append(this.textColour(this.secondColour.getValue())).append("t")));
        }
        if (this.ping.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(InfoCalculator.ping()).append(this.textColour(this.secondColour.getValue())).append(" ms")));
        }
        if (this.durability.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(InfoCalculator.dura()).append(this.textColour(this.secondColour.getValue())).append(" dura")));
        }
        if (this.memory.getValue()) {
            list.add(String.valueOf(new StringBuilder().append(this.textColour(this.firstColour.getValue())).append(InfoCalculator.memory()).append(this.textColour(this.secondColour.getValue())).append("mB free")));
        }
        return list;
    }
    
    public InfoOverlay() {
        this.version = (Setting<Boolean>)this.register((Setting)Settings.b("Version", true));
        this.username = (Setting<Boolean>)this.register((Setting)Settings.b("Username", true));
        this.time = (Setting<Boolean>)this.register((Setting)Settings.b("Time", true));
        this.tps = (Setting<Boolean>)this.register((Setting)Settings.b("Ticks Per Second", false));
        this.fps = (Setting<Boolean>)this.register((Setting)Settings.b("Frames Per Second", true));
        this.speed = (Setting<Boolean>)this.register((Setting)Settings.b("Speed", true));
        this.timerSpeed = (Setting<Boolean>)this.register((Setting)Settings.b("Timer Speed", false));
        this.ping = (Setting<Boolean>)this.register((Setting)Settings.b("Latency", false));
        this.durability = (Setting<Boolean>)this.register((Setting)Settings.b("Item Damage", false));
        this.memory = (Setting<Boolean>)this.register((Setting)Settings.b("Memory Used", false));
        this.speedUnit = (Setting<SpeedUnit>)this.register((Setting)Settings.e("Speed Unit", SpeedUnit.KmH));
        this.firstColour = (Setting<ColourUtils.ColourCode>)this.register((Setting)Settings.e("First Colour", ColourUtils.ColourCode.WHITE));
        this.secondColour = (Setting<ColourUtils.ColourCode>)this.register((Setting)Settings.e("Second Colour", ColourUtils.ColourCode.BLUE));
        this.timeTypeSetting = (Setting<TimeUtil.TimeType>)this.register((Setting)Settings.e("Time Format", TimeUtil.TimeType.HHMMSS));
        this.timeUnitSetting = (Setting<TimeUtil.TimeUnit>)this.register((Setting)Settings.e("Time Unit", TimeUtil.TimeUnit.h12));
        this.doLocale = (Setting<Boolean>)this.register((Setting)Settings.b("Time Show AMPM", true));
    }
    
    public boolean useUnitKmH() {
        return this.speedUnit.getValue().equals(SpeedUnit.KmH);
    }
    
    private String formatTimerSpeed() {
        return TimerSpeed.returnGui().replace(".", String.valueOf(new StringBuilder().append(this.textColour(this.secondColour.getValue())).append(".").append(this.textColour(this.firstColour.getValue()))));
    }
    
    public String textColour(final ColourUtils.ColourCode colourCode) {
        return ColourUtils.getStringColour(colourCode);
    }
    
    private String unitType(final SpeedUnit speedUnit) {
        switch (speedUnit) {
            case MpS: {
                return "m/s";
            }
            case KmH: {
                return "km/h";
            }
            default: {
                return "Invalid unit type (mps or kmh)";
            }
        }
    }
    
    public void onDisable() {
        this.enable();
    }
    
    private enum SpeedUnit
    {
        KmH, 
        MpS;
        
        private static final SpeedUnit[] $VALUES;
        
        static {
            $VALUES = new SpeedUnit[] { SpeedUnit.MpS, SpeedUnit.KmH };
        }
    }
}
