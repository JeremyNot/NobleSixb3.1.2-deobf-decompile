//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import me.noble.client.setting.*;
import net.minecraft.client.network.*;
import net.minecraft.scoreboard.*;
import me.noble.client.util.*;
import me.noble.client.*;

@Module.Info(name = "TabFriends", description = "Highlights friends in the tab menu", category = Module.Category.GUI, showOnArray = Module.ShowOnArray.OFF)
public class TabFriends extends Module
{
    public Setting<Boolean> startupGlobal;
    public static TabFriends INSTANCE;
    
    public TabFriends() {
        this.startupGlobal = (Setting<Boolean>)this.register((Setting)Settings.b("Enable Automatically", true));
        TabFriends.INSTANCE = this;
    }
    
    public static String getPlayerName(final NetworkPlayerInfo networkPlayerInfo) {
        final String s = (networkPlayerInfo.getDisplayName() != null) ? networkPlayerInfo.getDisplayName().getFormattedText() : ScorePlayerTeam.formatPlayerName((Team)networkPlayerInfo.getPlayerTeam(), networkPlayerInfo.getGameProfile().getName());
        if (Friends.isFriend(s)) {
            return String.format("%sa%s", NobleMod.colour, s);
        }
        return s;
    }
}
