//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.module.*;
import net.minecraft.init.*;
import net.minecraft.enchantment.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;

@Module.Info(name = "Pull32k", category = Module.Category.COMBAT, description = "Pulls 32ks out of hoppers automatically")
public class Pull32k extends Module
{
    boolean foundsword;
    
    public Pull32k() {
        this.foundsword = false;
    }
    
    public void onUpdate() {
        boolean b = false;
        int currentItem = -1;
        for (int i = 0; i < 9; ++i) {
            if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, (ItemStack)Pull32k.mc.player.inventory.mainInventory.get(i)) >= 32767) {
                currentItem = i;
                this.foundsword = true;
            }
            if (!this.foundsword) {
                currentItem = -1;
                this.foundsword = false;
            }
        }
        if (currentItem != -1 && Pull32k.mc.player.inventory.currentItem != currentItem) {
            Pull32k.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(currentItem));
            Pull32k.mc.player.inventory.currentItem = currentItem;
            Pull32k.mc.playerController.updateController();
        }
        if (currentItem == -1 && Pull32k.mc.player.openContainer != null && Pull32k.mc.player.openContainer instanceof ContainerHopper && Pull32k.mc.player.openContainer.inventorySlots != null && !Pull32k.mc.player.openContainer.inventorySlots.isEmpty()) {
            for (int j = 0; j < 5; ++j) {
                if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, Pull32k.mc.player.openContainer.inventorySlots.get(0).inventory.getStackInSlot(j)) >= 32767) {
                    currentItem = j;
                    break;
                }
            }
            if (currentItem == -1) {
                return;
            }
            if (currentItem != -1) {
                for (int k = 0; k < 9; ++k) {
                    if (((ItemStack)Pull32k.mc.player.inventory.mainInventory.get(k)).getItem() instanceof ItemAir) {
                        if (Pull32k.mc.player.inventory.currentItem != k) {
                            Pull32k.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(k));
                            Pull32k.mc.player.inventory.currentItem = k;
                            Pull32k.mc.playerController.updateController();
                        }
                        b = true;
                        break;
                    }
                }
            }
            if (b || this.checkStuff()) {
                Pull32k.mc.playerController.windowClick(Pull32k.mc.player.openContainer.windowId, currentItem, Pull32k.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)Pull32k.mc.player);
            }
        }
    }
    
    public boolean checkStuff() {
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, Pull32k.mc.player.inventory.getCurrentItem()) == 5;
    }
}
