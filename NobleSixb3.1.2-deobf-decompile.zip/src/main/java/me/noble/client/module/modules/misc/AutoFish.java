//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.network.play.server.*;
import java.util.function.*;

@Module.Info(name = "AutoFish", category = Module.Category.MISC, description = "Automatically catch fish")
public class AutoFish extends Module
{
    @EventHandler
    private Listener<PacketEvent.Receive> receiveListener;
    
    private void lambda$new$1(final PacketEvent.Receive receive) {
        if (receive.getPacket() instanceof SPacketSoundEffect) {
            final SPacketSoundEffect sPacketSoundEffect = (SPacketSoundEffect)receive.getPacket();
            if (sPacketSoundEffect.getSound().getSoundName().toString().toLowerCase().contains("entity.bobber.splash")) {
                if (AutoFish.mc.player.fishEntity == null) {
                    return;
                }
                final int n = (int)sPacketSoundEffect.getX();
                final int n2 = (int)sPacketSoundEffect.getZ();
                final int n3 = (int)AutoFish.mc.player.fishEntity.posX;
                final int n4 = (int)AutoFish.mc.player.fishEntity.posZ;
                if (this.kindaEquals(n, n3) && this.kindaEquals(n4, n2)) {
                    new Thread(AutoFish::lambda$null$0).start();
                }
            }
        }
    }
    
    public AutoFish() {
        this.receiveListener = new Listener<PacketEvent.Receive>(this::lambda$new$1, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
    }
    
    private static void lambda$null$0() {
        AutoFish.mc.rightClickMouse();
        try {
            Thread.sleep(1000L);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        AutoFish.mc.rightClickMouse();
    }
    
    public boolean kindaEquals(final int n, final int n2) {
        return n2 == n || n2 == n - 1 || n2 == n + 1;
    }
}
