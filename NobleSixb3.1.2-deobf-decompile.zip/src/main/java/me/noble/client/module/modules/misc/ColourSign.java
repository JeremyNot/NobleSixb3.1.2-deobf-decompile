//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import me.noble.client.module.*;
import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import net.minecraft.client.gui.inventory.*;
import java.util.function.*;
import net.minecraft.client.gui.*;
import me.noble.client.*;
import java.io.*;
import net.minecraft.tileentity.*;
import net.minecraft.util.text.*;

@Module.Info(name = "ColourSign", description = "Allows ingame colouring of text on signs", category = Module.Category.MISC)
public class ColourSign extends Module
{
    @EventHandler
    public Listener<GuiScreenEvent.Displayed> eventListener;
    
    private void lambda$new$0(final GuiScreenEvent.Displayed displayed) {
        if (displayed.getScreen() instanceof GuiEditSign && this.isEnabled()) {
            displayed.setScreen((GuiScreen)new KamiGuiEditSign(((GuiEditSign)displayed.getScreen()).tileSign));
        }
    }
    
    public ColourSign() {
        this.eventListener = new Listener<GuiScreenEvent.Displayed>(this::lambda$new$0, (Predicate<GuiScreenEvent.Displayed>[])new Predicate[0]);
    }
    
    private class KamiGuiEditSign extends GuiEditSign
    {
        final ColourSign this$0;
        
        protected void actionPerformed(final GuiButton guiButton) throws IOException {
            if (guiButton.id == 0) {
                this.tileSign.signText[this.editLine] = (ITextComponent)new TextComponentString(this.tileSign.signText[this.editLine].getFormattedText().replaceAll(String.valueOf(new StringBuilder().append("(").append(NobleMod.colour).append(")(.)")), "$1$1$2$2"));
            }
            super.actionPerformed(guiButton);
        }
        
        protected void keyTyped(final char c, final int n) throws IOException {
            super.keyTyped(c, n);
            this.tileSign.signText[this.editLine] = (ITextComponent)new TextComponentString(((TextComponentString)this.tileSign.signText[this.editLine]).getText().replace("&", String.valueOf(new StringBuilder().append(NobleMod.colour).append(""))));
        }
        
        public void initGui() {
            super.initGui();
        }
        
        public KamiGuiEditSign(final ColourSign this$0, final TileEntitySign tileEntitySign) {
            this.this$0 = this$0;
            super(tileEntitySign);
        }
    }
}
