//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.combat;

import me.noble.client.command.*;
import net.minecraft.network.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import me.noble.client.module.modules.player.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import me.noble.client.setting.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;

@Module.Info(name = "Surround", category = Module.Category.COMBAT, description = "Surrounds you with obsidian to take less damage")
public class Surround extends Module
{
    private Setting<AutoCenter> autoCenter;
    private Vec3d playerPos;
    private int playerHotbarSlot;
    private BlockPos basePos;
    private Setting<Double> blockPerTick;
    private Setting<Boolean> autoDisable;
    private Setting<Boolean> spoofHotbar;
    private int lastHotbarSlot;
    private final Vec3d[] surroundTargets;
    private Setting<DebugMsgs> debugMsgs;
    private Setting<Boolean> spoofRotations;
    private int offsetStep;
    
    private void endLoop() {
        this.offsetStep = 0;
        if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
            Command.sendChatMessage("[Surround] Ending Loop");
        }
        if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround] Setting Slot back to  = ").append(this.playerHotbarSlot)));
            }
            if (this.spoofHotbar.getValue()) {
                Surround.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.playerHotbarSlot));
            }
            else {
                Wrapper.getPlayer().inventory.currentItem = this.playerHotbarSlot;
            }
            this.lastHotbarSlot = this.playerHotbarSlot;
        }
        if (this.autoDisable.getValue()) {
            this.disable();
        }
    }
    
    private static Vec3d getEyesPos() {
        return new Vec3d(Wrapper.getPlayer().posX, Wrapper.getPlayer().posY + Wrapper.getPlayer().getEyeHeight(), Wrapper.getPlayer().posZ);
    }
    
    double getDst(final Vec3d vec3d) {
        return this.playerPos.distanceTo(vec3d);
    }
    
    public static Block getBlock(final BlockPos blockPos) {
        return getState(blockPos).getBlock();
    }
    
    private void centerPlayer(final double n, final double n2, final double n3) {
        if (this.debugMsgs.getValue().equals(DebugMsgs.ALL) && this.playerPos != null) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround: AutoCenter] Player position is ").append(this.playerPos.toString())));
        }
        else if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
            Command.sendChatMessage("[Surround: AutoCenter] Player position is null");
        }
        Surround.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(n, n2, n3, true));
        Surround.mc.player.setPosition(n, n2, n3);
    }
    
    private void placeBlock(final BlockPos blockPos) {
        if (!Wrapper.getWorld().getBlockState(blockPos).getMaterial().isReplaceable()) {
            if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                Command.sendChatMessage("[Surround] Block is already placed, skipping");
            }
        }
        else if (!BlockInteractionHelper.checkForNeighbours(blockPos) && this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
            Command.sendChatMessage("[Surround] !checkForNeighbours(blockPos), disabling! ");
        }
        else {
            Surround.mc.player.connection.sendPacket((Packet)new CPacketAnimation(Surround.mc.player.getActiveHand()));
            this.placeBlockExecute(blockPos);
        }
        if (ModuleManager.getModuleByName("NoBreakAnimation").isEnabled()) {
            ((NoBreakAnimation)ModuleManager.getModuleByName("NoBreakAnimation")).resetMining();
        }
    }
    
    private static void faceVectorPacketInstant(final Vec3d vec3d) {
        final float[] legitRotations = getLegitRotations(vec3d);
        Wrapper.getPlayer().connection.sendPacket((Packet)new CPacketPlayer.Rotation(legitRotations[0], legitRotations[1], Wrapper.getPlayer().onGround));
    }
    
    private int findObiInHotbar() {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack getStackInSlot = Wrapper.getPlayer().inventory.getStackInSlot(i);
            if (getStackInSlot != ItemStack.field_190927_a && getStackInSlot.getItem() instanceof ItemBlock && ((ItemBlock)getStackInSlot.getItem()).getBlock() instanceof BlockObsidian) {
                n = i;
                break;
            }
        }
        return n;
    }
    
    private static float[] getLegitRotations(final Vec3d vec3d) {
        final Vec3d eyesPos = getEyesPos();
        final double n = vec3d.xCoord - eyesPos.xCoord;
        final double n2 = vec3d.yCoord - eyesPos.yCoord;
        final double n3 = vec3d.zCoord - eyesPos.zCoord;
        return new float[] { Wrapper.getPlayer().rotationYaw + MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2(n3, n)) - 90.0f - Wrapper.getPlayer().rotationYaw), Wrapper.getPlayer().rotationPitch + MathHelper.wrapDegrees((float)(-Math.toDegrees(Math.atan2(n2, Math.sqrt(n * n + n3 * n3)))) - Wrapper.getPlayer().rotationPitch) };
    }
    
    public void onUpdate() {
        if (!this.isDisabled() && Surround.mc.player != null && !ModuleManager.isModuleEnabled("Freecam")) {
            if (this.offsetStep == 0) {
                this.basePos = new BlockPos(Surround.mc.player.getPositionVector()).down();
                this.playerHotbarSlot = Wrapper.getPlayer().inventory.currentItem;
                if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround] Starting Loop, current Player Slot: ").append(this.playerHotbarSlot)));
                }
                if (!this.spoofHotbar.getValue()) {
                    this.lastHotbarSlot = Surround.mc.player.inventory.currentItem;
                }
            }
            for (int i = 0; i < (int)Math.floor(this.blockPerTick.getValue()); ++i) {
                if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                    Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround] Loop iteration: ").append(this.offsetStep)));
                }
                if (this.offsetStep >= this.surroundTargets.length) {
                    this.endLoop();
                    return;
                }
                final Vec3d vec3d = this.surroundTargets[this.offsetStep];
                this.placeBlock(new BlockPos((Vec3i)this.basePos.add(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord)));
                ++this.offsetStep;
            }
        }
    }
    
    private static IBlockState getState(final BlockPos blockPos) {
        return Wrapper.getWorld().getBlockState(blockPos);
    }
    
    private static boolean canBeClicked(final BlockPos blockPos) {
        return getBlock(blockPos).canCollideCheck(getState(blockPos), false);
    }
    
    public void onDisable() {
        if (Surround.mc.player != null) {
            if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                Command.sendChatMessage("[Surround] Disabling");
            }
            if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                if (this.spoofHotbar.getValue()) {
                    Surround.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.playerHotbarSlot));
                }
                else {
                    Wrapper.getPlayer().inventory.currentItem = this.playerHotbarSlot;
                }
            }
            this.playerHotbarSlot = -1;
            this.lastHotbarSlot = -1;
        }
    }
    
    public Surround() {
        this.autoDisable = (Setting<Boolean>)this.register((Setting)Settings.b("Disable on place", true));
        this.spoofRotations = (Setting<Boolean>)this.register((Setting)Settings.b("Spoof Rotations", true));
        this.spoofHotbar = (Setting<Boolean>)this.register((Setting)Settings.b("Spoof Hotbar", true));
        this.blockPerTick = (Setting<Double>)this.register((Setting)Settings.doubleBuilder("Blocks per Tick").withMinimum(1.0).withValue(4.0).withMaximum(10.0).build());
        this.debugMsgs = (Setting<DebugMsgs>)this.register((Setting)Settings.e("Debug Messages", DebugMsgs.IMPORTANT));
        this.autoCenter = (Setting<AutoCenter>)this.register((Setting)Settings.e("Auto Center", AutoCenter.TP));
        this.surroundTargets = new Vec3d[] { new Vec3d(0.0, 0.0, 0.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, -1.0) };
        this.offsetStep = 0;
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
    }
    
    public void onEnable() {
        if (Surround.mc.player == null) {
            return;
        }
        final BlockPos getPosition = Surround.mc.player.getPosition();
        this.playerPos = Surround.mc.player.getPositionVector();
        final double n = getPosition.getY();
        final double n2 = getPosition.getX();
        final double n3 = getPosition.getZ();
        final Vec3d vec3d = new Vec3d(n2 + 0.5, n, n3 + 0.5);
        final Vec3d vec3d2 = new Vec3d(n2 + 0.5, n, n3 - 0.5);
        final Vec3d vec3d3 = new Vec3d(n2 - 0.5, n, n3 - 0.5);
        final Vec3d vec3d4 = new Vec3d(n2 - 0.5, n, n3 + 0.5);
        if (this.autoCenter.getValue().equals(AutoCenter.TP)) {
            if (this.getDst(vec3d) < this.getDst(vec3d2) && this.getDst(vec3d) < this.getDst(vec3d3) && this.getDst(vec3d) < this.getDst(vec3d4)) {
                this.centerPlayer(getPosition.getX() + 0.5, n, getPosition.getZ() + 0.5);
            }
            if (this.getDst(vec3d2) < this.getDst(vec3d) && this.getDst(vec3d2) < this.getDst(vec3d3) && this.getDst(vec3d2) < this.getDst(vec3d4)) {
                this.centerPlayer(getPosition.getX() + 0.5, n, getPosition.getZ() - 0.5);
            }
            if (this.getDst(vec3d3) < this.getDst(vec3d) && this.getDst(vec3d3) < this.getDst(vec3d2) && this.getDst(vec3d3) < this.getDst(vec3d4)) {
                this.centerPlayer(getPosition.getX() - 0.5, n, getPosition.getZ() - 0.5);
            }
            if (this.getDst(vec3d4) < this.getDst(vec3d) && this.getDst(vec3d4) < this.getDst(vec3d2) && this.getDst(vec3d4) < this.getDst(vec3d3)) {
                this.centerPlayer(getPosition.getX() - 0.5, n, getPosition.getZ() + 0.5);
            }
        }
        this.playerHotbarSlot = Wrapper.getPlayer().inventory.currentItem;
        this.lastHotbarSlot = -1;
        if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround] Saving initial Slot  = ").append(this.playerHotbarSlot)));
        }
    }
    
    public void placeBlockExecute(final BlockPos blockPos) {
        final Vec3d vec3d = new Vec3d(Wrapper.getPlayer().posX, Wrapper.getPlayer().posY + Wrapper.getPlayer().getEyeHeight(), Wrapper.getPlayer().posZ);
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            final EnumFacing getOpposite = enumFacing.getOpposite();
            if (!canBeClicked(offset)) {
                if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                    Command.sendChatMessage("[Surround] No neighbor to click at!");
                }
            }
            else {
                final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
                if (vec3d.squareDistanceTo(add) <= 18.0625) {
                    if (this.spoofRotations.getValue()) {
                        faceVectorPacketInstant(add);
                    }
                    boolean b = false;
                    final Block getBlock = Surround.mc.world.getBlockState(offset).getBlock();
                    if (BlockInteractionHelper.blackList.contains(getBlock) || BlockInteractionHelper.shulkerList.contains(getBlock)) {
                        if (this.debugMsgs.getValue().equals(DebugMsgs.IMPORTANT)) {
                            Command.sendChatMessage("[Surround] Sneak enabled!");
                        }
                        b = true;
                    }
                    if (b) {
                        Surround.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Surround.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    }
                    final int obiInHotbar = this.findObiInHotbar();
                    if (obiInHotbar == -1) {
                        if (this.debugMsgs.getValue().equals(DebugMsgs.IMPORTANT)) {
                            Command.sendChatMessage("[Surround] No obsidian in hotbar, disabling!");
                        }
                        this.disable();
                        return;
                    }
                    if (this.lastHotbarSlot != obiInHotbar) {
                        if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                            Command.sendChatMessage(String.valueOf(new StringBuilder().append("[Surround] Setting Slot to obsidian at  = ").append(obiInHotbar)));
                        }
                        if (this.spoofHotbar.getValue()) {
                            Surround.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(obiInHotbar));
                        }
                        else {
                            Wrapper.getPlayer().inventory.currentItem = obiInHotbar;
                        }
                        this.lastHotbarSlot = obiInHotbar;
                    }
                    Surround.mc.playerController.processRightClickBlock(Wrapper.getPlayer(), Surround.mc.world, offset, getOpposite, add, EnumHand.MAIN_HAND);
                    Surround.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
                    if (b) {
                        if (this.debugMsgs.getValue().equals(DebugMsgs.IMPORTANT)) {
                            Command.sendChatMessage("[Surround] Sneak disabled!");
                        }
                        Surround.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)Surround.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                    }
                    return;
                }
                else if (this.debugMsgs.getValue().equals(DebugMsgs.ALL)) {
                    Command.sendChatMessage("[Surround] Distance > 4.25 blocks!");
                }
            }
        }
    }
    
    private enum AutoCenter
    {
        private static final AutoCenter[] $VALUES;
        
        OFF, 
        TP;
        
        static {
            $VALUES = new AutoCenter[] { AutoCenter.OFF, AutoCenter.TP };
        }
    }
    
    private enum DebugMsgs
    {
        IMPORTANT, 
        NONE;
        
        private static final DebugMsgs[] $VALUES;
        
        ALL;
        
        static {
            $VALUES = new DebugMsgs[] { DebugMsgs.NONE, DebugMsgs.IMPORTANT, DebugMsgs.ALL };
        }
    }
}
