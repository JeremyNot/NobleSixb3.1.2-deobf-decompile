//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.chat;

import me.zero.alpine.listener.*;
import me.noble.client.event.events.*;
import java.text.*;
import net.minecraftforge.event.entity.living.*;
import me.noble.client.module.*;
import net.minecraft.init.*;
import me.noble.client.*;
import net.minecraft.item.*;
import net.minecraft.network.play.server.*;
import java.math.*;
import java.util.*;
import net.minecraft.client.gui.*;
import me.noble.client.setting.*;
import java.util.function.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import java.util.concurrent.*;

@Module.Info(name = "Annoyer", category = Module.Category.CHAT, description = "Annoyer")
public class Annoyer extends Module
{
    private Setting<Boolean> blocks;
    @EventHandler
    private Listener<PacketEvent.Send> packetEventSendListener;
    private Setting<Integer> mindistance;
    private Setting<Integer> delay;
    @EventHandler
    public Listener<GuiScreenEvent.Displayed> guiScreenEventDisplayedlistener;
    private static float gainedHealth;
    private static boolean isFirstRun;
    private Setting<Boolean> playerdeath;
    private static double distanceTraveled;
    private static Queue<String> messageQueue;
    private Setting<Boolean> distance;
    private static PacketEvent.Send lastEventSend;
    private static float thisTickHealth;
    private Setting<Integer> queuesize;
    private static TimerTask timerTask;
    private static DecimalFormat df;
    private static PacketEvent.Receive lastEventReceive;
    private static Map<String, Integer> consumedItems;
    private Setting<Boolean> clearqueue;
    @EventHandler
    public Listener<LivingEntityUseItemEvent.Finish> listener;
    private static LivingEntityUseItemEvent.Finish lastLivingEntityUseFinishEvent;
    private Setting<Boolean> playerdamage;
    private static float lastTickHealth;
    private static Map<String, Integer> minedBlocks;
    private Setting<Boolean> clientName;
    @EventHandler
    private Listener<PacketEvent.Receive> packetEventReceiveListener;
    private static String lastmessage;
    private static Vec3d lastTickPos;
    private Setting<Boolean> items;
    private static Timer timer;
    private static GuiScreenEvent.Displayed lastGuiScreenDisplayedEvent;
    private Setting<Integer> maxdistance;
    private Setting<Boolean> greentext;
    private static float lostHealth;
    private static Vec3d thisTickPos;
    private static Map<String, Integer> droppedItems;
    private static Map<String, Integer> placedBlocks;
    private Setting<Boolean> playerheal;
    
    private void lambda$new$2(final PacketEvent.Send lastEventSend) {
        if (this.isDisabled() || Annoyer.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (Annoyer.lastEventSend != null && Annoyer.lastEventSend.equals(lastEventSend)) {
            return;
        }
        if ((this.items.getValue() || this.blocks.getValue()) && lastEventSend.getPacket() instanceof CPacketPlayerDigging) {
            final CPacketPlayerDigging cPacketPlayerDigging = (CPacketPlayerDigging)lastEventSend.getPacket();
            if (this.items.getValue() && Annoyer.mc.player.getHeldItemMainhand().getItem() != Items.field_190931_a && (cPacketPlayerDigging.getAction().equals((Object)CPacketPlayerDigging.Action.DROP_ITEM) || cPacketPlayerDigging.getAction().equals((Object)CPacketPlayerDigging.Action.DROP_ALL_ITEMS))) {
                final String getDisplayName = Annoyer.mc.player.inventory.getCurrentItem().getDisplayName();
                if (Annoyer.droppedItems.containsKey(getDisplayName)) {
                    Annoyer.droppedItems.put(getDisplayName, Annoyer.droppedItems.get(getDisplayName) + 1);
                }
                else {
                    Annoyer.droppedItems.put(getDisplayName, 1);
                }
                Annoyer.lastEventSend = lastEventSend;
                return;
            }
            if (this.blocks.getValue() && cPacketPlayerDigging.getAction().equals((Object)CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK)) {
                final String getLocalizedName = Annoyer.mc.world.getBlockState(cPacketPlayerDigging.getPosition()).getBlock().getLocalizedName();
                if (Annoyer.minedBlocks.containsKey(getLocalizedName)) {
                    Annoyer.minedBlocks.put(getLocalizedName, Annoyer.minedBlocks.get(getLocalizedName) + 1);
                }
                else {
                    Annoyer.minedBlocks.put(getLocalizedName, 1);
                }
                Annoyer.lastEventSend = lastEventSend;
            }
        }
        else {
            if (this.items.getValue() && lastEventSend.getPacket() instanceof CPacketUpdateSign) {
                String value;
                if (this.clientName.getValue()) {
                    value = String.valueOf(new StringBuilder().append("I placed a Sign, thanks to ").append(NobleMod.MODNAME).append("!"));
                }
                else {
                    value = "I placed a Sign!";
                }
                this.queueMessage(value);
                Annoyer.lastEventSend = lastEventSend;
                return;
            }
            if (this.blocks.getValue() && lastEventSend.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
                final ItemStack getCurrentItem = Annoyer.mc.player.inventory.getCurrentItem();
                if (getCurrentItem.field_190928_g) {
                    Annoyer.lastEventSend = lastEventSend;
                    return;
                }
                if (getCurrentItem.getItem() instanceof ItemBlock) {
                    final String getDisplayName2 = Annoyer.mc.player.inventory.getCurrentItem().getDisplayName();
                    if (Annoyer.placedBlocks.containsKey(getDisplayName2)) {
                        Annoyer.placedBlocks.put(getDisplayName2, Annoyer.placedBlocks.get(getDisplayName2) + 1);
                    }
                    else {
                        Annoyer.placedBlocks.put(getDisplayName2, 1);
                    }
                    Annoyer.lastEventSend = lastEventSend;
                }
            }
        }
    }
    
    private void getGameTickData() {
        if (this.distance.getValue()) {
            Annoyer.lastTickPos = Annoyer.thisTickPos;
            Annoyer.thisTickPos = Annoyer.mc.player.getPositionVector();
            Annoyer.distanceTraveled += Annoyer.thisTickPos.distanceTo(Annoyer.lastTickPos);
        }
        if (this.playerheal.getValue() || this.playerdamage.getValue()) {
            Annoyer.lastTickHealth = Annoyer.thisTickHealth;
            Annoyer.thisTickHealth = Annoyer.mc.player.getHealth() + Annoyer.mc.player.getAbsorptionAmount();
            final float n = Annoyer.thisTickHealth - Annoyer.lastTickHealth;
            if (n < 0.0f) {
                Annoyer.lostHealth += n * -1.0f;
            }
            else {
                Annoyer.gainedHealth += n;
            }
        }
    }
    
    static void access$000(final Annoyer annoyer) {
        annoyer.sendMessageCycle();
    }
    
    private void queueMessage(final String s) {
        if (Annoyer.messageQueue.size() > this.queuesize.getValue()) {
            return;
        }
        Annoyer.messageQueue.add(s);
    }
    
    private void composeGameTickData() {
        if (Annoyer.isFirstRun) {
            Annoyer.isFirstRun = false;
            this.clearTickData();
            return;
        }
        String value;
        if (this.clientName.getValue()) {
            value = String.valueOf(new StringBuilder().append(", thanks to ").append(NobleMod.MODNAME).append("!"));
        }
        else {
            value = "!";
        }
        if (this.distance.getValue() && Annoyer.distanceTraveled >= 1.0) {
            if (Annoyer.distanceTraveled < this.delay.getValue() * this.mindistance.getValue()) {
                return;
            }
            if (Annoyer.distanceTraveled > this.delay.getValue() * this.maxdistance.getValue()) {
                Annoyer.distanceTraveled = 0.0;
                return;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("I moved ");
            sb.append((int)Annoyer.distanceTraveled);
            if ((int)Annoyer.distanceTraveled == 1) {
                sb.append(" Block");
            }
            else {
                sb.append(" Blocks");
            }
            sb.append(value);
            this.queueMessage(String.valueOf(sb));
            Annoyer.distanceTraveled = 0.0;
        }
        if (this.playerdamage.getValue() && Annoyer.lostHealth != 0.0f) {
            this.queueMessage(String.valueOf(new StringBuilder().append("I lost ").append(Annoyer.df.format(Annoyer.lostHealth)).append(" Health").append(value)));
            Annoyer.lostHealth = 0.0f;
        }
        if (this.playerheal.getValue() && Annoyer.gainedHealth != 0.0f) {
            this.queueMessage(String.valueOf(new StringBuilder().append("I gained ").append(Annoyer.df.format(Annoyer.gainedHealth)).append(" Health").append(value)));
            Annoyer.gainedHealth = 0.0f;
        }
    }
    
    private static void lambda$new$3(final LivingEntityUseItemEvent.Finish lastLivingEntityUseFinishEvent) {
        if (lastLivingEntityUseFinishEvent.getEntity().equals((Object)Annoyer.mc.player) && lastLivingEntityUseFinishEvent.getItem().getItem() instanceof ItemFood) {
            final String getDisplayName = lastLivingEntityUseFinishEvent.getItem().getDisplayName();
            if (Annoyer.consumedItems.containsKey(getDisplayName)) {
                Annoyer.consumedItems.put(getDisplayName, Annoyer.consumedItems.get(getDisplayName) + 1);
            }
            else {
                Annoyer.consumedItems.put(getDisplayName, 1);
            }
            Annoyer.lastLivingEntityUseFinishEvent = lastLivingEntityUseFinishEvent;
        }
    }
    
    private void lambda$new$1(final PacketEvent.Receive lastEventReceive) {
        if (this.isDisabled() || Annoyer.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (Annoyer.lastEventReceive != null && Annoyer.lastEventReceive.equals(lastEventReceive)) {
            return;
        }
        if (lastEventReceive.getPacket() instanceof SPacketUseBed) {
            String value;
            if (this.clientName.getValue()) {
                value = String.valueOf(new StringBuilder().append("I used a Bed, thanks to ").append(NobleMod.MODNAME).append("!"));
            }
            else {
                value = "I used a Bed!";
            }
            this.queueMessage(value);
            Annoyer.lastEventReceive = lastEventReceive;
        }
    }
    
    public void onEnable() {
        Annoyer.timer = new Timer();
        if (Annoyer.mc.player == null) {
            this.disable();
            return;
        }
        (Annoyer.df = new DecimalFormat("#.#")).setRoundingMode(RoundingMode.CEILING);
        Annoyer.timerTask = new TimerTask(this) {
            final Annoyer this$0;
            
            @Override
            public void run() {
                Annoyer.access$000(this.this$0);
            }
        };
        Annoyer.timer.schedule(Annoyer.timerTask, 0L, this.delay.getValue() * 1000);
    }
    
    private void sendMessageCycle() {
        if (this.isDisabled() || Annoyer.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        this.composeGameTickData();
        this.composeEventData();
        final Iterator<String> iterator = Annoyer.messageQueue.iterator();
        if (iterator.hasNext()) {
            final String s = iterator.next();
            this.sendMessage(s);
            Annoyer.messageQueue.remove(s);
        }
    }
    
    private void lambda$new$0(final GuiScreenEvent.Displayed lastGuiScreenDisplayedEvent) {
        if (this.isDisabled() || Annoyer.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (Annoyer.lastGuiScreenDisplayedEvent != null && Annoyer.lastGuiScreenDisplayedEvent.equals(lastGuiScreenDisplayedEvent)) {
            return;
        }
        if (this.playerdeath.getValue() && lastGuiScreenDisplayedEvent.getScreen() instanceof GuiGameOver) {
            String value;
            if (this.clientName.getValue()) {
                value = String.valueOf(new StringBuilder().append("I ded ;( thanks to ").append(NobleMod.MODNAME).append("!"));
            }
            else {
                value = "I ded ;(";
            }
            this.queueMessage(value);
            return;
        }
        Annoyer.lastGuiScreenDisplayedEvent = lastGuiScreenDisplayedEvent;
    }
    
    private void clearTickData() {
        Annoyer.thisTickPos = (Annoyer.lastTickPos = Annoyer.mc.player.getPositionVector());
        Annoyer.distanceTraveled = 0.0;
        Annoyer.thisTickHealth = (Annoyer.lastTickHealth = Annoyer.mc.player.getHealth() + Annoyer.mc.player.getAbsorptionAmount());
        Annoyer.lostHealth = 0.0f;
        Annoyer.gainedHealth = 0.0f;
    }
    
    public Annoyer() {
        this.distance = (Setting<Boolean>)this.register((Setting)Settings.b("Distance", true));
        this.mindistance = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Min Distance").withRange(1, 100).withValue(10).build());
        this.maxdistance = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Max Distance").withRange(100, 10000).withValue(150).build());
        this.blocks = (Setting<Boolean>)this.register((Setting)Settings.b("Blocks", true));
        this.items = (Setting<Boolean>)this.register((Setting)Settings.b("Items", true));
        this.playerheal = (Setting<Boolean>)this.register((Setting)Settings.b("Player Heal", true));
        this.playerdamage = (Setting<Boolean>)this.register((Setting)Settings.b("Player Damage", true));
        this.playerdeath = (Setting<Boolean>)this.register((Setting)Settings.b("Death", true));
        this.greentext = (Setting<Boolean>)this.register((Setting)Settings.b("Greentext", false));
        this.clientName = (Setting<Boolean>)this.register((Setting)Settings.b("ClientName", false));
        this.delay = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Send Delay").withRange(1, 10).withValue(2).build());
        this.queuesize = (Setting<Integer>)this.register((Setting)Settings.integerBuilder("Queue Size").withRange(1, 100).withValue(5).build());
        this.clearqueue = (Setting<Boolean>)this.register((Setting)Settings.b("Clear Queue", false));
        this.guiScreenEventDisplayedlistener = new Listener<GuiScreenEvent.Displayed>(this::lambda$new$0, (Predicate<GuiScreenEvent.Displayed>[])new Predicate[0]);
        this.packetEventReceiveListener = new Listener<PacketEvent.Receive>(this::lambda$new$1, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        this.packetEventSendListener = new Listener<PacketEvent.Send>(this::lambda$new$2, (Predicate<PacketEvent.Send>[])new Predicate[0]);
        this.listener = new Listener<LivingEntityUseItemEvent.Finish>(Annoyer::lambda$new$3, (Predicate<LivingEntityUseItemEvent.Finish>[])new Predicate[0]);
    }
    
    public void onUpdate() {
        if (this.isDisabled() || Annoyer.mc.player == null || ModuleManager.isModuleEnabled("Freecam")) {
            return;
        }
        if (this.clearqueue.getValue()) {
            this.clearqueue.setValue(false);
            Annoyer.messageQueue.clear();
        }
        this.getGameTickData();
    }
    
    public void onDisable() {
        Annoyer.timer.cancel();
        Annoyer.timer.purge();
        Annoyer.messageQueue.clear();
    }
    
    private Block getBlock(final BlockPos blockPos) {
        return Annoyer.mc.world.getBlockState(blockPos).getBlock();
    }
    
    private void sendMessage(final String s) {
        final StringBuilder sb = new StringBuilder();
        if (this.greentext.getValue()) {
            sb.append("> ");
        }
        sb.append(s);
        Annoyer.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(String.valueOf(sb).replaceAll("��", "")));
    }
    
    private void composeEventData() {
        String value;
        if (this.clientName.getValue()) {
            value = String.valueOf(new StringBuilder().append(", thanks to ").append(NobleMod.MODNAME).append("!"));
        }
        else {
            value = "!";
        }
        for (final Map.Entry<String, Integer> entry : Annoyer.minedBlocks.entrySet()) {
            this.queueMessage(String.valueOf(new StringBuilder().append("I mined ").append(entry.getValue()).append(" ").append(entry.getKey()).append(value)));
            Annoyer.minedBlocks.remove(entry.getKey());
        }
        for (final Map.Entry<String, Integer> entry2 : Annoyer.placedBlocks.entrySet()) {
            this.queueMessage(String.valueOf(new StringBuilder().append("I placed ").append(entry2.getValue()).append(" ").append(entry2.getKey()).append(value)));
            Annoyer.placedBlocks.remove(entry2.getKey());
        }
        for (final Map.Entry<String, Integer> entry3 : Annoyer.droppedItems.entrySet()) {
            this.queueMessage(String.valueOf(new StringBuilder().append("I dropped ").append(entry3.getValue()).append(" ").append(entry3.getKey()).append(value)));
            Annoyer.droppedItems.remove(entry3.getKey());
        }
        for (final Map.Entry<String, Integer> entry4 : Annoyer.consumedItems.entrySet()) {
            this.queueMessage(String.valueOf(new StringBuilder().append("I ate ").append(entry4.getValue()).append(" ").append(entry4.getKey()).append(value)));
            Annoyer.consumedItems.remove(entry4.getKey());
        }
    }
    
    static {
        Annoyer.isFirstRun = true;
        Annoyer.messageQueue = new ConcurrentLinkedQueue<String>();
        Annoyer.minedBlocks = new ConcurrentHashMap<String, Integer>();
        Annoyer.placedBlocks = new ConcurrentHashMap<String, Integer>();
        Annoyer.droppedItems = new ConcurrentHashMap<String, Integer>();
        Annoyer.consumedItems = new ConcurrentHashMap<String, Integer>();
        Annoyer.df = new DecimalFormat();
        Annoyer.lastmessage = "";
        Annoyer.distanceTraveled = 0.0;
    }
}
