//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.render;

import me.noble.client.module.*;
import net.minecraft.entity.*;
import me.noble.client.setting.*;
import me.noble.client.event.events.*;
import me.noble.client.util.*;
import java.util.function.*;
import net.minecraft.client.renderer.*;
import org.lwjgl.opengl.*;
import java.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.math.*;

@Module.Info(name = "ESP", category = Module.Category.RENDER, description = "Highlights entities")
public class ESP extends Module
{
    private Setting<Boolean> animals;
    private Setting<Boolean> mobs;
    private Setting<Boolean> players;
    private Setting<ESPMode> mode;
    
    private static boolean lambda$onWorldRender$0(final Entity entity) {
        return ESP.mc.player != entity;
    }
    
    private static EntityLivingBase lambda$onWorldRender$1(final Entity entity) {
        return (EntityLivingBase)entity;
    }
    
    public ESP() {
        this.mode = (Setting<ESPMode>)this.register((Setting)Settings.e("Mode", ESPMode.RECTANGLE));
        this.players = (Setting<Boolean>)this.register((Setting)Settings.b("Players", true));
        this.animals = (Setting<Boolean>)this.register((Setting)Settings.b("Animals", false));
        this.mobs = (Setting<Boolean>)this.register((Setting)Settings.b("Mobs", false));
    }
    
    public void onWorldRender(final RenderEvent renderEvent) {
        if (Wrapper.getMinecraft().getRenderManager().options == null) {
            return;
        }
        switch (this.mode.getValue()) {
            case RECTANGLE: {
                ESP.mc.world.loadedEntityList.stream().filter(EntityUtil::isLiving).filter(ESP::lambda$onWorldRender$0).map(ESP::lambda$onWorldRender$1).filter(ESP::lambda$onWorldRender$2).filter(this::lambda$onWorldRender$3).forEach(ESP::lambda$onWorldRender$4);
                GlStateManager.enableDepth();
                GlStateManager.depthMask(true);
                GlStateManager.disableTexture2D();
                GlStateManager.enableBlend();
                GlStateManager.disableAlpha();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                GlStateManager.shadeModel(7425);
                GlStateManager.disableDepth();
                GlStateManager.enableCull();
                GlStateManager.glLineWidth(1.0f);
                GL11.glColor3f(1.0f, 1.0f, 1.0f);
                break;
            }
        }
    }
    
    public void onDisable() {
        if (this.mode.getValue().equals(ESPMode.GLOW)) {
            final Iterator<Entity> iterator = ESP.mc.world.loadedEntityList.iterator();
            while (iterator.hasNext()) {
                iterator.next().setGlowing(false);
            }
            ESP.mc.player.setGlowing(false);
        }
    }
    
    private boolean lambda$onWorldRender$3(final EntityLivingBase entityLivingBase) {
        return (this.players.getValue() && entityLivingBase instanceof EntityPlayer) || (EntityUtil.isPassive((Entity)entityLivingBase) ? this.animals.getValue() : this.mobs.getValue());
    }
    
    public void onUpdate() {
        if (this.mode.getValue().equals(ESPMode.GLOW)) {
            for (final Entity entity : ESP.mc.world.loadedEntityList) {
                if (entity == null || entity.isDead) {
                    return;
                }
                if (entity instanceof EntityPlayer && this.players.getValue() && !entity.isGlowing()) {
                    entity.setGlowing(true);
                }
                else if (entity instanceof EntityPlayer && !this.players.getValue() && entity.isGlowing()) {
                    entity.setGlowing(false);
                }
                if (EntityUtil.isHostileMob(entity) && this.mobs.getValue() && !entity.isGlowing()) {
                    entity.setGlowing(true);
                }
                else if (EntityUtil.isHostileMob(entity) && !this.mobs.getValue() && entity.isGlowing()) {
                    entity.setGlowing(false);
                }
                if (EntityUtil.isPassive(entity) && this.animals.getValue() && !entity.isGlowing()) {
                    entity.setGlowing(true);
                }
                else {
                    if (!EntityUtil.isPassive(entity) || this.animals.getValue() || !entity.isGlowing()) {
                        continue;
                    }
                    entity.setGlowing(false);
                }
            }
        }
    }
    
    private static void lambda$onWorldRender$4(final RenderEvent renderEvent, final float n, final boolean b, final EntityLivingBase entityLivingBase) {
        GlStateManager.pushMatrix();
        final Vec3d interpolatedPos = EntityUtil.getInterpolatedPos((Entity)entityLivingBase, renderEvent.getPartialTicks());
        GlStateManager.translate(interpolatedPos.xCoord - ESP.mc.getRenderManager().renderPosX, interpolatedPos.yCoord - ESP.mc.getRenderManager().renderPosY, interpolatedPos.zCoord - ESP.mc.getRenderManager().renderPosZ);
        GlStateManager.glNormal3f(0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(-n, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate((float)(b ? -1 : 1), 1.0f, 0.0f, 0.0f);
        GlStateManager.disableLighting();
        GlStateManager.depthMask(false);
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        if (entityLivingBase instanceof EntityPlayer) {
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
        }
        else if (EntityUtil.isPassive((Entity)entityLivingBase)) {
            GL11.glColor3f(0.11f, 0.9f, 0.11f);
        }
        else {
            GL11.glColor3f(0.9f, 0.1f, 0.1f);
        }
        GlStateManager.disableTexture2D();
        GL11.glLineWidth(2.0f);
        GL11.glEnable(2848);
        GL11.glBegin(2);
        GL11.glVertex2d((double)(-entityLivingBase.width / 2.0f), 0.0);
        GL11.glVertex2d((double)(-entityLivingBase.width / 2.0f), (double)entityLivingBase.height);
        GL11.glVertex2d((double)(entityLivingBase.width / 2.0f), (double)entityLivingBase.height);
        GL11.glVertex2d((double)(entityLivingBase.width / 2.0f), 0.0);
        GL11.glEnd();
        GlStateManager.popMatrix();
    }
    
    private static boolean lambda$onWorldRender$2(final EntityLivingBase entityLivingBase) {
        return !entityLivingBase.isDead;
    }
    
    public enum ESPMode
    {
        private static final ESPMode[] $VALUES;
        
        GLOW, 
        RECTANGLE;
        
        static {
            $VALUES = new ESPMode[] { ESPMode.RECTANGLE, ESPMode.GLOW };
        }
    }
}
