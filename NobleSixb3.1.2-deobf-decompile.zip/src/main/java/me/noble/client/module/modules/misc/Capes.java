//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.module.modules.misc;

import net.minecraft.client.entity.*;
import net.minecraft.util.*;
import me.noble.client.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.*;
import javax.net.ssl.*;
import me.noble.client.*;
import java.net.*;
import com.google.gson.*;
import java.io.*;
import java.awt.image.*;
import java.awt.*;

public class Capes
{
    public CapeUser[] capeUser;
    public static Capes INSTANCE;
    
    static BufferedImage access$000(final Capes capes, final BufferedImage bufferedImage) {
        return capes.parseCape(bufferedImage);
    }
    
    public static ResourceLocation getCapeResource(final AbstractClientPlayer abstractClientPlayer) {
        for (final CapeUser capeUser2 : Capes.INSTANCE.capeUser) {
            if (abstractClientPlayer.getUniqueID().toString().equalsIgnoreCase(capeUser2.uuid)) {
                return new ResourceLocation(String.valueOf(new StringBuilder().append("capes/kami/").append(formatUUID(capeUser2.uuid))));
            }
        }
        return null;
    }
    
    private static String formatUUID(final String s) {
        return s.replaceAll("-", "");
    }
    
    public void bindTexture(final String s, final String s2) {
        final IImageBuffer imageBuffer = (IImageBuffer)new IImageBuffer(this) {
            final Capes this$0;
            
            public void skinAvailable() {
            }
            
            public BufferedImage parseUserSkin(final BufferedImage bufferedImage) {
                return Capes.access$000(this.this$0, bufferedImage);
            }
        };
        final ResourceLocation resourceLocation = new ResourceLocation(s2);
        final TextureManager getTextureManager = Wrapper.getMinecraft().getTextureManager();
        getTextureManager.getTexture(resourceLocation);
        getTextureManager.loadTexture(resourceLocation, (ITextureObject)new ThreadDownloadImageData((File)null, s, (ResourceLocation)null, (IImageBuffer)imageBuffer));
    }
    
    public Capes() {
        Capes.INSTANCE = this;
        try {
            final HttpsURLConnection httpsURLConnection = (HttpsURLConnection)new URL(NobleMod.CAPES_JSON).openConnection();
            httpsURLConnection.connect();
            this.capeUser = (CapeUser[])new Gson().fromJson((Reader)new InputStreamReader(httpsURLConnection.getInputStream()), (Class)CapeUser[].class);
            httpsURLConnection.disconnect();
        }
        catch (Exception ex) {
            NobleMod.log.error("Failed to load capes");
        }
        if (this.capeUser != null) {
            for (final CapeUser capeUser2 : this.capeUser) {
                this.bindTexture(capeUser2.url, String.valueOf(new StringBuilder().append("capes/kami/").append(formatUUID(capeUser2.uuid))));
            }
        }
    }
    
    private BufferedImage parseCape(final BufferedImage bufferedImage) {
        int n = 64;
        int n2 = 32;
        for (int width = bufferedImage.getWidth(), height = bufferedImage.getHeight(); n < width || n2 < height; n *= 2, n2 *= 2) {}
        final BufferedImage bufferedImage2 = new BufferedImage(n, n2, 2);
        final Graphics graphics = bufferedImage2.getGraphics();
        graphics.drawImage(bufferedImage, 0, 0, null);
        graphics.dispose();
        return bufferedImage2;
    }
    
    public class CapeUser
    {
        public String url;
        final Capes this$0;
        public String uuid;
        
        public CapeUser(final Capes this$0) {
            this.this$0 = this$0;
        }
    }
}
