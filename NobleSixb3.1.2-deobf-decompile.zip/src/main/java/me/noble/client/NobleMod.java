//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client;

import net.minecraftforge.fml.common.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.font.*;
import java.nio.file.*;
import me.noble.client.setting.config.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.util.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.module.*;
import net.minecraftforge.common.*;
import me.noble.client.event.*;
import me.noble.client.command.*;
import me.noble.client.module.modules.misc.*;
import me.noble.client.module.modules.render.*;
import me.noble.client.module.modules.chat.*;
import me.noble.client.module.modules.gui.*;
import me.noble.client.module.modules.noble.*;
import me.noble.client.gui.rgui.component.*;
import com.google.gson.*;
import java.util.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import org.apache.logging.log4j.*;
import me.zero.alpine.*;
import java.io.*;
import net.minecraftforge.fml.common.event.*;
import com.google.common.base.*;
import me.noble.client.setting.*;
import net.minecraftforge.client.event.*;
import java.awt.*;
import me.noble.client.util.*;
import net.minecraftforge.fml.common.eventhandler.*;
import java.util.function.*;
import java.nio.file.attribute.*;

@Mod(modid = "noblesixgod", name = "NOBLESIX.NET", version = "B312", updateJSON = "http://noblesix.net/update.json")
public class NobleMod
{
    static String UPDATE_JSON;
    public static Logger log;
    public static char quoteLeft;
    public static String MODNAME;
    public static String KAMI_KANJI;
    public int redForBG;
    public static String KAMI_BLUE;
    public static String MODVER;
    public static char quoteRight;
    public static String KAMI_ONTOP;
    public static String MODID;
    public CommandManager commandManager;
    public static String DONATORS_JSON;
    public KamiGUI kamiGUI;
    public static final EventBus EVENT_BUS;
    public static char colour;
    public static String KAMI_WEBSITE;
    CFontRenderer cFontRenderer;
    public KamiGUI guiManager;
    public static char separator;
    public String xxd;
    public boolean rainbowBG;
    public static String APP_ID;
    private Setting<JsonObject> guiStateSetting;
    public int blueForBG;
    @Mod.Instance
    private static NobleMod INSTANCE;
    private static String KAMI_CONFIG_NAME_DEFAULTXD;
    public int greenForBG;
    public static String CAPES_JSON;
    public static String KAMI_JAPANESE_ONTOP;
    
    private static boolean lambda$init$2(final Module module) {
        return module.alwaysListening;
    }
    
    public static String getConfigName() {
        final Path value = Paths.get("NOBLESIXLastConfig.txt", new String[0]);
        String s = NobleMod.KAMI_CONFIG_NAME_DEFAULTXD;
        try (final BufferedReader bufferedReader = Files.newBufferedReader(value)) {
            s = bufferedReader.readLine();
            if (!isFilenameValid(s)) {
                s = NobleMod.KAMI_CONFIG_NAME_DEFAULTXD;
            }
        }
        catch (NoSuchFileException ex3) {
            try (final BufferedWriter bufferedWriter = Files.newBufferedWriter(value, new OpenOption[0])) {
                bufferedWriter.write(NobleMod.KAMI_CONFIG_NAME_DEFAULTXD);
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        return s;
    }
    
    public static void loadConfigurationUnsafe() throws IOException {
        final Path value = Paths.get(getConfigName(), new String[0]);
        if (!Files.exists(value, new LinkOption[0])) {
            return;
        }
        Configuration.loadConfiguration(value);
        for (final Map.Entry<K, JsonElement> entry : NobleMod.INSTANCE.guiStateSetting.getValue().entrySet()) {
            final Optional first = NobleMod.INSTANCE.guiManager.getChildren().stream().filter(NobleMod::lambda$loadConfigurationUnsafe$3).filter(NobleMod::lambda$loadConfigurationUnsafe$4).findFirst();
            if (first.isPresent()) {
                final JsonObject asJsonObject = entry.getValue().getAsJsonObject();
                final Frame frame = first.get();
                frame.setX(asJsonObject.get("x").getAsInt());
                frame.setY(asJsonObject.get("y").getAsInt());
                final Docking docking = Docking.values()[asJsonObject.get("docking").getAsInt()];
                if (docking.isLeft()) {
                    ContainerHelper.setAlignment((Container)frame, AlignedComponent.Alignment.LEFT);
                }
                else if (docking.isRight()) {
                    ContainerHelper.setAlignment((Container)frame, AlignedComponent.Alignment.RIGHT);
                }
                else if (docking.isCenterVertical()) {
                    ContainerHelper.setAlignment((Container)frame, AlignedComponent.Alignment.CENTER);
                }
                frame.setDocking(docking);
                frame.setMinimized(asJsonObject.get("minimized").getAsBoolean());
                frame.setPinned(asJsonObject.get("pinned").getAsBoolean());
            }
            else {
                System.err.println(String.valueOf(new StringBuilder().append("Found GUI config entry for ").append((String)entry.getKey()).append(", but found no frame with that name")));
            }
        }
        getInstance().getGuiManager().getChildren().stream().filter(NobleMod::lambda$loadConfigurationUnsafe$5).forEach(NobleMod::lambda$loadConfigurationUnsafe$6);
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent fmlInitializationEvent) {
        NobleMod.log.info(String.valueOf(new StringBuilder().append("\n\nInitializing ").append(NobleMod.MODNAME).append(" ").append(NobleMod.MODVER)));
        ModuleManager.initialize();
        ModuleManager.getModules().stream().filter(NobleMod::lambda$init$2).forEach(NobleMod.EVENT_BUS::subscribe);
        MinecraftForge.EVENT_BUS.register((Object)new ForgeEventProcessor());
        LagCompensator.INSTANCE = new LagCompensator();
        Wrapper.init();
        (this.guiManager = new KamiGUI()).initializeGUI();
        this.commandManager = new CommandManager();
        Friends.initFriends();
        SettingsRegister.register("commandPrefix", Command.commandPrefix);
        loadConfiguration();
        NobleMod.log.info("Settings loaded");
        new Capes();
        NobleMod.log.info("Capes init!\n");
        new RichPresence();
        NobleMod.log.info("Rich Presence Users init!\n");
        ModuleManager.getModules().stream().filter(Module::isEnabled).forEach(Module::enable);
        try {
            ModuleManager.getModuleByName("InfoOverlay").setEnabled(true);
            ModuleManager.getModuleByName("InventoryViewer").setEnabled(true);
            if (((DiscordSettings)ModuleManager.getModuleByName("DiscordSettings")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("DiscordSettings").setEnabled(true);
            }
            if (((TabFriends)ModuleManager.getModuleByName("TabFriends")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("TabFriends").setEnabled(true);
            }
            if (((ChatSuffix)ModuleManager.getModuleByName("ChatSuffix")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("ChatSuffix").setEnabled(true);
            }
            if (((CleanGUI)ModuleManager.getModuleByName("CleanGUI")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("CleanGUI").setEnabled(true);
            }
            if (((PrefixChat)ModuleManager.getModuleByName("PrefixChat")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("PrefixChat").setEnabled(true);
            }
            if (((ClientName)ModuleManager.getModuleByName("ClientName")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("ClientName").setEnabled(true);
            }
            if (((AutoSaveConfig)ModuleManager.getModuleByName("AutoSaveConfig")).startupGlobal.getValue()) {
                ModuleManager.getModuleByName("AutoSaveConfig").setEnabled(true);
            }
        }
        catch (NullPointerException ex) {
            NobleMod.log.error("NPE in loading always enabled modules\n");
        }
        NobleMod.log.info(String.valueOf(new StringBuilder().append(NobleMod.MODNAME).append(" Mod initialized!\n")));
    }
    
    public static void loadConfiguration() {
        try {
            loadConfigurationUnsafe();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private static Frame lambda$saveConfigurationUnsafe$8(final Component component) {
        return (Frame)component;
    }
    
    private static void lambda$saveConfigurationUnsafe$9(final JsonObject jsonObject, final Frame frame) {
        final JsonObject jsonObject2 = new JsonObject();
        jsonObject2.add("x", (JsonElement)new JsonPrimitive((Number)frame.getX()));
        jsonObject2.add("y", (JsonElement)new JsonPrimitive((Number)frame.getY()));
        jsonObject2.add("docking", (JsonElement)new JsonPrimitive((Number)Arrays.asList(Docking.values()).indexOf(frame.getDocking())));
        jsonObject2.add("minimized", (JsonElement)new JsonPrimitive(Boolean.valueOf(frame.isMinimized())));
        jsonObject2.add("pinned", (JsonElement)new JsonPrimitive(Boolean.valueOf(frame.isPinned())));
        jsonObject.add(frame.getTitle(), (JsonElement)jsonObject2);
    }
    
    @Mod.EventHandler
    public void postInit(final FMLPostInitializationEvent fmlPostInitializationEvent) {
        if (RichPresence.INSTANCE.customUsers != null) {
            for (final RichPresence.CustomUser customUser : RichPresence.INSTANCE.customUsers) {
                if (customUser.uuid.equalsIgnoreCase(Minecraft.getMinecraft().session.getProfile().getId().toString())) {
                    switch (Integer.parseInt(customUser.type)) {
                        case 0: {
                            DiscordPresence.presence.smallImageKey = "booster";
                            DiscordPresence.presence.smallImageText = "booster uwu";
                            break;
                        }
                        case 1: {
                            DiscordPresence.presence.smallImageKey = "inviter";
                            DiscordPresence.presence.smallImageText = "inviter owo";
                            break;
                        }
                        case 2: {
                            DiscordPresence.presence.smallImageKey = "giveaway";
                            DiscordPresence.presence.smallImageText = "giveaway winner";
                            break;
                        }
                        case 3: {
                            DiscordPresence.presence.smallImageKey = "contest";
                            DiscordPresence.presence.smallImageText = "contest winner";
                            break;
                        }
                        case 4: {
                            DiscordPresence.presence.smallImageKey = "nine";
                            DiscordPresence.presence.smallImageText = "900th member";
                            break;
                        }
                        default: {
                            DiscordPresence.presence.smallImageKey = "donator2";
                            DiscordPresence.presence.smallImageText = "donator <3";
                            break;
                        }
                    }
                }
            }
        }
        Display.setTitle(String.valueOf(new StringBuilder().append("NobleSix ").append(NobleMod.MODVER).append(" ").append(this.xxd)));
    }
    
    static {
        NobleMod.MODNAME = "NOBLESIX.NET";
        NobleMod.MODID = "acenoblesix";
        NobleMod.MODVER = "B312";
        NobleMod.APP_ID = "680026635223040071";
        NobleMod.UPDATE_JSON = "http://noblesix.net/update.json";
        NobleMod.DONATORS_JSON = "http://noblesix.net/donate.json";
        NobleMod.CAPES_JSON = "https://noblesix.net/capes.json";
        NobleMod.KAMI_KANJI = "NobleSix";
        NobleMod.KAMI_BLUE = "\u0274\u1d0f\u0299\u029f\u1d07s\u026ax.\u0274\u1d07\u1d1b";
        NobleMod.KAMI_JAPANESE_ONTOP = "\u0274\u1d0f\u0299\u029f\u1d07s\u026ax.\u0274\u1d07\u1d1b";
        NobleMod.KAMI_ONTOP = "\u0274\u1d0f\u0299\u029f\u1d07s\u026ax \u026as \u0262\u1d0f\u1d05";
        NobleMod.KAMI_WEBSITE = "\u0274\u1d0f\u0299\u029f\u1d07s\u026ax.\u0274\u1d07\u1d1b";
        NobleMod.colour = '��';
        NobleMod.separator = '\u23d0';
        NobleMod.quoteLeft = '?';
        NobleMod.quoteRight = '?';
        NobleMod.KAMI_CONFIG_NAME_DEFAULTXD = "NOBLESIXConfig.json";
        NobleMod.log = LogManager.getLogger("NOBLESIX");
        EVENT_BUS = new EventManager();
    }
    
    private static boolean lambda$loadConfigurationUnsafe$4(final Map.Entry entry, final Component component) {
        return ((Frame)component).getTitle().equals(entry.getKey());
    }
    
    private static boolean lambda$loadConfigurationUnsafe$5(final Component component) {
        return component instanceof Frame && ((Frame)component).isPinnable() && component.isVisible();
    }
    
    public static boolean isFilenameValid(final String s) {
        final File file = new File(s);
        try {
            file.getCanonicalPath();
            return true;
        }
        catch (IOException ex) {
            return false;
        }
    }
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent fmlPreInitializationEvent) {
    }
    
    public KamiGUI getKamiGUI() {
        return this.kamiGUI;
    }
    
    private void lambda$onRenderGui$0(final Setting setting) {
        this.checkSettingGuiColour(setting);
    }
    
    public CommandManager getCommandManager() {
        return this.commandManager;
    }
    
    public NobleMod() {
        this.xxd = " - Noble Six Never Die He Turned Into A Ghost On Reach";
        this.guiStateSetting = Settings.custom("gui", new JsonObject(), new Converter<JsonObject, JsonObject>(this) {
            final NobleMod this$0;
            
            protected Object doBackward(final Object o) {
                return this.doBackward((JsonObject)o);
            }
            
            protected JsonObject doForward(final JsonObject jsonObject) {
                return jsonObject;
            }
            
            protected Object doForward(final Object o) {
                return this.doForward((JsonObject)o);
            }
            
            protected JsonObject doBackward(final JsonObject jsonObject) {
                return jsonObject;
            }
        }).buildAndRegister("");
        this.cFontRenderer = new CFontRenderer(new Font("Verdana", 0, 18), true, false);
    }
    
    private void lambda$onRenderGui$1(final Setting setting) {
        this.checkRainbowSetting(setting);
    }
    
    public static void saveConfiguration() {
        try {
            saveConfigurationUnsafe();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onRenderGui(final RenderGameOverlayEvent.Post post) {
        final Minecraft getMinecraft = Minecraft.getMinecraft();
        final float[] array = { System.currentTimeMillis() % 11520L / 11520.0f };
        ModuleManager.getModuleByName("RainBowNoble").settingList.forEach(this::lambda$onRenderGui$0);
        ModuleManager.getModuleByName("RainBowNoble").settingList.forEach(this::lambda$onRenderGui$1);
        final int hsBtoRGB = Color.HSBtoRGB(array[0], 1.0f, 1.0f);
        if (post.getType() != RenderGameOverlayEvent.ElementType.HOTBAR) {
            return;
        }
        final String getName = getMinecraft.player.getName();
        this.rainbowBG = true;
        if (this.rainbowBG) {
            this.cFontRenderer.drawStringWithShadow(String.valueOf(new StringBuilder().append("Welcome ").append(getName).append("")), 1.0, 10.0, hsBtoRGB);
            this.cFontRenderer.drawStringWithShadow("NobleSix B2.9.3", 1.0, 1.0, hsBtoRGB);
            final float[] array2 = array;
            final int n = 0;
            array2[n] += 0.02f;
        }
        else {
            this.cFontRenderer.drawStringWithShadow(String.valueOf(new StringBuilder().append("Welcome ").append(getName).append("")), 1.0, 10.0, ColourUtils.toRGBA(this.redForBG, this.greenForBG, this.blueForBG, 255));
            this.cFontRenderer.drawStringWithShadow("NobleSix B2.9.3", 1.0, 1.0, ColourUtils.toRGBA(this.redForBG, this.greenForBG, this.blueForBG, 255));
        }
    }
    
    public KamiGUI getGuiManager() {
        return this.guiManager;
    }
    
    private static void lambda$loadConfigurationUnsafe$6(final Component component) {
        component.setOpacity(0.0f);
    }
    
    private static boolean lambda$loadConfigurationUnsafe$3(final Component component) {
        return component instanceof Frame;
    }
    
    public static void saveConfigurationUnsafe() throws IOException {
        final JsonObject value = new JsonObject();
        NobleMod.INSTANCE.guiManager.getChildren().stream().filter(NobleMod::lambda$saveConfigurationUnsafe$7).map(NobleMod::lambda$saveConfigurationUnsafe$8).forEach(NobleMod::lambda$saveConfigurationUnsafe$9);
        NobleMod.INSTANCE.guiStateSetting.setValue(value);
        final Path value2 = Paths.get(getConfigName(), new String[0]);
        if (!Files.exists(value2, new LinkOption[0])) {
            Files.createFile(value2, (FileAttribute<?>[])new FileAttribute[0]);
        }
        Configuration.saveConfiguration(value2);
        ModuleManager.getModules().forEach(Module::destroy);
    }
    
    private static boolean lambda$saveConfigurationUnsafe$7(final Component component) {
        return component instanceof Frame;
    }
    
    public static NobleMod getInstance() {
        return NobleMod.INSTANCE;
    }
    
    private void checkRainbowSetting(final Setting setting) {
        final String name = setting.getName();
        switch (name) {
            case "Rainbow Watermark": {
                this.rainbowBG = true;
                break;
            }
        }
    }
    
    private void checkSettingGuiColour(final Setting setting) {
        final String name = setting.getName();
        switch (name) {
            case "Red": {
                this.redForBG = 255;
                break;
            }
            case "Green": {
                this.greenForBG = 0;
                break;
            }
            case "Blue": {
                this.blueForBG = 0;
                break;
            }
        }
    }
}
