//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.util.*;
import org.reflections.scanners.*;
import org.reflections.*;

public class ClassFinder
{
    public static Set<Class> findClasses(final String s, final Class clazz) {
        return (Set<Class>)new Reflections(s, new Scanner[0]).getSubTypesOf(clazz);
    }
}
