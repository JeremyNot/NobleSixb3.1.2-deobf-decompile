//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.lang.reflect.*;
import net.minecraft.entity.player.*;
import net.minecraft.inventory.*;
import net.minecraft.client.settings.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.block.model.*;
import java.util.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.entity.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.*;
import net.minecraft.util.text.*;
import net.minecraft.network.datasync.*;
import net.minecraft.client.gui.*;

public class ReflectionHelper
{
    public static Field hopperInventory;
    public static Field rightClickDelayTimer;
    public static Field speedInAir;
    public static Field playerViewY;
    public static Field sleeping;
    public static Field spacketPlayerPosLookPitch;
    public static Field guiDisconnectedParentScreen;
    private static Field modifiersField;
    public static Field playerViewX;
    public static Field spacketExplosionMotionZ;
    public static Field lowerChestInventory;
    public static Field sPacketChatChatComponent;
    public static Field horseJumpPower;
    public static Field cpacketPlayerPitch;
    public static Field PLAYER_MODEL_FLAG;
    public static Field mapTextureObjects;
    public static Field renderPosY;
    public static Field spacketExplosionMotionX;
    public static Field foodExhaustionLevel;
    public static Field spacketExplosionMotionY;
    public static Field session;
    public static Field timer;
    public static Field cpacketPlayerY;
    public static Field curBlockDamageMP;
    public static Field guiSceenServerListServerData;
    public static Field debugFps;
    public static Field modelManager;
    public static Field cpacketVehicleMoveY;
    public static Method rightClickMouse;
    public static Field guiButtonHovered;
    public static Field boundingBox;
    public static Field renderPosX;
    public static Field y_vec3d;
    public static Field cPacketUpdateSignLines;
    public static Field cpacketPlayerYaw;
    public static Field sleepTimer;
    public static Field cPacketChatMessage;
    public static Field renderPosZ;
    public static Field blockHitDelay;
    public static Field cpacketPlayerOnGround;
    public static Field spacketPlayerPosLookYaw;
    public static Field ridingEntity;
    public static Field pressed;
    public static Field shulkerInventory;
    
    public static boolean getSleeping(final EntityPlayer entityPlayer) {
        try {
            return (boolean)ReflectionHelper.sleeping.get(entityPlayer);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static IInventory getHopperInventory(final GuiHopper guiHopper) {
        try {
            return (IInventory)ReflectionHelper.hopperInventory.get(guiHopper);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSPacketExplosionMotionY(final SPacketExplosion sPacketExplosion, final float n) {
        try {
            ReflectionHelper.spacketExplosionMotionY.set(sPacketExplosion, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketPlayerPitch(final CPacketPlayer cPacketPlayer, final float n) {
        try {
            ReflectionHelper.cpacketPlayerPitch.set(cPacketPlayer, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setPressed(final KeyBinding keyBinding, final boolean b) {
        try {
            ReflectionHelper.pressed.set(keyBinding, b);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static float getPlayerViewX() {
        try {
            return (float)ReflectionHelper.playerViewX.get(Wrapper.getMinecraft().getRenderManager());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSPacketExplosionMotionX(final SPacketExplosion sPacketExplosion, final float n) {
        try {
            ReflectionHelper.spacketExplosionMotionX.set(sPacketExplosion, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static boolean getGuiButtonHovered(final GuiButton guiButton) {
        try {
            return (boolean)ReflectionHelper.guiButtonHovered.get(guiButton);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static double getRenderPosZ() {
        try {
            return (double)ReflectionHelper.renderPosZ.get(Wrapper.getMinecraft().getRenderManager());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSession(final Session session) {
        try {
            ReflectionHelper.session.set(Wrapper.getMinecraft(), session);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketChatMessage(final CPacketChatMessage cPacketChatMessage, final String s) {
        try {
            ReflectionHelper.cPacketChatMessage.set(cPacketChatMessage, s);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static ServerData getServerData(final GuiScreenServerList list) {
        try {
            return (ServerData)ReflectionHelper.guiSceenServerListServerData.get(list);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static double getRenderPosX() {
        try {
            return (double)ReflectionHelper.renderPosX.get(Wrapper.getMinecraft().getRenderManager());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSPacketExplosionMotionZ(final SPacketExplosion sPacketExplosion, final float n) {
        try {
            ReflectionHelper.spacketExplosionMotionZ.set(sPacketExplosion, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static Entity getRidingEntity(final Entity entity) {
        try {
            return (Entity)ReflectionHelper.ridingEntity.get(entity);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSpeedInAir(final EntityPlayer entityPlayer, final float n) {
        try {
            ReflectionHelper.speedInAir.set(entityPlayer, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static Timer getTimer() {
        try {
            return (Timer)ReflectionHelper.timer.get(Wrapper.getMinecraft());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static double getCPacketVehicleMoveY(final CPacketVehicleMove cPacketVehicleMove) {
        try {
            return (double)ReflectionHelper.cpacketVehicleMoveY.get(cPacketVehicleMove);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static int getDebugFps() {
        try {
            return (int)ReflectionHelper.debugFps.get(null);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static boolean getPressed(final KeyBinding keyBinding) {
        try {
            return (boolean)ReflectionHelper.pressed.get(keyBinding);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static double getCPacketPlayerY(final CPacketPlayer cPacketPlayer) {
        try {
            return (double)ReflectionHelper.cpacketPlayerY.get(cPacketPlayer);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void rightClickMouse() {
        try {
            ReflectionHelper.rightClickMouse.invoke(Wrapper.getMinecraft(), new Object[0]);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setHorseJumpPower(final float n) {
        try {
            ReflectionHelper.horseJumpPower.set(Wrapper.getMinecraft().player, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketVehicleMoveY(final CPacketVehicleMove cPacketVehicleMove, final double n) {
        try {
            ReflectionHelper.cpacketVehicleMoveY.set(cPacketVehicleMove, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static float getFoodExhaustionLevel() {
        try {
            return (float)ReflectionHelper.foodExhaustionLevel.get(Wrapper.getMinecraft().player.getFoodStats());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static float getPlayerViewY() {
        try {
            return (float)ReflectionHelper.playerViewY.get(Wrapper.getMinecraft().getRenderManager());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static ModelManager getModelManager() {
        try {
            return (ModelManager)ReflectionHelper.modelManager.get(Wrapper.getMinecraft());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketPlayerYaw(final CPacketPlayer cPacketPlayer, final float n) {
        try {
            ReflectionHelper.cpacketPlayerYaw.set(cPacketPlayer, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static Map<ResourceLocation, ITextureObject> getMapTextureObjects() {
        try {
            return (Map<ResourceLocation, ITextureObject>)ReflectionHelper.mapTextureObjects.get(Wrapper.getMinecraft().getTextureManager());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static int getBlockHitDelay() {
        try {
            return (int)ReflectionHelper.blockHitDelay.get(Wrapper.getMinecraft().playerController);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static Method getMethod(final Class clazz, final String[] array, final Class<?>... array2) {
        final int length = array.length;
        int i = 0;
        while (i < length) {
            final String s = array[i];
            try {
                final Method declaredMethod = clazz.getDeclaredMethod(s, (Class[])array2);
                declaredMethod.setAccessible(true);
                return declaredMethod;
            }
            catch (NoSuchMethodException ex) {
                FMLLog.log.info(String.valueOf(new StringBuilder().append("unable to find method: ").append(s)));
                ++i;
                continue;
            }
            break;
        }
        throw new IllegalStateException(String.valueOf(new StringBuilder().append("Method with names: ").append(array).append(" not found!")));
    }
    
    public static void setY_vec3d(final Vec3d vec3d, final double n) {
        try {
            ReflectionHelper.y_vec3d.set(vec3d, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setBlockHitDelay(final float n) {
        try {
            ReflectionHelper.blockHitDelay.set(Wrapper.getMinecraft().playerController, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void init() {
        try {
            ReflectionHelper.renderPosX = getField(RenderManager.class, "renderPosX", "renderPosX");
            ReflectionHelper.renderPosY = getField(RenderManager.class, "renderPosY", "renderPosY");
            ReflectionHelper.renderPosZ = getField(RenderManager.class, "renderPosZ", "renderPosZ");
            ReflectionHelper.playerViewX = getField(RenderManager.class, "playerViewX", "playerViewX");
            ReflectionHelper.playerViewY = getField(RenderManager.class, "playerViewY", "playerViewY");
            ReflectionHelper.timer = getField(Minecraft.class, "timer", "timer");
            ReflectionHelper.modelManager = getField(Minecraft.class, "modelManager", "modelManager");
            ReflectionHelper.rightClickMouse = getMethod(Minecraft.class, new String[] { "rightClickMouse", "rightClickMouse" }, (Class<?>[])new Class[0]);
            ReflectionHelper.pressed = getField(KeyBinding.class, "pressed", "pressed");
            ReflectionHelper.cpacketPlayerYaw = getField(CPacketPlayer.class, "yaw", "yaw");
            ReflectionHelper.cpacketPlayerPitch = getField(CPacketPlayer.class, "pitch", "pitch");
            ReflectionHelper.spacketPlayerPosLookYaw = getField(SPacketPlayerPosLook.class, "yaw", "yaw");
            ReflectionHelper.spacketPlayerPosLookPitch = getField(SPacketPlayerPosLook.class, "pitch", "pitch");
            ReflectionHelper.mapTextureObjects = getField(TextureManager.class, "mapTextureObjects", "mapTextureObjects");
            ReflectionHelper.cpacketPlayerOnGround = getField(CPacketPlayer.class, "onGround", "onGround");
            ReflectionHelper.rightClickDelayTimer = getField(Minecraft.class, "rightClickDelayTimer", "rightClickDelayTimer");
            ReflectionHelper.horseJumpPower = getField(EntityPlayerSP.class, "horseJumpPower", "horseJumpPower");
            ReflectionHelper.curBlockDamageMP = getField(PlayerControllerMP.class, "curBlockDamageMP", "curBlockDamageMP");
            ReflectionHelper.blockHitDelay = getField(PlayerControllerMP.class, "blockHitDelay", "blockHitDelay");
            ReflectionHelper.debugFps = getField(Minecraft.class, "debugFPS", "debugFPS");
            ReflectionHelper.lowerChestInventory = getField(GuiChest.class, "lowerChestInventory", "lowerChestInventory");
            ReflectionHelper.shulkerInventory = getField(GuiShulkerBox.class, "inventory", "field_190779_v");
            ReflectionHelper.spacketExplosionMotionX = getField(SPacketExplosion.class, "motionX", "motionX");
            ReflectionHelper.spacketExplosionMotionY = getField(SPacketExplosion.class, "motionY", "motionY");
            ReflectionHelper.spacketExplosionMotionZ = getField(SPacketExplosion.class, "motionZ", "motionZ");
            ReflectionHelper.cpacketPlayerY = getField(CPacketPlayer.class, "y", "y");
            ReflectionHelper.cpacketVehicleMoveY = getField(CPacketVehicleMove.class, "y", "y");
            ReflectionHelper.session = getField(Minecraft.class, "session", "session");
            ReflectionHelper.PLAYER_MODEL_FLAG = getField(EntityPlayer.class, "PLAYER_MODEL_FLAG", "PLAYER_MODEL_FLAG");
            ReflectionHelper.speedInAir = getField(EntityPlayer.class, "speedInAir", "speedInAir");
            ReflectionHelper.guiButtonHovered = getField(GuiButton.class, "hovered", "hovered");
            ReflectionHelper.ridingEntity = getField(Entity.class, "ridingEntity", "ridingEntity");
            ReflectionHelper.foodExhaustionLevel = getField(FoodStats.class, "foodExhaustionLevel", "foodExhaustionLevel");
            ReflectionHelper.cPacketUpdateSignLines = getField(CPacketUpdateSign.class, "lines", "lines");
            ReflectionHelper.hopperInventory = getField(GuiHopper.class, "hopperInventory", "hopperInventory");
            ReflectionHelper.cPacketChatMessage = getField(CPacketChatMessage.class, "message", "message");
            ReflectionHelper.guiSceenServerListServerData = getField(GuiScreenServerList.class, "serverData", "serverData");
            ReflectionHelper.guiDisconnectedParentScreen = getField(GuiDisconnected.class, "parentScreen", "parentScreen");
            ReflectionHelper.sPacketChatChatComponent = getField(SPacketChat.class, "chatComponent", "chatComponent");
            ReflectionHelper.boundingBox = getField(Entity.class, "boundingBox", "chatComponent");
            ReflectionHelper.y_vec3d = getField(Vec3d.class, "y", "yCoord", "c");
            ReflectionHelper.sleeping = getField(EntityPlayer.class, "sleeping", "sleeping", "bK");
            ReflectionHelper.sleepTimer = getField(EntityPlayer.class, "sleepTimer", "sleepTimer");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static void sleepTimer(final EntityPlayer entityPlayer, final int n) {
        try {
            ReflectionHelper.sleeping.set(entityPlayer, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static Field getField(final Class clazz, final String... array) {
        for (final String s : array) {
            try {
                final Field declaredField = clazz.getDeclaredField(s);
                declaredField.setAccessible(true);
                ReflectionHelper.modifiersField.setInt(declaredField, declaredField.getModifiers() & 0xFFFFFFEF);
                return declaredField;
            }
            catch (NoSuchFieldException ex) {
                FMLLog.log.info(String.valueOf(new StringBuilder().append("unable to find field: ").append(s)));
            }
            catch (IllegalAccessException ex2) {
                FMLLog.log.info("unable to make field changeable!");
            }
        }
        throw new IllegalStateException(String.valueOf(new StringBuilder().append("Field with names: ").append(array).append(" not found!")));
    }
    
    public static void setSleeping(final EntityPlayer entityPlayer, final boolean b) {
        try {
            ReflectionHelper.sleeping.set(entityPlayer, b);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static float getCurBlockDamageMP() {
        try {
            return (float)ReflectionHelper.curBlockDamageMP.get(Wrapper.getMinecraft().playerController);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketPlayerY(final CPacketPlayer cPacketPlayer, final double n) {
        try {
            ReflectionHelper.cpacketPlayerY.set(cPacketPlayer, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSPacketChatChatComponent(final SPacketChat sPacketChat, final TextComponentString textComponentString) {
        try {
            ReflectionHelper.sPacketChatChatComponent.set(sPacketChat, textComponentString);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static double getRenderPosY() {
        try {
            return (double)ReflectionHelper.renderPosY.get(Wrapper.getMinecraft().getRenderManager());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCurBlockDamageMP(final float n) {
        try {
            ReflectionHelper.curBlockDamageMP.set(Wrapper.getMinecraft().playerController, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static DataParameter<Byte> getPLAYER_MODEL_FLAG() {
        try {
            return (DataParameter<Byte>)ReflectionHelper.PLAYER_MODEL_FLAG.get(null);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static IInventory getShulkerInventory(final GuiShulkerBox guiShulkerBox) {
        try {
            return (IInventory)ReflectionHelper.shulkerInventory.get(guiShulkerBox);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketUpdateSignLines(final CPacketUpdateSign cPacketUpdateSign, final String[] array) {
        try {
            ReflectionHelper.cPacketUpdateSignLines.set(cPacketUpdateSign, array);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setRightClickDelayTimer(final int n) {
        try {
            ReflectionHelper.rightClickDelayTimer.set(Wrapper.getMinecraft(), n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSPacketPlayerPosLookPitch(final float n, final SPacketPlayerPosLook sPacketPlayerPosLook) {
        try {
            ReflectionHelper.spacketPlayerPosLookPitch.set(sPacketPlayerPosLook, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    static {
        try {
            (ReflectionHelper.modifiersField = Field.class.getDeclaredField("modifiers")).setAccessible(true);
        }
        catch (Exception ex) {}
    }
    
    public static IInventory getLowerChestInventory(final GuiChest guiChest) {
        try {
            return (IInventory)ReflectionHelper.lowerChestInventory.get(guiChest);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setSPacketPlayerPosLookYaw(final float n, final SPacketPlayerPosLook sPacketPlayerPosLook) {
        try {
            ReflectionHelper.spacketPlayerPosLookYaw.set(sPacketPlayerPosLook, n);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setGuiButtonHovered(final GuiButton guiButton, final boolean b) {
        try {
            ReflectionHelper.guiButtonHovered.set(guiButton, b);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static float getSpeedInAir(final EntityPlayer entityPlayer) {
        try {
            return (float)ReflectionHelper.speedInAir.get(entityPlayer);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static void setCPacketPlayerOnGround(final CPacketPlayer cPacketPlayer, final boolean b) {
        try {
            ReflectionHelper.cpacketPlayerOnGround.set(cPacketPlayer, b);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
    
    public static GuiScreen getGuiDisconnectedParentScreen(final GuiDisconnected guiDisconnected) {
        try {
            return (GuiScreen)ReflectionHelper.guiDisconnectedParentScreen.get(guiDisconnected);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw new IllegalStateException(ex);
        }
    }
}
