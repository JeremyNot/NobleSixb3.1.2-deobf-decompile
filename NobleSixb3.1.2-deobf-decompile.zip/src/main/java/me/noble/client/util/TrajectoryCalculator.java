//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.block.material.*;

public class TrajectoryCalculator
{
    public static Vec3d mult(final Vec3d vec3d, final float n) {
        return new Vec3d(vec3d.xCoord * n, vec3d.yCoord * n, vec3d.zCoord * n);
    }
    
    public static double[] interpolate(final Entity entity) {
        return new double[] { interpolate(entity.posX, entity.lastTickPosX) - Wrapper.getMinecraft().renderManager.renderPosX, interpolate(entity.posY, entity.lastTickPosY) - Wrapper.getMinecraft().renderManager.renderPosY, interpolate(entity.posZ, entity.lastTickPosZ) - Wrapper.getMinecraft().renderManager.renderPosZ };
    }
    
    public static Vec3d div(final Vec3d vec3d, final float n) {
        return new Vec3d(vec3d.xCoord / n, vec3d.yCoord / n, vec3d.zCoord / n);
    }
    
    public static ThrowingType getThrowType(final EntityLivingBase entityLivingBase) {
        if (entityLivingBase.getHeldItem(EnumHand.MAIN_HAND).func_190926_b()) {
            return ThrowingType.NONE;
        }
        final ItemStack getHeldItem = entityLivingBase.getHeldItem(EnumHand.MAIN_HAND);
        final Item getItem = getHeldItem.getItem();
        if (getItem instanceof ItemPotion) {
            if (getHeldItem.getItem() instanceof ItemSplashPotion) {
                return ThrowingType.POTION;
            }
        }
        else {
            if (getItem instanceof ItemBow && entityLivingBase.isHandActive()) {
                return ThrowingType.BOW;
            }
            if (getItem instanceof ItemExpBottle) {
                return ThrowingType.EXPERIENCE;
            }
            if (getItem instanceof ItemSnowball || getItem instanceof ItemEgg || getItem instanceof ItemEnderPearl) {
                return ThrowingType.NORMAL;
            }
        }
        return ThrowingType.NONE;
    }
    
    public static double interpolate(final double n, final double n2) {
        return n2 + (n - n2) * Wrapper.getMinecraft().getRenderPartialTicks();
    }
    
    public enum ThrowingType
    {
        EXPERIENCE;
        
        private static final ThrowingType[] $VALUES;
        
        NORMAL, 
        BOW, 
        POTION, 
        NONE;
        
        static {
            $VALUES = new ThrowingType[] { ThrowingType.NONE, ThrowingType.BOW, ThrowingType.EXPERIENCE, ThrowingType.POTION, ThrowingType.NORMAL };
        }
    }
    
    public static final class FlightPath
    {
        private float pitch;
        private Vec3d motion;
        private float yaw;
        private AxisAlignedBB boundingBox;
        public Vec3d position;
        private EntityLivingBase shooter;
        private ThrowingType throwingType;
        private RayTraceResult target;
        private boolean collided;
        
        private void onCollideWithEntity(final Vec3d vec3d, final RayTraceResult target) {
            Entity entity = null;
            double n = 0.0;
            for (final Entity entity2 : this.shooter.world.getEntitiesWithinAABBExcludingEntity((Entity)this.shooter, this.boundingBox.addCoord(this.motion.xCoord, this.motion.yCoord, this.motion.zCoord).addCoord(1.0, 1.0, 1.0))) {
                if (!entity2.canBeCollidedWith() && entity2 != this.shooter) {
                    continue;
                }
                final float getCollisionBorderSize = entity2.getCollisionBorderSize();
                final RayTraceResult calculateIntercept = entity2.getEntityBoundingBox().addCoord((double)getCollisionBorderSize, (double)getCollisionBorderSize, (double)getCollisionBorderSize).calculateIntercept(this.position, vec3d);
                if (calculateIntercept == null) {
                    continue;
                }
                final double distanceTo = this.position.distanceTo(calculateIntercept.hitVec);
                if (distanceTo >= n && n != 0.0) {
                    continue;
                }
                entity = entity2;
                n = distanceTo;
            }
            if (entity != null) {
                this.target = new RayTraceResult(entity);
            }
            else {
                this.target = target;
            }
        }
        
        private void setPosition(final Vec3d vec3d) {
            this.position = new Vec3d(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
            final double n = ((this.throwingType == ThrowingType.BOW) ? 0.5 : 0.25) / 2.0;
            this.boundingBox = new AxisAlignedBB(vec3d.xCoord - n, vec3d.yCoord - n, vec3d.zCoord - n, vec3d.xCoord + n, vec3d.yCoord + n, vec3d.zCoord + n);
        }
        
        public RayTraceResult getCollidingTarget() {
            return this.target;
        }
        
        private float getInitialVelocity() {
            final Item getItem = this.shooter.getHeldItem(EnumHand.MAIN_HAND).getItem();
            switch (this.throwingType) {
                case BOW: {
                    final float n = (((ItemBow)getItem).getMaxItemUseDuration(this.shooter.getHeldItem(EnumHand.MAIN_HAND)) - this.shooter.getItemInUseCount()) / 20.0f;
                    float n2 = (n * n + n * 2.0f) / 3.0f;
                    if (n2 > 1.0f) {
                        n2 = 1.0f;
                    }
                    return n2 * 2.0f * 1.5f;
                }
                case POTION: {
                    return 0.5f;
                }
                case EXPERIENCE: {
                    return 0.7f;
                }
                case NORMAL: {
                    return 1.5f;
                }
                default: {
                    return 1.5f;
                }
            }
        }
        
        private float getGravityVelocity() {
            switch (this.throwingType) {
                case BOW:
                case POTION: {
                    return 0.05f;
                }
                case EXPERIENCE: {
                    return 0.07f;
                }
                case NORMAL: {
                    return 0.03f;
                }
                default: {
                    return 0.03f;
                }
            }
        }
        
        public FlightPath(final EntityLivingBase shooter, final ThrowingType throwingType) {
            this.shooter = shooter;
            this.throwingType = throwingType;
            final double[] interpolate = TrajectoryCalculator.interpolate((Entity)this.shooter);
            this.setLocationAndAngles(interpolate[0] + Wrapper.getMinecraft().getRenderManager().renderPosX, interpolate[1] + this.shooter.getEyeHeight() + Wrapper.getMinecraft().getRenderManager().renderPosY, interpolate[2] + Wrapper.getMinecraft().getRenderManager().renderPosZ, this.shooter.rotationYaw, this.shooter.rotationPitch);
            this.setPosition(this.position = this.position.subtract(new Vec3d((double)(MathHelper.cos(this.yaw / 180.0f * 3.1415927f) * 0.16f), 0.1, (double)(MathHelper.sin(this.yaw / 180.0f * 3.1415927f) * 0.16f))));
            this.setThrowableHeading(this.motion = new Vec3d((double)(-MathHelper.sin(this.yaw / 180.0f * 3.1415927f) * MathHelper.cos(this.pitch / 180.0f * 3.1415927f)), (double)(-MathHelper.sin(this.pitch / 180.0f * 3.1415927f)), (double)(MathHelper.cos(this.yaw / 180.0f * 3.1415927f) * MathHelper.cos(this.pitch / 180.0f * 3.1415927f))), this.getInitialVelocity());
        }
        
        public boolean isCollided() {
            return this.collided;
        }
        
        private void setThrowableHeading(final Vec3d vec3d, final float n) {
            this.motion = TrajectoryCalculator.div(vec3d, (float)vec3d.lengthVector());
            this.motion = TrajectoryCalculator.mult(this.motion, n);
        }
        
        private void setLocationAndAngles(final double n, final double n2, final double n3, final float yaw, final float pitch) {
            this.position = new Vec3d(n, n2, n3);
            this.yaw = yaw;
            this.pitch = pitch;
        }
        
        public void onUpdate() {
            Vec3d vec3d = this.position.add(this.motion);
            final RayTraceResult rayTraceBlocks = this.shooter.getEntityWorld().rayTraceBlocks(this.position, vec3d, false, true, false);
            if (rayTraceBlocks != null) {
                vec3d = rayTraceBlocks.hitVec;
            }
            this.onCollideWithEntity(vec3d, rayTraceBlocks);
            if (this.target != null) {
                this.collided = true;
                this.setPosition(this.target.hitVec);
                return;
            }
            if (this.position.yCoord <= 0.0) {
                this.collided = true;
                return;
            }
            this.position = this.position.add(this.motion);
            float n = 0.99f;
            if (this.shooter.getEntityWorld().isMaterialInBB(this.boundingBox, Material.WATER)) {
                n = ((this.throwingType == ThrowingType.BOW) ? 0.6f : 0.8f);
            }
            this.motion = TrajectoryCalculator.mult(this.motion, n);
            this.motion = this.motion.subtract(0.0, (double)this.getGravityVelocity(), 0.0);
            this.setPosition(this.position);
        }
    }
}
