//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.text.*;
import java.util.*;

public class TimeUtil
{
    public static String time(final SimpleDateFormat simpleDateFormat) {
        return simpleDateFormat.format(new Date(System.currentTimeMillis()));
    }
    
    public static String getFinalTime(final ColourUtils.ColourCode colourCode, final ColourUtils.ColourCode colourCode2, final TimeUnit timeUnit, final TimeType timeType, final Boolean b) {
        final String value = String.valueOf(new StringBuilder().append(ColourUtils.getStringColour(colourCode)).append(":").append(ColourUtils.getStringColour(colourCode2)));
        String s = "";
        final String time = time(dateFormatter(TimeUnit.h24, TimeType.HH));
        if (timeUnit == TimeUnit.h12 && b) {
            if (Integer.parseInt(time) - 12 >= 0) {
                s = "pm";
            }
            else {
                s = "am";
            }
        }
        return String.valueOf(new StringBuilder().append(ColourUtils.getStringColour(colourCode2)).append(time(dateFormatter(timeUnit, timeType)).replace(":", value)).append(ColourUtils.getStringColour(colourCode)).append(s));
    }
    
    public static SimpleDateFormat dateFormatter(final TimeUnit timeUnit, final TimeType timeType) {
        SimpleDateFormat simpleDateFormat = null;
        switch (timeUnit) {
            case h12: {
                simpleDateFormat = new SimpleDateFormat(String.valueOf(new StringBuilder().append("hh").append(formatTimeString(timeType))), Locale.UK);
                break;
            }
            case h24: {
                simpleDateFormat = new SimpleDateFormat(String.valueOf(new StringBuilder().append("HH").append(formatTimeString(timeType))), Locale.UK);
                break;
            }
            default: {
                throw new IllegalStateException(String.valueOf(new StringBuilder().append("Unexpected value: ").append(timeUnit)));
            }
        }
        return simpleDateFormat;
    }
    
    private static String formatTimeString(final TimeType timeType) {
        switch (timeType) {
            case HHMM: {
                return ":mm";
            }
            case HHMMSS: {
                return ":mm:ss";
            }
            default: {
                return "";
            }
        }
    }
    
    public enum TimeUnit
    {
        h12, 
        h24;
        
        private static final TimeUnit[] $VALUES;
        
        static {
            $VALUES = new TimeUnit[] { TimeUnit.h24, TimeUnit.h12 };
        }
    }
    
    public enum TimeType
    {
        HH;
        
        private static final TimeType[] $VALUES;
        
        HHMMSS, 
        HHMM;
        
        static {
            $VALUES = new TimeType[] { TimeType.HHMM, TimeType.HHMMSS, TimeType.HH };
        }
    }
}
