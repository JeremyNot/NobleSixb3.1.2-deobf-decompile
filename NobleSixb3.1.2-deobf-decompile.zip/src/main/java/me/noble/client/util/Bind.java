//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import org.lwjgl.input.*;
import me.noble.client.command.commands.*;

public class Bind
{
    boolean ctrl;
    int key;
    boolean alt;
    boolean shift;
    
    public Bind(final boolean ctrl, final boolean alt, final boolean shift, final int key) {
        this.ctrl = ctrl;
        this.alt = alt;
        this.shift = shift;
        this.key = key;
    }
    
    public static boolean isShiftDown() {
        return Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54);
    }
    
    public static Bind none() {
        return new Bind(false, false, false, -1);
    }
    
    public static boolean isCtrlDown() {
        return Keyboard.isKeyDown(29) || Keyboard.isKeyDown(157);
    }
    
    public void setShift(final boolean shift) {
        this.shift = shift;
    }
    
    public boolean isDown(final int n) {
        return !this.isEmpty() && (!(boolean)BindCommand.modifiersEnabled.getValue() || (this.isShift() == isShiftDown() && this.isCtrl() == isCtrlDown() && this.isAlt() == isAltDown())) && n == this.getKey();
    }
    
    @Override
    public String toString() {
        return this.isEmpty() ? "None" : String.valueOf(new StringBuilder().append(this.isCtrl() ? "Ctrl+" : "").append(this.isAlt() ? "Alt+" : "").append(this.isShift() ? "Shift+" : "").append((this.key < 0) ? "None" : this.capitalise(Keyboard.getKeyName(this.key))));
    }
    
    public String capitalise(final String s) {
        if (s.isEmpty()) {
            return "";
        }
        return String.valueOf(new StringBuilder().append(Character.toUpperCase(s.charAt(0))).append((s.length() != 1) ? s.substring(1).toLowerCase() : ""));
    }
    
    public int getKey() {
        return this.key;
    }
    
    public static boolean isAltDown() {
        return Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184);
    }
    
    public void setAlt(final boolean alt) {
        this.alt = alt;
    }
    
    public void setKey(final int key) {
        this.key = key;
    }
    
    public boolean isCtrl() {
        return this.ctrl;
    }
    
    public boolean isEmpty() {
        return !this.ctrl && !this.shift && !this.alt && this.key < 0;
    }
    
    public void setCtrl(final boolean ctrl) {
        this.ctrl = ctrl;
    }
    
    public boolean isAlt() {
        return this.alt;
    }
    
    public boolean isShift() {
        return this.shift;
    }
}
