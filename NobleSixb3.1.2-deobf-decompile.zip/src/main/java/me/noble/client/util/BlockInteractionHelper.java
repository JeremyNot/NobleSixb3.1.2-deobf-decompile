//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import net.minecraft.client.*;
import net.minecraft.block.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.init.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.block.state.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

public class BlockInteractionHelper
{
    private static final Minecraft mc;
    public static final List<Block> blackList;
    public static final List<Block> shulkerList;
    
    private static boolean hasNeighbour(final BlockPos blockPos) {
        final EnumFacing[] values = EnumFacing.values();
        for (int length = values.length, i = 0; i < length; ++i) {
            if (!Wrapper.getWorld().getBlockState(blockPos.offset(values[i])).getMaterial().isReplaceable()) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean canBeClicked(final BlockPos blockPos) {
        return getBlock(blockPos).canCollideCheck(getState(blockPos), false);
    }
    
    public static boolean hotbarSlotCheckEmpty(final ItemStack itemStack) {
        return itemStack != ItemStack.field_190927_a;
    }
    
    private static PlayerControllerMP getPlayerController() {
        return Minecraft.getMinecraft().playerController;
    }
    
    private static Vec3d getEyesPos() {
        return new Vec3d(Wrapper.getPlayer().posX, Wrapper.getPlayer().posY + Wrapper.getPlayer().getEyeHeight(), Wrapper.getPlayer().posZ);
    }
    
    static {
        blackList = Arrays.asList(Blocks.ENDER_CHEST, (Block)Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.CRAFTING_TABLE, Blocks.ANVIL, Blocks.BREWING_STAND, (Block)Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER, Blocks.TRAPDOOR, Blocks.ENCHANTING_TABLE);
        shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        mc = Minecraft.getMinecraft();
    }
    
    public static float[] calcAngle(final Vec3d vec3d, final Vec3d vec3d2) {
        final double n = vec3d2.xCoord - vec3d.xCoord;
        final double n2 = (vec3d2.yCoord - vec3d.yCoord) * -1.0;
        final double n3 = vec3d2.zCoord - vec3d.zCoord;
        return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(n3, n)) - 90.0), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(n2, MathHelper.sqrt(n * n + n3 * n3)))) };
    }
    
    public static List<BlockPos> getCircle(final BlockPos blockPos, final int n, final float n2, final boolean b) {
        final ArrayList<BlockPos> list = new ArrayList<BlockPos>();
        final int getX = blockPos.getX();
        final int getZ = blockPos.getZ();
        for (int n3 = getX - (int)n2; n3 <= getX + n2; ++n3) {
            for (int n4 = getZ - (int)n2; n4 <= getZ + n2; ++n4) {
                final double n5 = (getX - n3) * (getX - n3) + (getZ - n4) * (getZ - n4);
                if (n5 < n2 * n2 && (!b || n5 >= (n2 - 1.0f) * (n2 - 1.0f))) {
                    list.add(new BlockPos(n3, n, n4));
                }
            }
        }
        return list;
    }
    
    public static boolean checkForNeighbours(final BlockPos blockPos) {
        if (!hasNeighbour(blockPos)) {
            final EnumFacing[] values = EnumFacing.values();
            for (int length = values.length, i = 0; i < length; ++i) {
                if (hasNeighbour(blockPos.offset(values[i]))) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }
    
    public static EnumFacing getPlaceableSide(final BlockPos blockPos) {
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            if (BlockInteractionHelper.mc.world.getBlockState(offset).getBlock().canCollideCheck(BlockInteractionHelper.mc.world.getBlockState(offset), false)) {
                if (!BlockInteractionHelper.mc.world.getBlockState(offset).getMaterial().isReplaceable()) {
                    return enumFacing;
                }
            }
        }
        return null;
    }
    
    private static float[] getLegitRotations(final Vec3d vec3d) {
        final Vec3d eyesPos = getEyesPos();
        final double n = vec3d.xCoord - eyesPos.xCoord;
        final double n2 = vec3d.yCoord - eyesPos.yCoord;
        final double n3 = vec3d.zCoord - eyesPos.zCoord;
        return new float[] { Wrapper.getPlayer().rotationYaw + MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2(n3, n)) - 90.0f - Wrapper.getPlayer().rotationYaw), Wrapper.getPlayer().rotationPitch + MathHelper.wrapDegrees((float)(-Math.toDegrees(Math.atan2(n2, Math.sqrt(n * n + n3 * n3)))) - Wrapper.getPlayer().rotationPitch) };
    }
    
    public static void placeBlockScaffold(final BlockPos blockPos) {
        final Vec3d vec3d = new Vec3d(Wrapper.getPlayer().posX, Wrapper.getPlayer().posY + Wrapper.getPlayer().getEyeHeight(), Wrapper.getPlayer().posZ);
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos offset = blockPos.offset(enumFacing);
            final EnumFacing getOpposite = enumFacing.getOpposite();
            if (canBeClicked(offset)) {
                final Vec3d add = new Vec3d((Vec3i)offset).addVector(0.5, 0.5, 0.5).add(new Vec3d(getOpposite.getDirectionVec()).scale(0.5));
                if (vec3d.squareDistanceTo(add) <= 18.0625) {
                    faceVectorPacketInstant(add);
                    processRightClickBlock(offset, getOpposite, add);
                    Wrapper.getPlayer().swingArm(EnumHand.MAIN_HAND);
                    BlockInteractionHelper.mc.rightClickDelayTimer = 4;
                    return;
                }
            }
        }
    }
    
    public static boolean blockCheckNonBlock(final ItemStack itemStack) {
        return itemStack.getItem() instanceof ItemBlock;
    }
    
    public static List<BlockPos> getSphere(final BlockPos blockPos, final float n, final int n2, final boolean b, final boolean b2, final int n3) {
        final ArrayList<BlockPos> list = new ArrayList<BlockPos>();
        final int getX = blockPos.getX();
        final int getY = blockPos.getY();
        final int getZ = blockPos.getZ();
        for (int n4 = getX - (int)n; n4 <= getX + n; ++n4) {
            for (int n5 = getZ - (int)n; n5 <= getZ + n; ++n5) {
                for (int n6 = b2 ? (getY - (int)n) : getY; n6 < (b2 ? (getY + n) : ((float)(getY + n2))); ++n6) {
                    final double n7 = (getX - n4) * (getX - n4) + (getZ - n5) * (getZ - n5) + (b2 ? ((getY - n6) * (getY - n6)) : 0);
                    if (n7 < n * n && (!b || n7 >= (n - 1.0f) * (n - 1.0f))) {
                        list.add(new BlockPos(n4, n6 + n3, n5));
                    }
                }
            }
        }
        return list;
    }
    
    private static Block getBlock(final BlockPos blockPos) {
        return getState(blockPos).getBlock();
    }
    
    private static void processRightClickBlock(final BlockPos blockPos, final EnumFacing enumFacing, final Vec3d vec3d) {
        getPlayerController().processRightClickBlock(Wrapper.getPlayer(), BlockInteractionHelper.mc.world, blockPos, enumFacing, vec3d, EnumHand.MAIN_HAND);
    }
    
    private static IBlockState getState(final BlockPos blockPos) {
        return Wrapper.getWorld().getBlockState(blockPos);
    }
    
    public static void faceVectorPacketInstant(final Vec3d vec3d) {
        final float[] legitRotations = getLegitRotations(vec3d);
        Wrapper.getPlayer().connection.sendPacket((Packet)new CPacketPlayer.Rotation(legitRotations[0], legitRotations[1], Wrapper.getPlayer().onGround));
    }
}
