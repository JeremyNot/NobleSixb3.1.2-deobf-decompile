//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.nio.charset.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;

public class FileHelper
{
    public static List<String> readTextFileAllLines(final String s) {
        try {
            return Files.readAllLines(Paths.get(s, new String[0]), StandardCharsets.UTF_8);
        }
        catch (IOException ex) {
            System.out.println(String.valueOf(new StringBuilder().append("WARNING: Unable to read file, creating new file: ").append(s)));
            appendTextFile("", s);
            return Collections.emptyList();
        }
    }
    
    public static boolean appendTextFile(final String s, final String s2) {
        try {
            final Path value = Paths.get(s2, new String[0]);
            Files.write(value, Collections.singletonList(s), StandardCharsets.UTF_8, Files.exists(value, new LinkOption[0]) ? StandardOpenOption.APPEND : StandardOpenOption.CREATE);
        }
        catch (IOException ex) {
            System.out.println(String.valueOf(new StringBuilder().append("WARNING: Unable to write file: ").append(s2)));
            return false;
        }
        return true;
    }
}
