//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import me.noble.client.setting.*;
import com.google.common.base.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.*;
import java.net.*;
import java.io.*;
import com.google.gson.*;

public class Friends
{
    public static final Friends INSTANCE;
    public static Setting<ArrayList<Friend>> friends;
    
    private Friends() {
    }
    
    public static void initFriends() {
        Friends.friends = (Setting<ArrayList<Friend>>)Settings.custom("Friends", (Object)new ArrayList(), (Converter)new FriendListConverter()).buildAndRegister("friends");
    }
    
    private static boolean lambda$isFriend$0(final String s, final Friend friend) {
        return friend.username.equalsIgnoreCase(s);
    }
    
    static {
        INSTANCE = new Friends();
    }
    
    public static boolean isFriend(final String s) {
        return ((ArrayList)Friends.friends.getValue()).stream().anyMatch(Friends::lambda$isFriend$0);
    }
    
    public static class FriendListConverter extends Converter<ArrayList<Friend>, JsonElement>
    {
        protected Object doBackward(final Object o) {
            return this.doBackward((JsonElement)o);
        }
        
        protected JsonElement doForward(final ArrayList<Friend> list) {
            final StringBuilder sb = new StringBuilder();
            for (final Friend friend : list) {
                sb.append(String.format("%s;%s$", friend.username, friend.uuid.toString()));
            }
            return (JsonElement)new JsonPrimitive(String.valueOf(sb));
        }
        
        protected ArrayList<Friend> doBackward(final JsonElement jsonElement) {
            final String[] split = jsonElement.getAsString().split(Pattern.quote("$"));
            final ArrayList<Friend> list = new ArrayList<Friend>();
            for (final String s : split) {
                try {
                    final String[] split2 = s.split(";");
                    final String s2 = split2[0];
                    final UUID fromString = UUID.fromString(split2[1]);
                    list.add(new Friend(this.getUsernameByUUID(fromString, s2), fromString));
                }
                catch (Exception ex) {}
            }
            return list;
        }
        
        private static String getSource(final String s) {
            try {
                final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(s).openConnection().getInputStream()));
                final StringBuilder sb = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }
                bufferedReader.close();
                return String.valueOf(sb);
            }
            catch (Exception ex) {
                return null;
            }
        }
        
        private String getUsernameByUUID(final UUID uuid, final String s) {
            final String source = getSource(String.valueOf(new StringBuilder().append("https://sessionserver.mojang.com/session/minecraft/profile/").append(uuid.toString())));
            if (source == null || source.isEmpty()) {
                return s;
            }
            try {
                return new JsonParser().parse(source).getAsJsonObject().get("name").getAsString();
            }
            catch (Exception ex) {
                ex.printStackTrace();
                System.err.println(source);
                return s;
            }
        }
        
        protected Object doForward(final Object o) {
            return this.doForward((ArrayList<Friend>)o);
        }
    }
    
    public static class Friend
    {
        String username;
        UUID uuid;
        
        public Friend(final String username, final UUID uuid) {
            this.username = username;
            this.uuid = uuid;
        }
        
        public String getUsername() {
            return this.username;
        }
    }
}
