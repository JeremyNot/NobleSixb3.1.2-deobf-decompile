//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import me.noble.client.gui.rgui.render.font.*;
import net.minecraft.client.*;
import net.minecraft.world.*;
import org.lwjgl.input.*;
import me.noble.client.gui.kami.*;
import net.minecraft.client.entity.*;

public class Wrapper
{
    private static FontRenderer fontRenderer;
    
    public static Minecraft getMinecraft() {
        return Minecraft.getMinecraft();
    }
    
    public static World getWorld() {
        return (World)getMinecraft().world;
    }
    
    public static int getKey(final String s) {
        return Keyboard.getKeyIndex(s.toUpperCase());
    }
    
    public static void init() {
        Wrapper.fontRenderer = (FontRenderer)KamiGUI.fontRenderer;
    }
    
    public static FontRenderer getFontRenderer() {
        return Wrapper.fontRenderer;
    }
    
    public static EntityPlayerSP getPlayer() {
        return getMinecraft().player;
    }
}
