//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.util.*;

public class ChatTextUtils
{
    private static Random rand;
    public static final String SECTIONSIGN;
    public static final String CHAT_SUFFIX;
    
    static {
        CHAT_SUFFIX = " \u23d0 Noble";
        SECTIONSIGN = "��";
        ChatTextUtils.rand = new Random();
    }
    
    public static String appendChatSuffix(String s) {
        s = cropMaxLengthMessage(s, " \u23d0 Noble".length());
        s = String.valueOf(new StringBuilder().append(s).append(" \u23d0 Noble"));
        return cropMaxLengthMessage(s);
    }
    
    public static String cropMaxLengthMessage(String substring, final int n) {
        if (substring.length() > 255 - n) {
            substring = substring.substring(0, 255 - n);
        }
        return substring;
    }
    
    public static String cropMaxLengthMessage(final String s) {
        return cropMaxLengthMessage(s, 0);
    }
    
    public static String transformPlainToFancy(final String s) {
        return s.toLowerCase().replace("a", "\u1d00").replace("b", "\u0299").replace("c", "\u1d04").replace("d", "\u1d05").replace("e", "\u1d07").replace("f", "\u0493").replace("g", "\u0262").replace("h", "\u029c").replace("i", "\u026a").replace("j", "\u1d0a").replace("k", "\u1d0b").replace("l", "\u029f").replace("m", "\u1d0d").replace("n", "\u0274").replace("o", "\u1d0f").replace("p", "\u1d18").replace("q", "\u01eb").replace("r", "\u0280").replace("s", "\u0455").replace("t", "\u1d1b").replace("u", "\u1d1c").replace("v", "\u1d20").replace("w", "\u1d21").replace("x", "\u0445").replace("y", "\u028f").replace("z", "\u1d22");
    }
    
    public static String generateRandomHexSuffix(final int n) {
        final StringBuffer sb = new StringBuffer();
        sb.append("[");
        sb.append(Integer.toHexString((ChatTextUtils.rand.nextInt() + 11) * ChatTextUtils.rand.nextInt()).substring(0, n));
        sb.append(']');
        return sb.toString();
    }
    
    public static String appendChatSuffix(String s, final String s2) {
        s = cropMaxLengthMessage(s, s2.length());
        s = String.valueOf(new StringBuilder().append(s).append(s2));
        return cropMaxLengthMessage(s);
    }
}
