//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.util.*;
import net.minecraft.util.*;

public final class GeometryMasks
{
    public static final HashMap<EnumFacing, Integer> FACEMAP;
    
    static {
        (FACEMAP = new HashMap<EnumFacing, Integer>()).put(EnumFacing.DOWN, 1);
        GeometryMasks.FACEMAP.put(EnumFacing.WEST, 16);
        GeometryMasks.FACEMAP.put(EnumFacing.NORTH, 4);
        GeometryMasks.FACEMAP.put(EnumFacing.SOUTH, 8);
        GeometryMasks.FACEMAP.put(EnumFacing.EAST, 32);
        GeometryMasks.FACEMAP.put(EnumFacing.UP, 2);
    }
    
    public static final class Line
    {
        public static final int DOWN_NORTH;
        public static final int UP_NORTH;
        public static final int DOWN_SOUTH;
        public static final int SOUTH_WEST;
        public static final int NORTH_WEST;
        public static final int DOWN_WEST;
        public static final int UP_SOUTH;
        public static final int UP_EAST;
        public static final int NORTH_EAST;
        public static final int ALL;
        public static final int SOUTH_EAST;
        public static final int UP_WEST;
        public static final int DOWN_EAST;
        
        static {
            NORTH_EAST = 36;
            UP_EAST = 34;
            DOWN_NORTH = 5;
            SOUTH_WEST = 24;
            UP_NORTH = 6;
            DOWN_SOUTH = 9;
            NORTH_WEST = 20;
            SOUTH_EAST = 40;
            DOWN_WEST = 17;
            DOWN_EAST = 33;
            UP_SOUTH = 10;
            ALL = 63;
            UP_WEST = 18;
        }
    }
    
    public static final class Quad
    {
        public static final int DOWN;
        public static final int SOUTH;
        public static final int NORTH;
        public static final int ALL;
        public static final int UP;
        public static final int EAST;
        public static final int WEST;
        
        static {
            SOUTH = 8;
            UP = 2;
            EAST = 32;
            DOWN = 1;
            WEST = 16;
            NORTH = 4;
            ALL = 63;
        }
    }
}
