//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import me.noble.client.module.modules.gui.*;
import java.text.*;
import me.noble.client.module.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;

public class InfoCalculator extends Module
{
    private static InfoOverlay info;
    private static DecimalFormat formatter;
    
    private static double coordsDiff(final String s) {
        switch (s) {
            case "x": {
                return InfoCalculator.mc.player.posX - InfoCalculator.mc.player.prevPosX;
            }
            case "z": {
                return InfoCalculator.mc.player.posZ - InfoCalculator.mc.player.prevPosZ;
            }
            default: {
                return 0.0;
            }
        }
    }
    
    public static double round(final double n, final int n2) {
        final double pow = Math.pow(10.0, n2);
        return Math.round(n * pow) / pow;
    }
    
    public static String memory() {
        return String.valueOf(new StringBuilder().append("").append(Runtime.getRuntime().freeMemory() / 1000000L));
    }
    
    public static String tps() {
        return String.valueOf(new StringBuilder().append("").append(Math.round(LagCompensator.INSTANCE.getTickRate())));
    }
    
    static {
        InfoCalculator.formatter = new DecimalFormat("#.#");
        InfoCalculator.info = (InfoOverlay)ModuleManager.getModuleByName("InfoOverlay");
    }
    
    public static String speed() {
        final float n = InfoCalculator.mc.timer.field_194149_e / 1000.0f;
        if (InfoCalculator.info.useUnitKmH()) {
            return InfoCalculator.formatter.format(MathHelper.sqrt(Math.pow(coordsDiff("x"), 2.0) + Math.pow(coordsDiff("y"), 2.0)) / n * 3.6);
        }
        return InfoCalculator.formatter.format(MathHelper.sqrt(Math.pow(coordsDiff("x"), 2.0) + Math.pow(coordsDiff("y"), 2.0)) / n);
    }
    
    public static int ping() {
        if (InfoCalculator.mc.getConnection() == null) {
            return 1;
        }
        if (InfoCalculator.mc.player == null) {
            return -1;
        }
        try {
            return InfoCalculator.mc.getConnection().getPlayerInfo(InfoCalculator.mc.player.getUniqueID()).getResponseTime();
        }
        catch (NullPointerException ex) {
            return -1;
        }
    }
    
    public static int dura() {
        final ItemStack getHeldItemMainhand = Wrapper.getMinecraft().player.getHeldItemMainhand();
        return getHeldItemMainhand.getMaxDamage() - getHeldItemMainhand.getItemDamage();
    }
}
