//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.util.*;
import java.net.*;
import java.io.*;
import java.util.function.*;

public class CapeManager
{
    private static final String usersPastebin;
    private static HashMap<String, Boolean> capeUsers;
    private static final String ogUsersPastebin;
    
    public static boolean isOg(final UUID uuid) {
        return hasCape(uuid) && CapeManager.capeUsers.get(sanitizeUuid(uuid));
    }
    
    private List<String> getFromPastebin(final String s) {
        URL url;
        try {
            url = new URL(s);
        }
        catch (MalformedURLException ex) {
            ex.printStackTrace();
            return new ArrayList<String>();
        }
        BufferedReader bufferedReader;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
            return new ArrayList<String>();
        }
        final ArrayList<String> list = new ArrayList<String>();
        while (true) {
            String line;
            try {
                if ((line = bufferedReader.readLine()) == null) {
                    break;
                }
            }
            catch (IOException ex3) {
                ex3.printStackTrace();
                return new ArrayList<String>();
            }
            list.add(sanitizeUuidString(line));
        }
        try {
            bufferedReader.close();
        }
        catch (IOException ex4) {
            ex4.printStackTrace();
            return new ArrayList<String>();
        }
        return list;
    }
    
    public static boolean hasCape(final UUID uuid) {
        return CapeManager.capeUsers.containsKey(sanitizeUuid(uuid));
    }
    
    private static String sanitizeUuidString(final String s) {
        return s.replaceAll("-", "").toLowerCase();
    }
    
    private static void lambda$initializeCapes$1(final String s) {
        CapeManager.capeUsers.put(s, true);
    }
    
    public void initializeCapes() {
        this.getFromPastebin("https://pastebin.com/raw/za3hEYdn").forEach(CapeManager::lambda$initializeCapes$0);
        this.getFromPastebin("https://pastebin.com/raw/9H0WwSkw").forEach(CapeManager::lambda$initializeCapes$1);
    }
    
    private static void lambda$initializeCapes$0(final String s) {
        CapeManager.capeUsers.put(s, false);
    }
    
    static {
        usersPastebin = "https://pastebin.com/raw/za3hEYdn";
        ogUsersPastebin = "https://pastebin.com/raw/9H0WwSkw";
    }
    
    public CapeManager() {
        CapeManager.capeUsers = new HashMap<String, Boolean>();
    }
    
    private static String sanitizeUuid(final UUID uuid) {
        return sanitizeUuidString(uuid.toString());
    }
}
