//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import org.lwjgl.opengl.*;
import java.awt.*;

public class HueCycler
{
    int[] cycles;
    int index;
    
    public void reset() {
        this.index = 0;
    }
    
    public void reset(final int index) {
        this.index = index;
    }
    
    public void set() {
        final int n = this.cycles[this.index];
        GL11.glColor3f((n >> 16 & 0xFF) / 255.0f, (n >> 8 & 0xFF) / 255.0f, (n & 0xFF) / 255.0f);
    }
    
    public void setNext() {
        this.next();
    }
    
    public void setNext(final float n) {
        final int next = this.next();
        GL11.glColor4f((next >> 16 & 0xFF) / 255.0f, (next >> 8 & 0xFF) / 255.0f, (next & 0xFF) / 255.0f, n);
    }
    
    public int next() {
        final int n = this.cycles[this.index];
        ++this.index;
        if (this.index >= this.cycles.length) {
            this.index = 0;
        }
        return n;
    }
    
    public int current() {
        return this.cycles[this.index];
    }
    
    public HueCycler(final int n) {
        this.index = 0;
        if (n <= 0) {
            throw new IllegalArgumentException("cycles <= 0");
        }
        this.cycles = new int[n];
        double n2 = 0.0;
        final double n3 = 1.0 / n;
        for (int i = 0; i < n; ++i) {
            this.cycles[i] = Color.HSBtoRGB((float)n2, 1.0f, 1.0f);
            n2 += n3;
        }
    }
}
