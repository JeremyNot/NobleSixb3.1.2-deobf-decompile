//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.awt.*;

public class ColourSet
{
    public static float componentWindowOutlineWidth;
    public static Color checkButtonDownColourToggle;
    public static float componentLineColour;
    public static float[] componentMainWindowArray;
    public static Color checkButtonIdleColourToggle;
    public static Color componentWindowOutline;
    public static float componentUnpinnedColour;
    public static Color componentMainWindow;
    public static float checkButtonBackgroundColourOther;
    public static Color checkButtonBackgroundColour;
    public static Color componentPinnedColour;
    public static Color checkButtonBackgroundColourHover;
    public static Color checkButtonDownColourNormal;
    public static Color checkButtonIdleColourNormal;
    
    static {
        ColourSet.checkButtonBackgroundColour = new Color(ColourConverter.toF(67), ColourConverter.toF(54), ColourConverter.toF(191));
        ColourSet.checkButtonBackgroundColourHover = new Color(ColourConverter.toF(67), ColourConverter.toF(54), ColourConverter.toF(191));
        ColourSet.checkButtonBackgroundColourOther = 0.9f;
        ColourSet.checkButtonIdleColourNormal = new Color(200, 200, 200);
        ColourSet.checkButtonDownColourNormal = new Color(190, 190, 190);
        ColourSet.checkButtonIdleColourToggle = new Color(165, 158, 232);
        ColourSet.checkButtonDownColourToggle = ColourSet.checkButtonIdleColourToggle.brighter();
        ColourSet.componentMainWindow = new Color(0.17f, 0.17f, 0.18f, 0.9f);
        ColourSet.componentWindowOutline = new Color(ColourConverter.toF(116), ColourConverter.toF(101), ColourConverter.toF(247));
        ColourSet.componentWindowOutlineWidth = 1.5f;
        ColourSet.componentPinnedColour = new Color(ColourConverter.toF(165), ColourConverter.toF(41), ColourConverter.toF(255));
        ColourSet.componentUnpinnedColour = ColourConverter.toF(168.3);
        ColourSet.componentLineColour = ColourConverter.toF(112.2);
    }
}
