//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import com.mojang.realmsclient.gui.*;

public class GuiManager
{
    private int moduleListBlue;
    private String textColor;
    private int textRadarPlayers;
    private ModuleListMode moduleListMode;
    private float guiBlue;
    private boolean textRadarPots;
    private float guiGreen;
    private int moduleListGreen;
    private int moduleListRed;
    private float guiRed;
    
    public float getGuiBlue() {
        return this.guiBlue;
    }
    
    public String getTextColor() {
        return this.textColor;
    }
    
    public int getTextRadarPlayers() {
        return this.textRadarPlayers;
    }
    
    public void setTextColor(final String textColor) {
        this.textColor = textColor;
    }
    
    public void setGuiColors(final float guiRed, final float guiGreen, final float guiBlue) {
        this.guiRed = guiRed;
        this.guiGreen = guiGreen;
        this.guiBlue = guiBlue;
    }
    
    public void setTextRadarPots(final boolean textRadarPots) {
        this.textRadarPots = textRadarPots;
    }
    
    public int getModuleListRed() {
        return this.moduleListRed;
    }
    
    public void setModuleListMode(final ModuleListMode moduleListMode) {
        this.moduleListMode = moduleListMode;
    }
    
    public int getModuleListBlue() {
        return this.moduleListBlue;
    }
    
    public float getGuiGreen() {
        return this.guiGreen;
    }
    
    public int getModuleListGreen() {
        return this.moduleListGreen;
    }
    
    public boolean isTextRadarPots() {
        return this.textRadarPots;
    }
    
    public GuiManager() {
        this.guiRed = 0.55f;
        this.guiGreen = 0.7f;
        this.guiBlue = 0.25f;
        this.textColor = ChatFormatting.GRAY.toString();
        this.moduleListMode = ModuleListMode.RAINBOW;
        this.moduleListRed = 60;
        this.moduleListGreen = 255;
        this.moduleListBlue = 60;
        this.textRadarPots = true;
        this.textRadarPlayers = 8;
    }
    
    public float getGuiRed() {
        return this.guiRed;
    }
    
    public void setModuleListColors(final int moduleListRed, final int moduleListGreen, final int moduleListBlue) {
        this.moduleListRed = moduleListRed;
        this.moduleListGreen = moduleListGreen;
        this.moduleListBlue = moduleListBlue;
    }
    
    public ModuleListMode getModuleListMode() {
        return this.moduleListMode;
    }
    
    public void setTextRadarPlayers(final int textRadarPlayers) {
        this.textRadarPlayers = textRadarPlayers;
    }
    
    public enum ModuleListMode
    {
        STATIC;
        
        private static final ModuleListMode[] $VALUES;
        
        RAINBOW;
        
        static {
            $VALUES = new ModuleListMode[] { ModuleListMode.STATIC, ModuleListMode.RAINBOW };
        }
    }
}
