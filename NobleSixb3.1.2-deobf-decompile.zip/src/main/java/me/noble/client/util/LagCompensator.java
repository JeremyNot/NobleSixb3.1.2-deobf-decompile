//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import me.noble.client.event.events.*;
import me.zero.alpine.listener.*;
import java.util.function.*;
import me.noble.client.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.server.*;

public class LagCompensator implements EventListener
{
    public static LagCompensator INSTANCE;
    private final float[] tickRates;
    private long timeLastTimeUpdate;
    private int nextIndex;
    @EventHandler
    Listener<PacketEvent.Receive> packetEventListener;
    
    public LagCompensator() {
        this.tickRates = new float[20];
        this.nextIndex = 0;
        this.packetEventListener = new Listener<PacketEvent.Receive>(LagCompensator::lambda$new$0, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        NobleMod.EVENT_BUS.subscribe(this);
        this.reset();
    }
    
    public void reset() {
        this.nextIndex = 0;
        this.timeLastTimeUpdate = -1L;
        Arrays.fill(this.tickRates, 0.0f);
    }
    
    public void onTimeUpdate() {
        if (this.timeLastTimeUpdate != -1L) {
            this.tickRates[this.nextIndex % this.tickRates.length] = MathHelper.clamp(20.0f / ((System.currentTimeMillis() - this.timeLastTimeUpdate) / 1000.0f), 0.0f, 20.0f);
            ++this.nextIndex;
        }
        this.timeLastTimeUpdate = System.currentTimeMillis();
    }
    
    private static void lambda$new$0(final PacketEvent.Receive receive) {
        if (receive.getPacket() instanceof SPacketTimeUpdate) {
            LagCompensator.INSTANCE.onTimeUpdate();
        }
    }
    
    public float getTickRate() {
        float n = 0.0f;
        float n2 = 0.0f;
        for (final float n3 : this.tickRates) {
            if (n3 > 0.0f) {
                n2 += n3;
                ++n;
            }
        }
        return MathHelper.clamp(n2 / n, 0.0f, 20.0f);
    }
}
