//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.io.*;
import net.minecraft.client.*;

public class LogUtil
{
    public static void writeCoords(final int n, final int n2, final int n3, final String s) {
        try {
            final FileWriter fileWriter = new FileWriter("KAMIBlueCoords.txt");
            fileWriter.write(formatter(n, n2, n3, s));
            fileWriter.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private static String formatter(final int n, final int n2, final int n3, final String s) {
        return String.valueOf(new StringBuilder().append(n).append(", ").append(n2).append(", ").append(n3).append(", ").append(s).append("\n"));
    }
    
    public static void writePlayerCoords(final String s) {
        final Minecraft getMinecraft = Minecraft.getMinecraft();
        writeCoords((int)getMinecraft.player.posX, (int)getMinecraft.player.posY, (int)getMinecraft.player.posZ, s);
    }
}
