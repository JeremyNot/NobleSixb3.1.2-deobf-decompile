//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

public class ColourConverter
{
    public static float toF(final int n) {
        return n / 255.0f;
    }
    
    public static float toF(final double n) {
        return (float)(n / 255.0);
    }
}
