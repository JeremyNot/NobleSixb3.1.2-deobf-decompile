//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

public class Pair<T, S>
{
    T key;
    S value;
    
    public T getKey() {
        return this.key;
    }
    
    public void setKey(final T key) {
        this.key = key;
    }
    
    public S getValue() {
        return this.value;
    }
    
    public void setValue(final S value) {
        this.value = value;
    }
    
    public Pair(final T key, final S value) {
        this.key = key;
        this.value = value;
    }
}
