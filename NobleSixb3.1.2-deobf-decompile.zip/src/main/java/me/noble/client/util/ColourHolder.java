//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import java.awt.*;
import org.lwjgl.opengl.*;

public class ColourHolder
{
    int r;
    int b;
    int g;
    int a;
    
    public ColourHolder(final int r, final int g, final int b) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = 255;
    }
    
    public ColourHolder setB(final int b) {
        this.b = b;
        return this;
    }
    
    public static ColourHolder fromHex(final int n) {
        final ColourHolder colourHolder = new ColourHolder(0, 0, 0);
        colourHolder.becomeHex(n);
        return colourHolder;
    }
    
    public int getB() {
        return this.b;
    }
    
    public int toHex() {
        return toHex(this.r, this.g, this.b);
    }
    
    public int getR() {
        return this.r;
    }
    
    public Color toJavaColour() {
        return new Color(this.r, this.g, this.b, this.a);
    }
    
    public ColourHolder brighter() {
        return new ColourHolder(Math.min(this.r + 10, 255), Math.min(this.g + 10, 255), Math.min(this.b + 10, 255), this.getA());
    }
    
    public int getA() {
        return this.a;
    }
    
    public void becomeHex(final int n) {
        this.setR((n & 0xFF0000) >> 16);
        this.setG((n & 0xFF00) >> 8);
        this.setB(n & 0xFF);
        this.setA(255);
    }
    
    public int getG() {
        return this.g;
    }
    
    public ColourHolder setR(final int r) {
        this.r = r;
        return this;
    }
    
    public ColourHolder clone() {
        return new ColourHolder(this.r, this.g, this.b, this.a);
    }
    
    public void setGLColour() {
        this.setGLColour(-1, -1, -1, -1);
    }
    
    public static int toHex(final int n, final int n2, final int n3) {
        return 0xFF000000 | (n & 0xFF) << 16 | (n2 & 0xFF) << 8 | (n3 & 0xFF);
    }
    
    public ColourHolder setA(final int a) {
        this.a = a;
        return this;
    }
    
    public void becomeGLColour() {
    }
    
    public Object clone() throws CloneNotSupportedException {
        return this.clone();
    }
    
    public void setGLColour(final int n, final int n2, final int n3, final int n4) {
        GL11.glColor4f(((n == -1) ? this.r : n) / 255.0f, ((n2 == -1) ? this.g : n2) / 255.0f, ((n3 == -1) ? this.b : n3) / 255.0f, ((n4 == -1) ? this.a : n4) / 255.0f);
    }
    
    public ColourHolder(final int r, final int g, final int b, final int a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }
    
    public ColourHolder darker() {
        return new ColourHolder(Math.max(this.r - 10, 0), Math.max(this.g - 10, 0), Math.max(this.b - 10, 0), this.getA());
    }
    
    public ColourHolder setG(final int g) {
        this.g = g;
        return this;
    }
}
