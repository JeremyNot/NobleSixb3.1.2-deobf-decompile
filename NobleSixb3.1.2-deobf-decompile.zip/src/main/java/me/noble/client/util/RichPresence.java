//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.util;

import javax.net.ssl.*;
import me.noble.client.*;
import java.net.*;
import com.google.gson.*;
import java.io.*;

public class RichPresence
{
    public static RichPresence INSTANCE;
    public CustomUser[] customUsers;
    
    public RichPresence() {
        RichPresence.INSTANCE = this;
        try {
            final HttpsURLConnection httpsURLConnection = (HttpsURLConnection)new URL(NobleMod.DONATORS_JSON).openConnection();
            httpsURLConnection.connect();
            this.customUsers = (CustomUser[])new Gson().fromJson((Reader)new InputStreamReader(httpsURLConnection.getInputStream()), (Class)CustomUser[].class);
            httpsURLConnection.disconnect();
        }
        catch (Exception ex) {
            NobleMod.log.error("Failed to load donators");
            ex.printStackTrace();
        }
    }
    
    public static class CustomUser
    {
        public String type;
        public String uuid;
    }
}
