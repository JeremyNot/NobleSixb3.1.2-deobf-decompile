//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event.events;

import me.noble.client.event.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.*;

public class RenderEvent extends KamiEvent
{
    private final Tessellator tessellator;
    private final Vec3d renderPos;
    
    public void setTranslation(final Vec3d vec3d) {
        this.getBuffer().setTranslation(-vec3d.xCoord, -vec3d.yCoord, -vec3d.zCoord);
    }
    
    public RenderEvent(final Tessellator tessellator, final Vec3d renderPos) {
        this.tessellator = tessellator;
        this.renderPos = renderPos;
    }
    
    public Tessellator getTessellator() {
        return this.tessellator;
    }
    
    public void resetTranslation() {
        this.setTranslation(this.renderPos);
    }
    
    public Vec3d getRenderPos() {
        return this.renderPos;
    }
    
    public BufferBuilder getBuffer() {
        return this.tessellator.getBuffer();
    }
}
