//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event.events;

import me.noble.client.event.*;
import net.minecraft.network.play.server.*;
import net.minecraft.world.chunk.*;

public class ChunkEvent extends KamiEvent
{
    private SPacketChunkData packet;
    private Chunk chunk;
    
    public Chunk getChunk() {
        return this.chunk;
    }
    
    public SPacketChunkData getPacket() {
        return this.packet;
    }
    
    public ChunkEvent(final Chunk chunk, final SPacketChunkData packet) {
        this.chunk = chunk;
        this.packet = packet;
    }
}
