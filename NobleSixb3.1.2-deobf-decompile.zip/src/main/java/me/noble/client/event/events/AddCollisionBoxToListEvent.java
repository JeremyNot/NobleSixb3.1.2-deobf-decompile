//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event.events;

import me.noble.client.event.*;
import net.minecraft.block.*;
import net.minecraft.block.state.*;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;

public class AddCollisionBoxToListEvent extends KamiEvent
{
    private final Block block;
    private final IBlockState state;
    private final AxisAlignedBB entityBox;
    private final List<AxisAlignedBB> collidingBoxes;
    private final boolean bool;
    private final Entity entity;
    private final World world;
    private final BlockPos pos;
    
    public Block getBlock() {
        return this.block;
    }
    
    public AddCollisionBoxToListEvent(final Block block, final IBlockState state, final World world, final BlockPos pos, final AxisAlignedBB entityBox, final List<AxisAlignedBB> collidingBoxes, final Entity entity, final boolean bool) {
        this.block = block;
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.entityBox = entityBox;
        this.collidingBoxes = collidingBoxes;
        this.entity = entity;
        this.bool = bool;
    }
    
    public World getWorld() {
        return this.world;
    }
    
    public List<AxisAlignedBB> getCollidingBoxes() {
        return this.collidingBoxes;
    }
    
    public boolean isBool() {
        return this.bool;
    }
    
    public Entity getEntity() {
        return this.entity;
    }
    
    public BlockPos getPos() {
        return this.pos;
    }
    
    public IBlockState getState() {
        return this.state;
    }
    
    public AxisAlignedBB getEntityBox() {
        return this.entityBox;
    }
}
