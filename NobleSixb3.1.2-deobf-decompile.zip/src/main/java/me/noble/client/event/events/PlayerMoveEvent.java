//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event.events;

import me.noble.client.event.*;
import net.minecraft.entity.*;

public class PlayerMoveEvent extends KamiEvent
{
    private double z;
    private double x;
    private double y;
    private MoverType type;
    
    public double getY() {
        return this.y;
    }
    
    public void setType(final MoverType type) {
        this.type = type;
    }
    
    public void setZ(final double z) {
        this.z = z;
    }
    
    public PlayerMoveEvent(final MoverType type, final double x, final double y, final double z) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public MoverType getType() {
        return this.type;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
}
