//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event;

import me.noble.client.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.kami.*;
import me.noble.client.command.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.client.*;
import me.noble.client.event.events.*;
import java.util.function.*;
import me.noble.client.command.commands.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.inventory.*;
import net.minecraftforge.event.world.*;
import me.noble.client.module.*;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.entity.*;
import me.noble.client.gui.rgui.component.container.*;
import net.minecraftforge.fml.common.gameevent.*;
import org.lwjgl.input.*;
import net.minecraft.client.gui.*;
import net.minecraft.entity.passive.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.*;
import me.noble.client.util.*;
import me.noble.client.module.modules.render.*;
import net.minecraftforge.client.event.*;

public class ForgeEventProcessor
{
    private int displayWidth;
    private int displayHeight;
    
    @SubscribeEvent
    public void onLivingDamageEvent(final LivingDamageEvent livingDamageEvent) {
        NobleMod.EVENT_BUS.post(livingDamageEvent);
    }
    
    private static void lambda$onUpdate$1(final Component component) {
        KamiGUI.dock((Frame)component);
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onChatSent(final ClientChatEvent clientChatEvent) {
        if (clientChatEvent.getMessage().startsWith(Command.getCommandPrefix())) {
            clientChatEvent.setCanceled(true);
            try {
                Wrapper.getMinecraft().ingameGUI.getChatGUI().addToSentMessages(clientChatEvent.getMessage());
                if (clientChatEvent.getMessage().length() > 1) {
                    NobleMod.getInstance().commandManager.callCommand(clientChatEvent.getMessage().substring(Command.getCommandPrefix().length() - 1));
                }
                else {
                    Command.sendChatMessage("Please enter a command.");
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
                Command.sendChatMessage(String.valueOf(new StringBuilder().append("Error occured while running command! (").append(ex.getMessage()).append(")")));
            }
            clientChatEvent.setMessage("");
        }
    }
    
    @SubscribeEvent
    public void onLeftClickBlock(final PlayerInteractEvent.LeftClickBlock leftClickBlock) {
        NobleMod.EVENT_BUS.post(leftClickBlock);
    }
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent livingUpdateEvent) {
        if (livingUpdateEvent.isCanceled()) {
            return;
        }
        if (Minecraft.getMinecraft().displayWidth != this.displayWidth || Minecraft.getMinecraft().displayHeight != this.displayHeight) {
            NobleMod.EVENT_BUS.post(new DisplaySizeChangedEvent());
            this.displayWidth = Minecraft.getMinecraft().displayWidth;
            this.displayHeight = Minecraft.getMinecraft().displayHeight;
            NobleMod.getInstance().getGuiManager().getChildren().stream().filter((Predicate<? super Object>)ForgeEventProcessor::lambda$onUpdate$0).forEach((Consumer<? super Object>)ForgeEventProcessor::lambda$onUpdate$1);
        }
        if (PeekCommand.sb != null) {
            final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            final int getScaledWidth = scaledResolution.getScaledWidth();
            final int getScaledHeight = scaledResolution.getScaledHeight();
            final GuiShulkerBox guiShulkerBox = new GuiShulkerBox(Wrapper.getPlayer().inventory, (IInventory)PeekCommand.sb);
            guiShulkerBox.setWorldAndResolution(Wrapper.getMinecraft(), getScaledWidth, getScaledHeight);
            Minecraft.getMinecraft().displayGuiScreen((GuiScreen)guiShulkerBox);
            PeekCommand.sb = null;
        }
    }
    
    @SubscribeEvent
    public void onChunkLoaded(final ChunkEvent.Load load) {
        NobleMod.EVENT_BUS.post(load);
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onPlayerDrawn(final RenderPlayerEvent.Pre pre) {
        NobleMod.EVENT_BUS.post(pre);
    }
    
    private static boolean lambda$onUpdate$0(final Component component) {
        return component instanceof Frame;
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onPlayerDrawn(final RenderPlayerEvent.Post post) {
        NobleMod.EVENT_BUS.post(post);
    }
    
    @SubscribeEvent
    public void onChunkLoaded(final ChunkEvent.Unload unload) {
        NobleMod.EVENT_BUS.post(unload);
    }
    
    @SubscribeEvent
    public void onRenderPre(final RenderGameOverlayEvent.Pre pre) {
        if (pre.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && ModuleManager.isModuleEnabled("BossStack")) {
            pre.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onLivingEntityUseItemEventTick(final LivingEntityUseItemEvent.Start start) {
        NobleMod.EVENT_BUS.post(start);
    }
    
    @SubscribeEvent
    public void onAttackEntity(final AttackEntityEvent attackEntityEvent) {
        NobleMod.EVENT_BUS.post(attackEntityEvent);
    }
    
    @SubscribeEvent
    public void onEntityJoinWorldEvent(final EntityJoinWorldEvent entityJoinWorldEvent) {
        NobleMod.EVENT_BUS.post(entityJoinWorldEvent);
    }
    
    @SubscribeEvent
    public void onTick(final TickEvent.ClientTickEvent clientTickEvent) {
        if (Wrapper.getPlayer() == null) {
            return;
        }
        ModuleManager.onUpdate();
        NobleMod.getInstance().getGuiManager().callTick(NobleMod.getInstance().getGuiManager());
    }
    
    @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
    public void onKeyInput(final InputEvent.KeyInputEvent keyInputEvent) {
        if (!Keyboard.getEventKeyState()) {
            return;
        }
        if (ModuleManager.isModuleEnabled("PrefixChat") && String.valueOf(new StringBuilder().append("").append(Keyboard.getEventCharacter())).equalsIgnoreCase(Command.getCommandPrefix()) && !Minecraft.getMinecraft().player.isSneaking()) {
            Minecraft.getMinecraft().displayGuiScreen((GuiScreen)new GuiChat(Command.getCommandPrefix()));
        }
        else {
            ModuleManager.onBind(Keyboard.getEventKey());
        }
    }
    
    @SubscribeEvent
    public void onRenderBlockOverlay(final RenderBlockOverlayEvent renderBlockOverlayEvent) {
        NobleMod.EVENT_BUS.post(renderBlockOverlayEvent);
    }
    
    @SubscribeEvent
    public void onWorldRender(final RenderWorldLastEvent renderWorldLastEvent) {
        if (renderWorldLastEvent.isCanceled()) {
            return;
        }
        ModuleManager.onWorldRender(renderWorldLastEvent);
    }
    
    @SubscribeEvent
    public void onRender(final RenderGameOverlayEvent.Post post) {
        if (post.isCanceled()) {
            return;
        }
        RenderGameOverlayEvent.ElementType elementType = RenderGameOverlayEvent.ElementType.EXPERIENCE;
        if (!Wrapper.getPlayer().isCreative() && Wrapper.getPlayer().getRidingEntity() instanceof AbstractHorse) {
            elementType = RenderGameOverlayEvent.ElementType.HEALTHMOUNT;
        }
        if (post.getType() == elementType) {
            ModuleManager.onRender();
            GL11.glPushMatrix();
            UIRenderer.renderAndUpdateFrames();
            GL11.glPopMatrix();
            KamiTessellator.releaseGL();
        }
        else if (post.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && ModuleManager.isModuleEnabled("BossStack")) {
            BossStack.render(post);
        }
    }
    
    @SubscribeEvent
    public void onInputUpdate(final InputUpdateEvent inputUpdateEvent) {
        NobleMod.EVENT_BUS.post(inputUpdateEvent);
    }
    
    @SubscribeEvent
    public void onPlayerPush(final PlayerSPPushOutOfBlocksEvent playerSPPushOutOfBlocksEvent) {
        NobleMod.EVENT_BUS.post(playerSPPushOutOfBlocksEvent);
    }
}
