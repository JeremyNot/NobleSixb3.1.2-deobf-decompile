//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event.events;

import net.minecraft.client.gui.*;

public class GuiScreenEvent
{
    private GuiScreen screen;
    
    public GuiScreenEvent(final GuiScreen screen) {
        this.screen = screen;
    }
    
    public void setScreen(final GuiScreen screen) {
        this.screen = screen;
    }
    
    public GuiScreen getScreen() {
        return this.screen;
    }
    
    public static class Closed extends GuiScreenEvent
    {
        public Closed(final GuiScreen guiScreen) {
            super(guiScreen);
        }
    }
    
    public static class Displayed extends GuiScreenEvent
    {
        public Displayed(final GuiScreen guiScreen) {
            super(guiScreen);
        }
    }
}
