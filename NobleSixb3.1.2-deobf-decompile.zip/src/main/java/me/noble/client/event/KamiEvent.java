//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.event;

import me.zero.alpine.type.*;
import me.noble.client.util.*;

public class KamiEvent extends Cancellable
{
    private Era era;
    private final float partialTicks;
    
    public float getPartialTicks() {
        return this.partialTicks;
    }
    
    public Era getEra() {
        return this.era;
    }
    
    public KamiEvent() {
        this.era = Era.PRE;
        this.partialTicks = Wrapper.getMinecraft().getRenderPartialTicks();
    }
    
    public enum Era
    {
        POST, 
        PERI, 
        PRE;
        
        private static final Era[] $VALUES;
        
        static {
            $VALUES = new Era[] { Era.PRE, Era.PERI, Era.POST };
        }
    }
}
