//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting;

public interface ISettingUnknown
{
    boolean isVisible();
    
    String getName();
    
    void setValueFromString(final String p0);
    
    String getValueAsString();
    
    Class getValueClass();
}
