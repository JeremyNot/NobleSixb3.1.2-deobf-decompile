//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting;

import com.google.common.base.*;
import java.util.function.*;
import me.noble.client.setting.builder.*;
import me.noble.client.setting.builder.numerical.*;
import me.noble.client.setting.builder.primitive.*;

public class Settings
{
    public static BooleanSettingBuilder booleanBuilder() {
        return new BooleanSettingBuilder();
    }
    
    public static StringSettingBuilder stringBuilder(final String s) {
        return (StringSettingBuilder)new StringSettingBuilder().withName(s);
    }
    
    public static Setting<Float> f(final String s, final float n) {
        return (Setting<Float>)floatBuilder(s).withValue((Number)n).build();
    }
    
    public static NumericalSettingBuilder<Double> doubleBuilder(final String s) {
        return (NumericalSettingBuilder<Double>)new DoubleSettingBuilder().withName(s);
    }
    
    public static <T> SettingBuilder<T> custom(final String s, final T t, final Converter converter, final Predicate<T> predicate, final BiConsumer<T, T> biConsumer, final boolean b) {
        return custom(s, t, converter, predicate, biConsumer, Settings::lambda$custom$0);
    }
    
    public static <T extends Enum> Setting<T> e(final String s, final Enum enum1) {
        return (Setting<T>)enumBuilder(enum1.getClass()).withName(s).withValue((Object)enum1).build();
    }
    
    private static void lambda$custom$3(final Object o, final Object o2) {
    }
    
    public static NumericalSettingBuilder<Integer> integerBuilder(final String s) {
        return (NumericalSettingBuilder<Integer>)new IntegerSettingBuilder().withName(s);
    }
    
    public static IntegerSettingBuilder integerBuilder() {
        return new IntegerSettingBuilder();
    }
    
    public static Setting<Integer> i(final String s, final int n) {
        return (Setting<Integer>)integerBuilder(s).withValue((Number)n).build();
    }
    
    public static <T> SettingBuilder<T> custom(final String s, final T t, final Converter converter) {
        return custom(s, t, converter, Settings::lambda$custom$4, Settings::lambda$custom$5, false);
    }
    
    public static NumericalSettingBuilder<Float> floatBuilder(final String s) {
        return (NumericalSettingBuilder<Float>)new FloatSettingBuilder().withName(s);
    }
    
    private static void lambda$custom$5(final Object o, final Object o2) {
    }
    
    public static Setting<Boolean> b(final String s, final boolean b) {
        return (Setting<Boolean>)booleanBuilder(s).withValue((Object)b).build();
    }
    
    public static <T> SettingBuilder<T> custom(final String s, final T t, final Converter converter, final boolean b) {
        return custom(s, t, converter, Settings::lambda$custom$2, Settings::lambda$custom$3, b);
    }
    
    public static BooleanSettingBuilder booleanBuilder(final String s) {
        return new BooleanSettingBuilder().withName(s);
    }
    
    public static DoubleSettingBuilder doubleBuilder() {
        return new DoubleSettingBuilder();
    }
    
    private static boolean lambda$custom$4(final Object o) {
        return true;
    }
    
    public static Setting<Double> d(final String s, final double n) {
        return (Setting<Double>)doubleBuilder(s).withValue((Number)n).build();
    }
    
    private static boolean lambda$custom$2(final Object o) {
        return true;
    }
    
    public static EnumSettingBuilder enumBuilder(final Class<? extends Enum> clazz) {
        return new EnumSettingBuilder((Class)clazz);
    }
    
    public static <T> SettingBuilder<T> custom(final String s, final T t, final Converter converter, final Predicate<T> predicate, final boolean b) {
        return custom(s, t, converter, predicate, Settings::lambda$custom$1, b);
    }
    
    private static void lambda$custom$1(final Object o, final Object o2) {
    }
    
    private static boolean lambda$custom$0(final boolean b, final Object o) {
        return !b;
    }
    
    public static StringSettingBuilder stringBuilder() {
        return new StringSettingBuilder();
    }
    
    public static FloatSettingBuilder floatBuilder() {
        return new FloatSettingBuilder();
    }
    
    public static Setting<Boolean> b(final String s) {
        return (Setting<Boolean>)booleanBuilder(s).withValue((Object)true).build();
    }
    
    public static <T> SettingBuilder<T> custom(final String s, final T t, final Converter converter, final Predicate<T> predicate, final BiConsumer<T, T> biConsumer, final Predicate<T> predicate2) {
        return (SettingBuilder<T>)new SettingBuilder<T>(converter) {
            final Converter val$converter;
            
            public Setting<T> build() {
                return new Setting<T>(this, this.initialValue, this.predicate(), this.consumer, this.name, this.visibilityPredicate()) {
                    final Settings$1 this$0;
                    
                    public Converter converter() {
                        return this.this$0.val$converter;
                    }
                };
            }
        }.withName(s).withValue((Object)t).withConsumer((BiConsumer)biConsumer).withVisibility((Predicate)predicate2).withRestriction((Predicate)predicate);
    }
    
    public static Setting<String> s(final String s, final String s2) {
        return (Setting<String>)stringBuilder(s).withValue((Object)s2).build();
    }
}
