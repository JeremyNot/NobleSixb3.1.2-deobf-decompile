//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.converter;

import com.google.common.base.*;
import com.google.gson.*;

public abstract class AbstractBoxedNumberConverter<T extends Number> extends Converter<T, JsonElement>
{
    protected JsonElement doForward(final T t) {
        return (JsonElement)new JsonPrimitive((Number)t);
    }
    
    protected Object doForward(final Object o) {
        return this.doForward((Number)o);
    }
}
