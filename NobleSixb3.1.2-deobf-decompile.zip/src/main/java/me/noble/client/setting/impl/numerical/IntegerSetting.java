//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl.numerical;

import java.util.function.*;
import me.noble.client.setting.converter.*;
import com.google.common.base.*;

public class IntegerSetting extends NumberSetting<Integer>
{
    private static final BoxedIntegerConverter converter;
    
    public IntegerSetting(final Integer n, final Predicate<Integer> predicate, final BiConsumer<Integer, Integer> biConsumer, final String s, final Predicate<Integer> predicate2, final Integer n2, final Integer n3) {
        super(n, predicate, biConsumer, s, predicate2, n2, n3);
    }
    
    @Override
    public AbstractBoxedNumberConverter converter() {
        return (AbstractBoxedNumberConverter)IntegerSetting.converter;
    }
    
    static {
        converter = new BoxedIntegerConverter();
    }
    
    @Override
    public Converter converter() {
        return (Converter)this.converter();
    }
}
