//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.converter;

import com.google.gson.*;

public class BoxedDoubleConverter extends AbstractBoxedNumberConverter<Double>
{
    protected Double doBackward(final JsonElement jsonElement) {
        return jsonElement.getAsDouble();
    }
    
    protected Object doBackward(final Object o) {
        return this.doBackward((JsonElement)o);
    }
}
