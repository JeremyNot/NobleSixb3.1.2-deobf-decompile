//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.builder.numerical;

import me.noble.client.setting.builder.*;
import me.noble.client.setting.*;
import java.util.function.*;
import me.noble.client.setting.impl.numerical.*;

public class IntegerSettingBuilder extends NumericalSettingBuilder<Integer>
{
    @Override
    public IntegerSettingBuilder withListener(final BiConsumer<Integer, Integer> biConsumer) {
        return (IntegerSettingBuilder)super.withListener(biConsumer);
    }
    
    @Override
    public NumericalSettingBuilder withMaximum(final Number n) {
        return this.withMaximum((Integer)n);
    }
    
    @Override
    public SettingBuilder withValue(final Object o) {
        return this.withValue((Integer)o);
    }
    
    @Override
    public IntegerSettingBuilder withMaximum(final Integer n) {
        return (IntegerSettingBuilder)super.withMaximum(n);
    }
    
    @Override
    public Setting build() {
        return this.build();
    }
    
    @Override
    public IntegerSettingBuilder withMinimum(final Integer n) {
        return (IntegerSettingBuilder)super.withMinimum(n);
    }
    
    @Override
    public IntegerSettingBuilder withVisibility(final Predicate<Integer> predicate) {
        return (IntegerSettingBuilder)super.withVisibility(predicate);
    }
    
    @Override
    public SettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public NumericalSettingBuilder withMinimum(final Number n) {
        return this.withMinimum((Integer)n);
    }
    
    @Override
    public IntegerSettingBuilder withRange(final Integer n, final Integer n2) {
        return (IntegerSettingBuilder)super.withRange(n, n2);
    }
    
    @Override
    public IntegerSettingBuilder withConsumer(final BiConsumer<Integer, Integer> biConsumer) {
        return (IntegerSettingBuilder)super.withConsumer(biConsumer);
    }
    
    @Override
    public SettingBuilder withRestriction(final Predicate predicate) {
        return this.withRestriction((Predicate<Integer>)predicate);
    }
    
    @Override
    public NumericalSettingBuilder withListener(final BiConsumer biConsumer) {
        return this.withListener((BiConsumer<Integer, Integer>)biConsumer);
    }
    
    @Override
    public NumericalSettingBuilder withName(final String s) {
        return super.withName(s);
    }
    
    @Override
    public NumericalSettingBuilder withValue(final Number n) {
        return this.withValue((Integer)n);
    }
    
    @Override
    public SettingBuilder withConsumer(final BiConsumer biConsumer) {
        return this.withConsumer((BiConsumer<Integer, Integer>)biConsumer);
    }
    
    @Override
    public IntegerSettingBuilder withValue(final Integer n) {
        return (IntegerSettingBuilder)super.withValue(n);
    }
    
    @Override
    public NumericalSettingBuilder withRange(final Number n, final Number n2) {
        return this.withRange((Integer)n, (Integer)n2);
    }
    
    @Override
    public NumberSetting build() {
        return new IntegerSetting((Integer)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate(), (Integer)this.min, (Integer)this.max);
    }
    
    @Override
    public SettingBuilder withVisibility(final Predicate predicate) {
        return this.withVisibility((Predicate<Integer>)predicate);
    }
    
    @Override
    public IntegerSettingBuilder withRestriction(final Predicate<Integer> predicate) {
        return (IntegerSettingBuilder)super.withRestriction(predicate);
    }
}
