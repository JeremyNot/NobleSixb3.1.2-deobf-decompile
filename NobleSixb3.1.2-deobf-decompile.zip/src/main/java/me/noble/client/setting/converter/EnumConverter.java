//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.converter;

import com.google.common.base.*;
import com.google.gson.*;

public class EnumConverter extends Converter<Enum, JsonElement>
{
    Class<? extends Enum> clazz;
    
    public EnumConverter(final Class<? extends Enum> clazz) {
        this.clazz = clazz;
    }
    
    protected JsonElement doForward(final Enum enum1) {
        return (JsonElement)new JsonPrimitive(enum1.toString());
    }
    
    protected Enum doBackward(final JsonElement jsonElement) {
        return (Enum)Enum.valueOf(this.clazz, jsonElement.getAsString());
    }
    
    protected Object doForward(final Object o) {
        return this.doForward((Enum)o);
    }
    
    protected Object doBackward(final Object o) {
        return this.doBackward((JsonElement)o);
    }
}
