//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.builder;

import java.util.function.*;
import com.google.common.base.*;
import java.util.*;
import me.noble.client.setting.*;

public abstract class SettingBuilder<T>
{
    protected BiConsumer<T, T> consumer;
    protected String name;
    protected List<Predicate<T>> predicateList;
    protected T initialValue;
    private Predicate<T> visibilityPredicate;
    
    public SettingBuilder<T> withValue(final T initialValue) {
        this.initialValue = initialValue;
        return this;
    }
    
    protected BiConsumer<T, T> consumer() {
        return (BiConsumer<T, T>)MoreObjects.firstNonNull((Object)this.consumer, (Object)SettingBuilder::lambda$consumer$4);
    }
    
    public SettingBuilder<T> withVisibility(final Predicate<T> visibilityPredicate) {
        this.visibilityPredicate = visibilityPredicate;
        return this;
    }
    
    protected Predicate<T> visibilityPredicate() {
        return (Predicate<T>)MoreObjects.firstNonNull((Object)this.visibilityPredicate, (Object)SettingBuilder::lambda$visibilityPredicate$3);
    }
    
    private static boolean lambda$null$1(final Object o, final Predicate predicate) {
        return predicate.test(o);
    }
    
    public SettingBuilder<T> withRestriction(final Predicate<T> predicate) {
        this.predicateList.add(predicate);
        return this;
    }
    
    private static boolean lambda$predicate$0(final Object o) {
        return true;
    }
    
    public abstract Setting<T> build();
    
    public SettingBuilder<T> withName(final String name) {
        this.name = name;
        return this;
    }
    
    public SettingBuilder() {
        this.predicateList = new ArrayList<Predicate<T>>();
    }
    
    private boolean lambda$predicate$2(final Object o) {
        return this.predicateList.stream().allMatch(SettingBuilder::lambda$null$1);
    }
    
    public SettingBuilder<T> withConsumer(final BiConsumer<T, T> consumer) {
        this.consumer = consumer;
        return this;
    }
    
    public static <T> Setting<T> register(final Setting<T> setting, final String s) {
        final String name = setting.getName();
        if (name == null || name.isEmpty()) {
            throw new RuntimeException("Can't register nameless setting");
        }
        SettingsRegister.register(String.valueOf(new StringBuilder().append(s).append(".").append(name)), setting);
        return setting;
    }
    
    protected Predicate<T> predicate() {
        return this.predicateList.isEmpty() ? SettingBuilder::lambda$predicate$0 : this::lambda$predicate$2;
    }
    
    private static boolean lambda$visibilityPredicate$3(final Object o) {
        return true;
    }
    
    public final Setting<T> buildAndRegister(final String s) {
        return register(this.build(), s);
    }
    
    private static void lambda$consumer$4(final Object o, final Object o2) {
    }
}
