//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl.numerical;

import me.noble.client.setting.converter.*;
import com.google.common.base.*;
import java.util.function.*;

public class FloatSetting extends NumberSetting<Float>
{
    private static final BoxedFloatConverter converter;
    
    @Override
    public AbstractBoxedNumberConverter converter() {
        return (AbstractBoxedNumberConverter)FloatSetting.converter;
    }
    
    static {
        converter = new BoxedFloatConverter();
    }
    
    @Override
    public Converter converter() {
        return (Converter)this.converter();
    }
    
    public FloatSetting(final Float n, final Predicate<Float> predicate, final BiConsumer<Float, Float> biConsumer, final String s, final Predicate<Float> predicate2, final Float n2, final Float n3) {
        super(n, predicate, biConsumer, s, predicate2, n2, n3);
    }
}
