//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting;

import me.noble.client.util.*;
import java.util.*;

public class SettingsRegister
{
    public HashMap<String, SettingsRegister> registerHashMap;
    public static final SettingsRegister ROOT;
    public HashMap<String, Setting> settingHashMap;
    
    private static Pair<String, SettingsRegister> dig(final String s) {
        SettingsRegister settingsRegister = SettingsRegister.ROOT;
        final StringTokenizer stringTokenizer = new StringTokenizer(s, ".");
        String nextToken = null;
        while (stringTokenizer.hasMoreTokens()) {
            if (nextToken == null) {
                nextToken = stringTokenizer.nextToken();
            }
            else {
                final String nextToken2 = stringTokenizer.nextToken();
                settingsRegister = settingsRegister.subregister(nextToken);
                nextToken = nextToken2;
            }
        }
        return new Pair<String, SettingsRegister>((nextToken == null) ? "" : nextToken, settingsRegister);
    }
    
    public Setting getSetting(final String s) {
        return this.settingHashMap.get(s);
    }
    
    public SettingsRegister() {
        this.registerHashMap = new HashMap<String, SettingsRegister>();
        this.settingHashMap = new HashMap<String, Setting>();
    }
    
    public SettingsRegister subregister(final String s) {
        if (this.registerHashMap.containsKey(s)) {
            return this.registerHashMap.get(s);
        }
        final SettingsRegister settingsRegister = new SettingsRegister();
        this.registerHashMap.put(s, settingsRegister);
        return settingsRegister;
    }
    
    public static Setting get(final String s) {
        final Pair<String, SettingsRegister> dig = dig(s);
        return dig.getValue().getSetting(dig.getKey());
    }
    
    private void put(final String s, final Setting setting) {
        this.settingHashMap.put(s, setting);
    }
    
    public static void register(final String s, final Setting setting) {
        final Pair<String, SettingsRegister> dig = dig(s);
        dig.getValue().put(dig.getKey(), setting);
    }
    
    static {
        ROOT = new SettingsRegister();
    }
}
