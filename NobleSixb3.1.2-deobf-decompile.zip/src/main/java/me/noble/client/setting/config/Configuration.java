//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.config;

import java.nio.file.*;
import me.noble.client.setting.*;
import me.noble.client.setting.converter.*;
import java.util.*;
import com.google.gson.*;
import java.io.*;
import me.noble.client.*;

public class Configuration
{
    public static void loadConfiguration(final Path path) throws IOException {
        final InputStream inputStream = Files.newInputStream(path, new OpenOption[0]);
        loadConfiguration(inputStream);
        inputStream.close();
    }
    
    public static JsonObject produceConfig() {
        return produceConfig(SettingsRegister.ROOT);
    }
    
    public static void saveConfiguration(final OutputStream outputStream) throws IOException {
        final String json = new GsonBuilder().setPrettyPrinting().create().toJson((JsonElement)produceConfig());
        final BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
        bufferedWriter.write(json);
        bufferedWriter.close();
    }
    
    public static void saveConfiguration(final Path path) throws IOException {
        saveConfiguration(Files.newOutputStream(path, new OpenOption[0]));
    }
    
    private static JsonObject produceConfig(final SettingsRegister settingsRegister) {
        final JsonObject jsonObject = new JsonObject();
        for (final Map.Entry<String, SettingsRegister> entry : settingsRegister.registerHashMap.entrySet()) {
            jsonObject.add((String)entry.getKey(), (JsonElement)produceConfig(entry.getValue()));
        }
        for (final Map.Entry<String, Setting> entry2 : settingsRegister.settingHashMap.entrySet()) {
            final Setting<Object> setting = entry2.getValue();
            if (!(setting instanceof Convertable)) {
                continue;
            }
            jsonObject.add((String)entry2.getKey(), (JsonElement)setting.converter().convert(setting.getValue()));
        }
        return jsonObject;
    }
    
    public static void loadConfiguration(final JsonObject jsonObject) {
        loadConfiguration(SettingsRegister.ROOT, jsonObject);
    }
    
    private static void loadConfiguration(final SettingsRegister settingsRegister, final JsonObject jsonObject) {
        for (final Map.Entry<String, V> entry : jsonObject.entrySet()) {
            final String s = entry.getKey();
            final JsonElement jsonElement = (JsonElement)entry.getValue();
            if (settingsRegister.registerHashMap.containsKey(s)) {
                loadConfiguration(settingsRegister.subregister(s), jsonElement.getAsJsonObject());
            }
            else {
                final Setting setting = settingsRegister.getSetting(s);
                if (setting == null) {
                    continue;
                }
                setting.setValue(setting.converter().reverse().convert((Object)jsonElement));
            }
        }
    }
    
    public static void loadConfiguration(final InputStream inputStream) {
        try {
            loadConfiguration(new JsonParser().parse((Reader)new InputStreamReader(inputStream)).getAsJsonObject());
        }
        catch (IllegalStateException ex) {
            NobleMod.log.error("NOBLE Config malformed: resetting.");
            loadConfiguration(new JsonObject());
        }
    }
}
