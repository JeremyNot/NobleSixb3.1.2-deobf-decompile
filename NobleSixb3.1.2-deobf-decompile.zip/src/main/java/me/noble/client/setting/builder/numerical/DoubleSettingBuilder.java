//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.builder.numerical;

import me.noble.client.setting.builder.*;
import java.util.function.*;
import me.noble.client.setting.*;
import me.noble.client.setting.impl.numerical.*;

public class DoubleSettingBuilder extends NumericalSettingBuilder<Double>
{
    @Override
    public DoubleSettingBuilder withValue(final Double n) {
        return (DoubleSettingBuilder)super.withValue(n);
    }
    
    @Override
    public DoubleSettingBuilder withRestriction(final Predicate<Double> predicate) {
        return (DoubleSettingBuilder)super.withRestriction(predicate);
    }
    
    @Override
    public SettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public NumericalSettingBuilder withValue(final Number n) {
        return this.withValue((Double)n);
    }
    
    @Override
    public DoubleSettingBuilder withName(final String s) {
        return (DoubleSettingBuilder)super.withName(s);
    }
    
    @Override
    public NumericalSettingBuilder withMinimum(final Number n) {
        return this.withMinimum((Double)n);
    }
    
    @Override
    public SettingBuilder withConsumer(final BiConsumer biConsumer) {
        return this.withConsumer((BiConsumer<Double, Double>)biConsumer);
    }
    
    @Override
    public DoubleSettingBuilder withMaximum(final Double n) {
        return (DoubleSettingBuilder)super.withMaximum(n);
    }
    
    @Override
    public Setting build() {
        return this.build();
    }
    
    @Override
    public NumericalSettingBuilder withMaximum(final Number n) {
        return this.withMaximum((Double)n);
    }
    
    @Override
    public NumericalSettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public NumberSetting build() {
        return new DoubleSetting((Double)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate(), (Double)this.min, (Double)this.max);
    }
    
    @Override
    public NumericalSettingBuilder withRange(final Number n, final Number n2) {
        return this.withRange((Double)n, (Double)n2);
    }
    
    @Override
    public DoubleSettingBuilder withConsumer(final BiConsumer<Double, Double> biConsumer) {
        return (DoubleSettingBuilder)super.withConsumer(biConsumer);
    }
    
    @Override
    public SettingBuilder withVisibility(final Predicate predicate) {
        return this.withVisibility((Predicate<Double>)predicate);
    }
    
    @Override
    public DoubleSettingBuilder withListener(final BiConsumer<Double, Double> biConsumer) {
        return (DoubleSettingBuilder)super.withListener(biConsumer);
    }
    
    @Override
    public NumericalSettingBuilder withListener(final BiConsumer biConsumer) {
        return this.withListener((BiConsumer<Double, Double>)biConsumer);
    }
    
    @Override
    public SettingBuilder withValue(final Object o) {
        return this.withValue((Double)o);
    }
    
    @Override
    public DoubleSettingBuilder withVisibility(final Predicate<Double> predicate) {
        return (DoubleSettingBuilder)super.withVisibility(predicate);
    }
    
    @Override
    public DoubleSettingBuilder withMinimum(final Double n) {
        return (DoubleSettingBuilder)super.withMinimum(n);
    }
    
    @Override
    public DoubleSettingBuilder withRange(final Double n, final Double n2) {
        return (DoubleSettingBuilder)super.withRange(n, n2);
    }
    
    @Override
    public SettingBuilder withRestriction(final Predicate predicate) {
        return this.withRestriction((Predicate<Double>)predicate);
    }
}
