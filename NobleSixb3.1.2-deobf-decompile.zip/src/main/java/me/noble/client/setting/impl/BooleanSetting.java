//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl;

import me.noble.client.setting.*;
import me.noble.client.setting.converter.*;
import com.google.common.base.*;
import java.util.function.*;

public class BooleanSetting extends Setting<Boolean>
{
    private static final BooleanConverter converter;
    
    static {
        converter = new BooleanConverter();
    }
    
    public Converter converter() {
        return (Converter)this.converter();
    }
    
    public BooleanConverter converter() {
        return BooleanSetting.converter;
    }
    
    public BooleanSetting(final Boolean b, final Predicate<Boolean> predicate, final BiConsumer<Boolean, Boolean> biConsumer, final String s, final Predicate<Boolean> predicate2) {
        super(b, predicate, biConsumer, s, predicate2);
    }
}
