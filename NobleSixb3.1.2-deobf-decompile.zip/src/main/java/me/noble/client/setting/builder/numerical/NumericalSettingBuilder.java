//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.builder.numerical;

import me.noble.client.setting.builder.*;
import me.noble.client.setting.impl.numerical.*;
import java.util.function.*;
import me.noble.client.setting.*;

public abstract class NumericalSettingBuilder<T extends Number> extends SettingBuilder<T>
{
    protected T max;
    protected T min;
    
    @Override
    public NumericalSettingBuilder<T> withValue(final T t) {
        return (NumericalSettingBuilder)super.withValue(t);
    }
    
    @Override
    public SettingBuilder withValue(final Object o) {
        return this.withValue((Number)o);
    }
    
    public NumericalSettingBuilder<T> withRange(final T min, final T max) {
        this.predicateList.add(NumericalSettingBuilder::lambda$withRange$2);
        if (this.min == null || min.doubleValue() > this.min.doubleValue()) {
            this.min = min;
        }
        if (this.max == null || max.doubleValue() < this.max.doubleValue()) {
            this.max = max;
        }
        return this;
    }
    
    @Override
    public NumericalSettingBuilder withName(final String s) {
        return (NumericalSettingBuilder)super.withName(s);
    }
    
    public NumericalSettingBuilder<T> withMinimum(final T min) {
        this.predicateList.add(NumericalSettingBuilder::lambda$withMinimum$0);
        if (this.min == null || min.doubleValue() > this.min.doubleValue()) {
            this.min = min;
        }
        return this;
    }
    
    @Override
    public SettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public abstract NumberSetting build();
    
    public NumericalSettingBuilder<T> withListener(final BiConsumer<T, T> consumer) {
        this.consumer = consumer;
        return this;
    }
    
    public NumericalSettingBuilder<T> withMaximum(final T max) {
        this.predicateList.add(NumericalSettingBuilder::lambda$withMaximum$1);
        if (this.max == null || max.doubleValue() < this.max.doubleValue()) {
            this.max = max;
        }
        return this;
    }
    
    private static boolean lambda$withMaximum$1(final Number n, final Number n2) {
        return n2.doubleValue() <= n.doubleValue();
    }
    
    private static boolean lambda$withMinimum$0(final Number n, final Number n2) {
        return n2.doubleValue() >= n.doubleValue();
    }
    
    private static boolean lambda$withRange$2(final Number n, final Number n2, final Number n3) {
        final double doubleValue = n3.doubleValue();
        return doubleValue >= n.doubleValue() && doubleValue <= n2.doubleValue();
    }
    
    @Override
    public Setting build() {
        return this.build();
    }
}
