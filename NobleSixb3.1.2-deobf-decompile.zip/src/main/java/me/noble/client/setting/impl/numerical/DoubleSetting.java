//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl.numerical;

import me.noble.client.setting.converter.*;
import com.google.common.base.*;
import java.util.function.*;

public class DoubleSetting extends NumberSetting<Double>
{
    private static final BoxedDoubleConverter converter;
    
    @Override
    public AbstractBoxedNumberConverter converter() {
        return (AbstractBoxedNumberConverter)DoubleSetting.converter;
    }
    
    static {
        converter = new BoxedDoubleConverter();
    }
    
    @Override
    public Converter converter() {
        return (Converter)this.converter();
    }
    
    public DoubleSetting(final Double n, final Predicate<Double> predicate, final BiConsumer<Double, Double> biConsumer, final String s, final Predicate<Double> predicate2, final Double n2, final Double n3) {
        super(n, predicate, biConsumer, s, predicate2, n2, n3);
    }
}
