//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl;

import me.noble.client.setting.*;
import me.noble.client.setting.converter.*;
import com.google.common.base.*;
import java.util.function.*;

public class StringSetting extends Setting<String>
{
    private static final StringConverter converter;
    
    @Override
    public String getValueAsString() {
        return this.getValue();
    }
    
    static {
        converter = new StringConverter();
    }
    
    public StringConverter converter() {
        return StringSetting.converter;
    }
    
    @Override
    public void setValueFromString(final String value) {
        this.setValue(value);
    }
    
    public Converter converter() {
        return (Converter)this.converter();
    }
    
    public StringSetting(final String s, final Predicate<String> predicate, final BiConsumer<String, String> biConsumer, final String s2, final Predicate<String> predicate2) {
        super(s, predicate, biConsumer, s2, predicate2);
    }
}
