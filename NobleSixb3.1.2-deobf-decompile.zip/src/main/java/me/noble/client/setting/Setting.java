//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting;

import me.noble.client.setting.converter.*;
import java.util.function.*;
import com.google.gson.*;

public abstract class Setting<T> implements ISettingUnknown, Convertable<T>
{
    T value;
    private Predicate<T> restriction;
    private BiConsumer<T, T> consumer;
    private Predicate<T> visibilityPredicate;
    String name;
    private final Class valueType;
    
    public BiConsumer<T, T> changeListener() {
        return this.consumer;
    }
    
    public Setting(final T value, final Predicate<T> restriction, final BiConsumer<T, T> consumer, final String name, final Predicate<T> visibilityPredicate) {
        this.value = value;
        this.valueType = value.getClass();
        this.restriction = restriction;
        this.consumer = consumer;
        this.name = name;
        this.visibilityPredicate = visibilityPredicate;
    }
    
    public Class getValueClass() {
        return this.valueType;
    }
    
    public String getName() {
        return this.name;
    }
    
    public boolean isVisible() {
        return this.visibilityPredicate.test(this.getValue());
    }
    
    public boolean setValue(final T value) {
        final T value2 = this.getValue();
        if (!this.restriction.test(value)) {
            return false;
        }
        this.value = value;
        this.consumer.accept(value2, value);
        return true;
    }
    
    public String getValueAsString() {
        return ((JsonElement)this.converter().convert(this.getValue())).toString();
    }
    
    public void setValueFromString(final String s) {
        this.setValue(this.converter().reverse().convert((Object)new JsonParser().parse(s)));
    }
    
    public T getValue() {
        return this.value;
    }
}
