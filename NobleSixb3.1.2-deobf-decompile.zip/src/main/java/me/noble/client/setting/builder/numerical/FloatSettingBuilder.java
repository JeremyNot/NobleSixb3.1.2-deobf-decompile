//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.builder.numerical;

import me.noble.client.setting.*;
import me.noble.client.setting.builder.*;
import java.util.function.*;
import me.noble.client.setting.impl.numerical.*;

public class FloatSettingBuilder extends NumericalSettingBuilder<Float>
{
    @Override
    public FloatSettingBuilder withRestriction(final Predicate<Float> predicate) {
        return (FloatSettingBuilder)super.withRestriction(predicate);
    }
    
    @Override
    public FloatSettingBuilder withName(final String s) {
        return (FloatSettingBuilder)super.withName(s);
    }
    
    @Override
    public Setting build() {
        return this.build();
    }
    
    @Override
    public FloatSettingBuilder withMaximum(final Float n) {
        return (FloatSettingBuilder)super.withMaximum(n);
    }
    
    @Override
    public NumericalSettingBuilder withValue(final Number n) {
        return this.withValue((Float)n);
    }
    
    @Override
    public SettingBuilder withRestriction(final Predicate predicate) {
        return this.withRestriction((Predicate<Float>)predicate);
    }
    
    @Override
    public SettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public FloatSettingBuilder withValue(final Float n) {
        return (FloatSettingBuilder)super.withValue(n);
    }
    
    @Override
    public FloatSettingBuilder withMinimum(final Float n) {
        return (FloatSettingBuilder)super.withMinimum(n);
    }
    
    @Override
    public SettingBuilder withVisibility(final Predicate predicate) {
        return this.withVisibility((Predicate<Float>)predicate);
    }
    
    @Override
    public FloatSettingBuilder withListener(final BiConsumer<Float, Float> biConsumer) {
        return (FloatSettingBuilder)super.withListener(biConsumer);
    }
    
    @Override
    public NumericalSettingBuilder withMaximum(final Number n) {
        return this.withMaximum((Float)n);
    }
    
    @Override
    public NumericalSettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public SettingBuilder withValue(final Object o) {
        return this.withValue((Float)o);
    }
    
    @Override
    public NumericalSettingBuilder withRange(final Number n, final Number n2) {
        return this.withRange((Float)n, (Float)n2);
    }
    
    @Override
    public FloatSettingBuilder withVisibility(final Predicate<Float> predicate) {
        return (FloatSettingBuilder)super.withVisibility(predicate);
    }
    
    @Override
    public FloatSettingBuilder withConsumer(final BiConsumer<Float, Float> biConsumer) {
        return (FloatSettingBuilder)super.withConsumer(biConsumer);
    }
    
    @Override
    public NumericalSettingBuilder withMinimum(final Number n) {
        return this.withMinimum((Float)n);
    }
    
    @Override
    public NumericalSettingBuilder withListener(final BiConsumer biConsumer) {
        return this.withListener((BiConsumer<Float, Float>)biConsumer);
    }
    
    @Override
    public NumberSetting build() {
        return new FloatSetting((Float)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate(), (Float)this.min, (Float)this.max);
    }
    
    @Override
    public SettingBuilder withConsumer(final BiConsumer biConsumer) {
        return this.withConsumer((BiConsumer<Float, Float>)biConsumer);
    }
    
    @Override
    public FloatSettingBuilder withRange(final Float n, final Float n2) {
        return (FloatSettingBuilder)super.withRange(n, n2);
    }
}
