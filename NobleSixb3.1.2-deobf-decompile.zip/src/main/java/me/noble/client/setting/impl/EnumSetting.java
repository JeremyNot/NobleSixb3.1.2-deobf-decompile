//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl;

import me.noble.client.setting.*;
import me.noble.client.setting.converter.*;
import java.util.function.*;
import com.google.common.base.*;

public class EnumSetting<T extends Enum> extends Setting<T>
{
    private EnumConverter converter;
    public final Class<? extends Enum> clazz;
    
    public EnumSetting(final T t, final Predicate<T> predicate, final BiConsumer<T, T> biConsumer, final String s, final Predicate<T> predicate2, final Class<? extends Enum> clazz) {
        super(t, predicate, biConsumer, s, predicate2);
        this.converter = new EnumConverter((Class)clazz);
        this.clazz = clazz;
    }
    
    public Converter converter() {
        return (Converter)this.converter;
    }
}
