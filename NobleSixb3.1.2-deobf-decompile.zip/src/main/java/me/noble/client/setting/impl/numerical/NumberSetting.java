//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.impl.numerical;

import me.noble.client.setting.*;
import java.util.function.*;
import me.noble.client.setting.converter.*;
import com.google.common.base.*;

public abstract class NumberSetting<T extends Number> extends Setting<T>
{
    private final T min;
    private final T max;
    
    public NumberSetting(final T t, final Predicate<T> predicate, final BiConsumer<T, T> biConsumer, final String s, final Predicate<T> predicate2, final T min, final T max) {
        super(t, predicate, biConsumer, s, predicate2);
        this.min = min;
        this.max = max;
    }
    
    public boolean isBound() {
        return this.min != null && this.max != null;
    }
    
    public abstract AbstractBoxedNumberConverter converter();
    
    public T getMax() {
        return this.max;
    }
    
    public T getMin() {
        return this.min;
    }
    
    @Override
    public T getValue() {
        return super.getValue();
    }
    
    public Converter converter() {
        return (Converter)this.converter();
    }
    
    @Override
    public Object getValue() {
        return this.getValue();
    }
}
