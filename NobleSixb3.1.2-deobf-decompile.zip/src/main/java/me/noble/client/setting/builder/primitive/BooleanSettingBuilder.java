//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.setting.builder.primitive;

import me.noble.client.setting.builder.*;
import me.noble.client.setting.impl.*;
import me.noble.client.setting.*;

public class BooleanSettingBuilder extends SettingBuilder<Boolean>
{
    @Override
    public SettingBuilder withName(final String s) {
        return this.withName(s);
    }
    
    @Override
    public BooleanSetting build() {
        return new BooleanSetting((Boolean)this.initialValue, this.predicate(), this.consumer(), this.name, this.visibilityPredicate());
    }
    
    @Override
    public BooleanSettingBuilder withName(final String s) {
        return (BooleanSettingBuilder)super.withName(s);
    }
    
    @Override
    public Setting build() {
        return this.build();
    }
}
