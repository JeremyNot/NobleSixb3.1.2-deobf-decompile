//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client;

import me.noble.client.module.modules.misc.*;
import me.noble.client.module.*;
import club.minnced.discord.rpc.*;

public class DiscordPresence
{
    private static String state;
    private static String details;
    private static final DiscordRPC rpc;
    private static boolean hasStarted;
    public static DiscordRichPresence presence;
    private static DiscordSettings discordSettings;
    
    private static void setRpcFromSettingsNonInt() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                DiscordPresence.rpc.Discord_RunCallbacks();
                DiscordPresence.discordSettings = (DiscordSettings)ModuleManager.getModuleByName("DiscordSettings");
                final String s = " | ";
                DiscordPresence.details = String.valueOf(new StringBuilder().append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line1Setting.getValue())).append(s).append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line3Setting.getValue())));
                DiscordPresence.state = String.valueOf(new StringBuilder().append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line2Setting.getValue())).append(s).append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line4Setting.getValue())));
                DiscordPresence.presence.details = DiscordPresence.details;
                DiscordPresence.presence.state = DiscordPresence.state;
                DiscordPresence.rpc.Discord_UpdatePresence(DiscordPresence.presence);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
                Thread.sleep(4000L);
            }
            catch (InterruptedException ex2) {
                ex2.printStackTrace();
            }
        }
    }
    
    private static void setRpcFromSettings() {
        DiscordPresence.discordSettings = (DiscordSettings)ModuleManager.getModuleByName("DiscordSettings");
        DiscordPresence.details = String.valueOf(new StringBuilder().append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line1Setting.getValue())).append(" ").append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line3Setting.getValue())));
        DiscordPresence.state = String.valueOf(new StringBuilder().append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line2Setting.getValue())).append(" ").append(DiscordPresence.discordSettings.getLine(DiscordPresence.discordSettings.line4Setting.getValue())));
        DiscordPresence.presence.details = DiscordPresence.details;
        DiscordPresence.presence.state = DiscordPresence.state;
        DiscordPresence.presence.largeImageKey = "noble";
        DiscordPresence.presence.largeImageText = "NobleSix.net";
        DiscordPresence.rpc.Discord_UpdatePresence(DiscordPresence.presence);
    }
    
    private static void lambda$start$0(final int n, final String s) {
        NobleMod.log.info(String.valueOf(new StringBuilder().append("Discord RPC disconnected, var1: ").append(n).append(", var2: ").append(s)));
    }
    
    public static void start() {
        NobleMod.log.info("Starting Discord RPC");
        if (DiscordPresence.hasStarted) {
            return;
        }
        DiscordPresence.hasStarted = true;
        final DiscordEventHandlers discordEventHandlers = new DiscordEventHandlers();
        discordEventHandlers.disconnected = DiscordPresence::lambda$start$0;
        DiscordPresence.rpc.Discord_Initialize(NobleMod.APP_ID, discordEventHandlers, true, "");
        DiscordPresence.presence.startTimestamp = System.currentTimeMillis() / 1000L;
        setRpcFromSettings();
        new Thread(DiscordPresence::setRpcFromSettingsNonInt, "Discord-RPC-Callback-Handler").start();
        NobleMod.log.info("Discord RPC initialised successfully");
    }
    
    static {
        rpc = DiscordRPC.INSTANCE;
        DiscordPresence.presence = new DiscordRichPresence();
        DiscordPresence.hasStarted = false;
    }
}
