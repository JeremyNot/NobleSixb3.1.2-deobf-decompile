//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.use;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.poof.use.*;

public class Button extends AbstractComponent
{
    private String name;
    
    public Button(final String s) {
        this(s, 0, 0);
        this.addMouseListener((MouseListener)new MouseListener(this) {
            final Button this$0;
            
            public void onMouseDown(final MouseListener.MouseButtonEvent mouseButtonEvent) {
                this.this$0.callPoof((Class)ButtonPoof.class, (PoofInfo)new ButtonPoof.ButtonInfo(mouseButtonEvent.getButton(), mouseButtonEvent.getX(), mouseButtonEvent.getY()));
            }
            
            public void onMouseMove(final MouseListener.MouseMoveEvent mouseMoveEvent) {
            }
            
            public void onMouseRelease(final MouseListener.MouseButtonEvent mouseButtonEvent) {
            }
            
            public void onScroll(final MouseListener.MouseScrollEvent mouseScrollEvent) {
            }
            
            public void onMouseDrag(final MouseListener.MouseButtonEvent mouseButtonEvent) {
            }
        });
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void kill() {
    }
    
    public Button(final String name, final int x, final int y) {
        this.name = name;
        this.setX(x);
        this.setY(y);
    }
    
    public abstract static class ButtonPoof<T extends Button, S extends ButtonInfo> extends Poof<T, S>
    {
        ButtonInfo info;
        
        public static class ButtonInfo extends PoofInfo
        {
            int y;
            int button;
            int x;
            
            public ButtonInfo(final int button, final int x, final int y) {
                this.button = button;
                this.x = x;
                this.y = y;
            }
            
            public int getX() {
                return this.x;
            }
            
            public int getButton() {
                return this.button;
            }
            
            public int getY() {
                return this.y;
            }
        }
    }
}
