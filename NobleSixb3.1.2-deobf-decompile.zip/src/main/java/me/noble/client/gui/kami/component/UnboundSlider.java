//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.component.listen.*;

public class UnboundSlider extends AbstractComponent
{
    public int sensitivity;
    double value;
    double originValue;
    double min;
    int originX;
    boolean integer;
    double max;
    String text;
    
    public void setValue(double n) {
        if (this.min != Double.MIN_VALUE) {
            n = Math.max(n, this.min);
        }
        if (this.max != Double.MAX_VALUE) {
            n = Math.min(n, this.max);
        }
        final Slider.SliderPoof.SliderPoofInfo sliderPoofInfo = new Slider.SliderPoof.SliderPoofInfo(this.value, n);
        this.callPoof(Slider.SliderPoof.class, sliderPoofInfo);
        this.value = (this.integer ? Math.floor(sliderPoofInfo.getNewValue()) : sliderPoofInfo.getNewValue());
    }
    
    public void setMax(final double max) {
        this.max = max;
    }
    
    public void setMin(final double min) {
        this.min = min;
    }
    
    public double getValue() {
        return this.value;
    }
    
    public UnboundSlider(final double value, final String text, final boolean integer) {
        this.sensitivity = 5;
        this.max = Double.MAX_VALUE;
        this.min = Double.MIN_VALUE;
        this.value = value;
        this.text = text;
        this.integer = integer;
        this.addMouseListener(new MouseListener(this) {
            final UnboundSlider this$0;
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.originX = mouseButtonEvent.getX();
                this.this$0.originValue = this.this$0.getValue();
            }
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.setValue(Math.floor((this.this$0.originValue - (this.this$0.originX - mouseButtonEvent.getX()) / this.this$0.sensitivity * ((this.this$0.originValue == 0.0) ? 1.0 : (Math.abs(this.this$0.originValue) / 10.0))) * 10.0) / 10.0);
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
                this.this$0.setValue((double)Math.round(this.this$0.getValue() + (mouseScrollEvent.isUp() ? 1 : -1)));
                this.this$0.originValue = this.this$0.getValue();
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.originValue = this.this$0.getValue();
                this.this$0.originX = mouseButtonEvent.getX();
            }
        });
    }
    
    public String getText() {
        return this.text;
    }
}
