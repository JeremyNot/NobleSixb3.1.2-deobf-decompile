//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami;

import org.lwjgl.opengl.*;

public class RenderHelper
{
    public static void drawCircleOutline(final float n, final float n2, final float n3, final int n4, final int n5, final int n6) {
        drawArcOutline(n, n2, n3, (float)n4, (float)n5, n6);
    }
    
    public static void drawArcOutline(final float n, final float n2, final float n3, final float n4, final float n5, final int n6) {
        GL11.glBegin(2);
        for (int n7 = (int)(n6 / (360.0f / n4)) + 1; n7 <= n6 / (360.0f / n5); ++n7) {
            final double n8 = 6.283185307179586 * n7 / n6;
            GL11.glVertex2d(n + Math.cos(n8) * n3, n2 + Math.sin(n8) * n3);
        }
        GL11.glEnd();
    }
    
    public static void drawOutlinedRoundedRectangle(final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7, final float n8, final float n9, final float n10) {
        drawRoundedRectangle((float)n, (float)n2, (float)n3, (float)n4, n5);
        GL11.glColor4f(n6, n7, n8, n9);
        drawRoundedRectangle(n + n10, n2 + n10, n3 - n10 * 2.0f, n4 - n10 * 2.0f, n5);
    }
    
    public static void drawCircleOutline(final float n, final float n2, final float n3) {
        drawCircleOutline(n, n2, n3, 0, 360, 40);
    }
    
    public static void drawArc(final float n, final float n2, final float n3, final float n4, final float n5, final int n6) {
        GL11.glBegin(4);
        for (int n7 = (int)(n6 / (360.0f / n4)) + 1; n7 <= n6 / (360.0f / n5); ++n7) {
            final double n8 = 6.283185307179586 * (n7 - 1) / n6;
            final double n9 = 6.283185307179586 * n7 / n6;
            GL11.glVertex2d((double)n, (double)n2);
            GL11.glVertex2d(n + Math.cos(n9) * n3, n2 + Math.sin(n9) * n3);
            GL11.glVertex2d(n + Math.cos(n8) * n3, n2 + Math.sin(n8) * n3);
        }
        GL11.glEnd();
    }
    
    public static void drawCircle(final float n, final float n2, final float n3) {
        drawCircle(n, n2, n3, 0, 360, 64);
    }
    
    public static void drawFilledRectangle(final float n, final float n2, final float n3, final float n4) {
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glBegin(7);
        GL11.glVertex2d((double)(n + n3), (double)n2);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glVertex2d((double)n, (double)(n2 + n4));
        GL11.glVertex2d((double)(n + n3), (double)(n2 + n4));
        GL11.glEnd();
    }
    
    public static void drawCircle(final float n, final float n2, final float n3, final int n4, final int n5, final int n6) {
        drawArc(n, n2, n3, (float)n4, (float)n5, n6);
    }
    
    public static void drawRectangle(final float n, final float n2, final float n3, final float n4) {
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glBegin(2);
        GL11.glVertex2d((double)n3, 0.0);
        GL11.glVertex2d(0.0, 0.0);
        GL11.glVertex2d(0.0, (double)n4);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glEnd();
    }
    
    public static void drawRoundedRectangle(final float n, final float n2, final float n3, final float n4, final float n5) {
        GL11.glEnable(3042);
        drawArc(n + n3 - n5, n2 + n4 - n5, n5, 0.0f, 90.0f, 16);
        drawArc(n + n5, n2 + n4 - n5, n5, 90.0f, 180.0f, 16);
        drawArc(n + n5, n2 + n5, n5, 180.0f, 270.0f, 16);
        drawArc(n + n3 - n5, n2 + n5, n5, 270.0f, 360.0f, 16);
        GL11.glBegin(4);
        GL11.glVertex2d((double)(n + n3 - n5), (double)n2);
        GL11.glVertex2d((double)(n + n5), (double)n2);
        GL11.glVertex2d((double)(n + n3 - n5), (double)(n2 + n5));
        GL11.glVertex2d((double)(n + n3 - n5), (double)(n2 + n5));
        GL11.glVertex2d((double)(n + n5), (double)n2);
        GL11.glVertex2d((double)(n + n5), (double)(n2 + n5));
        GL11.glVertex2d((double)(n + n3), (double)(n2 + n5));
        GL11.glVertex2d((double)n, (double)(n2 + n5));
        GL11.glVertex2d((double)n, (double)(n2 + n4 - n5));
        GL11.glVertex2d((double)(n + n3), (double)(n2 + n5));
        GL11.glVertex2d((double)n, (double)(n2 + n4 - n5));
        GL11.glVertex2d((double)(n + n3), (double)(n2 + n4 - n5));
        GL11.glVertex2d((double)(n + n3 - n5), (double)(n2 + n4 - n5));
        GL11.glVertex2d((double)(n + n5), (double)(n2 + n4 - n5));
        GL11.glVertex2d((double)(n + n3 - n5), (double)(n2 + n4));
        GL11.glVertex2d((double)(n + n3 - n5), (double)(n2 + n4));
        GL11.glVertex2d((double)(n + n5), (double)(n2 + n4 - n5));
        GL11.glVertex2d((double)(n + n5), (double)(n2 + n4));
        GL11.glEnd();
    }
}
