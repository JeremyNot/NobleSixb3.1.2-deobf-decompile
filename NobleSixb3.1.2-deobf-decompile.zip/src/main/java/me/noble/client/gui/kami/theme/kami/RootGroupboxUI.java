//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.rgui.component.container.*;

public class RootGroupboxUI extends AbstractComponentUI<Groupbox>
{
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Groupbox)component, fontRenderer);
    }
    
    @Override
    public void handleMouseDown(final Groupbox groupbox, final int n, final int n2, final int n3) {
    }
    
    @Override
    public void renderComponent(final Groupbox groupbox, final FontRenderer fontRenderer) {
        GL11.glLineWidth(1.0f);
        fontRenderer.drawString(1, 1, groupbox.getName());
        GL11.glColor3f(1.0f, 0.0f, 0.0f);
        GL11.glDisable(3553);
        GL11.glBegin(1);
        GL11.glVertex2d(0.0, 0.0);
        GL11.glVertex2d((double)groupbox.getWidth(), 0.0);
        GL11.glVertex2d((double)groupbox.getWidth(), 0.0);
        GL11.glVertex2d((double)groupbox.getWidth(), (double)groupbox.getHeight());
        GL11.glVertex2d((double)groupbox.getWidth(), (double)groupbox.getHeight());
        GL11.glVertex2d(0.0, (double)groupbox.getHeight());
        GL11.glVertex2d(0.0, (double)groupbox.getHeight());
        GL11.glVertex2d(0.0, 0.0);
        GL11.glEnd();
    }
    
    @Override
    public void handleAddComponent(final Groupbox groupbox, final Container container) {
        groupbox.setWidth(100);
        groupbox.setHeight(100);
        groupbox.setOriginOffsetY(groupbox.getTheme().getFontRenderer().getFontHeight() + 3);
    }
    
    @Override
    public void handleMouseDown(final Component component, final int n, final int n2, final int n3) {
        this.handleMouseDown((Groupbox)component, n, n2, n3);
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((Groupbox)component, container);
    }
}
