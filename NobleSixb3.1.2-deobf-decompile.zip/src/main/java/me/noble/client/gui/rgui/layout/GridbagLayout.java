//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.layout;

import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.component.*;
import java.util.*;

public class GridbagLayout implements Layout
{
    private static final int COMPONENT_OFFSET;
    int maxrows;
    int blocks;
    
    static {
        COMPONENT_OFFSET = 10;
    }
    
    public GridbagLayout(final int blocks) {
        this.maxrows = -1;
        this.blocks = blocks;
    }
    
    @Override
    public void organiseContainer(final Container container) {
        int max = 0;
        int height = 0;
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        final ArrayList children = container.getChildren();
        for (final Component component : children) {
            if (!component.doAffectLayout()) {
                continue;
            }
            n2 += component.getWidth() + 10;
            n3 = Math.max(n3, component.getHeight());
            if (++n < this.blocks) {
                continue;
            }
            max = Math.max(max, n2);
            height += n3 + 10;
            n3 = (n2 = (n = 0));
        }
        int n4 = 0;
        int n5 = 0;
        for (final Component component2 : children) {
            if (!component2.doAffectLayout()) {
                continue;
            }
            component2.setX(n4 + 3);
            component2.setY(n5 + 3);
            n3 = Math.max(component2.getHeight(), n3);
            n4 += max / this.blocks;
            if (n4 < max) {
                continue;
            }
            n5 += n3 + 10;
            n4 = 0;
        }
        container.setWidth(max);
        container.setHeight(height);
    }
    
    public GridbagLayout(final int blocks, final int maxrows) {
        this.maxrows = -1;
        this.blocks = blocks;
        this.maxrows = maxrows;
    }
}
