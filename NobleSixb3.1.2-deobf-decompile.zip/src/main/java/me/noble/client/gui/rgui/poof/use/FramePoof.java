//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.poof.use;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.poof.*;

public abstract class FramePoof<T extends Component, S extends PoofInfo> extends Poof<T, S>
{
    public enum Action
    {
        MAXIMIZE, 
        CLOSE, 
        MINIMIZE;
        
        private static final Action[] $VALUES;
        
        static {
            $VALUES = new Action[] { Action.MINIMIZE, Action.MAXIMIZE, Action.CLOSE };
        }
    }
    
    public static class FramePoofInfo extends PoofInfo
    {
        private Action action;
        
        public Action getAction() {
            return this.action;
        }
        
        public FramePoofInfo(final Action action) {
            this.action = action;
        }
    }
}
