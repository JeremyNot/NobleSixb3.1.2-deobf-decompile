//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.poof.use.*;

public class EnumButton extends Button
{
    String[] modes;
    int index;
    
    public int getIndex() {
        return this.index;
    }
    
    public void setModes(final String[] modes) {
        this.modes = modes;
    }
    
    public String[] getModes() {
        return this.modes;
    }
    
    public EnumButton(final String s, final String[] modes) {
        super(s);
        this.modes = modes;
        this.index = 0;
        this.addPoof(new ButtonPoof<EnumButton, ButtonPoof.ButtonInfo>(this) {
            final EnumButton this$0;
            
            @Override
            public void execute(final EnumButton enumButton, final ButtonInfo buttonInfo) {
                if (buttonInfo.getButton() == 0) {
                    if (buttonInfo.getX() / (double)enumButton.getWidth() <= 0.5) {
                        this.this$0.increaseIndex(-1);
                    }
                    else {
                        this.this$0.increaseIndex(1);
                    }
                }
            }
            
            @Override
            public void execute(final Component component, final PoofInfo poofInfo) {
                this.execute((EnumButton)component, (ButtonInfo)poofInfo);
            }
        });
    }
    
    public String getIndexMode() {
        return this.modes[this.index];
    }
    
    public void setIndex(final int index) {
        this.index = index;
    }
    
    protected void increaseIndex(final int n) {
        final int index = this.index;
        int abs = this.index + n;
        if (abs < 0) {
            abs = this.modes.length - Math.abs(abs);
        }
        else if (abs >= this.modes.length) {
            abs = Math.abs(abs - this.modes.length);
        }
        this.index = Math.min(this.modes.length, Math.max(0, abs));
        this.callPoof(EnumbuttonIndexPoof.class, new EnumbuttonIndexPoof.EnumbuttonInfo(index, this.index));
    }
    
    public abstract static class EnumbuttonIndexPoof<T extends Button, S extends EnumbuttonInfo> extends Poof<T, S>
    {
        ButtonPoof.ButtonInfo info;
        
        public static class EnumbuttonInfo extends PoofInfo
        {
            int newIndex;
            int oldIndex;
            
            public int getOldIndex() {
                return this.oldIndex;
            }
            
            public EnumbuttonInfo(final int oldIndex, final int newIndex) {
                this.oldIndex = oldIndex;
                this.newIndex = newIndex;
            }
            
            public void setNewIndex(final int newIndex) {
                this.newIndex = newIndex;
            }
            
            public int getNewIndex() {
                return this.newIndex;
            }
        }
    }
}
