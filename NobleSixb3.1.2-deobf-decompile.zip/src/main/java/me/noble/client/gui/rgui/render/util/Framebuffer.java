//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.util;

import java.nio.*;
import org.lwjgl.opengl.*;

public class Framebuffer
{
    private int HEIGHT;
    private int framebufferDepthbuffer;
    private int WIDTH;
    private int framebufferTexture;
    private int framebufferID;
    
    private int createTextureAttachment(final int n, final int n2) {
        final int glGenTextures = GL11.glGenTextures();
        GL11.glBindTexture(3553, glGenTextures);
        GL11.glTexImage2D(3553, 0, 6407, n, n2, 0, 6407, 5121, (ByteBuffer)null);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL32.glFramebufferTexture(36160, 36064, glGenTextures, 0);
        return glGenTextures;
    }
    
    private int createDepthBufferAttachment(final int n, final int n2) {
        final int glGenRenderbuffers = GL30.glGenRenderbuffers();
        GL30.glBindRenderbuffer(36161, glGenRenderbuffers);
        GL30.glRenderbufferStorage(36161, 6402, n, n2);
        GL30.glFramebufferRenderbuffer(36160, 36096, 36161, glGenRenderbuffers);
        return glGenRenderbuffers;
    }
    
    public void unbindFramebuffer() {
        GL30.glBindFramebuffer(36160, 0);
        GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
    }
    
    public void cleanUp() {
        GL30.glDeleteFramebuffers(this.framebufferID);
        GL11.glDeleteTextures(this.framebufferTexture);
        GL30.glDeleteRenderbuffers(this.framebufferDepthbuffer);
    }
    
    private void bindFrameBuffer(final int n, final int n2, final int n3) {
        GL11.glBindTexture(3553, 0);
        GL30.glBindFramebuffer(36160, n);
        GL11.glViewport(0, 0, n2, n3);
    }
    
    private int createFrameBuffer() {
        final int glGenFramebuffers = GL30.glGenFramebuffers();
        GL30.glBindFramebuffer(36160, glGenFramebuffers);
        GL11.glDrawBuffer(36064);
        return glGenFramebuffers;
    }
    
    public int getHeight() {
        return this.HEIGHT;
    }
    
    public Framebuffer() {
        this(Display.getWidth(), Display.getHeight());
    }
    
    private int createDepthTextureAttachment(final int n, final int n2) {
        final int glGenTextures = GL11.glGenTextures();
        GL11.glBindTexture(3553, glGenTextures);
        GL11.glTexImage2D(3553, 0, 33191, n, n2, 0, 6402, 5126, (ByteBuffer)null);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL32.glFramebufferTexture(36160, 36096, glGenTextures, 0);
        return glGenTextures;
    }
    
    private void initialiseFramebuffer() {
        this.framebufferID = this.createFrameBuffer();
        this.framebufferTexture = this.createTextureAttachment(this.WIDTH, this.HEIGHT);
        this.framebufferDepthbuffer = this.createDepthBufferAttachment(this.WIDTH, this.HEIGHT);
        this.unbindFramebuffer();
    }
    
    public int getWidth() {
        return this.WIDTH;
    }
    
    public void framebufferClear() {
        this.bindFrameBuffer();
        GL11.glClear(16384);
        this.unbindFramebuffer();
    }
    
    public int getFramebufferTexture() {
        return this.framebufferTexture;
    }
    
    public void bindFrameBuffer() {
        this.bindFrameBuffer(this.framebufferID, this.WIDTH, this.HEIGHT);
    }
    
    public Framebuffer(final int width, final int height) {
        this.WIDTH = Display.getWidth();
        this.HEIGHT = Display.getHeight();
        this.WIDTH = width;
        this.HEIGHT = height;
        this.initialiseFramebuffer();
    }
}
