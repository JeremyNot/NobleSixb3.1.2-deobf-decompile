//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami;

import net.minecraft.client.gui.*;
import net.minecraft.client.shader.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.use.*;
import java.io.*;
import me.noble.client.util.*;
import org.lwjgl.input.*;
import net.minecraft.client.*;
import me.noble.client.module.*;
import me.noble.client.*;
import java.util.*;
import java.util.function.*;

public class DisplayGuiScreen extends GuiScreen
{
    public final GuiScreen lastScreen;
    Framebuffer framebuffer;
    public static int mouseY;
    public static int mouseX;
    KamiGUI gui;
    
    public void drawScreen(final int n, final int n2, final float n3) {
        this.calculateMouse();
        this.gui.drawGUI();
        GL11.glEnable(3553);
        GlStateManager.color(100.0f, 255.0f, 100.0f);
    }
    
    private static boolean lambda$onGuiClosed$0(final Component component) {
        return component instanceof Frame && ((Frame)component).isPinnable() && component.isVisible();
    }
    
    protected void mouseClicked(final int n, final int n2, final int n3) throws IOException {
        this.gui.handleMouseDown(DisplayGuiScreen.mouseX, DisplayGuiScreen.mouseY);
    }
    
    public static int getScale() {
        int n = 0;
        int guiScale = Wrapper.getMinecraft().gameSettings.guiScale;
        if (guiScale == 0) {
            guiScale = 1000;
        }
        while (n < guiScale && Wrapper.getMinecraft().displayWidth / (n + 1) >= 320 && Wrapper.getMinecraft().displayHeight / (n + 1) >= 240) {
            ++n;
        }
        if (n == 0) {
            n = 1;
        }
        return n;
    }
    
    private static void lambda$onGuiClosed$1(final Component component) {
        component.setOpacity(0.0f);
    }
    
    public void updateScreen() {
        if (Mouse.hasWheel()) {
            final int dWheel = Mouse.getDWheel();
            if (dWheel != 0) {
                this.gui.handleWheel(DisplayGuiScreen.mouseX, DisplayGuiScreen.mouseY, dWheel);
            }
        }
    }
    
    private void calculateMouse() {
        final Minecraft getMinecraft = Minecraft.getMinecraft();
        final int scale = getScale();
        DisplayGuiScreen.mouseX = Mouse.getX() / scale;
        DisplayGuiScreen.mouseY = getMinecraft.displayHeight / scale - Mouse.getY() / scale - 1;
    }
    
    protected void mouseClickMove(final int n, final int n2, final int n3, final long n4) {
        this.gui.handleMouseDrag(DisplayGuiScreen.mouseX, DisplayGuiScreen.mouseY);
    }
    
    protected void keyTyped(final char c, final int n) throws IOException {
        if (ModuleManager.getModuleByName("clickGUI").getBind().isDown(n) || n == 1) {
            this.mc.displayGuiScreen(this.lastScreen);
        }
        else {
            this.gui.handleKeyDown(n);
            this.gui.handleKeyUp(n);
        }
    }
    
    public void initGui() {
        this.gui = NobleMod.getInstance().getGuiManager();
    }
    
    public DisplayGuiScreen(final GuiScreen lastScreen) {
        this.lastScreen = lastScreen;
        for (final Component component : NobleMod.getInstance().getGuiManager().getChildren()) {
            if (component instanceof Frame) {
                final Frame frame = (Frame)component;
                if (!frame.isPinnable() || !frame.isVisible()) {
                    continue;
                }
                frame.setOpacity(0.5f);
            }
        }
        this.framebuffer = new Framebuffer(Wrapper.getMinecraft().displayWidth, Wrapper.getMinecraft().displayHeight, false);
    }
    
    protected void mouseReleased(final int n, final int n2, final int n3) {
        this.gui.handleMouseRelease(DisplayGuiScreen.mouseX, DisplayGuiScreen.mouseY);
    }
    
    public void onGuiClosed() {
        NobleMod.getInstance().getGuiManager().getChildren().stream().filter((Predicate<? super Object>)DisplayGuiScreen::lambda$onGuiClosed$0).forEach((Consumer<? super Object>)DisplayGuiScreen::lambda$onGuiClosed$1);
    }
}
