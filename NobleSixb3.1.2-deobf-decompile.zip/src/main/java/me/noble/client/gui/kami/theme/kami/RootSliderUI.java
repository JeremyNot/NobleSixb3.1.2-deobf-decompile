//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;

public class RootSliderUI extends AbstractComponentUI<Slider>
{
    RootSmallFontRenderer smallFontRenderer;
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((Slider)component, container);
    }
    
    public RootSliderUI() {
        this.smallFontRenderer = new RootSmallFontRenderer();
    }
    
    @Override
    public void renderComponent(final Slider slider, final FontRenderer fontRenderer) {
        GL11.glColor4f(1.0f, 0.33f, 0.33f, slider.getOpacity());
        GL11.glLineWidth(2.5f);
        final int height = slider.getHeight();
        final double value = slider.getValue();
        final double n = slider.getWidth() * ((value - slider.getMinimum()) / (slider.getMaximum() - slider.getMinimum()));
        final float n2 = 1.1f;
        GL11.glBegin(1);
        GL11.glVertex2d(0.0, (double)(height / n2));
        GL11.glVertex2d(n, (double)(height / n2));
        GL11.glColor3f(0.33f, 0.33f, 0.33f);
        GL11.glVertex2d(n, (double)(height / n2));
        GL11.glVertex2d((double)slider.getWidth(), (double)(height / n2));
        GL11.glEnd();
        GL11.glColor3f(1.0f, 0.33f, 0.33f);
        RenderHelper.drawCircle((float)(int)n, height / n2, 2.0f);
        final String value2 = String.valueOf(new StringBuilder().append(value).append(""));
        if (slider.isPressed()) {
            this.smallFontRenderer.drawString((int)Math.max(0.0, Math.min(n - this.smallFontRenderer.getStringWidth(value2) / 2, slider.getWidth() - this.smallFontRenderer.getStringWidth(value2))), 0, value2);
        }
        else {
            this.smallFontRenderer.drawString(0, 0, slider.getText());
            this.smallFontRenderer.drawString(slider.getWidth() - this.smallFontRenderer.getStringWidth(value2), 0, value2);
        }
        GL11.glDisable(3553);
    }
    
    @Override
    public void handleAddComponent(final Slider slider, final Container container) {
        slider.setHeight(slider.getTheme().getFontRenderer().getFontHeight() + 2);
        slider.setWidth(this.smallFontRenderer.getStringWidth(slider.getText()) + this.smallFontRenderer.getStringWidth(String.valueOf(new StringBuilder().append(slider.getMaximum()).append(""))) + 3);
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Slider)component, fontRenderer);
    }
}
