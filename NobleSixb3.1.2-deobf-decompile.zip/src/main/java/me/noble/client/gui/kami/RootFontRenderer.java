//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami;

import me.noble.client.gui.rgui.render.font.*;
import java.awt.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;

public class RootFontRenderer implements FontRenderer
{
    private final float fontsize;
    private final net.minecraft.client.gui.FontRenderer fontRenderer;
    
    @Override
    public void drawString(final int n, final int n2, final Color color, final String s) {
        this.drawString(n, n2, color.getRGB(), s);
    }
    
    @Override
    public void drawString(final int n, final int n2, final String s) {
        this.drawString(n, n2, 255, 255, 255, s);
    }
    
    public RootFontRenderer(final float fontsize) {
        this.fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        this.fontsize = fontsize;
    }
    
    @Override
    public int getFontHeight() {
        return (int)(Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT * this.fontsize);
    }
    
    public void drawString(final int n, final int n2, final int n3, final String s, final boolean b) {
        this.prepare(n, n2);
        Minecraft.getMinecraft().fontRendererObj.drawString(s, 0.0f, 0.0f, n3, b);
        this.pop(n, n2);
    }
    
    @Override
    public void drawString(final int n, final int n2, final int n3, final String s) {
        this.drawString(n, n2, n3, s, true);
    }
    
    @Override
    public int getStringHeight(final String s) {
        return this.getFontHeight();
    }
    
    @Override
    public void drawString(final int n, final int n2, final int n3, final int n4, final int n5, final String s) {
        this.drawString(n, n2, 0xFF000000 | (n3 & 0xFF) << 16 | (n4 & 0xFF) << 8 | (n5 & 0xFF), s);
    }
    
    private void prepare(final int n, final int n2) {
        GL11.glEnable(3553);
        GL11.glEnable(3042);
        GL11.glTranslatef((float)n, (float)n2, 0.0f);
        GL11.glScalef(this.fontsize, this.fontsize, 1.0f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void pop(final int n, final int n2) {
        GL11.glScalef(1.0f / this.fontsize, 1.0f / this.fontsize, 1.0f);
        GL11.glTranslatef((float)(-n), (float)(-n2), 0.0f);
        GL11.glDisable(3553);
    }
    
    @Override
    public int getStringWidth(final String s) {
        return (int)(this.fontRenderer.getStringWidth(s) * this.fontsize);
    }
    
    @Override
    public void drawStringWithShadow(final int n, final int n2, final int n3, final int n4, final int n5, final String s) {
        this.drawString(n, n2, 0xFF000000 | (n3 & 0xFF) << 16 | (n4 & 0xFF) << 8 | (n5 & 0xFF), s, true);
    }
}
