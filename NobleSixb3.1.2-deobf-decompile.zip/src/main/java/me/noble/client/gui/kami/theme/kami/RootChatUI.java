//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;

public class RootChatUI extends AbstractComponentUI<Chat>
{
}
