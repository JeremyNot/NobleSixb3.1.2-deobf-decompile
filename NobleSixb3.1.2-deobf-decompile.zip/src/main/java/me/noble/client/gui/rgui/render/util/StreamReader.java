//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.util;

import java.util.*;
import java.io.*;

public final class StreamReader
{
    private final InputStream stream;
    
    public final String read() {
        final StringJoiner stringJoiner = new StringJoiner("\n");
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.stream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringJoiner.add(line);
            }
            bufferedReader.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        return stringJoiner.toString();
    }
    
    public StreamReader(final InputStream stream) {
        this.stream = stream;
    }
}
