//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.theme;

import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.*;

public interface Theme
{
    FontRenderer getFontRenderer();
    
    ComponentUI getUIForComponent(final Component p0);
}
