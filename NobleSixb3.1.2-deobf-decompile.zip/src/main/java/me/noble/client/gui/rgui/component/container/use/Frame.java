//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.container.use;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.util.*;
import java.util.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.poof.use.*;

public class Frame extends OrganisedContainer
{
    int dy;
    boolean isLayoutWorking;
    boolean isCloseable;
    String title;
    int trueheight;
    int dx;
    HashMap<Component, Boolean> visibilityMap;
    Docking docking;
    boolean isPinned;
    boolean startDrag;
    boolean isMinimizeable;
    boolean isMinimized;
    int truemaxheight;
    boolean doDrag;
    boolean isPinneable;
    
    public boolean isMinimized() {
        return this.isMinimized;
    }
    
    public void setDocking(final Docking docking) {
        this.docking = docking;
    }
    
    public boolean isCloseable() {
        return this.isCloseable;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void setMinimized(final boolean isMinimized) {
        if (isMinimized && !this.isMinimized) {
            this.trueheight = this.getHeight();
            this.truemaxheight = this.getMaximumHeight();
            this.setHeight(0);
            this.setMaximumHeight(this.getOriginOffsetY());
            for (final Component component : this.getChildren()) {
                this.visibilityMap.put(component, component.isVisible());
                component.setVisible(false);
            }
        }
        else if (!isMinimized && this.isMinimized) {
            this.setMaximumHeight(this.truemaxheight);
            this.setHeight(this.trueheight - this.getOriginOffsetY());
            for (final Map.Entry<Component, Boolean> entry : this.visibilityMap.entrySet()) {
                entry.getKey().setVisible((boolean)entry.getValue());
            }
        }
        this.isMinimized = isMinimized;
    }
    
    public void setPinnable(final boolean isPinneable) {
        this.isPinneable = isPinneable;
    }
    
    public boolean isPinnable() {
        return this.isPinneable;
    }
    
    public Frame(final Theme theme, final Layout layout, final String title) {
        super(theme, layout);
        this.trueheight = 0;
        this.truemaxheight = 0;
        this.dx = 0;
        this.dy = 0;
        this.doDrag = false;
        this.startDrag = false;
        this.isMinimized = false;
        this.isMinimizeable = true;
        this.isCloseable = true;
        this.isPinned = false;
        this.isPinneable = false;
        this.isLayoutWorking = false;
        this.docking = Docking.NONE;
        this.visibilityMap = new HashMap<Component, Boolean>();
        this.title = title;
        this.addPoof((IPoof)new FramePoof<Frame, FramePoof.FramePoofInfo>(this) {
            final Frame this$0;
            
            @Override
            public void execute(final Frame frame, final FramePoofInfo framePoofInfo) {
                switch (framePoofInfo.getAction()) {
                    case MINIMIZE: {
                        if (this.this$0.isMinimizeable) {
                            this.this$0.setMinimized(true);
                            break;
                        }
                        break;
                    }
                    case MAXIMIZE: {
                        if (this.this$0.isMinimizeable) {
                            this.this$0.setMinimized(false);
                            break;
                        }
                        break;
                    }
                    case CLOSE: {
                        if (this.this$0.isCloseable) {
                            this.this$0.getParent().removeChild((Component)this.this$0);
                            break;
                        }
                        break;
                    }
                }
            }
            
            @Override
            public void execute(final Component component, final PoofInfo poofInfo) {
                this.execute((Frame)component, (FramePoofInfo)poofInfo);
            }
        });
        this.addUpdateListener((UpdateListener)new UpdateListener(this, layout) {
            final Layout val$layout;
            final Frame this$0;
            
            @Override
            public void updateSize(final Component component, final int n, final int n2) {
                if (this.this$0.isLayoutWorking) {
                    return;
                }
                if (!component.equals(this.this$0)) {
                    this.this$0.isLayoutWorking = true;
                    this.val$layout.organiseContainer((Container)this.this$0);
                    this.this$0.isLayoutWorking = false;
                }
            }
            
            @Override
            public void updateLocation(final Component component, final int n, final int n2) {
                if (this.this$0.isLayoutWorking) {
                    return;
                }
                if (!component.equals(this.this$0)) {
                    this.this$0.isLayoutWorking = true;
                    this.val$layout.organiseContainer((Container)this.this$0);
                    this.this$0.isLayoutWorking = false;
                }
            }
        });
        this.addRenderListener((RenderListener)new RenderListener(this) {
            final Frame this$0;
            
            @Override
            public void onPreRender() {
                if (this.this$0.startDrag) {
                    final FrameDragPoof.DragInfo dragInfo = new FrameDragPoof.DragInfo(DisplayGuiScreen.mouseX - this.this$0.dx, DisplayGuiScreen.mouseY - this.this$0.dy);
                    this.this$0.callPoof((Class)FrameDragPoof.class, (PoofInfo)dragInfo);
                    this.this$0.setX(dragInfo.getX());
                    this.this$0.setY(dragInfo.getY());
                }
            }
            
            @Override
            public void onPostRender() {
            }
        });
        this.addMouseListener((MouseListener)new GayMouseListener());
    }
    
    public Frame(final Theme theme, final String s) {
        this(theme, new UselessLayout(), s);
    }
    
    public void setPinned(final boolean b) {
        this.isPinned = (b && this.isPinneable);
    }
    
    public boolean isMinimizeable() {
        return this.isMinimizeable;
    }
    
    public Docking getDocking() {
        return this.docking;
    }
    
    public void setCloseable(final boolean isCloseable) {
        this.isCloseable = isCloseable;
    }
    
    public boolean isPinned() {
        return this.isPinned;
    }
    
    public void setMinimizeable(final boolean isMinimizeable) {
        this.isMinimizeable = isMinimizeable;
    }
    
    public abstract static class FrameDragPoof<T extends Frame, S extends DragInfo> extends Poof<T, S>
    {
        public static class DragInfo extends PoofInfo
        {
            int y;
            int x;
            
            public int getY() {
                return this.y;
            }
            
            public int getX() {
                return this.x;
            }
            
            public void setY(final int y) {
                this.y = y;
            }
            
            public DragInfo(final int x, final int y) {
                this.x = x;
                this.y = y;
            }
            
            public void setX(final int x) {
                this.x = x;
            }
        }
    }
    
    public class GayMouseListener implements MouseListener
    {
        final Frame this$0;
        
        public GayMouseListener(final Frame this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public void onScroll(final MouseScrollEvent mouseScrollEvent) {
        }
        
        @Override
        public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
            if (!this.this$0.doDrag) {
                return;
            }
            this.this$0.startDrag = true;
        }
        
        @Override
        public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
            this.this$0.doDrag = false;
            this.this$0.startDrag = false;
        }
        
        @Override
        public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
            this.this$0.dx = mouseButtonEvent.getX() + this.this$0.getOriginOffsetX();
            this.this$0.dy = mouseButtonEvent.getY() + this.this$0.getOriginOffsetY();
            if (this.this$0.dy <= this.this$0.getOriginOffsetY() && mouseButtonEvent.getButton() == 0 && this.this$0.dy > 0) {
                this.this$0.doDrag = true;
            }
            else {
                this.this$0.doDrag = false;
            }
            if (this.this$0.isMinimized && mouseButtonEvent.getY() > this.this$0.getOriginOffsetY()) {
                mouseButtonEvent.cancel();
            }
        }
        
        @Override
        public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
        }
    }
}
