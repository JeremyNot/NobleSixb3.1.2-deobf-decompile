//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.staticui;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import me.noble.client.gui.kami.*;
import net.minecraft.entity.*;
import me.noble.client.util.*;
import java.util.*;

public class RadarUI extends AbstractComponentUI<Radar>
{
    public static final int radius;
    float scale;
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Radar)component, fontRenderer);
    }
    
    static {
        radius = 45;
    }
    
    @Override
    public void handleSizeComponent(final Radar radar) {
        radar.setWidth(90);
        radar.setHeight(90);
    }
    
    @Override
    public void handleSizeComponent(final Component component) {
        this.handleSizeComponent((Radar)component);
    }
    
    public RadarUI() {
        this.scale = 2.0f;
    }
    
    @Override
    public void renderComponent(final Radar radar, final FontRenderer fontRenderer) {
        this.scale = 2.0f;
        GL11.glTranslated((double)(radar.getWidth() / 2), (double)(radar.getHeight() / 2), 0.0);
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.disableCull();
        GlStateManager.pushMatrix();
        GL11.glColor4f(0.11f, 0.11f, 0.11f, 0.6f);
        RenderHelper.drawCircle(0.0f, 0.0f, 45.0f);
        GL11.glRotatef(Wrapper.getPlayer().rotationYaw + 180.0f, 0.0f, 0.0f, -1.0f);
        for (final Entity entity : Wrapper.getWorld().loadedEntityList) {
            if (!(entity instanceof EntityLiving)) {
                continue;
            }
            float n = 1.0f;
            float n2 = 1.0f;
            if (EntityUtil.isPassive(entity)) {
                n = 0.0f;
            }
            else {
                n2 = 0.0f;
            }
            final double n3 = entity.posX - Wrapper.getPlayer().posX;
            final double n4 = entity.posZ - Wrapper.getPlayer().posZ;
            if (Math.sqrt(Math.pow(n3, 2.0) + Math.pow(n4, 2.0)) > 45.0f * this.scale) {
                continue;
            }
            if (Math.abs(Wrapper.getPlayer().posY - entity.posY) > 30.0) {
                continue;
            }
            GL11.glColor4f(n, n2, 0.0f, 0.5f);
            RenderHelper.drawCircle((int)n3 / this.scale, (int)n4 / this.scale, 2.5f / this.scale);
        }
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        RenderHelper.drawCircle(0.0f, 0.0f, 3.0f / this.scale);
        GL11.glLineWidth(1.8f);
        GL11.glColor3f(0.6f, 0.56f, 1.0f);
        GL11.glEnable(2848);
        RenderHelper.drawCircleOutline(0.0f, 0.0f, 45.0f);
        GL11.glDisable(2848);
        radar.getTheme().getFontRenderer().drawString(-radar.getTheme().getFontRenderer().getStringWidth("+z") / 2, 45 - radar.getTheme().getFontRenderer().getFontHeight(), "��7z+");
        GL11.glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
        radar.getTheme().getFontRenderer().drawString(-radar.getTheme().getFontRenderer().getStringWidth("+x") / 2, 45 - radar.getTheme().getFontRenderer().getFontHeight(), "��7x-");
        GL11.glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
        radar.getTheme().getFontRenderer().drawString(-radar.getTheme().getFontRenderer().getStringWidth("-z") / 2, 45 - radar.getTheme().getFontRenderer().getFontHeight(), "��7z-");
        GL11.glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
        radar.getTheme().getFontRenderer().drawString(-radar.getTheme().getFontRenderer().getStringWidth("+x") / 2, 45 - radar.getTheme().getFontRenderer().getFontHeight(), "��7x+");
        GlStateManager.popMatrix();
        GlStateManager.enableTexture2D();
        GL11.glTranslated((double)(-radar.getWidth() / 2), (double)(-radar.getHeight() / 2), 0.0);
    }
}
