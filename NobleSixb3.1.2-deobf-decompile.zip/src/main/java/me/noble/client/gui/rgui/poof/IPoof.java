//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.poof;

import me.noble.client.gui.rgui.component.*;

public interface IPoof<T extends Component, S extends PoofInfo>
{
    Class getComponentClass();
    
    void execute(final T p0, final S p1);
    
    Class getInfoClass();
}
