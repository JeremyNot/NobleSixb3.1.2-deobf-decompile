//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.use.*;

public class ColorizedCheckButton extends CheckButton
{
    public ColorizedCheckButton(final String s) {
        super(s);
    }
}
