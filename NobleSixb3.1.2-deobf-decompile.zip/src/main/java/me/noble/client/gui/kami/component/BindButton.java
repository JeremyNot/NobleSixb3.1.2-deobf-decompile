//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.module.*;
import me.noble.client.gui.rgui.component.listen.*;

public class BindButton extends EnumButton
{
    static String[] lookingFor;
    boolean waiting;
    Module m;
    boolean ctrl;
    static String[] none;
    boolean shift;
    boolean alt;
    
    private boolean isCtrl(final int n) {
        return n == 29 || n == 157;
    }
    
    static {
        BindButton.lookingFor = new String[] { "_" };
        BindButton.none = new String[] { "NONE" };
    }
    
    static boolean access$000(final BindButton bindButton, final int n) {
        return bindButton.isShift(n);
    }
    
    private boolean isAlt(final int n) {
        return n == 56 || n == 184;
    }
    
    public BindButton(final String s, final Module m) {
        super(s, BindButton.none);
        this.waiting = false;
        this.ctrl = false;
        this.shift = false;
        this.alt = false;
        this.m = m;
        this.modes = new String[] { m.getBind().toString() };
        this.addKeyListener(new KeyListener(this, m) {
            final BindButton this$0;
            final Module val$m;
            
            @Override
            public void onKeyUp(final KeyEvent keyEvent) {
            }
            
            @Override
            public void onKeyDown(final KeyEvent keyEvent) {
                if (!this.this$0.waiting) {
                    return;
                }
                final int key = keyEvent.getKey();
                if (BindButton.access$000(this.this$0, key)) {
                    this.this$0.shift = true;
                    this.this$0.modes = new String[] { String.valueOf(new StringBuilder().append(this.this$0.ctrl ? "Ctrl+" : "").append(this.this$0.alt ? "Alt+" : "").append("Shift+")) };
                }
                else if (BindButton.access$100(this.this$0, key)) {
                    this.this$0.ctrl = true;
                    this.this$0.modes = new String[] { String.valueOf(new StringBuilder().append("Ctrl+").append(this.this$0.alt ? "Alt+" : "").append(this.this$0.shift ? "Shift+" : "")) };
                }
                else if (BindButton.access$200(this.this$0, key)) {
                    this.this$0.alt = true;
                    this.this$0.modes = new String[] { String.valueOf(new StringBuilder().append(this.this$0.ctrl ? "Ctrl+" : "").append("Alt+").append(this.this$0.shift ? "Shift+" : "")) };
                }
                else if (key == 14) {
                    this.val$m.getBind().setCtrl(false);
                    this.val$m.getBind().setShift(false);
                    this.val$m.getBind().setAlt(false);
                    this.val$m.getBind().setKey(-1);
                    this.this$0.modes = new String[] { this.val$m.getBind().toString() };
                    this.this$0.waiting = false;
                }
                else {
                    this.val$m.getBind().setCtrl(this.this$0.ctrl);
                    this.val$m.getBind().setShift(this.this$0.shift);
                    this.val$m.getBind().setAlt(this.this$0.alt);
                    this.val$m.getBind().setKey(key);
                    this.this$0.modes = new String[] { this.val$m.getBind().toString() };
                    final BindButton this$0 = this.this$0;
                    final BindButton this$2 = this.this$0;
                    final BindButton this$3 = this.this$0;
                    final boolean ctrl = false;
                    this$3.shift = ctrl;
                    this$2.alt = ctrl;
                    this$0.ctrl = ctrl;
                    this.this$0.waiting = false;
                }
            }
        });
        this.addMouseListener(new MouseListener(this) {
            final BindButton this$0;
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.setModes(BindButton.lookingFor);
                this.this$0.waiting = true;
            }
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
            }
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
            }
        });
    }
    
    private boolean isShift(final int n) {
        return n == 42 || n == 54;
    }
    
    static boolean access$200(final BindButton bindButton, final int n) {
        return bindButton.isAlt(n);
    }
    
    static boolean access$100(final BindButton bindButton, final int n) {
        return bindButton.isCtrl(n);
    }
}
