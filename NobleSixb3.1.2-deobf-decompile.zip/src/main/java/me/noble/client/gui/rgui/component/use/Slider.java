//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.use;

import me.noble.client.gui.rgui.component.listen.*;
import net.minecraft.util.math.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.poof.use.*;

public class Slider extends AbstractComponent
{
    double maximum;
    boolean integer;
    String text;
    double value;
    double step;
    double minimum;
    
    public Slider(final double value, final double minimum, final double maximum, final double step, final String text, final boolean integer) {
        this.value = value;
        this.minimum = minimum;
        this.maximum = maximum;
        this.step = step;
        this.text = text;
        this.integer = integer;
        this.addMouseListener((MouseListener)new MouseListener(this) {
            final Slider this$0;
            
            public void onMouseRelease(final MouseListener.MouseButtonEvent mouseButtonEvent) {
            }
            
            public void onMouseDown(final MouseListener.MouseButtonEvent mouseButtonEvent) {
                this.this$0.setValue(Slider.access$000(this.this$0, mouseButtonEvent.getX()));
            }
            
            public void onMouseDrag(final MouseListener.MouseButtonEvent mouseButtonEvent) {
                this.this$0.setValue(Slider.access$000(this.this$0, mouseButtonEvent.getX()));
            }
            
            public void onMouseMove(final MouseListener.MouseMoveEvent mouseMoveEvent) {
            }
            
            public void onScroll(final MouseListener.MouseScrollEvent mouseScrollEvent) {
            }
        });
    }
    
    private double calculateValue(final double n) {
        return MathHelper.clamp(Math.floor(Math.round((n / this.getWidth() * (this.maximum - this.minimum) + this.minimum) / this.step) * this.step * 100.0) / 100.0, this.minimum, this.maximum);
    }
    
    public static double getDefaultStep(final double n, final double n2) {
        double gcd = gcd(n, n2);
        if (gcd == n2) {
            gcd = n2 / 20.0;
        }
        if (n2 > 10.0) {
            gcd = (double)Math.round(gcd);
        }
        if (gcd == 0.0) {
            gcd = n2;
        }
        return gcd;
    }
    
    public void setValue(final double n) {
        final SliderPoof.SliderPoofInfo sliderPoofInfo = new SliderPoof.SliderPoofInfo(this.value, n);
        this.callPoof((Class)SliderPoof.class, (PoofInfo)sliderPoofInfo);
        final double newValue = sliderPoofInfo.getNewValue();
        this.value = (this.integer ? ((double)(int)newValue) : newValue);
    }
    
    static double access$000(final Slider slider, final double n) {
        return slider.calculateValue(n);
    }
    
    public static double gcd(double floor, double floor2) {
        floor = Math.floor(floor);
        floor2 = Math.floor(floor2);
        if (floor == 0.0 || floor2 == 0.0) {
            return floor + floor2;
        }
        return gcd(floor2, floor % floor2);
    }
    
    public double getMaximum() {
        return this.maximum;
    }
    
    public String getText() {
        return this.text;
    }
    
    public double getStep() {
        return this.step;
    }
    
    public double getMinimum() {
        return this.minimum;
    }
    
    public double getValue() {
        return this.value;
    }
    
    public Slider(final double n, final double n2, final double n3, final String s) {
        this(n, n2, n3, getDefaultStep(n2, n3), s, false);
    }
    
    public abstract static class SliderPoof<T extends Component, S extends SliderPoofInfo> extends Poof<T, S>
    {
        public static class SliderPoofInfo extends PoofInfo
        {
            double oldValue;
            double newValue;
            
            public double getOldValue() {
                return this.oldValue;
            }
            
            public SliderPoofInfo(final double oldValue, final double newValue) {
                this.oldValue = oldValue;
                this.newValue = newValue;
            }
            
            public void setNewValue(final double newValue) {
                this.newValue = newValue;
            }
            
            public double getNewValue() {
                return this.newValue;
            }
        }
    }
}
