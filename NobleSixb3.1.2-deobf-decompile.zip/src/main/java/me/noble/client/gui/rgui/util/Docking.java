//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.util;

public enum Docking
{
    boolean isLeft;
    
    CENTERBOTTOM(false, false, true, false);
    
    boolean isBottom;
    
    RIGHT(false, false, false, true), 
    BOTTOMRIGHT(false, false, true, true), 
    CENTERLEFT(true, true, true, false), 
    NONE(false, false, false, false);
    
    boolean isRight;
    private static final Docking[] $VALUES;
    
    TOPLEFT(true, true, false, false), 
    CENTERTOP(true, true, false, true), 
    BOTTOMLEFT(false, true, true, false), 
    CENTERRIGHT(true, false, true, true), 
    CENTERHOIZONTAL(true, false, true, false), 
    TOPRIGHT(true, false, false, true), 
    CENTER(true, true, true, true), 
    BOTTOM(false, false, true, false), 
    LEFT(false, true, false, false);
    
    boolean isTop;
    
    TOP(true, false, false, false), 
    CENTERVERTICAL(false, true, false, true);
    
    public boolean isTop() {
        return this.isTop && !this.isBottom;
    }
    
    public boolean isCenterHorizontal() {
        return this.isLeft && this.isRight;
    }
    
    public boolean isRight() {
        return this.isRight && !this.isLeft;
    }
    
    private Docking(final boolean isTop, final boolean isLeft, final boolean isBottom, final boolean isRight) {
        this.isTop = isTop;
        this.isLeft = isLeft;
        this.isBottom = isBottom;
        this.isRight = isRight;
    }
    
    static {
        $VALUES = new Docking[] { Docking.TOPLEFT, Docking.TOP, Docking.TOPRIGHT, Docking.RIGHT, Docking.BOTTOMRIGHT, Docking.BOTTOM, Docking.BOTTOMLEFT, Docking.LEFT, Docking.CENTER, Docking.NONE, Docking.CENTERTOP, Docking.CENTERBOTTOM, Docking.CENTERVERTICAL, Docking.CENTERHOIZONTAL, Docking.CENTERLEFT, Docking.CENTERRIGHT };
    }
    
    public boolean isBottom() {
        return this.isBottom && !this.isTop;
    }
    
    public boolean isLeft() {
        return this.isLeft && !this.isRight;
    }
    
    public boolean isCenterVertical() {
        return this.isTop && this.isBottom;
    }
}
