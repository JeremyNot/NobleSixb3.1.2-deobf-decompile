//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami;

import me.noble.client.gui.rgui.*;
import me.noble.client.gui.rgui.render.theme.*;
import java.text.*;
import com.mojang.realmsclient.gui.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.entity.*;
import me.noble.client.*;
import net.minecraft.client.*;
import javax.annotation.*;
import net.minecraft.util.text.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.projectile.*;
import java.util.concurrent.atomic.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.util.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.font.*;
import java.math.*;
import me.noble.client.gui.rgui.component.listen.*;
import java.util.stream.*;
import java.util.function.*;
import me.noble.client.gui.kami.component.*;
import java.util.*;
import me.noble.client.module.modules.gui.*;
import me.noble.client.gui.kami.theme.kami.*;

public class KamiGUI extends GUI
{
    private static final int DOCK_OFFSET;
    public Theme theme;
    public static final RootFontRenderer fontRenderer;
    public static ColourHolder primaryColour;
    
    static {
        DOCK_OFFSET = 0;
        fontRenderer = new RootFontRenderer(1.0f);
        KamiGUI.primaryColour = new ColourHolder(29, 29, 29);
    }
    
    private static void lambda$initializeGUI$7(final Label label, final DecimalFormat decimalFormat, final StringBuilder sb) {
        if (!label.isVisible()) {
            return;
        }
        label.setText("");
        final Minecraft minecraft = Wrapper.getMinecraft();
        if (minecraft.player == null) {
            return;
        }
        final List playerEntities = minecraft.world.playerEntities;
        final HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
        for (final Entity entity : playerEntities) {
            if (entity.getName().equals(minecraft.player.getName())) {
                continue;
            }
            final String s = (entity.posY > minecraft.player.posY) ? String.valueOf(new StringBuilder().append(ChatFormatting.DARK_GREEN).append("+")) : ((entity.posY == minecraft.player.posY) ? " " : String.valueOf(new StringBuilder().append(ChatFormatting.DARK_RED).append("-")));
            String s2;
            if (((EntityPlayer)entity).isPotionActive(MobEffects.STRENGTH)) {
                s2 = "S ";
            }
            else {
                s2 = "  ";
            }
            final float n = ((EntityLivingBase)entity).getHealth() + ((EntityLivingBase)entity).getAbsorptionAmount();
            final String format = decimalFormat.format(n);
            sb.append(NobleMod.colour);
            if (n >= 20.0f) {
                sb.append("a");
            }
            else if (n >= 10.0f) {
                sb.append("e");
            }
            else if (n >= 5.0f) {
                sb.append("6");
            }
            else {
                sb.append("c");
            }
            sb.append(format);
            hashMap.put(String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append(s).append(" ").append(String.valueOf(sb)).append(" ").append(ChatFormatting.RED).append(s2).append(ChatFormatting.GRAY).append(entity.getName())), (int)minecraft.player.getDistanceToEntity(entity));
            sb.setLength(0);
        }
        if (hashMap.isEmpty()) {
            label.setText("");
            return;
        }
        for (final Map.Entry<Object, Comparable> entry : sortByValue((Map<Object, Comparable>)hashMap).entrySet()) {
            label.addLine(String.valueOf(new StringBuilder().append(NobleMod.colour).append("7").append(entry.getKey()).append(" ").append(NobleMod.colour).append("8").append(entry.getValue())));
        }
    }
    
    private static void lambda$initializeGUI$0(final CheckButton checkButton, final Module module) {
        checkButton.setToggled(module.isEnabled());
        checkButton.setName(module.getName());
    }
    
    @Override
    public void destroyGUI() {
        this.kill();
    }
    
    private static String getEntityName(@Nonnull final Entity entity) {
        if (entity instanceof EntityItem) {
            return String.valueOf(new StringBuilder().append(TextFormatting.DARK_AQUA).append(((EntityItem)entity).getEntityItem().getItem().getItemStackDisplayName(((EntityItem)entity).getEntityItem())));
        }
        if (entity instanceof EntityWitherSkull) {
            return String.valueOf(new StringBuilder().append(TextFormatting.DARK_GRAY).append("Wither skull"));
        }
        if (entity instanceof EntityEnderCrystal) {
            return String.valueOf(new StringBuilder().append(TextFormatting.LIGHT_PURPLE).append("End crystal"));
        }
        if (entity instanceof EntityEnderPearl) {
            return "Thrown ender pearl";
        }
        if (entity instanceof EntityMinecart) {
            return "Minecart";
        }
        if (entity instanceof EntityItemFrame) {
            return "Item frame";
        }
        if (entity instanceof EntityEgg) {
            return "Thrown egg";
        }
        if (entity instanceof EntitySnowball) {
            return "Thrown snowball";
        }
        return entity.getName();
    }
    
    private static void lambda$initializeGUI$2(final Label label) {
        label.setWidth(151);
        label.setHeight(40);
        label.setOpacity(0.1f);
    }
    
    private static void lambda$null$5(final AtomicInteger atomicInteger, final Friends.Friend friend) {
        atomicInteger.getAndIncrement();
    }
    
    @Override
    public void drawGUI() {
        super.drawGUI();
    }
    
    public static void dock(final Frame frame) {
        final Docking docking = frame.getDocking();
        if (docking.isTop()) {
            frame.setY(0);
        }
        if (docking.isBottom()) {
            frame.setY(Wrapper.getMinecraft().displayHeight / DisplayGuiScreen.getScale() - frame.getHeight() - 0);
        }
        if (docking.isLeft()) {
            frame.setX(0);
        }
        if (docking.isRight()) {
            frame.setX(Wrapper.getMinecraft().displayWidth / DisplayGuiScreen.getScale() - frame.getWidth() - 0);
        }
        if (docking.isCenterHorizontal()) {
            frame.setX(Wrapper.getMinecraft().displayWidth / (DisplayGuiScreen.getScale() * 2) - frame.getWidth() / 2);
        }
        if (docking.isCenterVertical()) {
            frame.setY(Wrapper.getMinecraft().displayHeight / (DisplayGuiScreen.getScale() * 2) - frame.getHeight() / 2);
        }
    }
    
    private static Comparable lambda$sortByValue$8(final Map.Entry entry) {
        return entry.getValue();
    }
    
    private static void lambda$initializeGUI$6(final Frame frame, final Label label, final AtomicInteger atomicInteger) {
        if (!frame.isMinimized()) {
            label.setText("");
            Friends.friends.getValue().forEach(KamiGUI::lambda$null$5);
        }
        else {
            label.setText("");
        }
    }
    
    private static void lambda$initializeGUI$3(final Label label) {
        label.setWidth(255);
        label.setHeight(20);
        label.setOpacity(0.1f);
    }
    
    private static void lambda$initializeGUI$4(final Label label) {
        label.setWidth(82);
        label.setHeight(58);
        label.setOpacity(0.1f);
    }
    
    static String access$000(final Entity entity) {
        return getEntityName(entity);
    }
    
    @Override
    public void initializeGUI() {
        final HashMap<Module.Category, Pair<Object, Object>> hashMap = new HashMap<Module.Category, Pair<Object, Object>>();
        for (final Module module : ModuleManager.getModules()) {
            if (module.getCategory().isHidden()) {
                continue;
            }
            final Module.Category category = module.getCategory();
            if (!hashMap.containsKey(category)) {
                final Stretcherlayout stretcherlayout = new Stretcherlayout(1);
                stretcherlayout.setComponentOffsetWidth(0);
                final Scrollpane scrollpane = new Scrollpane(this.getTheme(), stretcherlayout, 300, 260);
                scrollpane.setMaximumHeight(180);
                hashMap.put(category, new Pair<Object, Object>(scrollpane, new SettingsPanel(this.getTheme(), (Module)null)));
            }
            final Pair<Object, Object> pair = hashMap.get(category);
            final Scrollpane scrollpane2 = pair.getKey();
            final CheckButton checkButton = new CheckButton(module.getName());
            checkButton.setToggled(module.isEnabled());
            checkButton.addTickListener(KamiGUI::lambda$initializeGUI$0);
            checkButton.addMouseListener(new MouseListener(this, pair, module, checkButton) {
                final KamiGUI this$0;
                final CheckButton val$checkButton;
                final Pair val$pair;
                final Module val$module;
                
                @Override
                public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                    if (mouseButtonEvent.getButton() == 1) {
                        this.val$pair.getValue().setModule(this.val$module);
                        this.val$pair.getValue().setX(mouseButtonEvent.getX() + this.val$checkButton.getX());
                        this.val$pair.getValue().setY(mouseButtonEvent.getY() + this.val$checkButton.getY());
                    }
                }
                
                @Override
                public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
                }
                
                @Override
                public void onScroll(final MouseScrollEvent mouseScrollEvent) {
                }
                
                @Override
                public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
                }
                
                @Override
                public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
                }
            });
            checkButton.addPoof(new CheckButton.CheckButtonPoof<CheckButton, CheckButton.CheckButtonPoof.CheckButtonPoofInfo>(this, module, checkButton) {
                final KamiGUI this$0;
                final Module val$module;
                final CheckButton val$checkButton;
                
                @Override
                public void execute(final Component component, final PoofInfo poofInfo) {
                    this.execute((CheckButton)component, (CheckButtonPoofInfo)poofInfo);
                }
                
                @Override
                public void execute(final CheckButton checkButton, final CheckButtonPoofInfo checkButtonPoofInfo) {
                    if (checkButtonPoofInfo.getAction().equals(CheckButtonPoofInfo.CheckButtonPoofInfoAction.TOGGLE)) {
                        this.val$module.setEnabled(this.val$checkButton.isToggled());
                    }
                }
            });
            scrollpane2.addChild(checkButton);
        }
        int n = 10;
        int n3;
        int n2 = n3 = 10;
        for (final Map.Entry<Module.Category, Pair<Object, Object>> entry : hashMap.entrySet()) {
            final Stretcherlayout stretcherlayout2 = new Stretcherlayout(1);
            stretcherlayout2.COMPONENT_OFFSET_Y = 1;
            final Frame frame = new Frame(this.getTheme(), stretcherlayout2, entry.getKey().getName());
            final Scrollpane scrollpane3 = entry.getValue().getKey();
            frame.addChild(scrollpane3);
            frame.addChild(entry.getValue().getValue());
            scrollpane3.setOriginOffsetY(0);
            scrollpane3.setOriginOffsetX(0);
            frame.setCloseable(false);
            frame.setX(n);
            frame.setY(n2);
            this.addChild(frame);
            n3 = Math.max(n2 + frame.getHeight() + 10, n3);
            n += frame.getWidth() + 10;
            if (n > Wrapper.getMinecraft().displayWidth / 1.2f) {
                n2 = (n3 = n3);
            }
        }
        this.addMouseListener(new MouseListener(this) {
            final KamiGUI this$0;
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
            
            private boolean isNotBetween(final int n, final int n2, final int n3) {
                return n2 > n3 || n2 < n;
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
            }
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
            }
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                for (final SettingsPanel settingsPanel : ContainerHelper.getAllChildren((Class<? extends SettingsPanel>)SettingsPanel.class, (Container)this.this$0)) {
                    if (!settingsPanel.isVisible()) {
                        continue;
                    }
                    final int[] calculateRealPosition = GUI.calculateRealPosition((Component)settingsPanel);
                    final int n = mouseButtonEvent.getX() - calculateRealPosition[0];
                    final int n2 = mouseButtonEvent.getY() - calculateRealPosition[1];
                    if (!this.isNotBetween(0, n, settingsPanel.getWidth()) && !this.isNotBetween(0, n2, settingsPanel.getHeight())) {
                        continue;
                    }
                    settingsPanel.setVisible(false);
                }
            }
        });
        final ArrayList<Frame> list = new ArrayList<Frame>();
        final Frame frame2 = new Frame(this.getTheme(), new Stretcherlayout(1), "Active modules");
        frame2.setCloseable(false);
        frame2.addChild((Component)new ActiveModules());
        frame2.setPinnable(true);
        list.add(frame2);
        final Frame frame3 = new Frame(this.getTheme(), new Stretcherlayout(1), "Info");
        frame3.setCloseable(false);
        frame3.setPinnable(true);
        final Label label = new Label("");
        label.setShadow(true);
        label.addTickListener(KamiGUI::lambda$initializeGUI$1);
        frame3.addChild(label);
        label.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame3);
        final Frame frame4 = new Frame(this.getTheme(), new Stretcherlayout(1), "Inventory Viewer");
        frame4.setCloseable(false);
        frame4.setMinimizeable(false);
        frame4.setPinnable(true);
        frame4.setPinned(true);
        final Label label2 = new Label("");
        label2.addTickListener(KamiGUI::lambda$initializeGUI$2);
        label2.setShadow(false);
        frame4.addChild(label2);
        label2.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame4);
        final Frame frame5 = new Frame(this.getTheme(), new Stretcherlayout(1), "Spartan Energyshield");
        frame5.setCloseable(false);
        frame5.setMinimizeable(false);
        frame5.setPinnable(true);
        frame5.setPinned(true);
        final Label label3 = new Label("");
        label3.addTickListener(KamiGUI::lambda$initializeGUI$3);
        label3.setShadow(false);
        frame5.addChild(label3);
        label3.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame5);
        final Frame frame6 = new Frame(this.getTheme(), new Stretcherlayout(1), "Combat Info");
        frame6.setCloseable(false);
        frame6.setMinimizeable(false);
        frame6.setPinnable(true);
        frame6.setPinned(true);
        final Label label4 = new Label("");
        label4.addTickListener(KamiGUI::lambda$initializeGUI$4);
        label4.setShadow(false);
        frame6.addChild(label4);
        label4.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame6);
        final Frame frame7 = new Frame(this.getTheme(), new Stretcherlayout(1), "Friends");
        frame7.setCloseable(false);
        frame7.setPinnable(true);
        final Label label5 = new Label("");
        label5.setShadow(true);
        label5.addTickListener(KamiGUI::lambda$initializeGUI$6);
        frame7.addChild(label5);
        label5.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame7);
        final Frame frame8 = new Frame(this.getTheme(), new Stretcherlayout(1), "Text Radar");
        final Label label6 = new Label("");
        final DecimalFormat decimalFormat = new DecimalFormat("#.#");
        decimalFormat.setRoundingMode(RoundingMode.HALF_UP);
        label6.addTickListener(KamiGUI::lambda$initializeGUI$7);
        frame8.setCloseable(false);
        frame8.setPinnable(true);
        frame8.setMinimumWidth(75);
        label6.setShadow(true);
        frame8.addChild(label6);
        label6.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame8);
        final Frame frame9 = new Frame(this.getTheme(), new Stretcherlayout(1), "Entities");
        final Label label7 = new Label("");
        frame9.setCloseable(false);
        label7.addTickListener(new TickListener(this, label7) {
            final Label val$entityLabel;
            final KamiGUI this$0;
            Minecraft mc = Wrapper.getMinecraft();
            
            @Override
            public void onTick() {
                if (this.mc.player == null || !this.val$entityLabel.isVisible()) {
                    return;
                }
                final ArrayList<Object> list = new ArrayList<Object>(this.mc.world.loadedEntityList);
                if (list.size() <= 1) {
                    this.val$entityLabel.setText("");
                    return;
                }
                final Map<Object, Object> map = list.stream().filter(Objects::nonNull).filter((Predicate<? super Object>)KamiGUI$4::lambda$onTick$0).collect(Collectors.groupingBy((Function<? super Object, ?>)KamiGUI$4::lambda$onTick$1, (Collector<? super Object, ?, Object>)Collectors.reducing((D)0, (Function<? super Object, ? extends D>)KamiGUI$4::lambda$onTick$2, Integer::sum)));
                this.val$entityLabel.setText("");
                map.entrySet().stream().sorted((Comparator<? super Object>)Map.Entry.comparingByValue()).map((Function<? super Object, ?>)KamiGUI$4::lambda$onTick$3).forEach((Consumer<? super Object>)this.val$entityLabel::addLine);
            }
            
            private static String lambda$onTick$3(final Map.Entry entry) {
                return String.valueOf(new StringBuilder().append(TextFormatting.GRAY).append(entry.getKey()).append(" ").append(TextFormatting.DARK_GRAY).append("x").append(entry.getValue()));
            }
            
            private static Integer lambda$onTick$2(final Entity entity) {
                if (entity instanceof EntityItem) {
                    return ((EntityItem)entity).getEntityItem().func_190916_E();
                }
                return 1;
            }
            
            private static String lambda$onTick$1(final Entity entity) {
                return KamiGUI.access$000(entity);
            }
            
            private static boolean lambda$onTick$0(final Entity entity) {
                return !(entity instanceof EntityPlayer);
            }
        });
        frame9.addChild(label7);
        frame9.setPinnable(true);
        label7.setShadow(true);
        label7.setFontRenderer(KamiGUI.fontRenderer);
        list.add(frame9);
        final Frame frame10 = new Frame(this.getTheme(), new Stretcherlayout(1), "Coordinates");
        frame10.setCloseable(false);
        frame10.setPinnable(true);
        final Label label8 = new Label("");
        label8.addTickListener(new TickListener(this, label8) {
            Minecraft mc = Minecraft.getMinecraft();
            final Label val$coordsLabel;
            final KamiGUI this$0;
            
            @Override
            public void onTick() {
                final boolean equals = this.mc.world.getBiome(this.mc.player.getPosition()).getBiomeName().equals("Hell");
                final int n = (int)this.mc.player.posX;
                final int n2 = (int)this.mc.player.posY;
                final int n3 = (int)this.mc.player.posZ;
                final float n4 = equals ? 8.0f : 0.125f;
                this.val$coordsLabel.setText(String.format(" %sf%,d%s7, %sf%,d%s7, %sf%,d %s7(%sf%,d%s7, %sf%,d%s7, %sf%,d%s7)", NobleMod.colour, n, NobleMod.colour, NobleMod.colour, n2, NobleMod.colour, NobleMod.colour, n3, NobleMod.colour, NobleMod.colour, (int)(this.mc.player.posX * n4), NobleMod.colour, NobleMod.colour, n2, NobleMod.colour, NobleMod.colour, (int)(this.mc.player.posZ * n4), NobleMod.colour));
            }
        });
        frame10.addChild(label8);
        label8.setFontRenderer(KamiGUI.fontRenderer);
        label8.setShadow(true);
        frame10.setHeight(20);
        list.add(frame10);
        final Frame frame11 = new Frame(this.getTheme(), new Stretcherlayout(1), "Radar");
        frame11.setCloseable(false);
        frame11.setMinimizeable(true);
        frame11.setPinnable(true);
        frame11.addChild((Component)new Radar());
        frame11.setWidth(100);
        frame11.setHeight(100);
        list.add(frame11);
        for (final Frame frame12 : list) {
            frame12.setX(n);
            frame12.setY(n2);
            n3 = Math.max(n2 + frame12.getHeight() + 10, n3);
            n += frame12.getWidth() + 10;
            if (n * DisplayGuiScreen.getScale() > Wrapper.getMinecraft().displayWidth / 1.2f) {
                n2 = (n3 = n3);
                n = 10;
            }
            this.addChild(frame12);
        }
    }
    
    public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(final Map<K, V> map) {
        final LinkedList<Object> list = new LinkedList<Object>(map.entrySet());
        Collections.sort(list, Comparator.comparing((Function<? super Object, ? extends Comparable>)KamiGUI::lambda$sortByValue$8));
        final LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>();
        for (final Map.Entry<Object, V> entry : list) {
            linkedHashMap.put(entry.getKey(), entry.getValue());
        }
        return (Map<K, V>)linkedHashMap;
    }
    
    private static void lambda$initializeGUI$1(final Label label) {
        final InfoOverlay infoOverlay = (InfoOverlay)ModuleManager.getModuleByName("InfoOverlay");
        label.setText("");
        infoOverlay.infoContents().forEach(label::addLine);
    }
    
    public KamiGUI() {
        super(new KamiTheme());
        this.theme = this.getTheme();
    }
}
