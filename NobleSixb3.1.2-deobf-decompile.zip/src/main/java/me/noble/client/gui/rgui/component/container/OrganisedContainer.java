//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.container;

import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.component.*;

public class OrganisedContainer extends AbstractContainer
{
    Layout layout;
    
    public void setOriginOffsetX(final int originOffsetX) {
        super.setOriginOffsetX(originOffsetX);
        this.layout.organiseContainer((Container)this);
    }
    
    public void setOriginOffsetY(final int originOffsetY) {
        super.setOriginOffsetY(originOffsetY);
        this.layout.organiseContainer((Container)this);
    }
    
    public OrganisedContainer(final Theme theme, final Layout layout) {
        super(theme);
        this.layout = layout;
    }
    
    public Container addChild(final Component... array) {
        super.addChild(array);
        this.layout.organiseContainer((Container)this);
        return (Container)this;
    }
    
    public Layout getLayout() {
        return this.layout;
    }
    
    public void setLayout(final Layout layout) {
        this.layout = layout;
    }
}
