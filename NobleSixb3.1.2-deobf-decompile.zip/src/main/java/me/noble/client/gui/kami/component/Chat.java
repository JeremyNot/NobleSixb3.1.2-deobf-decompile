//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.listen.*;

public class Chat extends AbstractContainer
{
    Label label;
    InputField field;
    Scrollpane scrollpane;
    
    public Chat(final Theme theme, final int n, final int n2) {
        super(theme);
        this.label = new Label("", true);
        this.field = new InputField(n);
        (this.scrollpane = new Scrollpane(this.getTheme(), new Stretcherlayout(1), n, n2)).setWidth(n);
        this.scrollpane.setHeight(n2);
        this.scrollpane.setLockHeight(true).setLockWidth(true);
        this.scrollpane.addChild(this.label);
        this.field.addKeyListener(new KeyListener(this) {
            final Chat this$0;
            
            @Override
            public void onKeyUp(final KeyEvent keyEvent) {
            }
            
            @Override
            public void onKeyDown(final KeyEvent keyEvent) {
                if (keyEvent.getKey() == 28) {
                    this.this$0.label.addLine(this.this$0.field.getText());
                    this.this$0.field.setText("");
                    if (this.this$0.scrollpane.canScrollY()) {
                        this.this$0.scrollpane.setScrolledY(this.this$0.scrollpane.getMaxScrollY());
                    }
                }
            }
        });
        this.addChild(this.scrollpane);
        this.addChild(this.field);
        this.scrollpane.setLockHeight(false);
        this.scrollpane.setHeight(n2 - this.field.getHeight());
        this.scrollpane.setLockHeight(true);
        this.setWidth(n);
        this.setHeight(n2);
        this.field.setY(this.getHeight() - this.field.getHeight());
    }
}
