//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.listen;

import me.noble.client.gui.rgui.component.*;

public interface MouseListener
{
    void onScroll(final MouseScrollEvent p0);
    
    void onMouseRelease(final MouseButtonEvent p0);
    
    void onMouseDown(final MouseButtonEvent p0);
    
    void onMouseDrag(final MouseButtonEvent p0);
    
    void onMouseMove(final MouseMoveEvent p0);
    
    public static class MouseMoveEvent
    {
        int x;
        int y;
        boolean cancelled;
        int oldX;
        int oldY;
        Component component;
        
        public int getOldY() {
            return this.oldY;
        }
        
        public MouseMoveEvent(final int x, final int y, final int oldX, final int oldY, final Component component) {
            this.cancelled = false;
            this.x = x;
            this.y = y;
            this.oldX = oldX;
            this.oldY = oldY;
            this.component = component;
        }
        
        public int getOldX() {
            return this.oldX;
        }
        
        public boolean isCancelled() {
            return this.cancelled;
        }
        
        public void setY(final int y) {
            this.y = y;
        }
        
        public void setX(final int x) {
            this.x = x;
        }
        
        public Component getComponent() {
            return this.component;
        }
        
        public int getX() {
            return this.x;
        }
        
        public int getY() {
            return this.y;
        }
    }
    
    public static class MouseScrollEvent
    {
        Component component;
        private boolean cancelled;
        int y;
        boolean up;
        int x;
        
        public void setY(final int y) {
            this.y = y;
        }
        
        public void cancel() {
            this.cancelled = true;
        }
        
        public int getY() {
            return this.y;
        }
        
        public void setX(final int x) {
            this.x = x;
        }
        
        public Component getComponent() {
            return this.component;
        }
        
        public boolean isUp() {
            return this.up;
        }
        
        public boolean isCancelled() {
            return this.cancelled;
        }
        
        public MouseScrollEvent(final int x, final int y, final boolean up, final Component component) {
            this.x = x;
            this.y = y;
            this.up = up;
            this.component = component;
        }
        
        public int getX() {
            return this.x;
        }
        
        public void setUp(final boolean up) {
            this.up = up;
        }
    }
    
    public static class MouseButtonEvent
    {
        int x;
        boolean cancelled;
        int y;
        Component component;
        int button;
        
        public boolean isCancelled() {
            return this.cancelled;
        }
        
        public int getX() {
            return this.x;
        }
        
        public int getButton() {
            return this.button;
        }
        
        public MouseButtonEvent(final int x, final int y, final int button, final Component component) {
            this.cancelled = false;
            this.x = x;
            this.y = y;
            this.button = button;
            this.component = component;
        }
        
        public void setY(final int y) {
            this.y = y;
        }
        
        public void cancel() {
            this.cancelled = true;
        }
        
        public int getY() {
            return this.y;
        }
        
        public void setX(final int x) {
            this.x = x;
        }
        
        public void setButton(final int button) {
            this.button = button;
        }
        
        public Component getComponent() {
            return this.component;
        }
    }
}
