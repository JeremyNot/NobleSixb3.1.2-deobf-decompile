//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.use;

import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.theme.*;

public class Label extends AlignedComponent
{
    boolean multiline;
    String text;
    boolean shadow;
    FontRenderer fontRenderer;
    
    public Label(final String s) {
        this(s, false);
    }
    
    public void setText(final String text) {
        this.text = text;
        this.getTheme().getUIForComponent((Component)this).handleSizeComponent((Component)this);
    }
    
    public boolean isShadow() {
        return this.shadow;
    }
    
    public Label(final String text, final boolean multiline) {
        this.text = text;
        this.multiline = multiline;
        this.setAlignment(AlignedComponent.Alignment.LEFT);
    }
    
    public void setTheme(final Theme theme) {
        super.setTheme(theme);
        this.setFontRenderer(theme.getFontRenderer());
        this.getTheme().getUIForComponent((Component)this).handleSizeComponent((Component)this);
    }
    
    public void setMultiline(final boolean multiline) {
        this.multiline = multiline;
    }
    
    public void addLine(final String text) {
        if (this.getText().isEmpty()) {
            this.setText(text);
        }
        else {
            this.setText(String.valueOf(new StringBuilder().append(this.getText()).append(System.lineSeparator()).append(text)));
            this.multiline = true;
        }
    }
    
    public String[] getLines() {
        String[] split;
        if (this.isMultiline()) {
            split = this.getText().split(System.lineSeparator());
        }
        else {
            split = new String[] { this.getText() };
        }
        return split;
    }
    
    public FontRenderer getFontRenderer() {
        return this.fontRenderer;
    }
    
    public void addText(final String s) {
        this.setText(String.valueOf(new StringBuilder().append(this.getText()).append(s)));
    }
    
    public void setShadow(final boolean shadow) {
        this.shadow = shadow;
    }
    
    public void setFontRenderer(final FontRenderer fontRenderer) {
        this.fontRenderer = fontRenderer;
    }
    
    public boolean isMultiline() {
        return this.multiline;
    }
    
    public String getText() {
        return this.text;
    }
}
