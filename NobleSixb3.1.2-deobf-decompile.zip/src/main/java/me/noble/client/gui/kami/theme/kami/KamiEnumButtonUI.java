//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.*;
import java.awt.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.poof.*;

public class KamiEnumButtonUI extends AbstractComponentUI<EnumButton>
{
    RootSmallFontRenderer smallFontRenderer;
    long lastMS;
    protected Color idleColour;
    protected Color downColour;
    EnumButton modeComponent;
    
    @Override
    public void handleSizeComponent(final EnumButton enumButton) {
        int max = 0;
        final String[] modes = enumButton.getModes();
        for (int length = modes.length, i = 0; i < length; ++i) {
            max = Math.max(max, this.smallFontRenderer.getStringWidth(modes[i]));
        }
        enumButton.setWidth(this.smallFontRenderer.getStringWidth(enumButton.getName()) + max + 1);
        enumButton.setHeight(this.smallFontRenderer.getFontHeight() + 2);
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((EnumButton)component, container);
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((EnumButton)component, fontRenderer);
    }
    
    public KamiEnumButtonUI() {
        this.smallFontRenderer = new RootSmallFontRenderer();
        this.idleColour = new Color(163, 163, 163);
        this.downColour = new Color(255, 255, 255);
        this.lastMS = System.currentTimeMillis();
    }
    
    @Override
    public void renderComponent(final EnumButton enumButton, final FontRenderer fontRenderer) {
        if (System.currentTimeMillis() - this.lastMS > 3000L && this.modeComponent != null) {
            this.modeComponent = null;
        }
        int n = enumButton.isPressed() ? 11184810 : 14540253;
        if (enumButton.isHovered()) {
            n = (n & 0x7F7F7F) << 1;
        }
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        final double n2 = enumButton.getWidth() / (double)enumButton.getModes().length;
        final double n3 = n2 * enumButton.getIndex();
        final double n4 = n2 * (enumButton.getIndex() + 1);
        final int height = enumButton.getHeight();
        final float n5 = 1.1f;
        GL11.glDisable(3553);
        GL11.glColor3f(0.6f, 0.56f, 1.0f);
        GL11.glBegin(1);
        GL11.glVertex2d(n3, (double)(height / n5));
        GL11.glVertex2d(n4, (double)(height / n5));
        GL11.glEnd();
        if (this.modeComponent == null || !this.modeComponent.equals(enumButton)) {
            this.smallFontRenderer.drawString(0, 0, n, enumButton.getName());
            this.smallFontRenderer.drawString(enumButton.getWidth() - this.smallFontRenderer.getStringWidth(enumButton.getIndexMode()), 0, n, enumButton.getIndexMode());
        }
        else {
            this.smallFontRenderer.drawString(enumButton.getWidth() / 2 - this.smallFontRenderer.getStringWidth(enumButton.getIndexMode()) / 2, 0, n, enumButton.getIndexMode());
        }
        GL11.glDisable(3042);
    }
    
    @Override
    public void handleAddComponent(final EnumButton enumButton, final Container container) {
        enumButton.addPoof((IPoof)new EnumButton.EnumbuttonIndexPoof<EnumButton, EnumButton.EnumbuttonIndexPoof.EnumbuttonInfo>(this) {
            final KamiEnumButtonUI this$0;
            
            public void execute(final Component component, final PoofInfo poofInfo) {
                this.execute((EnumButton)component, (EnumbuttonIndexPoof.EnumbuttonInfo)poofInfo);
            }
            
            public void execute(final EnumButton modeComponent, final EnumbuttonIndexPoof.EnumbuttonInfo enumbuttonInfo) {
                this.this$0.modeComponent = modeComponent;
                this.this$0.lastMS = System.currentTimeMillis();
            }
        });
    }
    
    @Override
    public void handleSizeComponent(final Component component) {
        this.handleSizeComponent((EnumButton)component);
    }
}
