//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.staticui;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;
import me.noble.client.util.*;
import me.noble.client.module.*;

public class TabGuiUI extends AbstractComponentUI<TabGUI>
{
    long lastms;
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((TabGUI)component, fontRenderer);
    }
    
    private void drawBox(final int n, final int n2, final int n3, final int n4) {
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.6f);
        GL11.glBegin(7);
        GL11.glVertex2i(n, n2);
        GL11.glVertex2i(n3, n2);
        GL11.glVertex2i(n3, n4);
        GL11.glVertex2i(n, n4);
        GL11.glEnd();
        final double n5 = n - 0.1;
        final double n6 = n3 + 0.1;
        final double n7 = n2 - 0.1;
        final double n8 = n4 + 0.1;
        GL11.glLineWidth(1.5f);
        GL11.glColor3f(0.59f, 0.05f, 0.11f);
        GL11.glBegin(2);
        GL11.glVertex2d(n5, n7);
        GL11.glVertex2d(n6, n7);
        GL11.glVertex2d(n6, n8);
        GL11.glVertex2d(n5, n8);
        GL11.glEnd();
        final double n9 = n5 - 0.9;
        final double n10 = n6 + 0.9;
        final double n11 = n7 - 0.9;
        final double n12 = n8 + 0.9;
        GL11.glBegin(9);
        GL11.glColor4f(0.125f, 0.125f, 0.125f, 0.75f);
        GL11.glVertex2d((double)n, (double)n2);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glVertex2d(n10, n11);
        GL11.glVertex2d(n9, n11);
        GL11.glVertex2d(n9, n12);
        GL11.glColor4f(0.125f, 0.125f, 0.125f, 0.75f);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glEnd();
        GL11.glBegin(9);
        GL11.glVertex2d((double)n3, (double)n4);
        GL11.glVertex2d((double)n3, (double)n2);
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glVertex2d(n10, n11);
        GL11.glVertex2d(n10, n12);
        GL11.glVertex2d(n9, n12);
        GL11.glColor4f(0.125f, 0.125f, 0.125f, 0.75f);
        GL11.glVertex2d((double)n, (double)n4);
        GL11.glEnd();
    }
    
    @Override
    public void renderComponent(final TabGUI tabGUI, final FontRenderer fontRenderer) {
        boolean b = false;
        final float n = (float)(System.currentTimeMillis() - this.lastms);
        if (n > 2.0f) {
            tabGUI.selectedLerpY += (tabGUI.selected * 10 - tabGUI.selectedLerpY) * n * 0.02f;
            b = true;
            this.lastms = System.currentTimeMillis();
        }
        GL11.glDisable(2884);
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glShadeModel(7425);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)2, (float)2, 0.0f);
        this.drawBox(0, 0, tabGUI.width, tabGUI.height);
        KamiGUI.primaryColour.setGLColour();
        GL11.glColor3f(0.59f, 0.05f, 0.11f);
        GL11.glBegin(7);
        GL11.glVertex2d(0.0, (double)tabGUI.selectedLerpY);
        GL11.glVertex2d(0.0, (double)(tabGUI.selectedLerpY + 10.0f));
        GL11.glVertex2d((double)tabGUI.width, (double)(tabGUI.selectedLerpY + 10.0f));
        GL11.glVertex2d((double)tabGUI.width, (double)tabGUI.selectedLerpY);
        GL11.glEnd();
        int n2 = 1;
        for (int i = 0; i < tabGUI.tabs.size(); ++i) {
            final String name = tabGUI.tabs.get(i).name;
            GL11.glEnable(3553);
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
            Wrapper.getFontRenderer().drawStringWithShadow(2, n2, 255, 255, 255, String.valueOf(new StringBuilder().append("��7").append(name)));
            n2 += 10;
        }
        if (tabGUI.tabOpened) {
            GL11.glPushMatrix();
            GL11.glDisable(3553);
            final TabGUI.Tab tab = tabGUI.tabs.get(tabGUI.selected);
            GL11.glTranslatef((float)(tabGUI.width + 2), 0.0f, 0.0f);
            this.drawBox(0, 0, tab.width, tab.height);
            if (b) {
                tab.lerpSelectY += (tab.selected * 10 - tab.lerpSelectY) * n * 0.02f;
            }
            GL11.glColor3f(0.6f, 0.56f, 1.0f);
            GL11.glBegin(7);
            GL11.glVertex2d(0.0, (double)tab.lerpSelectY);
            GL11.glVertex2d(0.0, (double)(tab.lerpSelectY + 10.0f));
            GL11.glVertex2d((double)tab.width, (double)(tab.lerpSelectY + 10.0f));
            GL11.glVertex2d((double)tab.width, (double)tab.lerpSelectY);
            GL11.glEnd();
            int n3 = 1;
            for (int j = 0; j < tab.features.size(); ++j) {
                final Module module = tab.features.get(j);
                final String value = String.valueOf(new StringBuilder().append(module.isEnabled() ? "��c" : "��7").append(module.getName()));
                GL11.glEnable(3553);
                GL11.glColor3f(1.0f, 1.0f, 1.0f);
                Wrapper.getFontRenderer().drawStringWithShadow(2, n3, 255, 255, 255, value);
                n3 += 10;
            }
            GL11.glDisable(3089);
            GL11.glPopMatrix();
        }
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glEnable(2884);
    }
    
    public TabGuiUI() {
        this.lastms = System.currentTimeMillis();
    }
}
