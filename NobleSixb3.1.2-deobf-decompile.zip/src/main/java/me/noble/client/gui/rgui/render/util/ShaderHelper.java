//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.util;

import org.lwjgl.opengl.*;

public final class ShaderHelper
{
    public static void createProgram(final int n) {
        ARBShaderObjects.glLinkProgramARB(n);
        checkObjecti(n, 35714);
        ARBShaderObjects.glValidateProgramARB(n);
        checkObjecti(n, 35715);
    }
    
    public static int loadShader(final String s, final int n) {
        final int glCreateShaderObjectARB = ARBShaderObjects.glCreateShaderObjectARB(n);
        if (glCreateShaderObjectARB == 0) {
            return 0;
        }
        ARBShaderObjects.glShaderSourceARB(glCreateShaderObjectARB, (CharSequence)new StreamReader(ShaderHelper.class.getResourceAsStream(s)).read());
        ARBShaderObjects.glCompileShaderARB(glCreateShaderObjectARB);
        checkObjecti(glCreateShaderObjectARB, 35713);
        return glCreateShaderObjectARB;
    }
    
    private ShaderHelper() {
    }
    
    private static String getLogInfo(final int n) {
        return ARBShaderObjects.glGetInfoLogARB(n, ARBShaderObjects.glGetObjectParameteriARB(n, 35716));
    }
    
    private static void checkObjecti(final int n, final int n2) {
        if (ARBShaderObjects.glGetObjectParameteriARB(n, n2) == 0) {
            try {
                throw new Exception(getLogInfo(n));
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
