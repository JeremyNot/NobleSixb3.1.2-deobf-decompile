//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.container;

import me.noble.client.gui.rgui.component.*;
import java.util.*;

public interface Container extends Component
{
    boolean penetrateTest(final int p0, final int p1);
    
    ArrayList<Component> getChildren();
    
    int getOriginOffsetY();
    
    void renderChildren();
    
    Container removeChild(final Component p0);
    
    Container addChild(final Component... p0);
    
    boolean hasChild(final Component p0);
    
    int getOriginOffsetX();
    
    Component getComponentAt(final int p0, final int p1);
}
