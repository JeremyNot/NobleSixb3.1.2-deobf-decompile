//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.*;
import java.lang.reflect.*;
import me.noble.client.gui.rgui.render.font.*;

public abstract class AbstractComponentUI<T extends Component> implements ComponentUI<T>
{
    private Class<T> persistentClass;
    
    @Override
    public Class<? extends Component> getHandledClass() {
        return this.persistentClass;
    }
    
    @Override
    public void handleMouseRelease(final T t, final int n, final int n2, final int n3) {
    }
    
    @Override
    public void handleAddComponent(final T t, final Container container) {
    }
    
    @Override
    public void handleKeyUp(final T t, final int n) {
    }
    
    @Override
    public void handleMouseDrag(final T t, final int n, final int n2, final int n3) {
    }
    
    public AbstractComponentUI() {
        this.persistentClass = (Class<T>)((ParameterizedType)this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }
    
    @Override
    public void handleKeyDown(final T t, final int n) {
    }
    
    @Override
    public void handleMouseDown(final T t, final int n, final int n2, final int n3) {
    }
    
    @Override
    public void renderComponent(final T t, final FontRenderer fontRenderer) {
    }
    
    @Override
    public void handleScroll(final T t, final int n, final int n2, final int n3, final boolean b) {
    }
    
    @Override
    public void handleSizeComponent(final T t) {
    }
}
