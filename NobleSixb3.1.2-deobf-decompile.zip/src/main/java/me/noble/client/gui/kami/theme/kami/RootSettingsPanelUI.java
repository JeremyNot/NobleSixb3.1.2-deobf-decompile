//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.component.*;

public class RootSettingsPanelUI extends AbstractComponentUI<SettingsPanel>
{
    @Override
    public void renderComponent(final SettingsPanel settingsPanel, final FontRenderer fontRenderer) {
        GL11.glColor4f(1.0f, 0.33f, 0.33f, 0.2f);
        RenderHelper.drawOutlinedRoundedRectangle(0, 0, settingsPanel.getWidth(), settingsPanel.getHeight(), 6.0f, 0.14f, 0.14f, 0.14f, settingsPanel.getOpacity(), 1.0f);
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((SettingsPanel)component, fontRenderer);
    }
}
