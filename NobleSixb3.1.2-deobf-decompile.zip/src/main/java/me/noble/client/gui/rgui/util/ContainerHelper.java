//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.util;

import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.theme.*;
import java.util.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.*;

public class ContainerHelper
{
    public static void setTheme(final Container container, final Theme theme) {
        final Theme theme2 = container.getTheme();
        container.setTheme(theme);
        for (final Component component : container.getChildren()) {
            if (component.getTheme().equals(theme2)) {
                component.setTheme(theme);
            }
        }
    }
    
    public static <S extends Component> List<S> getAllChildren(final Class<? extends S> clazz, final Container container) {
        final ArrayList<Component> list = (ArrayList<Component>)new ArrayList<S>();
        for (final Component component : container.getChildren()) {
            if (clazz.isAssignableFrom(component.getClass())) {
                list.add(component);
            }
            if (component instanceof Container) {
                list.addAll(getAllChildren((Class<? extends Component>)clazz, (Container)component));
            }
        }
        return (List<S>)list;
    }
    
    public static void setAlignment(final Container container, final AlignedComponent.Alignment alignment) {
        for (final Component component : container.getChildren()) {
            if (component instanceof Container) {
                setAlignment((Container)component, alignment);
            }
            if (component instanceof AlignedComponent) {
                ((AlignedComponent)component).setAlignment(alignment);
            }
        }
    }
    
    public static Component getHighParent(final Component component) {
        if (component.getParent() instanceof GUI || component.getParent() == null) {
            return component;
        }
        return getHighParent((Component)component.getParent());
    }
    
    public static <T extends Component> T getFirstParent(final Class<? extends T> clazz, final Component component) {
        if (component.getClass().equals(clazz)) {
            return (T)component;
        }
        if (component == null) {
            return null;
        }
        return (T)getFirstParent((Class<? extends Component>)clazz, (Component)component.getParent());
    }
    
    public static AlignedComponent.Alignment getAlignment(final Container container) {
        for (final Component component : container.getChildren()) {
            if (component instanceof Container) {
                return getAlignment((Container)component);
            }
            if (component instanceof AlignedComponent) {
                return ((AlignedComponent)component).getAlignment();
            }
        }
        return AlignedComponent.Alignment.LEFT;
    }
}
