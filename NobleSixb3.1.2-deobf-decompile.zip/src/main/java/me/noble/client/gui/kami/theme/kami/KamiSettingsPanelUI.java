//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.module.modules.gui.*;
import me.noble.client.module.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.component.*;

public class KamiSettingsPanelUI extends AbstractComponentUI<SettingsPanel>
{
    @Override
    public void renderComponent(final SettingsPanel settingsPanel, final FontRenderer fontRenderer) {
        super.renderComponent(settingsPanel, fontRenderer);
        GL11.glLineWidth(2.0f);
        final float n = ((GUIColour)ModuleManager.getModuleByName("GUI Colour")).red.getValue() / 255.0f;
        final float n2 = ((GUIColour)ModuleManager.getModuleByName("GUI Colour")).green.getValue() / 255.0f;
        final float n3 = ((GUIColour)ModuleManager.getModuleByName("GUI Colour")).blue.getValue() / 255.0f;
        final float n4 = ((GUIColour)ModuleManager.getModuleByName("GUI Colour")).alpha.getValue() / 255.0f;
        if (ModuleManager.getModuleByName("GUI Colour").isEnabled()) {
            GL11.glColor4f(n, n2, n3, n4);
        }
        else {
            GL11.glColor4f(0.17f, 0.17f, 0.18f, 0.9f);
        }
        RenderHelper.drawFilledRectangle(0.0f, 0.0f, (float)settingsPanel.getWidth(), (float)settingsPanel.getHeight());
        GL11.glColor3f(0.6f, 0.56f, 1.0f);
        GL11.glLineWidth(1.5f);
        RenderHelper.drawRectangle(0.0f, 0.0f, (float)settingsPanel.getWidth(), (float)settingsPanel.getHeight());
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((SettingsPanel)component, fontRenderer);
    }
}
