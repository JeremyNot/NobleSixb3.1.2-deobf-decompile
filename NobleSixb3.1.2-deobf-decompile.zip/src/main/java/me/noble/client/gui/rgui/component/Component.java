//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component;

import java.util.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.listen.*;

public interface Component
{
    void kill();
    
    ArrayList<RenderListener> getRenderListeners();
    
    void setVisible(final boolean p0);
    
    void addPoof(final IPoof p0);
    
    ArrayList<MouseListener> getMouseListeners();
    
    int getWidth();
    
    void setX(final int p0);
    
    void setParent(final Container p0);
    
    int getMinimumHeight();
    
    void setTheme(final Theme p0);
    
    int getHeight();
    
    ArrayList<TickListener> getTickListeners();
    
    boolean doAffectLayout();
    
    void addRenderListener(final RenderListener p0);
    
    int getX();
    
    boolean isHovered();
    
    int getY();
    
    Component setMinimumHeight(final int p0);
    
    boolean isPressed();
    
    void callPoof(final Class<? extends IPoof> p0, final PoofInfo p1);
    
    void setFocused(final boolean p0);
    
    void setY(final int p0);
    
    boolean isFocused();
    
    void setHeight(final int p0);
    
    boolean isVisible();
    
    boolean liesIn(final Component p0);
    
    void setWidth(final int p0);
    
    Theme getTheme();
    
    ArrayList<KeyListener> getKeyListeners();
    
    ComponentUI getUI();
    
    int getMaximumWidth();
    
    int getMinimumWidth();
    
    void addUpdateListener(final UpdateListener p0);
    
    int getMaximumHeight();
    
    int getPriority();
    
    Component setMaximumWidth(final int p0);
    
    void addKeyListener(final KeyListener p0);
    
    Component setMinimumWidth(final int p0);
    
    ArrayList<UpdateListener> getUpdateListeners();
    
    void setOpacity(final float p0);
    
    Component setMaximumHeight(final int p0);
    
    float getOpacity();
    
    Container getParent();
    
    void setAffectLayout(final boolean p0);
    
    void addTickListener(final TickListener p0);
    
    void addMouseListener(final MouseListener p0);
}
