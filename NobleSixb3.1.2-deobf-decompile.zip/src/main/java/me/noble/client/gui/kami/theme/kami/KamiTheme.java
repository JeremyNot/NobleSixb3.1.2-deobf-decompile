//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.kami.theme.staticui.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.render.*;

public class KamiTheme extends AbstractTheme
{
    FontRenderer fontRenderer;
    
    @Override
    public FontRenderer getFontRenderer() {
        return this.fontRenderer;
    }
    
    public KamiTheme() {
        this.installUI(new RootButtonUI<Object>());
        this.installUI(new GUIUI());
        this.installUI(new RootGroupboxUI());
        this.installUI((ComponentUI<?>)new KamiFrameUI());
        this.installUI(new RootScrollpaneUI());
        this.installUI(new RootInputFieldUI<Object>());
        this.installUI(new RootLabelUI<Object>());
        this.installUI(new RootChatUI());
        this.installUI(new RootCheckButtonUI<Object>());
        this.installUI((ComponentUI<?>)new KamiActiveModulesUI());
        this.installUI((ComponentUI<?>)new KamiSettingsPanelUI());
        this.installUI(new RootSliderUI());
        this.installUI((ComponentUI<?>)new KamiEnumButtonUI());
        this.installUI(new RootColorizedCheckButtonUI());
        this.installUI(new KamiUnboundSliderUI());
        this.installUI(new RadarUI());
        this.installUI(new TabGuiUI());
        this.fontRenderer = (FontRenderer)KamiGUI.fontRenderer;
    }
    
    public class GUIUI extends AbstractComponentUI<KamiGUI>
    {
        final KamiTheme this$0;
        
        public GUIUI(final KamiTheme this$0) {
            this.this$0 = this$0;
        }
    }
}
