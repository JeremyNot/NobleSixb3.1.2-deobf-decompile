//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.util.*;

public class ActiveModules extends Label
{
    public boolean sort_up;
    
    public ActiveModules() {
        super("");
        this.sort_up = true;
        this.addRenderListener(new RenderListener(this) {
            final ActiveModules this$0;
            
            @Override
            public void onPreRender() {
                final Frame frame = ContainerHelper.getFirstParent((Class<? extends Frame>)Frame.class, (Component)this.this$0);
                if (frame == null) {
                    return;
                }
                final Docking docking = frame.getDocking();
                if (docking.isTop()) {
                    this.this$0.sort_up = true;
                }
                if (docking.isBottom()) {
                    this.this$0.sort_up = false;
                }
            }
            
            @Override
            public void onPostRender() {
            }
        });
    }
}
