//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.util;

import org.lwjgl.opengl.*;
import org.lwjgl.util.vector.*;

public final class Uniform
{
    private final String name;
    private final int location;
    
    public final void setVec(final Vector2f vector2f) {
        ARBShaderObjects.glUniform2fARB(this.location, vector2f.x, vector2f.y);
    }
    
    public final String getName() {
        return this.name;
    }
    
    private Uniform(final String name, final int location) {
        this.name = name;
        this.location = location;
    }
    
    public final int getLocation() {
        return this.location;
    }
    
    public final void setBoolean(final boolean b) {
        ARBShaderObjects.glUniform1fARB(this.location, b ? 1.0f : 0.0f);
    }
    
    public final void setFloat(final float n) {
        ARBShaderObjects.glUniform1fARB(this.location, n);
    }
    
    public static Uniform get(final int n, final String s) {
        return new Uniform(s, ARBShaderObjects.glGetUniformLocationARB(n, (CharSequence)s));
    }
    
    public final void setInt(final int n) {
        ARBShaderObjects.glUniform1iARB(this.location, n);
    }
    
    public final void setVec(final Vector3f vector3f) {
        ARBShaderObjects.glUniform3fARB(this.location, vector3f.x, vector3f.y, vector3f.z);
    }
}
