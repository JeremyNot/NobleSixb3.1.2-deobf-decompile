//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui;

import me.noble.client.gui.rgui.component.*;
import java.util.function.*;
import java.util.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.component.listen.*;
import org.lwjgl.opengl.*;
import org.lwjgl.input.*;

public abstract class GUI extends AbstractContainer
{
    int my;
    boolean press;
    long lastMS;
    int y;
    int x;
    Component focus;
    int button;
    int mx;
    
    public abstract void initializeGUI();
    
    public abstract void destroyGUI();
    
    public void handleKeyDown(final int n) {
        if (this.focus == null) {
            return;
        }
        this.focus.getTheme().getUIForComponent(this.focus).handleKeyDown(this.focus, n);
        final ArrayList<Component> list = new ArrayList<Component>();
        for (Object o = this.focus; o != null; o = ((Component)o).getParent()) {
            list.add(0, (Component)o);
        }
        final KeyListener.KeyEvent keyEvent = new KeyListener.KeyEvent(n);
        final Iterator<Component> iterator = list.iterator();
        while (iterator.hasNext()) {
            iterator.next().getKeyListeners().forEach(GUI::lambda$handleKeyDown$0);
        }
    }
    
    private static void lambda$handleMouseDrag$6(final MouseListener.MouseButtonEvent mouseButtonEvent, final MouseListener mouseListener) {
        mouseListener.onMouseDrag(mouseButtonEvent);
    }
    
    public void drawGUI() {
        this.renderChildren();
    }
    
    public void handleMouseDown(final int x, final int y) {
        final Component component = this.getComponentAt(x, y);
        final int[] calculateRealPosition = calculateRealPosition(component);
        if (this.focus != null) {
            this.focus.setFocused(false);
        }
        this.focus = component;
        if (!component.equals(this)) {
            Object parent;
            for (parent = component; !this.hasChild((Component)parent); parent = ((Component)parent).getParent()) {}
            this.children.remove(parent);
            this.children.add(parent);
            Collections.sort((List<Object>)this.children, (Comparator<? super Object>)new Comparator<Component>(this) {
                final GUI this$0;
                
                @Override
                public int compare(final Component component, final Component component2) {
                    return component.getPriority() - component2.getPriority();
                }
                
                @Override
                public int compare(final Object o, final Object o2) {
                    return this.compare((Component)o, (Component)o2);
                }
            });
        }
        this.focus.setFocused(true);
        this.press = true;
        this.x = x;
        this.y = y;
        this.button = Mouse.getEventButton();
        this.getTheme().getUIForComponent(component).handleMouseDown(component, x - calculateRealPosition[0], y - calculateRealPosition[1], Mouse.getEventButton());
        final ArrayList<Component> list = new ArrayList<Component>();
        for (Object o = this.focus; o != null; o = ((Component)o).getParent()) {
            list.add(0, (Component)o);
        }
        final MouseListener.MouseButtonEvent mouseButtonEvent = new MouseListener.MouseButtonEvent(x, y, this.button, this.focus);
        for (final Component component2 : list) {
            mouseButtonEvent.setX(mouseButtonEvent.getX() - component2.getX());
            mouseButtonEvent.setY(mouseButtonEvent.getY() - component2.getY());
            if (component2 instanceof Container) {
                mouseButtonEvent.setX(mouseButtonEvent.getX() - ((Container)component2).getOriginOffsetX());
                mouseButtonEvent.setY(mouseButtonEvent.getY() - ((Container)component2).getOriginOffsetY());
            }
            component2.getMouseListeners().forEach(GUI::lambda$handleMouseDown$2);
            if (mouseButtonEvent.isCancelled()) {
                break;
            }
        }
    }
    
    public void handleWheel(final int n, final int n2, final int n3) {
        if (n3 == 0) {
            return;
        }
        final Component component = this.getComponentAt(n, n2);
        final int[] calculateRealPosition = calculateRealPosition(component);
        this.getTheme().getUIForComponent(component).handleScroll(component, n - calculateRealPosition[0], n2 - calculateRealPosition[1], n3, n3 > 0);
        final ArrayList<Component> list = new ArrayList<Component>();
        for (Object parent = component; parent != null; parent = ((Component)parent).getParent()) {
            list.add(0, (Component)parent);
        }
        final MouseListener.MouseScrollEvent mouseScrollEvent = new MouseListener.MouseScrollEvent(n, n2, n3 > 0, component);
        for (final Component component2 : list) {
            mouseScrollEvent.setX(mouseScrollEvent.getX() - component2.getX());
            mouseScrollEvent.setY(mouseScrollEvent.getY() - component2.getY());
            if (component2 instanceof Container) {
                mouseScrollEvent.setX(mouseScrollEvent.getX() - ((Container)component2).getOriginOffsetX());
                mouseScrollEvent.setY(mouseScrollEvent.getY() - ((Container)component2).getOriginOffsetY());
            }
            component2.getMouseListeners().forEach(GUI::lambda$handleWheel$5);
            if (mouseScrollEvent.isCancelled()) {
                break;
            }
        }
    }
    
    public static int[] calculateRealPosition(final Component component) {
        int x = component.getX();
        int y = component.getY();
        if (component instanceof Container) {
            x += ((Container)component).getOriginOffsetX();
            y += ((Container)component).getOriginOffsetY();
        }
        for (Container container = component.getParent(); container != null; container = ((Component)container).getParent()) {
            x += ((Component)container).getX();
            y += ((Component)container).getY();
            if (container instanceof Container) {
                x += container.getOriginOffsetX();
                y += container.getOriginOffsetY();
            }
        }
        return new int[] { x, y };
    }
    
    public void callTick(final Container container) {
        container.getTickListeners().forEach(GUI::lambda$callTick$7);
        for (final Component component : container.getChildren()) {
            if (component instanceof Container) {
                this.callTick((Container)component);
            }
            else {
                component.getTickListeners().forEach(GUI::lambda$callTick$8);
            }
        }
    }
    
    private static void lambda$handleWheel$5(final MouseListener.MouseScrollEvent mouseScrollEvent, final MouseListener mouseListener) {
        mouseListener.onScroll(mouseScrollEvent);
    }
    
    public GUI(final Theme theme) {
        super(theme);
        this.focus = null;
        this.press = false;
        this.x = 0;
        this.y = 0;
        this.button = 0;
        this.mx = 0;
        this.my = 0;
        this.lastMS = System.currentTimeMillis();
    }
    
    private static void lambda$callTick$7(final TickListener tickListener) {
        tickListener.onTick();
    }
    
    private static void lambda$callTick$8(final TickListener tickListener) {
        tickListener.onTick();
    }
    
    private void catchMouse() {
        while (Mouse.next()) {
            final int x = Mouse.getX();
            final int n = Display.getHeight() - Mouse.getY();
            if (this.press && this.focus != null && (this.x != x || this.y != n)) {
                this.handleMouseDrag(x, n);
            }
            if (Mouse.getEventButtonState()) {
                this.handleMouseDown(x, n);
            }
            else {
                this.handleMouseRelease(x, n);
            }
            if (Mouse.hasWheel()) {
                this.handleWheel(x, n, Mouse.getDWheel());
            }
        }
    }
    
    public void update() {
        if (System.currentTimeMillis() - this.lastMS > 50L) {
            this.callTick((Container)this);
            this.lastMS = System.currentTimeMillis();
        }
    }
    
    private static void lambda$handleKeyDown$0(final KeyListener.KeyEvent keyEvent, final KeyListener keyListener) {
        keyListener.onKeyDown(keyEvent);
    }
    
    public Component getFocus() {
        return this.focus;
    }
    
    public void handleMouseRelease(final int n, final int n2) {
        final int eventButton = Mouse.getEventButton();
        if (this.focus != null && eventButton != -1) {
            final int[] calculateRealPosition = calculateRealPosition(this.focus);
            this.getTheme().getUIForComponent(this.focus).handleMouseRelease(this.focus, n - calculateRealPosition[0], n2 - calculateRealPosition[1], eventButton);
            final ArrayList<Component> list = new ArrayList<Component>();
            for (Object o = this.focus; o != null; o = ((Component)o).getParent()) {
                list.add(0, (Component)o);
            }
            final MouseListener.MouseButtonEvent mouseButtonEvent = new MouseListener.MouseButtonEvent(n, n2, eventButton, this.focus);
            for (final Component component : list) {
                mouseButtonEvent.setX(mouseButtonEvent.getX() - component.getX());
                mouseButtonEvent.setY(mouseButtonEvent.getY() - component.getY());
                if (component instanceof Container) {
                    mouseButtonEvent.setX(mouseButtonEvent.getX() - ((Container)component).getOriginOffsetX());
                    mouseButtonEvent.setY(mouseButtonEvent.getY() - ((Container)component).getOriginOffsetY());
                }
                component.getMouseListeners().forEach(GUI::lambda$handleMouseRelease$3);
                if (mouseButtonEvent.isCancelled()) {
                    break;
                }
            }
            this.press = false;
            return;
        }
        if (eventButton != -1) {
            final Component component2 = this.getComponentAt(n, n2);
            final int[] calculateRealPosition2 = calculateRealPosition(component2);
            this.getTheme().getUIForComponent(component2).handleMouseRelease(component2, n - calculateRealPosition2[0], n2 - calculateRealPosition2[1], eventButton);
            final ArrayList<Component> list2 = new ArrayList<Component>();
            for (Object parent = component2; parent != null; parent = ((Component)parent).getParent()) {
                list2.add(0, (Component)parent);
            }
            final MouseListener.MouseButtonEvent mouseButtonEvent2 = new MouseListener.MouseButtonEvent(n, n2, eventButton, component2);
            for (final Component component3 : list2) {
                mouseButtonEvent2.setX(mouseButtonEvent2.getX() - component3.getX());
                mouseButtonEvent2.setY(mouseButtonEvent2.getY() - component3.getY());
                if (component3 instanceof Container) {
                    mouseButtonEvent2.setX(mouseButtonEvent2.getX() - ((Container)component3).getOriginOffsetX());
                    mouseButtonEvent2.setY(mouseButtonEvent2.getY() - ((Container)component3).getOriginOffsetY());
                }
                component3.getMouseListeners().forEach(GUI::lambda$handleMouseRelease$4);
                if (mouseButtonEvent2.isCancelled()) {
                    break;
                }
            }
            this.press = false;
        }
    }
    
    public void catchKey() {
        if (this.focus == null) {
            return;
        }
        while (Keyboard.next()) {
            if (Keyboard.getEventKeyState()) {
                this.handleKeyDown(Keyboard.getEventKey());
            }
            else {
                this.handleKeyUp(Keyboard.getEventKey());
            }
        }
    }
    
    public void handleKeyUp(final int n) {
        if (this.focus == null) {
            return;
        }
        this.focus.getTheme().getUIForComponent(this.focus).handleKeyUp(this.focus, n);
        final ArrayList<Component> list = new ArrayList<Component>();
        for (Object o = this.focus; o != null; o = ((Component)o).getParent()) {
            list.add(0, (Component)o);
        }
        final KeyListener.KeyEvent keyEvent = new KeyListener.KeyEvent(n);
        final Iterator<Component> iterator = list.iterator();
        while (iterator.hasNext()) {
            iterator.next().getKeyListeners().forEach(GUI::lambda$handleKeyUp$1);
        }
    }
    
    private static void lambda$handleKeyUp$1(final KeyListener.KeyEvent keyEvent, final KeyListener keyListener) {
        keyListener.onKeyUp(keyEvent);
    }
    
    private static void lambda$handleMouseRelease$3(final MouseListener.MouseButtonEvent mouseButtonEvent, final MouseListener mouseListener) {
        mouseListener.onMouseRelease(mouseButtonEvent);
    }
    
    private static void lambda$handleMouseDown$2(final MouseListener.MouseButtonEvent mouseButtonEvent, final MouseListener mouseListener) {
        mouseListener.onMouseDown(mouseButtonEvent);
    }
    
    private static void lambda$handleMouseRelease$4(final MouseListener.MouseButtonEvent mouseButtonEvent, final MouseListener mouseListener) {
        mouseListener.onMouseRelease(mouseButtonEvent);
    }
    
    public void updateGUI() {
        this.catchMouse();
        this.catchKey();
    }
    
    public void handleMouseDrag(final int n, final int n2) {
        final int[] calculateRealPosition = calculateRealPosition(this.focus);
        this.getTheme().getUIForComponent(this.focus).handleMouseDrag(this.focus, n - calculateRealPosition[0], n2 - calculateRealPosition[1], this.button);
        final ArrayList<Component> list = new ArrayList<Component>();
        for (Object o = this.focus; o != null; o = ((Component)o).getParent()) {
            list.add(0, (Component)o);
        }
        final MouseListener.MouseButtonEvent mouseButtonEvent = new MouseListener.MouseButtonEvent(n, n2, this.button, this.focus);
        for (final Component component : list) {
            mouseButtonEvent.setX(mouseButtonEvent.getX() - component.getX());
            mouseButtonEvent.setY(mouseButtonEvent.getY() - component.getY());
            if (component instanceof Container) {
                mouseButtonEvent.setX(mouseButtonEvent.getX() - ((Container)component).getOriginOffsetX());
                mouseButtonEvent.setY(mouseButtonEvent.getY() - ((Container)component).getOriginOffsetY());
            }
            component.getMouseListeners().forEach(GUI::lambda$handleMouseDrag$6);
            if (mouseButtonEvent.isCancelled()) {
                break;
            }
        }
    }
}
