//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.render.font.*;
import java.awt.*;
import me.noble.client.*;
import org.lwjgl.opengl.*;
import me.noble.client.util.*;
import me.noble.client.module.*;
import java.util.*;
import java.util.stream.*;
import me.noble.client.gui.rgui.component.*;
import java.util.function.*;

public class KamiActiveModulesUI extends AbstractComponentUI<ActiveModules>
{
    @Override
    public void handleSizeComponent(final ActiveModules activeModules) {
        activeModules.setWidth(100);
        activeModules.setHeight(100);
    }
    
    private static void lambda$renderComponent$4(final float[] array, final FontRenderer fontRenderer, final Function function, final int[] array2, final Module module) {
        if (module.getShowOnArray().equals(Module.ShowOnArray.ON)) {
            final int hsBtoRGB = Color.HSBtoRGB(array[0], 1.0f, 1.0f);
            final String hudInfo = module.getHudInfo();
            final String value = String.valueOf(new StringBuilder().append(module.getName()).append((hudInfo == null) ? "" : String.valueOf(new StringBuilder().append(" ").append(NobleMod.colour).append("7").append(hudInfo))));
            final int stringWidth = fontRenderer.getStringWidth(value);
            final int n = fontRenderer.getFontHeight() + 1;
            fontRenderer.drawStringWithShadow(function.apply(stringWidth), array2[0], hsBtoRGB >> 16 & 0xFF, hsBtoRGB >> 8 & 0xFF, hsBtoRGB & 0xFF, value);
            final int n2 = 0;
            array[n2] += 0.02f;
            final int n3 = 0;
            array2[n3] += n;
        }
    }
    
    @Override
    public void handleSizeComponent(final Component component) {
        this.handleSizeComponent((ActiveModules)component);
    }
    
    private static Integer lambda$renderComponent$0(final FontRenderer fontRenderer, final ActiveModules activeModules, final Module module) {
        return fontRenderer.getStringWidth(String.valueOf(new StringBuilder().append(module.getName()).append((module.getHudInfo() == null) ? "" : String.valueOf(new StringBuilder().append(module.getHudInfo()).append(" "))))) * (activeModules.sort_up ? -1 : 1);
    }
    
    @Override
    public void renderComponent(final ActiveModules activeModules, final FontRenderer fontRenderer) {
        GL11.glDisable(2884);
        GL11.glEnable(3042);
        GL11.glEnable(3553);
        final FontRenderer fontRenderer2 = Wrapper.getFontRenderer();
        final List<? super Object> list = ModuleManager.getModules().stream().filter(Module::isEnabled).sorted(Comparator.comparing((Function<? super Object, ? extends Comparable>)KamiActiveModulesUI::lambda$renderComponent$0)).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
        final int[] array = { 2 };
        if (activeModules.getParent().getY() < 26 && Wrapper.getPlayer().getActivePotionEffects().size() > 0 && activeModules.getParent().getOpacity() == 0.0f) {
            array[0] = Math.max(activeModules.getParent().getY(), 26 - activeModules.getParent().getY());
        }
        final float[] array2 = { System.currentTimeMillis() % 11520L / 11520.0f };
        final boolean b = activeModules.getAlignment() == AlignedComponent.Alignment.LEFT;
        Object o = null;
        switch (activeModules.getAlignment()) {
            case RIGHT: {
                o = KamiActiveModulesUI::lambda$renderComponent$1;
                break;
            }
            case CENTER: {
                o = KamiActiveModulesUI::lambda$renderComponent$2;
                break;
            }
            default: {
                o = KamiActiveModulesUI::lambda$renderComponent$3;
                break;
            }
        }
        list.forEach((Consumer<? super Object>)KamiActiveModulesUI::lambda$renderComponent$4);
        activeModules.setHeight(array[0]);
        GL11.glEnable(2884);
        GL11.glDisable(3042);
    }
    
    private static Integer lambda$renderComponent$2(final ActiveModules activeModules, final Integer n) {
        return activeModules.getWidth() / 2 - n / 2;
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((ActiveModules)component, fontRenderer);
    }
    
    private static Integer lambda$renderComponent$3(final Integer n) {
        return 0;
    }
    
    private static Integer lambda$renderComponent$1(final ActiveModules activeModules, final Integer n) {
        return activeModules.getWidth() - n;
    }
}
