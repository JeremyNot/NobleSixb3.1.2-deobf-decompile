//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.use;

import me.noble.client.gui.rgui.render.font.*;
import java.util.*;
import me.noble.client.gui.rgui.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.kami.*;
import org.lwjgl.opengl.*;
import org.lwjgl.input.*;
import java.awt.*;
import java.io.*;
import java.awt.datatransfer.*;
import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.poof.use.*;

public class InputField extends AbstractComponent
{
    long lastTypeMS;
    int railChar;
    char echoChar;
    boolean rail;
    FontRenderer fontRenderer;
    ArrayList<InputState> undoMap;
    KeyListener inputListener;
    InputState currentState;
    int railDelay;
    boolean shift;
    long startRail;
    int undoT;
    int scrollX;
    float railT;
    int railRepeat;
    ArrayList<InputState> redoMap;
    
    public void remove(int min) {
        min = Math.min(min, this.currentState.getCursorRow());
        if (!this.setText(String.valueOf(new StringBuilder().append(this.getText().substring(0, Math.max(this.currentState.getCursorRow() - min, 0))).append(this.getText().substring(this.currentState.getCursorRow()))))) {
            final InputState currentState = this.currentState;
            currentState.cursorRow -= min;
        }
        this.scroll();
    }
    
    public boolean isEchoCharSet() {
        return this.echoChar != '\0';
    }
    
    public InputField() {
        this("");
    }
    
    public char getEchoChar() {
        return this.echoChar;
    }
    
    private void pushUndo() {
        ++this.undoT;
        if (this.undoT > 3) {
            this.undoT = 0;
            this.undoMap.add(0, this.currentState.clone());
        }
    }
    
    public InputField(final int n) {
        this("");
    }
    
    public InputState getCurrentState() {
        return this.currentState;
    }
    
    public InputField(final String text) {
        this.echoChar = '\0';
        this.currentState = new InputState("", 0, false, 0, 0);
        this.startRail = 0L;
        this.railT = 0.0f;
        this.rail = false;
        this.railChar = 0;
        this.railDelay = 500;
        this.railRepeat = 32;
        this.lastTypeMS = 0L;
        this.undoT = 0;
        this.undoMap = new ArrayList<InputState>();
        this.redoMap = new ArrayList<InputState>();
        this.scrollX = 0;
        this.shift = false;
        this.fontRenderer = null;
        this.currentState.text = text;
        this.addRenderListener((RenderListener)new RenderListener(this) {
            final InputField this$0;
            
            public void onPreRender() {
            }
            
            public void onPostRender() {
                if (!this.this$0.isFocused()) {
                    this.this$0.currentState.selection = false;
                }
                final int[] calculateRealPosition = GUI.calculateRealPosition((Component)this.this$0);
                final int scale = DisplayGuiScreen.getScale();
                GL11.glScissor(calculateRealPosition[0] * scale - this.this$0.getParent().getOriginOffsetX() - 1, Display.getHeight() - this.this$0.getHeight() * scale - calculateRealPosition[1] * scale - 1, this.this$0.getWidth() * scale + this.this$0.getParent().getOriginOffsetX() + 1, this.this$0.getHeight() * scale + 1);
                GL11.glEnable(3089);
                GL11.glTranslatef((float)(-this.this$0.scrollX), 0.0f, 0.0f);
                final FontRenderer fontRenderer = this.this$0.getFontRenderer();
                GL11.glLineWidth(1.0f);
                GL11.glColor3f(1.0f, 1.0f, 1.0f);
                final boolean b = (int)((System.currentTimeMillis() - this.this$0.lastTypeMS) / 500L) % 2 == 0 && this.this$0.isFocused();
                int n = 0;
                int n2 = 0;
                int n3 = 0;
                if (this.this$0.getCursorRow() == 0 && b) {
                    GL11.glBegin(1);
                    GL11.glVertex2d(4.0, 2.0);
                    GL11.glVertex2d(4.0, (double)(fontRenderer.getFontHeight() - 1));
                    GL11.glEnd();
                }
                final char[] charArray = this.this$0.getDisplayText().toCharArray();
                for (int length = charArray.length, i = 0; i < length; ++i) {
                    final int stringWidth = fontRenderer.getStringWidth(String.valueOf(new StringBuilder().append(charArray[i]).append("")));
                    if (this.this$0.getCurrentState().isSelection() && n2 == this.this$0.getCurrentState().getSelectionStart()) {
                        n3 = 1;
                    }
                    if (n3 != 0) {
                        GL11.glColor4f(0.2f, 0.6f, 1.0f, 0.3f);
                        GL11.glBegin(7);
                        GL11.glVertex2d((double)(n + 2), 2.0);
                        GL11.glVertex2d((double)(n + 2), (double)(fontRenderer.getFontHeight() - 2));
                        GL11.glVertex2d((double)(n + stringWidth + 2), (double)(fontRenderer.getFontHeight() - 2));
                        GL11.glVertex2d((double)(n + stringWidth + 2), 2.0);
                        GL11.glEnd();
                    }
                    ++n2;
                    n += stringWidth;
                    if (n2 == this.this$0.getCursorRow() && b && !this.this$0.getCurrentState().isSelection()) {
                        GL11.glBegin(1);
                        GL11.glVertex2d((double)(n + 2), 2.0);
                        GL11.glVertex2d((double)(n + 2), (double)fontRenderer.getFontHeight());
                        GL11.glEnd();
                    }
                    if (this.this$0.getCurrentState().isSelection() && n2 == this.this$0.getCurrentState().getSelectionEnd()) {
                        n3 = 0;
                    }
                }
                String displayText = this.this$0.getDisplayText();
                if (displayText.isEmpty()) {
                    displayText = " ";
                }
                GL11.glEnable(3042);
                fontRenderer.drawString(0, -1, displayText);
                GL11.glDisable(3553);
                GL11.glBlendFunc(770, 771);
                GL11.glTranslatef((float)this.this$0.scrollX, 0.0f, 0.0f);
                GL11.glDisable(3089);
            }
        });
        this.addKeyListener(this.inputListener = (KeyListener)new KeyListener(this) {
            final InputField this$0;
            
            public void onKeyUp(final KeyListener.KeyEvent keyEvent) {
                this.this$0.rail = false;
                this.this$0.startRail = 0L;
                if (keyEvent.getKey() == 54) {
                    this.this$0.shift = false;
                }
            }
            
            public void onKeyDown(final KeyListener.KeyEvent keyEvent) {
                this.this$0.lastTypeMS = System.currentTimeMillis();
                if (keyEvent.getKey() == 14) {
                    if (this.this$0.getText().length() > 0) {
                        InputField.access$000(this.this$0);
                        if (this.this$0.currentState.selection) {
                            this.this$0.currentState.cursorRow = this.this$0.currentState.selectionEnd;
                            InputField.access$100(this.this$0);
                            this.this$0.remove(this.this$0.currentState.selectionEnd - this.this$0.currentState.selectionStart);
                            this.this$0.currentState.selection = false;
                        }
                        else {
                            this.this$0.remove(1);
                        }
                    }
                }
                else if (Keyboard.getEventCharacter() == '\u001a') {
                    if (!this.this$0.undoMap.isEmpty()) {
                        this.this$0.redoMap.add(0, this.this$0.currentState.clone());
                        this.this$0.currentState = this.this$0.undoMap.get(0);
                        this.this$0.undoMap.remove(0);
                    }
                }
                else if (Keyboard.getEventCharacter() == '\u0019') {
                    if (!this.this$0.redoMap.isEmpty()) {
                        this.this$0.undoMap.add(0, this.this$0.currentState.clone());
                        this.this$0.currentState = this.this$0.redoMap.get(0);
                        this.this$0.redoMap.remove(0);
                    }
                }
                else if (Keyboard.getEventCharacter() == '\u0001') {
                    this.this$0.currentState.selection = true;
                    this.this$0.currentState.selectionStart = 0;
                    this.this$0.currentState.selectionEnd = this.this$0.currentState.getText().length();
                }
                else if (keyEvent.getKey() == 54) {
                    this.this$0.shift = true;
                }
                else if (keyEvent.getKey() == 1) {
                    this.this$0.currentState.selection = false;
                }
                else if (Keyboard.getEventCharacter() == '\u0016') {
                    final Clipboard systemClipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                    try {
                        this.this$0.type((String)systemClipboard.getData(DataFlavor.stringFlavor));
                    }
                    catch (UnsupportedFlavorException ex) {}
                    catch (IOException ex2) {}
                }
                else if (Keyboard.getEventCharacter() == '\u0003') {
                    if (this.this$0.currentState.selection) {
                        final Clipboard systemClipboard2 = Toolkit.getDefaultToolkit().getSystemClipboard();
                        final StringSelection stringSelection = new StringSelection(this.this$0.currentState.getText().substring(this.this$0.currentState.selectionStart, this.this$0.currentState.selectionEnd));
                        systemClipboard2.setContents(stringSelection, stringSelection);
                    }
                }
                else if (keyEvent.getKey() == 205) {
                    if (this.this$0.currentState.cursorRow < this.this$0.getText().length()) {
                        if (this.this$0.shift) {
                            if (!this.this$0.currentState.selection) {
                                this.this$0.currentState.selectionStart = this.this$0.currentState.cursorRow;
                                this.this$0.currentState.selectionEnd = this.this$0.currentState.cursorRow;
                            }
                            this.this$0.currentState.selection = true;
                            this.this$0.currentState.selectionEnd = Math.min(this.this$0.getText().length(), this.this$0.currentState.selectionEnd + 1);
                        }
                        else if (this.this$0.currentState.selection) {
                            this.this$0.currentState.selection = false;
                            this.this$0.currentState.cursorRow = this.this$0.currentState.selectionEnd;
                            InputField.access$100(this.this$0);
                        }
                        else {
                            this.this$0.currentState.cursorRow = Math.min(this.this$0.getText().length(), this.this$0.currentState.cursorRow + 1);
                            InputField.access$100(this.this$0);
                        }
                    }
                }
                else if (keyEvent.getKey() == 203) {
                    if (this.this$0.currentState.cursorRow > 0) {
                        if (this.this$0.shift) {
                            if (!this.this$0.currentState.selection) {
                                this.this$0.currentState.selectionStart = this.this$0.currentState.cursorRow;
                                this.this$0.currentState.selectionEnd = this.this$0.currentState.cursorRow;
                            }
                            this.this$0.currentState.selection = true;
                            this.this$0.currentState.selectionStart = Math.max(0, this.this$0.currentState.selectionStart - 1);
                        }
                        else if (this.this$0.currentState.selection) {
                            this.this$0.currentState.selection = false;
                            this.this$0.currentState.cursorRow = this.this$0.currentState.selectionStart;
                            InputField.access$100(this.this$0);
                        }
                        else {
                            this.this$0.currentState.cursorRow = Math.max(0, this.this$0.currentState.cursorRow - 1);
                            InputField.access$100(this.this$0);
                        }
                    }
                }
                else if (Keyboard.getEventCharacter() != '\0') {
                    InputField.access$000(this.this$0);
                    if (this.this$0.currentState.selection) {
                        this.this$0.currentState.cursorRow = this.this$0.currentState.selectionEnd;
                        this.this$0.remove(this.this$0.currentState.selectionEnd - this.this$0.currentState.selectionStart);
                        this.this$0.currentState.selection = false;
                    }
                    this.this$0.type(String.valueOf(new StringBuilder().append(Keyboard.getEventCharacter()).append("")));
                }
                if (keyEvent.getKey() == 42) {
                    return;
                }
                this.this$0.startRail = System.currentTimeMillis();
                this.this$0.railChar = keyEvent.getKey();
            }
        });
        this.addMouseListener((MouseListener)new MouseListener(this) {
            final InputField this$0;
            
            public void onMouseDown(final MouseListener.MouseButtonEvent mouseButtonEvent) {
                this.this$0.currentState.selection = false;
                int n = -this.this$0.scrollX;
                int n2 = 0;
                final char[] charArray = this.this$0.getText().toCharArray();
                for (int length = charArray.length, i = 0; i < length; ++i) {
                    n += this.this$0.getFontRenderer().getStringWidth(String.valueOf(new StringBuilder().append(charArray[i]).append("")));
                    if (mouseButtonEvent.getX() < n) {
                        this.this$0.currentState.cursorRow = n2;
                        InputField.access$100(this.this$0);
                        return;
                    }
                    ++n2;
                }
                this.this$0.currentState.cursorRow = n2;
                InputField.access$100(this.this$0);
            }
            
            public void onMouseDrag(final MouseListener.MouseButtonEvent mouseButtonEvent) {
                this.this$0.currentState.selection = true;
                this.this$0.currentState.selectionStart = this.this$0.currentState.cursorRow;
                int n = -this.this$0.scrollX;
                int cursorRow = 0;
                final char[] charArray = this.this$0.getText().toCharArray();
                for (int length = charArray.length, i = 0; i < length; ++i) {
                    n += this.this$0.getFontRenderer().getStringWidth(String.valueOf(new StringBuilder().append(charArray[i]).append("")));
                    if (mouseButtonEvent.getX() < n) {
                        this.this$0.currentState.selectionEnd = cursorRow;
                        InputField.access$100(this.this$0);
                        break;
                    }
                    ++cursorRow;
                }
                this.this$0.currentState.selectionEnd = cursorRow;
                final int cursorRow2 = this.this$0.currentState.cursorRow;
                this.this$0.currentState.cursorRow = cursorRow;
                InputField.access$100(this.this$0);
                this.this$0.currentState.cursorRow = cursorRow2;
                if (this.this$0.currentState.selectionStart > this.this$0.currentState.selectionEnd) {
                    final int selectionStart = this.this$0.currentState.selectionStart;
                    this.this$0.currentState.selectionStart = this.this$0.currentState.selectionEnd;
                    this.this$0.currentState.selectionEnd = selectionStart;
                }
                if (this.this$0.currentState.selectionStart == this.this$0.currentState.selectionEnd) {
                    this.this$0.currentState.selection = false;
                }
            }
            
            public void onScroll(final MouseListener.MouseScrollEvent mouseScrollEvent) {
            }
            
            public void onMouseRelease(final MouseListener.MouseButtonEvent mouseButtonEvent) {
            }
            
            public void onMouseMove(final MouseListener.MouseMoveEvent mouseMoveEvent) {
            }
        });
        this.addRenderListener((RenderListener)new RenderListener(this) {
            final InputField this$0;
            
            public void onPostRender() {
            }
            
            public void onPreRender() {
                if (this.this$0.startRail == 0L) {
                    return;
                }
                if (!this.this$0.rail) {
                    this.this$0.railT = (float)(System.currentTimeMillis() - this.this$0.startRail);
                    if (this.this$0.railT > this.this$0.railDelay) {
                        this.this$0.rail = true;
                        this.this$0.startRail = System.currentTimeMillis();
                    }
                }
                else {
                    this.this$0.railT = (float)(System.currentTimeMillis() - this.this$0.startRail);
                    if (this.this$0.railT > this.this$0.railRepeat) {
                        this.this$0.inputListener.onKeyDown(new KeyListener.KeyEvent(this.this$0.railChar));
                        this.this$0.startRail = System.currentTimeMillis();
                    }
                }
            }
        });
    }
    
    static void access$100(final InputField inputField) {
        inputField.scroll();
    }
    
    public String getText() {
        return this.currentState.getText();
    }
    
    public int getCursorRow() {
        return this.currentState.getCursorRow();
    }
    
    private void scroll() {
        int n = 0;
        int n2 = 0;
        String value = "";
        for (final char c : this.getText().toCharArray()) {
            n += this.getFontRenderer().getStringWidth(String.valueOf(new StringBuilder().append(c).append("")));
            ++n2;
            value = String.valueOf(new StringBuilder().append(value).append(c));
            if (n2 >= this.currentState.cursorRow) {
                break;
            }
        }
        final int n3 = n - this.scrollX;
        if (n3 > this.getWidth()) {
            this.scrollX = n - this.getWidth() + 8;
        }
        else if (n3 < 0) {
            this.scrollX = n + 8;
        }
        if (this.currentState.cursorRow == 0) {
            this.scrollX = 0;
        }
    }
    
    public String getDisplayText() {
        return this.isEchoCharSet() ? this.getText().replaceAll(".", String.valueOf(new StringBuilder().append(this.getEchoChar()).append(""))) : this.getText();
    }
    
    public boolean setText(final String text) {
        this.currentState.text = text;
        this.callPoof((Class)InputFieldTextPoof.class, (PoofInfo)null);
        if (this.currentState.cursorRow > this.currentState.text.length()) {
            this.currentState.cursorRow = this.currentState.text.length();
            this.scroll();
            return true;
        }
        return false;
    }
    
    public InputField setEchoChar(final char echoChar) {
        this.echoChar = echoChar;
        return this;
    }
    
    public void type(final String s) {
        try {
            this.setText(String.valueOf(new StringBuilder().append(this.getText().substring(0, this.currentState.getCursorRow())).append(s).append(this.getText().substring(this.currentState.getCursorRow()))));
            final InputState currentState = this.currentState;
            currentState.cursorRow += s.length();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        this.scroll();
    }
    
    public void setFontRenderer(final FontRenderer fontRenderer) {
        this.fontRenderer = fontRenderer;
    }
    
    public FontRenderer getFontRenderer() {
        return (this.fontRenderer == null) ? this.getTheme().getFontRenderer() : this.fontRenderer;
    }
    
    static void access$000(final InputField inputField) {
        inputField.pushUndo();
    }
    
    public abstract static class InputFieldTextPoof<T extends InputField, S extends PoofInfo> extends Poof<T, S>
    {
    }
    
    public class InputState
    {
        String text;
        int cursorRow;
        int selectionEnd;
        int selectionStart;
        boolean selection;
        final InputField this$0;
        
        @Override
        protected Object clone() throws CloneNotSupportedException {
            return this.clone();
        }
        
        public void setSelectionEnd(final int selectionEnd) {
            this.selectionEnd = selectionEnd;
        }
        
        public void setCursorRow(final int cursorRow) {
            this.cursorRow = cursorRow;
            InputField.access$100(this.this$0);
        }
        
        public void setSelection(final boolean selection) {
            this.selection = selection;
        }
        
        public int getSelectionEnd() {
            return this.selectionEnd;
        }
        
        public void setText(final String text) {
            this.text = text;
        }
        
        public String getText() {
            return this.text;
        }
        
        public boolean isSelection() {
            return this.selection;
        }
        
        public int getCursorRow() {
            return this.cursorRow;
        }
        
        @Override
        protected InputState clone() {
            return this.this$0.new InputState(this.getText(), this.getCursorRow(), this.isSelection(), this.getSelectionStart(), this.getSelectionEnd());
        }
        
        public void setSelectionStart(final int selectionStart) {
            this.selectionStart = selectionStart;
        }
        
        public InputState(final InputField this$0, final String text, final int cursorRow, final boolean selection, final int selectionStart, final int selectionEnd) {
            this.this$0 = this$0;
            this.text = text;
            this.cursorRow = cursorRow;
            this.selection = selection;
            this.selectionStart = selectionStart;
            this.selectionEnd = selectionEnd;
        }
        
        public int getSelectionStart() {
            return this.selectionStart;
        }
    }
}
