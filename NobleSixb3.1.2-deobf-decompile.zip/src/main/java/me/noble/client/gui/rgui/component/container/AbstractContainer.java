//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.container;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.poof.use.*;
import me.noble.client.gui.rgui.poof.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.rgui.component.listen.*;
import java.util.function.*;
import java.util.*;
import me.noble.client.gui.rgui.render.theme.*;

public abstract class AbstractContainer extends AbstractComponent implements Container
{
    int originoffsetX;
    int originoffsetY;
    protected ArrayList<Component> children;
    
    public int getOriginOffsetX() {
        return this.originoffsetX;
    }
    
    public void setHeight(final int n) {
        super.setHeight(n + this.getOriginOffsetY());
    }
    
    public boolean hasChild(final Component component) {
        return this.children.contains(component);
    }
    
    public Container addChild(final Component... array) {
        for (final Component component : array) {
            if (!this.children.contains(component)) {
                component.setTheme(this.getTheme());
                component.setParent((Container)this);
                component.getUI().handleAddComponent(component, this);
                component.getUI().handleSizeComponent(component);
                synchronized (this.children) {
                    this.children.add(component);
                    Collections.sort(this.children, new Comparator<Component>(this) {
                        final AbstractContainer this$0;
                        
                        @Override
                        public int compare(final Component component, final Component component2) {
                            return component.getPriority() - component2.getPriority();
                        }
                        
                        @Override
                        public int compare(final Object o, final Object o2) {
                            return this.compare((Component)o, (Component)o2);
                        }
                    });
                    component.callPoof((Class)AdditionPoof.class, (PoofInfo)null);
                }
            }
        }
        return this;
    }
    
    public void renderChildren() {
        for (final Component component : this.getChildren()) {
            if (!component.isVisible()) {
                continue;
            }
            GL11.glPushMatrix();
            GL11.glTranslatef((float)component.getX(), (float)component.getY(), 0.0f);
            component.getRenderListeners().forEach(RenderListener::onPreRender);
            component.getUI().renderComponent(component, this.getTheme().getFontRenderer());
            if (component instanceof Container) {
                GL11.glTranslatef((float)((Container)component).getOriginOffsetX(), (float)((Container)component).getOriginOffsetY(), 0.0f);
                ((Container)component).renderChildren();
                GL11.glTranslatef((float)(-((Container)component).getOriginOffsetX()), (float)(-((Container)component).getOriginOffsetY()), 0.0f);
            }
            component.getRenderListeners().forEach(RenderListener::onPostRender);
            GL11.glTranslatef((float)(-component.getX()), (float)(-component.getY()), 0.0f);
            GL11.glPopMatrix();
        }
    }
    
    public void setOriginOffsetX(final int originoffsetX) {
        this.originoffsetX = originoffsetX;
    }
    
    public void setOriginOffsetY(final int originoffsetY) {
        this.originoffsetY = originoffsetY;
    }
    
    public void kill() {
        final Iterator<Component> iterator = this.children.iterator();
        while (iterator.hasNext()) {
            iterator.next().kill();
        }
        super.kill();
    }
    
    public Component getComponentAt(final int n, final int n2) {
        for (int i = this.getChildren().size() - 1; i >= 0; --i) {
            final Component component = this.getChildren().get(i);
            if (component.isVisible()) {
                final int n3 = component.getX() + this.getOriginOffsetX();
                final int n4 = component.getY() + this.getOriginOffsetY();
                final int width = component.getWidth();
                final int height = component.getHeight();
                if (component instanceof Container) {
                    if (!((Container)component).penetrateTest(n - this.getOriginOffsetX(), n2 - this.getOriginOffsetY())) {
                        continue;
                    }
                    final Component component2 = ((Container)component).getComponentAt(n - n3, n2 - n4);
                    if (component2 != component) {
                        return component2;
                    }
                }
                if (n >= n3 && n2 >= n4 && n <= n3 + width && n2 <= n4 + height) {
                    if (component instanceof Container) {
                        return ((Container)component).getComponentAt(n - n3, n2 - n4);
                    }
                    return component;
                }
            }
        }
        return (Component)this;
    }
    
    public boolean penetrateTest(final int n, final int n2) {
        return true;
    }
    
    public int getOriginOffsetY() {
        return this.originoffsetY;
    }
    
    public Container removeChild(final Component component) {
        if (this.children.contains(component)) {
            this.children.remove(component);
        }
        return this;
    }
    
    public void setWidth(final int n) {
        super.setWidth(n + this.getOriginOffsetX());
    }
    
    public AbstractContainer(final Theme theme) {
        this.children = new ArrayList<Component>();
        this.originoffsetX = 0;
        this.originoffsetY = 0;
        this.setTheme(theme);
    }
    
    public ArrayList<Component> getChildren() {
        return this.children;
    }
}
