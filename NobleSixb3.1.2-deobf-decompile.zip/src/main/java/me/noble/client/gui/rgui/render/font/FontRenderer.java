//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.font;

import java.awt.*;

public interface FontRenderer
{
    int getFontHeight();
    
    void drawString(final int p0, final int p1, final int p2, final int p3, final int p4, final String p5);
    
    void drawStringWithShadow(final int p0, final int p1, final int p2, final int p3, final int p4, final String p5);
    
    void drawString(final int p0, final int p1, final String p2);
    
    int getStringHeight(final String p0);
    
    void drawString(final int p0, final int p1, final int p2, final String p3);
    
    int getStringWidth(final String p0);
    
    void drawString(final int p0, final int p1, final Color p2, final String p3);
}
