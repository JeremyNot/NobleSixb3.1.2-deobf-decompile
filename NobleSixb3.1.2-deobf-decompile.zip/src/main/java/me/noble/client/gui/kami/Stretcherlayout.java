//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami;

import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.component.*;
import java.util.*;

public class Stretcherlayout implements Layout
{
    int blocks;
    int maxrows;
    public int COMPONENT_OFFSET_Y;
    public int COMPONENT_OFFSET_X;
    
    public Stretcherlayout(final int blocks) {
        this.COMPONENT_OFFSET_X = 10;
        this.COMPONENT_OFFSET_Y = 4;
        this.maxrows = -1;
        this.blocks = blocks;
    }
    
    public Stretcherlayout(final int blocks, final int maxrows) {
        this.COMPONENT_OFFSET_X = 10;
        this.COMPONENT_OFFSET_Y = 4;
        this.maxrows = -1;
        this.blocks = blocks;
        this.maxrows = maxrows;
    }
    
    @Override
    public void organiseContainer(final Container container) {
        int max = 0;
        int height = 0;
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        final ArrayList<Component> children = container.getChildren();
        for (final Component component : children) {
            if (!component.doAffectLayout()) {
                continue;
            }
            n2 += component.getWidth() + this.COMPONENT_OFFSET_X;
            n3 = Math.max(n3, component.getHeight());
            if (++n < this.blocks) {
                continue;
            }
            max = Math.max(max, n2);
            height += n3 + this.COMPONENT_OFFSET_Y;
            n3 = (n2 = (n = 0));
        }
        int n4 = 0;
        int n5 = 0;
        for (final Component component2 : children) {
            if (!component2.doAffectLayout()) {
                continue;
            }
            component2.setX(n4 + this.COMPONENT_OFFSET_X / 3);
            component2.setY(n5 + this.COMPONENT_OFFSET_Y / 3);
            n3 = Math.max(component2.getHeight(), n3);
            n4 += max / this.blocks;
            if (n4 < max) {
                continue;
            }
            n5 += n3 + this.COMPONENT_OFFSET_Y;
            n4 = 0;
        }
        container.setWidth(max);
        container.setHeight(height);
        final int width = max - this.COMPONENT_OFFSET_X;
        for (final Component component3 : children) {
            if (!component3.doAffectLayout()) {
                return;
            }
            component3.setWidth(width);
        }
    }
    
    public void setComponentOffsetWidth(final int component_OFFSET_X) {
        this.COMPONENT_OFFSET_X = component_OFFSET_X;
    }
    
    public void setComponentOffsetHeight(final int component_OFFSET_Y) {
        this.COMPONENT_OFFSET_Y = component_OFFSET_Y;
    }
}
