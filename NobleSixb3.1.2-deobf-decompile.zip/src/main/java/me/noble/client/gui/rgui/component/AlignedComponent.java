//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component;

public class AlignedComponent extends AbstractComponent
{
    Alignment alignment;
    
    public void setAlignment(final Alignment alignment) {
        this.alignment = alignment;
    }
    
    public Alignment getAlignment() {
        return this.alignment;
    }
    
    public enum Alignment
    {
        int index;
        private static final Alignment[] $VALUES;
        
        RIGHT(2), 
        CENTER(1), 
        LEFT(0);
        
        static {
            $VALUES = new Alignment[] { Alignment.LEFT, Alignment.CENTER, Alignment.RIGHT };
        }
        
        public int getIndex() {
            return this.index;
        }
        
        private Alignment(final int index) {
            this.index = index;
        }
    }
}
