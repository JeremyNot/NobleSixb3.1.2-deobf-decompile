//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.util.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.rgui.component.*;

public class RootCheckButtonUI<T extends CheckButton> extends AbstractComponentUI<CheckButton>
{
    @Override
    public void handleAddComponent(final CheckButton checkButton, final Container container) {
        checkButton.setWidth(KamiGUI.fontRenderer.getStringWidth(checkButton.getName()) + 28);
        checkButton.setHeight(KamiGUI.fontRenderer.getFontHeight() + 2);
    }
    
    @Override
    public void renderComponent(final CheckButton checkButton, final FontRenderer fontRenderer) {
        GL11.glColor4f((float)ColourSet.checkButtonBackgroundColour.getRed(), (float)ColourSet.checkButtonBackgroundColour.getGreen(), (float)ColourSet.checkButtonBackgroundColour.getBlue(), checkButton.getOpacity());
        if (checkButton.isToggled()) {
            GL11.glColor3f(ColourSet.checkButtonBackgroundColourOther, (float)ColourSet.checkButtonBackgroundColour.getGreen(), (float)ColourSet.checkButtonBackgroundColour.getBlue());
        }
        if (checkButton.isHovered() || checkButton.isPressed()) {
            GL11.glColor4f((float)ColourSet.checkButtonBackgroundColourHover.getRed(), (float)ColourSet.checkButtonBackgroundColourHover.getGreen(), (float)ColourSet.checkButtonBackgroundColourHover.getBlue(), checkButton.getOpacity());
        }
        final String name = checkButton.getName();
        int n = checkButton.isPressed() ? 11184810 : (checkButton.isToggled() ? 16724787 : 14540253);
        if (checkButton.isHovered()) {
            n = (n & 0x7F7F7F) << 1;
        }
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        KamiGUI.fontRenderer.drawString(checkButton.getWidth() / 2 - KamiGUI.fontRenderer.getStringWidth(name) / 2, KamiGUI.fontRenderer.getFontHeight() / 2 - 2, n, name);
        GL11.glDisable(3553);
        GL11.glDisable(3042);
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((CheckButton)component, fontRenderer);
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((CheckButton)component, container);
    }
}
