//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui;

import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.util.*;
import me.noble.client.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.use.*;
import net.minecraft.client.renderer.*;
import java.util.function.*;
import me.noble.client.gui.kami.*;
import java.util.*;

public class UIRenderer
{
    private static void lambda$renderAndUpdateFrames$0(final RenderListener renderListener) {
        renderListener.onPreRender();
    }
    
    public static void renderAndUpdateFrames() {
        if (Wrapper.getMinecraft().currentScreen instanceof DisplayGuiScreen || Wrapper.getMinecraft().gameSettings.showDebugInfo) {
            return;
        }
        final KamiGUI guiManager = NobleMod.getInstance().getGuiManager();
        GL11.glDisable(3553);
        for (final Component component : guiManager.getChildren()) {
            if (component instanceof Frame) {
                GlStateManager.pushMatrix();
                final Frame frame = (Frame)component;
                if (frame.isPinned() && frame.isVisible()) {
                    final boolean b = frame.getOpacity() != 0.0f;
                    GL11.glTranslated((double)frame.getX(), (double)frame.getY(), 0.0);
                    frame.getRenderListeners().forEach(UIRenderer::lambda$renderAndUpdateFrames$0);
                    frame.getTheme().getUIForComponent((Component)frame).renderComponent((Component)frame, frame.getTheme().getFontRenderer());
                    int n = 0;
                    int n2 = 0;
                    if (b) {
                        n += frame.getOriginOffsetX();
                        n2 += frame.getOriginOffsetY();
                    }
                    else {
                        if (frame.getDocking().isBottom()) {
                            n2 += frame.getOriginOffsetY();
                        }
                        if (frame.getDocking().isRight()) {
                            n += frame.getOriginOffsetX();
                            if (frame.getChildren().size() > 0) {
                                n += (frame.getWidth() - frame.getChildren().get(0).getX() - frame.getChildren().get(0).getWidth()) / DisplayGuiScreen.getScale();
                            }
                        }
                        if (frame.getDocking().isLeft() && frame.getChildren().size() > 0) {
                            n -= frame.getChildren().get(0).getX();
                        }
                        if (frame.getDocking().isTop() && frame.getChildren().size() > 0) {
                            n2 -= frame.getChildren().get(0).getY();
                        }
                    }
                    GL11.glTranslated((double)n, (double)n2, 0.0);
                    frame.getRenderListeners().forEach(RenderListener::onPostRender);
                    frame.renderChildren();
                    GL11.glTranslated((double)(-n), (double)(-n2), 0.0);
                    GL11.glTranslated((double)(-frame.getX()), (double)(-frame.getY()), 0.0);
                }
                GlStateManager.popMatrix();
            }
        }
        GL11.glEnable(3553);
        GL11.glEnable(3042);
        GlStateManager.enableBlend();
    }
}
