//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.font.*;

public interface ComponentUI<T extends Component>
{
    void handleKeyUp(final T p0, final int p1);
    
    void handleSizeComponent(final T p0);
    
    Class<? extends Component> getHandledClass();
    
    void handleMouseRelease(final T p0, final int p1, final int p2, final int p3);
    
    void handleScroll(final T p0, final int p1, final int p2, final int p3, final boolean p4);
    
    void handleMouseDrag(final T p0, final int p1, final int p2, final int p3);
    
    void handleAddComponent(final T p0, final Container p1);
    
    void renderComponent(final T p0, final FontRenderer p1);
    
    void handleKeyDown(final T p0, final int p1);
    
    void handleMouseDown(final T p0, final int p1, final int p2, final int p3);
}
