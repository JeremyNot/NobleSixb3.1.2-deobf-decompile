//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.module.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.kami.*;
import me.noble.client.gui.rgui.layout.*;
import me.noble.client.setting.*;
import me.noble.client.setting.impl.*;
import me.noble.client.util.*;
import me.noble.client.setting.impl.numerical.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.component.use.*;
import java.util.*;
import java.util.function.*;

public class SettingsPanel extends OrganisedContainer
{
    Module module;
    
    public Module getModule() {
        return this.module;
    }
    
    public void setModule(final Module module) {
        this.module = module;
        this.setMinimumWidth((int)(this.getParent().getWidth() * 0.9f));
        this.prepare();
        this.setAffectLayout(false);
        for (final Component component : this.children) {
            component.setWidth(this.getWidth() - 10);
            component.setX(5);
        }
    }
    
    @Override
    public void renderChildren() {
        super.renderChildren();
    }
    
    private static String lambda$prepare$0(final Object o) {
        return o.toString().toUpperCase();
    }
    
    private static String[] lambda$prepare$1(final int n) {
        return new String[n];
    }
    
    public SettingsPanel(final Theme theme, final Module module) {
        super(theme, new Stretcherlayout(1));
        this.setAffectLayout(false);
        this.module = module;
        this.prepare();
    }
    
    private void prepare() {
        this.getChildren().clear();
        if (this.module == null) {
            this.setVisible(false);
            return;
        }
        if (!this.module.settingList.isEmpty()) {
            for (final Setting<Object> setting : this.module.settingList) {
                if (!setting.isVisible()) {
                    continue;
                }
                final String name = setting.getName();
                final boolean b = setting instanceof NumberSetting;
                final boolean b2 = setting instanceof BooleanSetting;
                final boolean b3 = setting instanceof EnumSetting;
                if (setting.getValue() instanceof Bind) {
                    this.addChild((Component)new BindButton("Bind", this.module));
                }
                if (b) {
                    final NumberSetting<Object> numberSetting = (NumberSetting<Object>)setting;
                    final boolean bound = numberSetting.isBound();
                    final double double1 = Double.parseDouble(numberSetting.getValue().toString());
                    if (!bound) {
                        final UnboundSlider unboundSlider = new UnboundSlider(double1, name, setting instanceof IntegerSetting);
                        unboundSlider.addPoof(new Slider.SliderPoof<UnboundSlider, Slider.SliderPoof.SliderPoofInfo>(this, setting) {
                            final Setting val$setting;
                            final SettingsPanel this$0;
                            
                            @Override
                            public void execute(final UnboundSlider unboundSlider, final SliderPoofInfo sliderPoofInfo) {
                                if (this.val$setting instanceof IntegerSetting) {
                                    this.val$setting.setValue((int)sliderPoofInfo.getNewValue());
                                }
                                else if (this.val$setting instanceof FloatSetting) {
                                    this.val$setting.setValue((float)sliderPoofInfo.getNewValue());
                                }
                                else if (this.val$setting instanceof DoubleSetting) {
                                    this.val$setting.setValue(sliderPoofInfo.getNewValue());
                                }
                                this.this$0.setModule(this.this$0.module);
                            }
                            
                            @Override
                            public void execute(final Component component, final PoofInfo poofInfo) {
                                this.execute((UnboundSlider)component, (SliderPoofInfo)poofInfo);
                            }
                        });
                        if (numberSetting.getMax() != null) {
                            unboundSlider.setMax(numberSetting.getMax().doubleValue());
                        }
                        if (numberSetting.getMin() != null) {
                            unboundSlider.setMin(numberSetting.getMin().doubleValue());
                        }
                        this.addChild(unboundSlider);
                    }
                    else {
                        final double double2 = Double.parseDouble(numberSetting.getMin().toString());
                        final double double3 = Double.parseDouble(numberSetting.getMax().toString());
                        final Slider slider = new Slider(double1, double2, double3, Slider.getDefaultStep(double2, double3), name, setting instanceof IntegerSetting);
                        slider.addPoof(new Slider.SliderPoof<Slider, Slider.SliderPoof.SliderPoofInfo>(this, setting) {
                            final Setting val$setting;
                            final SettingsPanel this$0;
                            
                            @Override
                            public void execute(final Component component, final PoofInfo poofInfo) {
                                this.execute((Slider)component, (SliderPoofInfo)poofInfo);
                            }
                            
                            @Override
                            public void execute(final Slider slider, final SliderPoofInfo sliderPoofInfo) {
                                if (this.val$setting instanceof IntegerSetting) {
                                    this.val$setting.setValue((int)sliderPoofInfo.getNewValue());
                                }
                                else if (this.val$setting instanceof FloatSetting) {
                                    this.val$setting.setValue((float)sliderPoofInfo.getNewValue());
                                }
                                else if (this.val$setting instanceof DoubleSetting) {
                                    this.val$setting.setValue(sliderPoofInfo.getNewValue());
                                }
                            }
                        });
                        this.addChild(slider);
                    }
                }
                else if (b2) {
                    final CheckButton checkButton = new CheckButton(name);
                    checkButton.setToggled(((BooleanSetting)setting).getValue());
                    checkButton.addPoof(new CheckButton.CheckButtonPoof<CheckButton, CheckButton.CheckButtonPoof.CheckButtonPoofInfo>(this, setting, checkButton) {
                        final Setting val$setting;
                        final CheckButton val$checkButton;
                        final SettingsPanel this$0;
                        
                        @Override
                        public void execute(final Component component, final PoofInfo poofInfo) {
                            this.execute((CheckButton)component, (CheckButtonPoofInfo)poofInfo);
                        }
                        
                        @Override
                        public void execute(final CheckButton checkButton, final CheckButtonPoofInfo checkButtonPoofInfo) {
                            if (checkButtonPoofInfo.getAction() == CheckButtonPoofInfo.CheckButtonPoofInfoAction.TOGGLE) {
                                this.val$setting.setValue(this.val$checkButton.isToggled());
                                this.this$0.setModule(this.this$0.module);
                            }
                        }
                    });
                    this.addChild(checkButton);
                }
                else {
                    if (!b3) {
                        continue;
                    }
                    final? extends Enum[] enumConstants = ((EnumSetting<Object>)setting).clazz.getEnumConstants();
                    final EnumButton enumButton = new EnumButton(name, (String[])Arrays.stream((Object[])enumConstants).map((Function<? super Object, ?>)SettingsPanel::lambda$prepare$0).toArray(SettingsPanel::lambda$prepare$1));
                    enumButton.addPoof((IPoof)new EnumButton.EnumbuttonIndexPoof<EnumButton, EnumButton.EnumbuttonIndexPoof.EnumbuttonInfo>(this, setting, enumConstants) {
                        final Setting val$setting;
                        final Object[] val$con;
                        final SettingsPanel this$0;
                        
                        public void execute(final Component component, final PoofInfo poofInfo) {
                            this.execute((EnumButton)component, (EnumbuttonIndexPoof.EnumbuttonInfo)poofInfo);
                        }
                        
                        public void execute(final EnumButton enumButton, final EnumbuttonIndexPoof.EnumbuttonInfo enumbuttonInfo) {
                            this.val$setting.setValue(this.val$con[enumbuttonInfo.getNewIndex()]);
                            this.this$0.setModule(this.this$0.module);
                        }
                    });
                    enumButton.setIndex(Arrays.asList((Object[])enumConstants).indexOf(setting.getValue()));
                    this.addChild((Component)enumButton);
                }
            }
        }
        if (this.children.isEmpty()) {
            this.setVisible(false);
            return;
        }
        this.setVisible(true);
    }
}
