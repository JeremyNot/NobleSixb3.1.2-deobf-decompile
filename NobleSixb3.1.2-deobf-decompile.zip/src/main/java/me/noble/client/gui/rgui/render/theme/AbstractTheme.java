//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.theme;

import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.*;
import java.util.*;

public abstract class AbstractTheme implements Theme
{
    protected final Map<Class<? extends Layout>, Class<? extends Layout>> layoutMap;
    protected final Map<Class<? extends Component>, ComponentUI> uis;
    
    public AbstractTheme() {
        this.uis = new HashMap<Class<? extends Component>, ComponentUI>();
        this.layoutMap = new HashMap<Class<? extends Layout>, Class<? extends Layout>>();
    }
    
    public ComponentUI getComponentUIForClass(final Class<? extends Component> clazz) {
        if (this.uis.containsKey(clazz)) {
            return this.uis.get(clazz);
        }
        if (clazz == null) {
            return null;
        }
        final Class[] interfaces = clazz.getInterfaces();
        for (int length = interfaces.length, i = 0; i < length; ++i) {
            final ComponentUI componentUI = this.uis.get(interfaces[i]);
            if (componentUI != null) {
                return componentUI;
            }
        }
        return this.getComponentUIForClass((Class<? extends Component>)clazz.getSuperclass());
    }
    
    @Override
    public ComponentUI getUIForComponent(final Component component) {
        final ComponentUI componentUIForClass = this.getComponentUIForClass(component.getClass());
        if (componentUIForClass == null) {
            throw new RuntimeException(String.valueOf(new StringBuilder().append("No installed component UI for ").append(component.getClass().getName())));
        }
        return componentUIForClass;
    }
    
    protected void installUI(final ComponentUI<?> componentUI) {
        this.uis.put(componentUI.getHandledClass(), componentUI);
    }
}
