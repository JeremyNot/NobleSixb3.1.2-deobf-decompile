//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.render.util;

import org.lwjgl.opengl.*;
import java.util.function.*;
import java.util.*;

public abstract class Shader
{
    private final int programID;
    private final Map<String, Uniform> uniforms;
    private final int fragmentID;
    private final int vertexID;
    
    public final void attach() {
        ARBShaderObjects.glUseProgramObjectARB(this.programID);
        this.update();
    }
    
    private Uniform lambda$getUniform$0(final String s) {
        return Uniform.get(this.programID, s);
    }
    
    public final void delete() {
        ARBShaderObjects.glUseProgramObjectARB(0);
        ARBShaderObjects.glDetachObjectARB(this.programID, this.vertexID);
        ARBShaderObjects.glDetachObjectARB(this.programID, this.fragmentID);
        ARBShaderObjects.glDeleteObjectARB(this.vertexID);
        ARBShaderObjects.glDeleteObjectARB(this.fragmentID);
        ARBShaderObjects.glDeleteObjectARB(this.programID);
    }
    
    public abstract void update();
    
    protected final Uniform getUniform(final String s) {
        return this.uniforms.computeIfAbsent(s, this::lambda$getUniform$0);
    }
    
    public final void detach() {
        ARBShaderObjects.glUseProgramObjectARB(0);
    }
    
    public Shader(final String s, final String s2) {
        this.uniforms = new HashMap<String, Uniform>();
        this.programID = ARBShaderObjects.glCreateProgramObjectARB();
        this.vertexID = ShaderHelper.loadShader(s, 35633);
        this.fragmentID = ShaderHelper.loadShader(s2, 35632);
        ARBShaderObjects.glAttachObjectARB(this.programID, this.vertexID);
        ARBShaderObjects.glAttachObjectARB(this.programID, this.fragmentID);
        ShaderHelper.createProgram(this.programID);
    }
}
