//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.rgui.component.*;
import org.lwjgl.opengl.*;

public class RootLabelUI<T extends Label> extends AbstractComponentUI<Label>
{
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Label)component, fontRenderer);
    }
    
    @Override
    public void handleSizeComponent(final Label label) {
        final String[] lines = label.getLines();
        int height = 0;
        int max = 0;
        final String[] array = lines;
        for (int length = array.length, i = 0; i < length; ++i) {
            max = Math.max(max, label.getFontRenderer().getStringWidth(array[i]));
            height += label.getFontRenderer().getFontHeight() + 3;
        }
        label.setWidth(max);
        label.setHeight(height);
    }
    
    @Override
    public void handleSizeComponent(final Component component) {
        this.handleSizeComponent((Label)component);
    }
    
    @Override
    public void renderComponent(final Label label, FontRenderer fontRenderer) {
        fontRenderer = label.getFontRenderer();
        final String[] lines = label.getLines();
        int n = 0;
        final boolean shadow = label.isShadow();
        for (final String s : lines) {
            int n2 = 0;
            if (label.getAlignment() == AlignedComponent.Alignment.CENTER) {
                n2 = label.getWidth() / 2 - fontRenderer.getStringWidth(s) / 2;
            }
            else if (label.getAlignment() == AlignedComponent.Alignment.RIGHT) {
                n2 = label.getWidth() - fontRenderer.getStringWidth(s);
            }
            if (shadow) {
                fontRenderer.drawStringWithShadow(n2, n, 255, 255, 255, s);
            }
            else {
                fontRenderer.drawString(n2, n, s);
            }
            n += fontRenderer.getFontHeight() + 3;
        }
        GL11.glDisable(3553);
        GL11.glDisable(3042);
    }
}
