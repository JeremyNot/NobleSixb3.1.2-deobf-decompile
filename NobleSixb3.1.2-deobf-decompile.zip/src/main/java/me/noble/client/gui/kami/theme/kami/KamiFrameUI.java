//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.poof.use.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.util.*;
import java.util.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;
import me.noble.client.util.*;
import me.noble.client.gui.rgui.*;

public class KamiFrameUI<T extends Frame> extends AbstractComponentUI<Frame>
{
    Component yLineComponent;
    Component xLineComponent;
    boolean centerX;
    ColourHolder frameColour;
    boolean centerY;
    private static final RootFontRenderer ff;
    int xLineOffset;
    Component centerYComponent;
    ColourHolder outlineColour;
    Component centerXComponent;
    
    @Override
    public void handleMouseRelease(final Component component, final int n, final int n2, final int n3) {
        this.handleMouseRelease((Frame)component, n, n2, n3);
    }
    
    public KamiFrameUI() {
        this.frameColour = KamiGUI.primaryColour.setA(100);
        this.outlineColour = this.frameColour.darker();
        this.yLineComponent = null;
        this.xLineComponent = null;
        this.centerXComponent = null;
        this.centerYComponent = null;
        this.centerX = false;
        this.centerY = false;
        this.xLineOffset = 0;
    }
    
    @Override
    public void handleMouseDrag(final Component component, final int n, final int n2, final int n3) {
        this.handleMouseDrag((Frame)component, n, n2, n3);
    }
    
    @Override
    public void handleAddComponent(final Frame frame, final Container container) {
        super.handleAddComponent(frame, container);
        frame.setOriginOffsetY(frame.getTheme().getFontRenderer().getFontHeight() + 3);
        frame.setOriginOffsetX(3);
        frame.addMouseListener(new MouseListener(this, frame) {
            final KamiFrameUI this$0;
            final Frame val$component;
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
            }
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                final int y = mouseButtonEvent.getY();
                final int x = mouseButtonEvent.getX();
                if (y < 0) {
                    if (x > this.val$component.getWidth() - 22) {
                        if (this.val$component.isMinimizeable() && this.val$component.isCloseable()) {
                            if (y > -this.val$component.getOriginOffsetY() / 2) {
                                if (this.val$component.isMinimized()) {
                                    this.val$component.callPoof(FramePoof.class, new FramePoof.FramePoofInfo(FramePoof.Action.MAXIMIZE));
                                }
                                else {
                                    this.val$component.callPoof(FramePoof.class, new FramePoof.FramePoofInfo(FramePoof.Action.MINIMIZE));
                                }
                            }
                            else {
                                this.val$component.callPoof(FramePoof.class, new FramePoof.FramePoofInfo(FramePoof.Action.CLOSE));
                            }
                        }
                        else if (this.val$component.isMinimized() && this.val$component.isMinimizeable()) {
                            this.val$component.callPoof(FramePoof.class, new FramePoof.FramePoofInfo(FramePoof.Action.MAXIMIZE));
                        }
                        else if (this.val$component.isMinimizeable()) {
                            this.val$component.callPoof(FramePoof.class, new FramePoof.FramePoofInfo(FramePoof.Action.MINIMIZE));
                        }
                        else if (this.val$component.isCloseable()) {
                            this.val$component.callPoof(FramePoof.class, new FramePoof.FramePoofInfo(FramePoof.Action.CLOSE));
                        }
                    }
                    if (x < 10 && x > 0 && this.val$component.isPinnable()) {
                        this.val$component.setPinned(!this.val$component.isPinned());
                    }
                }
            }
        });
        frame.addUpdateListener(new UpdateListener(this) {
            final KamiFrameUI this$0;
            
            @Override
            public void updateSize(final Component component, final int n, final int n2) {
                if (component instanceof Frame) {
                    KamiGUI.dock((Frame)component);
                }
            }
            
            @Override
            public void updateLocation(final Component component, final int n, final int n2) {
            }
        });
        frame.addPoof(new Frame.FrameDragPoof<Frame, Frame.FrameDragPoof.DragInfo>(this) {
            final KamiFrameUI this$0;
            
            @Override
            public void execute(final Frame centerYComponent, final DragInfo dragInfo) {
                if (Bind.isShiftDown() || Bind.isAltDown() || Bind.isCtrlDown()) {
                    return;
                }
                int x = dragInfo.getX();
                int y = dragInfo.getY();
                this.this$0.yLineComponent = null;
                this.this$0.xLineComponent = null;
                centerYComponent.setDocking(Docking.NONE);
                for (final Component component : NobleMod.getInstance().getGuiManager().getChildren()) {
                    if (component.equals(centerYComponent)) {
                        continue;
                    }
                    if (Math.abs(y - component.getY()) < 4) {
                        y = component.getY();
                        this.this$0.yLineComponent = centerYComponent;
                    }
                    if (Math.abs(y - (component.getY() + component.getHeight() + 3)) < 4) {
                        y = component.getY() + component.getHeight();
                        y += 3;
                        this.this$0.yLineComponent = centerYComponent;
                    }
                    if (Math.abs(x + centerYComponent.getWidth() - (component.getX() + component.getWidth())) < 4) {
                        x = component.getX() + component.getWidth() - centerYComponent.getWidth();
                        this.this$0.xLineComponent = centerYComponent;
                        this.this$0.xLineOffset = centerYComponent.getWidth();
                    }
                    if (Math.abs(x - component.getX()) < 4) {
                        x = component.getX();
                        this.this$0.xLineComponent = centerYComponent;
                        this.this$0.xLineOffset = 0;
                    }
                    if (Math.abs(x - (component.getX() + component.getWidth() + 3)) >= 4) {
                        continue;
                    }
                    x = component.getX() + component.getWidth() + 3;
                    this.this$0.xLineComponent = centerYComponent;
                    this.this$0.xLineOffset = 0;
                }
                if (x < 5) {
                    x = 0;
                    ContainerHelper.setAlignment(centerYComponent, AlignedComponent.Alignment.LEFT);
                    centerYComponent.setDocking(Docking.LEFT);
                }
                if (-((x + centerYComponent.getWidth()) * DisplayGuiScreen.getScale() - Wrapper.getMinecraft().displayWidth) < 5) {
                    x = Wrapper.getMinecraft().displayWidth / DisplayGuiScreen.getScale() - centerYComponent.getWidth();
                    ContainerHelper.setAlignment(centerYComponent, AlignedComponent.Alignment.RIGHT);
                    centerYComponent.setDocking(Docking.RIGHT);
                }
                if (y < 5) {
                    y = 0;
                    if (centerYComponent.getDocking().equals(Docking.RIGHT)) {
                        centerYComponent.setDocking(Docking.TOPRIGHT);
                    }
                    else if (centerYComponent.getDocking().equals(Docking.LEFT)) {
                        centerYComponent.setDocking(Docking.TOPLEFT);
                    }
                    else {
                        centerYComponent.setDocking(Docking.TOP);
                    }
                }
                if (-((y + centerYComponent.getHeight()) * DisplayGuiScreen.getScale() - Wrapper.getMinecraft().displayHeight) < 5) {
                    y = Wrapper.getMinecraft().displayHeight / DisplayGuiScreen.getScale() - centerYComponent.getHeight();
                    if (centerYComponent.getDocking().equals(Docking.RIGHT)) {
                        centerYComponent.setDocking(Docking.BOTTOMRIGHT);
                    }
                    else if (centerYComponent.getDocking().equals(Docking.LEFT)) {
                        centerYComponent.setDocking(Docking.BOTTOMLEFT);
                    }
                    else {
                        centerYComponent.setDocking(Docking.BOTTOM);
                    }
                }
                if (Math.abs((x + centerYComponent.getWidth() / 2) * DisplayGuiScreen.getScale() * 2 - Wrapper.getMinecraft().displayWidth) < 5) {
                    this.this$0.xLineComponent = null;
                    this.this$0.centerXComponent = centerYComponent;
                    this.this$0.centerX = true;
                    x = Wrapper.getMinecraft().displayWidth / (DisplayGuiScreen.getScale() * 2) - centerYComponent.getWidth() / 2;
                    if (centerYComponent.getDocking().isTop()) {
                        centerYComponent.setDocking(Docking.CENTERTOP);
                    }
                    else if (centerYComponent.getDocking().isBottom()) {
                        centerYComponent.setDocking(Docking.CENTERBOTTOM);
                    }
                    else {
                        centerYComponent.setDocking(Docking.CENTERVERTICAL);
                    }
                    ContainerHelper.setAlignment(centerYComponent, AlignedComponent.Alignment.CENTER);
                }
                else {
                    this.this$0.centerX = false;
                }
                if (Math.abs((y + centerYComponent.getHeight() / 2) * DisplayGuiScreen.getScale() * 2 - Wrapper.getMinecraft().displayHeight) < 5) {
                    this.this$0.yLineComponent = null;
                    this.this$0.centerYComponent = centerYComponent;
                    this.this$0.centerY = true;
                    y = Wrapper.getMinecraft().displayHeight / (DisplayGuiScreen.getScale() * 2) - centerYComponent.getHeight() / 2;
                    if (centerYComponent.getDocking().isLeft()) {
                        centerYComponent.setDocking(Docking.CENTERLEFT);
                    }
                    else if (centerYComponent.getDocking().isRight()) {
                        centerYComponent.setDocking(Docking.CENTERRIGHT);
                    }
                    else if (centerYComponent.getDocking().isCenterHorizontal()) {
                        centerYComponent.setDocking(Docking.CENTER);
                    }
                    else {
                        centerYComponent.setDocking(Docking.CENTERHOIZONTAL);
                    }
                }
                else {
                    this.this$0.centerY = false;
                }
                dragInfo.setX(x);
                dragInfo.setY(y);
            }
            
            @Override
            public void execute(final Component component, final PoofInfo poofInfo) {
                this.execute((Frame)component, (DragInfo)poofInfo);
            }
        });
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((Frame)component, container);
    }
    
    @Override
    public void handleMouseDrag(final Frame frame, final int n, final int n2, final int n3) {
        super.handleMouseDrag(frame, n, n2, n3);
    }
    
    @Override
    public void handleMouseRelease(final Frame frame, final int n, final int n2, final int n3) {
        this.yLineComponent = null;
        this.xLineComponent = null;
        this.centerXComponent = null;
        this.centerYComponent = null;
    }
    
    static {
        ff = (RootFontRenderer)new RootLargeFontRenderer();
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Frame)component, fontRenderer);
    }
    
    @Override
    public void renderComponent(final Frame frame, final FontRenderer fontRenderer) {
        if (frame.getOpacity() == 0.0f) {
            return;
        }
        GL11.glDisable(3553);
        GL11.glColor4f(0.17f, 0.17f, 0.18f, 0.5f);
        RenderHelper.drawFilledRectangle(0.0f, 0.0f, (float)frame.getWidth(), (float)frame.getHeight());
        GL11.glColor3f(0.2f, 0.8f, 0.95f);
        GL11.glLineWidth(ColourSet.componentWindowOutlineWidth);
        RenderHelper.drawRectangle(0.0f, 0.0f, (float)frame.getWidth(), (float)frame.getHeight());
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        KamiFrameUI.ff.drawString(frame.getWidth() / 2 - KamiFrameUI.ff.getStringWidth(frame.getTitle()) / 2, 1, frame.getTitle());
        int n = 5;
        int n2 = frame.getTheme().getFontRenderer().getFontHeight() - 9;
        if (frame.isCloseable() && frame.isMinimizeable()) {
            n -= 4;
            n2 -= 4;
        }
        if (frame.isCloseable()) {
            GL11.glLineWidth(2.0f);
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
            GL11.glBegin(1);
            GL11.glVertex2d((double)(frame.getWidth() - 20), (double)n);
            GL11.glVertex2d((double)(frame.getWidth() - 10), (double)n2);
            GL11.glVertex2d((double)(frame.getWidth() - 10), (double)n);
            GL11.glVertex2d((double)(frame.getWidth() - 20), (double)n2);
            GL11.glEnd();
        }
        if (frame.isCloseable() && frame.isMinimizeable()) {
            n += 12;
            n2 += 12;
        }
        if (frame.isMinimizeable()) {
            GL11.glLineWidth(1.5f);
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
            if (frame.isMinimized()) {
                GL11.glBegin(2);
                GL11.glVertex2d((double)(frame.getWidth() - 15), (double)(n + 2));
                GL11.glVertex2d((double)(frame.getWidth() - 15), (double)(n2 + 3));
                GL11.glVertex2d((double)(frame.getWidth() - 10), (double)(n2 + 3));
                GL11.glVertex2d((double)(frame.getWidth() - 10), (double)(n + 2));
                GL11.glEnd();
            }
            else {
                GL11.glBegin(1);
                GL11.glVertex2d((double)(frame.getWidth() - 15), (double)(n2 + 4));
                GL11.glVertex2d((double)(frame.getWidth() - 10), (double)(n2 + 4));
                GL11.glEnd();
            }
        }
        if (frame.isPinnable()) {
            if (frame.isPinned()) {
                GL11.glColor3f(1.0f, 0.33f, 0.33f);
            }
            else {
                GL11.glColor3f(0.66f, 0.66f, 0.66f);
            }
            RenderHelper.drawCircle(7.0f, 4.0f, 2.0f);
            GL11.glLineWidth(3.0f);
            GL11.glBegin(1);
            GL11.glVertex2d(7.0, 4.0);
            GL11.glVertex2d(4.0, 8.0);
            GL11.glEnd();
        }
        if (frame.equals(this.xLineComponent)) {
            GL11.glColor3f(ColourSet.componentLineColour, ColourSet.componentLineColour, ColourSet.componentLineColour);
            GL11.glLineWidth(1.0f);
            GL11.glBegin(1);
            GL11.glVertex2d((double)this.xLineOffset, (double)(-GUI.calculateRealPosition(frame)[1]));
            GL11.glVertex2d((double)this.xLineOffset, (double)Wrapper.getMinecraft().displayHeight);
            GL11.glEnd();
        }
        if (frame == this.centerXComponent && this.centerX) {
            GL11.glColor3f(0.86f, 0.03f, 1.0f);
            GL11.glLineWidth(1.0f);
            GL11.glBegin(1);
            final double n3 = frame.getWidth() / 2;
            GL11.glVertex2d(n3, (double)(-GUI.calculateRealPosition(frame)[1]));
            GL11.glVertex2d(n3, (double)Wrapper.getMinecraft().displayHeight);
            GL11.glEnd();
        }
        if (frame.equals(this.yLineComponent)) {
            GL11.glColor3f(0.44f, 0.44f, 0.44f);
            GL11.glLineWidth(1.0f);
            GL11.glBegin(1);
            GL11.glVertex2d((double)(-GUI.calculateRealPosition(frame)[0]), 0.0);
            GL11.glVertex2d((double)Wrapper.getMinecraft().displayWidth, 0.0);
            GL11.glEnd();
        }
        if (frame == this.centerYComponent && this.centerY) {
            GL11.glColor3f(0.86f, 0.03f, 1.0f);
            GL11.glLineWidth(1.0f);
            GL11.glBegin(1);
            final double n4 = frame.getHeight() / 2;
            GL11.glVertex2d((double)(-GUI.calculateRealPosition(frame)[0]), n4);
            GL11.glVertex2d((double)Wrapper.getMinecraft().displayWidth, n4);
            GL11.glEnd();
        }
        GL11.glDisable(3042);
    }
}
