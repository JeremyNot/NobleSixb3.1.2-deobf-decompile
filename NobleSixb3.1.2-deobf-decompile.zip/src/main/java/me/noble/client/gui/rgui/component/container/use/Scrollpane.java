//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.container.use;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.layout.*;
import me.noble.client.gui.rgui.*;
import me.noble.client.gui.kami.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.rgui.component.listen.*;
import java.util.*;

public class Scrollpane extends OrganisedContainer
{
    int maxScrollY;
    boolean lockHeight;
    int step;
    int scrolledX;
    boolean canScrollY;
    int maxScrollX;
    boolean doScrollX;
    boolean canScrollX;
    int scrolledY;
    boolean lockWidth;
    boolean doScrollY;
    
    static void access$000(final Scrollpane scrollpane) {
        scrollpane.performCalculations();
    }
    
    public void setDoScrollX(final boolean doScrollX) {
        this.doScrollX = doScrollX;
    }
    
    public Container addChild(final Component... array) {
        super.addChild(array);
        this.performCalculations();
        return (Container)this;
    }
    
    public void setDoScrollY(final boolean doScrollY) {
        this.doScrollY = doScrollY;
    }
    
    public void setWidth(final int width) {
        if (!this.lockWidth) {
            super.setWidth(width);
        }
    }
    
    public int getMaxScrollY() {
        return this.maxScrollY;
    }
    
    public boolean penetrateTest(final int n, final int n2) {
        return n > 0 && n < this.getWidth() && n2 > 0 && n2 < this.getHeight();
    }
    
    public void setHeight(final int height) {
        if (!this.lockHeight) {
            super.setHeight(height);
        }
    }
    
    public Scrollpane(final Theme theme, final Layout layout, final int width, final int height) {
        super(theme, layout);
        this.doScrollX = false;
        this.doScrollY = true;
        this.canScrollX = false;
        this.canScrollY = false;
        this.lockWidth = false;
        this.lockHeight = false;
        this.step = 22;
        this.setWidth(width);
        this.setHeight(height);
        this.scrolledX = 0;
        this.scrolledY = 0;
        this.addRenderListener((RenderListener)new RenderListener(this) {
            int translatex;
            int translatey;
            final Scrollpane this$0;
            
            @Override
            public void onPostRender() {
                GL11.glDisable(3089);
            }
            
            @Override
            public void onPreRender() {
                this.translatex = this.this$0.scrolledX;
                this.translatey = this.this$0.scrolledY;
                final int[] calculateRealPosition = GUI.calculateRealPosition((Component)this.this$0);
                final int scale = DisplayGuiScreen.getScale();
                GL11.glScissor(this.this$0.getX() * scale + calculateRealPosition[0] * scale - this.this$0.getParent().getOriginOffsetX() - 1, Display.getHeight() - this.this$0.getHeight() * scale - calculateRealPosition[1] * scale - 1, this.this$0.getWidth() * scale + this.this$0.getParent().getOriginOffsetX() * scale + 1, this.this$0.getHeight() * scale + 1);
                GL11.glEnable(3089);
            }
        });
        this.addMouseListener((MouseListener)new MouseListener(this) {
            final Scrollpane this$0;
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
                if (this.this$0.canScrollY() && (!this.this$0.canScrollX() || this.this$0.scrolledX == 0 || !this.this$0.isDoScrollX()) && this.this$0.isDoScrollY()) {
                    if (mouseScrollEvent.isUp() && this.this$0.getScrolledY() > 0) {
                        this.this$0.setScrolledY(Math.max(0, this.this$0.getScrolledY() - this.this$0.step));
                        return;
                    }
                    if (!mouseScrollEvent.isUp() && this.this$0.getScrolledY() < this.this$0.getMaxScrollY()) {
                        this.this$0.setScrolledY(Math.min(this.this$0.getMaxScrollY(), this.this$0.getScrolledY() + this.this$0.step));
                        return;
                    }
                }
                if (this.this$0.canScrollX() && this.this$0.isDoScrollX()) {
                    if (mouseScrollEvent.isUp() && this.this$0.getScrolledX() > 0) {
                        this.this$0.setScrolledX(Math.max(0, this.this$0.getScrolledX() - this.this$0.step));
                        return;
                    }
                    if (!mouseScrollEvent.isUp() && this.this$0.getScrolledX() < this.this$0.getMaxScrollX()) {
                        this.this$0.setScrolledX(Math.min(this.this$0.getMaxScrollX(), this.this$0.getScrolledX() + this.this$0.step));
                    }
                }
            }
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                if (mouseButtonEvent.getY() > this.this$0.getHeight() || mouseButtonEvent.getX() > this.this$0.getWidth() || mouseButtonEvent.getX() < 0 || mouseButtonEvent.getY() < 0) {
                    mouseButtonEvent.cancel();
                }
            }
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
            }
        });
        this.addUpdateListener((UpdateListener)new UpdateListener(this) {
            final Scrollpane this$0;
            
            @Override
            public void updateLocation(final Component component, final int n, final int n2) {
                Scrollpane.access$000(this.this$0);
            }
            
            @Override
            public void updateSize(final Component component, final int n, final int n2) {
                Scrollpane.access$000(this.this$0);
            }
        });
    }
    
    public void setScrolledY(final int scrolledY) {
        final int scrolledY2 = this.getScrolledY();
        this.scrolledY = scrolledY;
        final int n = this.getScrolledY() - scrolledY2;
        for (final Component component : this.getChildren()) {
            component.setY(component.getY() - n);
        }
    }
    
    public int getScrolledX() {
        return this.scrolledX;
    }
    
    private void performCalculations() {
        int max = 0;
        int max2 = 0;
        for (final Component component : this.getChildren()) {
            max = Math.max(this.getScrolledX() + component.getX() + component.getWidth(), max);
            max2 = Math.max(this.getScrolledY() + component.getY() + component.getHeight(), max2);
        }
        this.canScrollX = (max > this.getWidth());
        this.maxScrollX = max - this.getWidth();
        this.canScrollY = (max2 > this.getHeight());
        this.maxScrollY = max2 - this.getHeight();
    }
    
    public boolean isDoScrollX() {
        return this.doScrollX;
    }
    
    public int getMaxScrollX() {
        return this.maxScrollX;
    }
    
    public void setScrolledX(final int scrolledX) {
        final int scrolledX2 = this.getScrolledX();
        this.scrolledX = scrolledX;
        final int n = this.getScrolledX() - scrolledX2;
        for (final Component component : this.getChildren()) {
            component.setX(component.getX() - n);
        }
    }
    
    public Scrollpane setLockHeight(final boolean lockHeight) {
        this.lockHeight = lockHeight;
        return this;
    }
    
    public boolean isDoScrollY() {
        return this.doScrollY;
    }
    
    public boolean canScrollY() {
        return this.canScrollY;
    }
    
    public Scrollpane setLockWidth(final boolean lockWidth) {
        this.lockWidth = lockWidth;
        return this;
    }
    
    public int getScrolledY() {
        return this.scrolledY;
    }
    
    public boolean canScrollX() {
        return this.canScrollX;
    }
}
