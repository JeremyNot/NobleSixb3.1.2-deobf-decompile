//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.listen;

public interface KeyListener
{
    void onKeyDown(final KeyEvent p0);
    
    void onKeyUp(final KeyEvent p0);
    
    public static class KeyEvent
    {
        int key;
        
        public KeyEvent(final int key) {
            this.key = key;
        }
        
        public void setKey(final int key) {
            this.key = key;
        }
        
        public int getKey() {
            return this.key;
        }
    }
}
