//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.component.listen.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;

public class RootScrollpaneUI extends AbstractComponentUI<Scrollpane>
{
    double hovering;
    long lastScroll;
    Component scrollComponent;
    int dY;
    boolean dragBar;
    float barLife;
    
    public RootScrollpaneUI() {
        this.lastScroll = 0L;
        this.scrollComponent = null;
        this.barLife = 1220.0f;
        this.dragBar = false;
        this.dY = 0;
        this.hovering = 0.0;
    }
    
    @Override
    public void renderComponent(final Scrollpane scrollpane, final FontRenderer fontRenderer) {
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((Scrollpane)component, container);
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Scrollpane)component, fontRenderer);
    }
    
    @Override
    public void handleAddComponent(final Scrollpane scrollpane, final Container container) {
        scrollpane.addMouseListener(new MouseListener(this, scrollpane) {
            final RootScrollpaneUI this$0;
            final Scrollpane val$component;
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.dragBar = false;
            }
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                if (System.currentTimeMillis() - this.this$0.lastScroll < this.this$0.barLife && this.this$0.scrollComponent.liesIn(this.val$component) && this.val$component.canScrollY()) {
                    final double n = this.val$component.getScrolledY() / (double)this.val$component.getMaxScrollY();
                    final int n2 = 30;
                    final int n3 = (int)((this.val$component.getHeight() - n2) * n);
                    if (mouseButtonEvent.getX() > this.val$component.getWidth() - 10 && mouseButtonEvent.getY() > n3 && mouseButtonEvent.getY() < n3 + n2) {
                        this.this$0.dragBar = true;
                        this.this$0.dY = mouseButtonEvent.getY() - n3;
                        mouseButtonEvent.cancel();
                    }
                }
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
                this.this$0.lastScroll = System.currentTimeMillis();
                this.this$0.scrollComponent = mouseScrollEvent.getComponent();
            }
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
                if (this.this$0.dragBar) {
                    this.val$component.setScrolledY((int)(this.val$component.getMaxScrollY() * Math.max(Math.min(mouseButtonEvent.getY() / (double)this.val$component.getHeight(), 1.0), 0.0)));
                    mouseButtonEvent.cancel();
                }
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
        });
        scrollpane.addRenderListener(new RenderListener(this, scrollpane) {
            final Scrollpane val$component;
            final RootScrollpaneUI this$0;
            
            @Override
            public void onPostRender() {
                if (this.this$0.dragBar) {
                    this.this$0.lastScroll = System.currentTimeMillis();
                }
                if (System.currentTimeMillis() - this.this$0.lastScroll < this.this$0.barLife && this.this$0.scrollComponent.liesIn(this.val$component) && this.val$component.canScrollY()) {
                    float n = Math.min(1.0f, (this.this$0.barLife - (System.currentTimeMillis() - this.this$0.lastScroll)) / 100.0f) / 3.0f;
                    if (this.this$0.dragBar) {
                        n = 0.4f;
                    }
                    GL11.glColor4f(1.0f, 0.22f, 0.22f, n);
                    GL11.glDisable(3553);
                    final int n2 = 30;
                    RenderHelper.drawRoundedRectangle((float)(this.val$component.getWidth() - 6), (float)(int)((this.val$component.getHeight() - n2) * (this.val$component.getScrolledY() / (double)this.val$component.getMaxScrollY())), 4.0f, (float)n2, 1.0f);
                }
            }
            
            @Override
            public void onPreRender() {
            }
        });
    }
}
