//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.render.*;
import java.awt.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.rgui.component.container.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;

public class RootButtonUI<T extends Button> extends AbstractComponentUI<Button>
{
    protected Color downColour;
    protected Color idleColour;
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((Button)component, fontRenderer);
    }
    
    public RootButtonUI() {
        this.idleColour = new Color(163, 163, 163);
        this.downColour = new Color(255, 255, 255);
    }
    
    @Override
    public void handleAddComponent(final Button button, final Container container) {
        button.setWidth(KamiGUI.fontRenderer.getStringWidth(button.getName()) + 28);
        button.setHeight(KamiGUI.fontRenderer.getFontHeight() + 2);
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((Button)component, container);
    }
    
    @Override
    public void renderComponent(final Button button, final FontRenderer fontRenderer) {
        GL11.glColor3f(0.22f, 0.22f, 0.22f);
        if (button.isHovered() || button.isPressed()) {
            GL11.glColor3f(0.26f, 0.26f, 0.26f);
        }
        RenderHelper.drawRoundedRectangle(0.0f, 0.0f, (float)button.getWidth(), (float)button.getHeight(), 3.0f);
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        KamiGUI.fontRenderer.drawString(button.getWidth() / 2 - KamiGUI.fontRenderer.getStringWidth(button.getName()) / 2, 0, button.isPressed() ? this.downColour : this.idleColour, button.getName());
        GL11.glDisable(3553);
        GL11.glDisable(3042);
    }
}
