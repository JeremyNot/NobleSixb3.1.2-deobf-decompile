//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.component;

import me.noble.client.gui.rgui.component.*;
import me.noble.client.util.*;
import net.minecraftforge.fml.common.*;
import me.noble.client.module.*;
import java.util.*;
import java.util.function.*;
import net.minecraftforge.fml.common.gameevent.*;
import org.lwjgl.input.*;
import me.noble.client.gui.rgui.component.container.use.*;
import me.noble.client.gui.rgui.component.container.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class TabGUI extends AbstractComponent implements EventListener
{
    public float selectedLerpY;
    public boolean tabOpened;
    public final ArrayList<Tab> tabs;
    public int width;
    public int height;
    public int selected;
    
    private void updateSize() {
        this.width = 64;
        final Iterator<Tab> iterator = this.tabs.iterator();
        while (iterator.hasNext()) {
            final int width = Wrapper.getFontRenderer().getStringWidth(iterator.next().name) + 10;
            if (width > this.width) {
                this.width = width;
            }
        }
        this.height = this.tabs.size() * 10;
    }
    
    public TabGUI() {
        this.tabs = new ArrayList<Tab>();
        FMLCommonHandler.instance().bus().register((Object)this);
        final LinkedHashMap<Module.Category, Tab> linkedHashMap = new LinkedHashMap<Module.Category, Tab>();
        for (final Module.Category category : Module.Category.values()) {
            linkedHashMap.put(category, new Tab(category.getName()));
        }
        final ArrayList<Module> list = new ArrayList<Module>();
        list.addAll(ModuleManager.getModules());
        for (final Module module : list) {
            if (module.getCategory() != null && !module.getCategory().isHidden()) {
                linkedHashMap.get(module.getCategory()).add(module);
            }
        }
        final Iterator<Map.Entry<Module.Category, Tab>> iterator2 = linkedHashMap.entrySet().iterator();
        while (iterator2.hasNext()) {
            if (iterator2.next().getValue().features.isEmpty()) {
                iterator2.remove();
            }
        }
        this.tabs.addAll(linkedHashMap.values());
        this.tabs.forEach(TabGUI::lambda$new$0);
        this.updateSize();
    }
    
    @SubscribeEvent
    public void onKeyPress(final InputEvent.KeyInputEvent keyInputEvent) {
        if (!Keyboard.getEventKeyState()) {
            return;
        }
        Container container;
        for (container = this.getParent(); !(container instanceof Frame); container = container.getParent()) {}
        if (!((Frame)container).isPinned()) {
            return;
        }
        if (this.tabOpened) {
            switch (Keyboard.getEventKey()) {
                case 203: {
                    this.tabOpened = false;
                    break;
                }
                default: {
                    this.tabs.get(this.selected).onKeyPress(Keyboard.getEventKey());
                    break;
                }
            }
        }
        else {
            switch (Keyboard.getEventKey()) {
                case 208: {
                    if (this.selected < this.tabs.size() - 1) {
                        ++this.selected;
                        break;
                    }
                    this.selected = 0;
                    break;
                }
                case 200: {
                    if (this.selected > 0) {
                        --this.selected;
                        break;
                    }
                    this.selected = this.tabs.size() - 1;
                    break;
                }
                case 205: {
                    this.tabOpened = true;
                    break;
                }
            }
        }
    }
    
    private static void lambda$new$0(final Tab tab) {
        tab.updateSize();
    }
    
    public static final class Tab
    {
        public float lerpSelectY;
        public final ArrayList<Module> features;
        public int width;
        public int height;
        public final String name;
        public int selected;
        
        public void updateSize() {
            this.width = 64;
            final Iterator<Module> iterator = this.features.iterator();
            while (iterator.hasNext()) {
                final int width = Wrapper.getFontRenderer().getStringWidth(iterator.next().getName()) + 10;
                if (width > this.width) {
                    this.width = width;
                }
            }
            this.height = this.features.size() * 10;
        }
        
        public Tab(final String name) {
            this.features = new ArrayList<Module>();
            this.lerpSelectY = 0.0f;
            this.name = name;
        }
        
        public void onKeyPress(final int n) {
            switch (n) {
                case 208: {
                    if (this.selected < this.features.size() - 1) {
                        ++this.selected;
                        break;
                    }
                    this.selected = 0;
                    break;
                }
                case 200: {
                    if (this.selected > 0) {
                        --this.selected;
                        break;
                    }
                    this.selected = this.features.size() - 1;
                    break;
                }
                case 205: {
                    this.features.get(this.selected).toggle();
                    break;
                }
            }
        }
        
        public void add(final Module module) {
            this.features.add(module);
        }
    }
}
