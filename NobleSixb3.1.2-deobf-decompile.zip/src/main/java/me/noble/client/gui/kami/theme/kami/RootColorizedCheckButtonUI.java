//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.util.*;
import java.awt.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;

public class RootColorizedCheckButtonUI extends RootCheckButtonUI<ColorizedCheckButton>
{
    RootSmallFontRenderer ff;
    
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((CheckButton)component, fontRenderer);
    }
    
    public RootColorizedCheckButtonUI() {
        this.ff = new RootSmallFontRenderer();
        ColourSet.checkButtonBackgroundColour = new Color(200, ColourSet.checkButtonBackgroundColour.getGreen(), ColourSet.checkButtonBackgroundColour.getBlue());
        ColourSet.checkButtonBackgroundColourHover = new Color(255, ColourSet.checkButtonBackgroundColourHover.getGreen(), ColourSet.checkButtonBackgroundColourHover.getBlue());
    }
    
    public void renderComponent(final CheckButton checkButton, final FontRenderer fontRenderer) {
        GL11.glColor4f(ColourSet.checkButtonBackgroundColour.getRed() / 255.0f, ColourSet.checkButtonBackgroundColour.getGreen() / 255.0f, ColourSet.checkButtonBackgroundColour.getBlue() / 255.0f, checkButton.getOpacity());
        if (checkButton.isHovered() || checkButton.isPressed()) {
            GL11.glColor4f(ColourSet.checkButtonBackgroundColourHover.getRed() / 255.0f, ColourSet.checkButtonBackgroundColourHover.getGreen() / 255.0f, ColourSet.checkButtonBackgroundColourHover.getBlue() / 255.0f, checkButton.getOpacity());
        }
        if (checkButton.isToggled()) {
            GL11.glColor3f(ColourSet.checkButtonBackgroundColour.getRed() / 255.0f, ColourSet.checkButtonBackgroundColour.getGreen() / 255.0f, ColourSet.checkButtonBackgroundColour.getBlue() / 255.0f);
        }
        GL11.glLineWidth(2.5f);
        GL11.glBegin(1);
        GL11.glVertex2d(0.0, (double)checkButton.getHeight());
        GL11.glVertex2d((double)checkButton.getWidth(), (double)checkButton.getHeight());
        GL11.glEnd();
        final Color color = checkButton.isToggled() ? ColourSet.checkButtonIdleColourToggle : ColourSet.checkButtonIdleColourNormal;
        final Color color2 = checkButton.isToggled() ? ColourSet.checkButtonDownColourToggle : ColourSet.checkButtonDownColourNormal;
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        this.ff.drawString(checkButton.getWidth() / 2 - KamiGUI.fontRenderer.getStringWidth(checkButton.getName()) / 2, 0, checkButton.isPressed() ? color2 : color, checkButton.getName());
        GL11.glDisable(3553);
    }
}
