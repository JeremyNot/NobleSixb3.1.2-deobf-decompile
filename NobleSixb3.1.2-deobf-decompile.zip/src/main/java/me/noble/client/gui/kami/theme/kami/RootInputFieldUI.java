//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.component.use.*;
import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;
import me.noble.client.gui.kami.*;

public class RootInputFieldUI<T extends InputField> extends AbstractComponentUI<InputField>
{
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((InputField)component, container);
    }
    
    @Override
    public void renderComponent(final InputField inputField, final FontRenderer fontRenderer) {
        GL11.glColor3f(0.33f, 0.22f, 0.22f);
        RenderHelper.drawFilledRectangle(0.0f, 0.0f, (float)inputField.getWidth(), (float)inputField.getHeight());
        GL11.glLineWidth(1.5f);
        GL11.glColor4f(1.0f, 0.33f, 0.33f, 0.6f);
        RenderHelper.drawRectangle(0.0f, 0.0f, (float)inputField.getWidth(), (float)inputField.getHeight());
    }
    
    @Override
    public void handleAddComponent(final InputField inputField, final Container container) {
        inputField.setWidth(200);
        inputField.setHeight(inputField.getTheme().getFontRenderer().getFontHeight());
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((InputField)component, fontRenderer);
    }
}
