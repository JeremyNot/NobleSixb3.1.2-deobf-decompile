//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component;

import me.noble.client.gui.rgui.render.theme.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.render.*;
import java.util.function.*;
import me.noble.client.gui.rgui.poof.*;
import java.util.*;
import me.noble.client.gui.rgui.*;
import me.noble.client.gui.kami.*;
import me.noble.client.setting.*;

public abstract class AbstractComponent implements Component
{
    int x;
    private Setting<Boolean> visible;
    ArrayList<MouseListener> mouseListeners;
    int minHeight;
    ArrayList<UpdateListener> updateListeners;
    protected int priority;
    boolean workingx;
    ArrayList<KeyListener> keyListeners;
    int maxWidth;
    boolean drag;
    ArrayList<RenderListener> renderListeners;
    int maxHeight;
    float opacity;
    Theme theme;
    boolean workingy;
    Container parent;
    int width;
    boolean press;
    int height;
    boolean hover;
    int y;
    ArrayList<TickListener> tickListeners;
    ComponentUI ui;
    int minWidth;
    ArrayList<IPoof> poofs;
    private boolean focus;
    boolean affectlayout;
    
    @Override
    public int getY() {
        return this.y;
    }
    
    @Override
    public int getMaximumHeight() {
        return this.maxHeight;
    }
    
    private void lambda$setX$3(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateLocation(this, n, n2);
    }
    
    private void lambda$setY$0(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateLocation(this, n, n2);
    }
    
    @Override
    public void addPoof(final IPoof poof) {
        this.poofs.add(poof);
    }
    
    @Override
    public boolean isPressed() {
        return this.press;
    }
    
    @Override
    public boolean isVisible() {
        return this.visible.getValue();
    }
    
    @Override
    public void setX(final int x) {
        final int x2 = this.getX();
        final int y = this.getY();
        this.x = x;
        if (!this.workingx) {
            this.workingx = true;
            this.getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setX$2);
            if (this.getParent() != null) {
                this.getParent().getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setX$3);
            }
            this.workingx = false;
        }
    }
    
    @Override
    public void setFocused(final boolean focus) {
        this.focus = focus;
    }
    
    @Override
    public boolean isHovered() {
        return this.isMouseOver() && !this.press;
    }
    
    private void lambda$setY$1(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateLocation(this, n, n2);
    }
    
    private void lambda$setWidth$4(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateSize(this, n, n2);
    }
    
    @Override
    public Component setMaximumHeight(final int maxHeight) {
        this.maxHeight = maxHeight;
        return this;
    }
    
    @Override
    public void callPoof(final Class<? extends IPoof> clazz, final PoofInfo poofInfo) {
        for (final IPoof<AbstractComponent, PoofInfo> poof : this.poofs) {
            if (clazz.isAssignableFrom(poof.getClass()) && poof.getComponentClass().isAssignableFrom(this.getClass())) {
                poof.execute(this, poofInfo);
            }
        }
    }
    
    private void lambda$setWidth$5(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateSize(this, n, n2);
    }
    
    @Override
    public Container getParent() {
        return this.parent;
    }
    
    private void lambda$setHeight$6(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateSize(this, n, n2);
    }
    
    @Override
    public Theme getTheme() {
        return this.theme;
    }
    
    @Override
    public void setOpacity(final float opacity) {
        this.opacity = opacity;
    }
    
    private void lambda$setX$2(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateLocation(this, n, n2);
    }
    
    @Override
    public int getMinimumWidth() {
        return this.minWidth;
    }
    
    @Override
    public boolean isFocused() {
        return this.focus;
    }
    
    @Override
    public Component setMinimumWidth(final int minWidth) {
        this.minWidth = minWidth;
        return this;
    }
    
    @Override
    public void setAffectLayout(final boolean affectlayout) {
        this.affectlayout = affectlayout;
    }
    
    @Override
    public void addKeyListener(final KeyListener keyListener) {
        if (!this.keyListeners.contains(keyListener)) {
            this.keyListeners.add(keyListener);
        }
    }
    
    @Override
    public float getOpacity() {
        return this.opacity;
    }
    
    @Override
    public ArrayList<MouseListener> getMouseListeners() {
        return this.mouseListeners;
    }
    
    private boolean isMouseOver() {
        final int[] calculateRealPosition = GUI.calculateRealPosition(this);
        final int mouseX = DisplayGuiScreen.mouseX;
        final int mouseY = DisplayGuiScreen.mouseY;
        return calculateRealPosition[0] <= mouseX && calculateRealPosition[1] <= mouseY && calculateRealPosition[0] + this.getWidth() >= mouseX && calculateRealPosition[1] + this.getHeight() >= mouseY;
    }
    
    @Override
    public ArrayList<TickListener> getTickListeners() {
        return this.tickListeners;
    }
    
    @Override
    public Component setMaximumWidth(final int maxWidth) {
        this.maxWidth = maxWidth;
        return this;
    }
    
    @Override
    public ComponentUI getUI() {
        if (this.ui == null) {
            this.ui = this.getTheme().getUIForComponent(this);
        }
        return this.ui;
    }
    
    @Override
    public void setY(final int y) {
        final int x = this.getX();
        final int y2 = this.getY();
        this.y = y;
        if (!this.workingy) {
            this.workingy = true;
            this.getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setY$0);
            if (this.getParent() != null) {
                this.getParent().getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setY$1);
            }
            this.workingy = false;
        }
    }
    
    @Override
    public int getWidth() {
        return this.width;
    }
    
    @Override
    public void setHeight(int max) {
        max = Math.max(this.getMinimumHeight(), Math.min(max, this.getMaximumHeight()));
        final int width = this.getWidth();
        final int height = this.getHeight();
        this.height = max;
        this.getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setHeight$6);
        if (this.getParent() != null) {
            this.getParent().getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setHeight$7);
        }
    }
    
    @Override
    public Component setMinimumHeight(final int minHeight) {
        this.minHeight = minHeight;
        return this;
    }
    
    @Override
    public void kill() {
        this.setVisible(false);
    }
    
    private void lambda$setHeight$7(final int n, final int n2, final UpdateListener updateListener) {
        updateListener.updateSize(this, n, n2);
    }
    
    @Override
    public void setVisible(final boolean b) {
        this.visible.setValue(b);
    }
    
    @Override
    public boolean doAffectLayout() {
        return this.affectlayout;
    }
    
    public AbstractComponent() {
        this.minWidth = Integer.MIN_VALUE;
        this.minHeight = Integer.MIN_VALUE;
        this.maxWidth = Integer.MAX_VALUE;
        this.maxHeight = Integer.MAX_VALUE;
        this.priority = 0;
        this.visible = Settings.b("Visible", true);
        this.opacity = 1.0f;
        this.focus = false;
        this.hover = false;
        this.press = false;
        this.drag = false;
        this.affectlayout = true;
        this.mouseListeners = new ArrayList<MouseListener>();
        this.renderListeners = new ArrayList<RenderListener>();
        this.keyListeners = new ArrayList<KeyListener>();
        this.updateListeners = new ArrayList<UpdateListener>();
        this.tickListeners = new ArrayList<TickListener>();
        this.poofs = new ArrayList<IPoof>();
        this.workingy = false;
        this.workingx = false;
        this.addMouseListener(new MouseListener(this) {
            final AbstractComponent this$0;
            
            @Override
            public void onMouseDrag(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.drag = true;
            }
            
            @Override
            public void onMouseRelease(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.press = false;
                this.this$0.drag = false;
            }
            
            @Override
            public void onScroll(final MouseScrollEvent mouseScrollEvent) {
            }
            
            @Override
            public void onMouseDown(final MouseButtonEvent mouseButtonEvent) {
                this.this$0.press = true;
            }
            
            @Override
            public void onMouseMove(final MouseMoveEvent mouseMoveEvent) {
            }
        });
    }
    
    @Override
    public ArrayList<RenderListener> getRenderListeners() {
        return this.renderListeners;
    }
    
    @Override
    public void setParent(final Container parent) {
        this.parent = parent;
    }
    
    @Override
    public void addTickListener(final TickListener tickListener) {
        if (!this.tickListeners.contains(tickListener)) {
            this.tickListeners.add(tickListener);
        }
    }
    
    @Override
    public void addUpdateListener(final UpdateListener updateListener) {
        if (!this.updateListeners.contains(updateListener)) {
            this.updateListeners.add(updateListener);
        }
    }
    
    @Override
    public void addRenderListener(final RenderListener renderListener) {
        if (!this.renderListeners.contains(renderListener)) {
            this.renderListeners.add(renderListener);
        }
    }
    
    @Override
    public int getPriority() {
        return this.priority;
    }
    
    @Override
    public ArrayList<UpdateListener> getUpdateListeners() {
        return this.updateListeners;
    }
    
    @Override
    public boolean liesIn(final Component component) {
        if (component.equals(this)) {
            return true;
        }
        if (component instanceof Container) {
            for (final Component component2 : ((Container)component).getChildren()) {
                if (component2.equals(this)) {
                    return true;
                }
                boolean liesIn = false;
                if (component2 instanceof Container) {
                    liesIn = this.liesIn(component2);
                }
                if (liesIn) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
    
    @Override
    public int getHeight() {
        return this.height;
    }
    
    @Override
    public int getX() {
        return this.x;
    }
    
    @Override
    public int getMinimumHeight() {
        return this.minHeight;
    }
    
    @Override
    public void setTheme(final Theme theme) {
        this.theme = theme;
    }
    
    @Override
    public ArrayList<KeyListener> getKeyListeners() {
        return this.keyListeners;
    }
    
    @Override
    public int getMaximumWidth() {
        return this.maxWidth;
    }
    
    @Override
    public void addMouseListener(final MouseListener mouseListener) {
        if (!this.mouseListeners.contains(mouseListener)) {
            this.mouseListeners.add(mouseListener);
        }
    }
    
    @Override
    public void setWidth(int max) {
        max = Math.max(this.getMinimumWidth(), Math.min(max, this.getMaximumWidth()));
        final int width = this.getWidth();
        final int height = this.getHeight();
        this.width = max;
        this.getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setWidth$4);
        if (this.getParent() != null) {
            this.getParent().getUpdateListeners().forEach((Consumer<? super UpdateListener>)this::lambda$setWidth$5);
        }
    }
}
