//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.container.use;

import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.render.theme.*;

public class Groupbox extends AbstractContainer
{
    String name;
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public Groupbox(final Theme theme, final String name) {
        super(theme);
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Groupbox(final Theme theme, final String s, final int x, final int y) {
        this(theme, s);
        this.setX(x);
        this.setY(y);
    }
}
