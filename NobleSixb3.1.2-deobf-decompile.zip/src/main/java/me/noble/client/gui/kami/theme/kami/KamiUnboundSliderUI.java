//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.kami.theme.kami;

import me.noble.client.gui.rgui.render.*;
import me.noble.client.gui.kami.component.*;
import me.noble.client.gui.rgui.component.container.*;
import me.noble.client.gui.rgui.component.*;
import me.noble.client.gui.rgui.render.font.*;
import org.lwjgl.opengl.*;

public class KamiUnboundSliderUI extends AbstractComponentUI<UnboundSlider>
{
    @Override
    public void handleAddComponent(final UnboundSlider unboundSlider, final Container container) {
        unboundSlider.setHeight(unboundSlider.getTheme().getFontRenderer().getFontHeight());
        unboundSlider.setWidth(unboundSlider.getTheme().getFontRenderer().getStringWidth(unboundSlider.getText()));
    }
    
    @Override
    public void renderComponent(final Component component, final FontRenderer fontRenderer) {
        this.renderComponent((UnboundSlider)component, fontRenderer);
    }
    
    @Override
    public void handleAddComponent(final Component component, final Container container) {
        this.handleAddComponent((UnboundSlider)component, container);
    }
    
    @Override
    public void renderComponent(final UnboundSlider unboundSlider, final FontRenderer fontRenderer) {
        final String value = String.valueOf(new StringBuilder().append(unboundSlider.getText()).append(": ").append(unboundSlider.getValue()));
        int n = unboundSlider.isPressed() ? 11184810 : 14540253;
        if (unboundSlider.isHovered()) {
            n = (n & 0x7F7F7F) << 1;
        }
        fontRenderer.drawString(unboundSlider.getWidth() / 2 - fontRenderer.getStringWidth(value) / 2, unboundSlider.getHeight() - fontRenderer.getFontHeight() / 2 - 4, n, value);
        GL11.glDisable(3042);
    }
}
