//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.rgui.component.use;

import me.noble.client.gui.rgui.component.listen.*;
import me.noble.client.gui.rgui.poof.*;
import me.noble.client.gui.rgui.poof.use.*;

public class CheckButton extends Button
{
    boolean toggled;
    
    public CheckButton(final String s) {
        this(s, 0, 0);
    }
    
    public CheckButton(final String s, final int n, final int n2) {
        super(s, n, n2);
        this.addMouseListener((MouseListener)new MouseListener(this) {
            final CheckButton this$0;
            
            public void onScroll(final MouseListener.MouseScrollEvent mouseScrollEvent) {
            }
            
            public void onMouseMove(final MouseListener.MouseMoveEvent mouseMoveEvent) {
            }
            
            public void onMouseDown(final MouseListener.MouseButtonEvent mouseButtonEvent) {
                if (mouseButtonEvent.getButton() != 0) {
                    return;
                }
                this.this$0.toggled = !this.this$0.toggled;
                this.this$0.callPoof((Class)CheckButtonPoof.class, (PoofInfo)new CheckButtonPoof.CheckButtonPoofInfo(CheckButtonPoof.CheckButtonPoofInfo.CheckButtonPoofInfoAction.TOGGLE));
                if (this.this$0.toggled) {
                    this.this$0.callPoof((Class)CheckButtonPoof.class, (PoofInfo)new CheckButtonPoof.CheckButtonPoofInfo(CheckButtonPoof.CheckButtonPoofInfo.CheckButtonPoofInfoAction.ENABLE));
                }
                else {
                    this.this$0.callPoof((Class)CheckButtonPoof.class, (PoofInfo)new CheckButtonPoof.CheckButtonPoofInfo(CheckButtonPoof.CheckButtonPoofInfo.CheckButtonPoofInfoAction.DISABLE));
                }
            }
            
            public void onMouseDrag(final MouseListener.MouseButtonEvent mouseButtonEvent) {
            }
            
            public void onMouseRelease(final MouseListener.MouseButtonEvent mouseButtonEvent) {
            }
        });
    }
    
    public void setToggled(final boolean toggled) {
        this.toggled = toggled;
    }
    
    public boolean isToggled() {
        return this.toggled;
    }
    
    public abstract static class CheckButtonPoof<T extends CheckButton, S extends CheckButtonPoofInfo> extends Poof<T, S>
    {
        CheckButtonPoofInfo info;
        
        public static class CheckButtonPoofInfo extends PoofInfo
        {
            CheckButtonPoofInfoAction action;
            
            public CheckButtonPoofInfo(final CheckButtonPoofInfoAction action) {
                this.action = action;
            }
            
            public CheckButtonPoofInfoAction getAction() {
                return this.action;
            }
            
            public enum CheckButtonPoofInfoAction
            {
                DISABLE, 
                TOGGLE;
                
                private static final CheckButtonPoofInfoAction[] $VALUES;
                
                ENABLE;
                
                static {
                    $VALUES = new CheckButtonPoofInfoAction[] { CheckButtonPoofInfoAction.TOGGLE, CheckButtonPoofInfoAction.ENABLE, CheckButtonPoofInfoAction.DISABLE };
                }
            }
        }
    }
}
