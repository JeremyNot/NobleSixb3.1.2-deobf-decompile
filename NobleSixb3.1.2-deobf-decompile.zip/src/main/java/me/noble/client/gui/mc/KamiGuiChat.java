//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.noble.client.gui.mc;

import me.noble.client.command.*;
import java.io.*;
import net.minecraft.client.gui.*;
import me.noble.client.*;
import java.util.*;
import me.noble.client.command.syntax.*;
import org.lwjgl.input.*;
import org.lwjgl.opengl.*;
import net.minecraft.util.text.*;

public class KamiGuiChat extends GuiChat
{
    private String currentFillinLine;
    private int cursor;
    private String startString;
    
    protected void keyTyped(final char c, final int n) throws IOException {
        this.sentHistoryCursor = this.cursor;
        super.keyTyped(c, n);
        this.cursor = this.sentHistoryCursor;
        final String getText = this.inputField.getText();
        if (Command.getCommandPrefix() != null && !getText.startsWith(Command.getCommandPrefix())) {
            final GuiChat guiChat = new GuiChat(this, getText) {
                final KamiGuiChat this$0;
                int cursor = KamiGuiChat.access$000(this.this$0);
                
                protected void keyTyped(final char c, final int n) throws IOException {
                    this.sentHistoryCursor = this.cursor;
                    super.keyTyped(c, n);
                    this.cursor = this.sentHistoryCursor;
                }
            };
            guiChat.historyBuffer = this.historyBuffer;
            this.mc.displayGuiScreen((GuiScreen)guiChat);
            return;
        }
        if (getText.equals(Command.getCommandPrefix())) {
            this.currentFillinLine = "";
            return;
        }
        this.calculateCommand(getText.substring(Command.getCommandPrefix().length()));
    }
    
    public KamiGuiChat(final String startString, final String historyBuffer, final int cursor) {
        super(startString);
        this.startString = startString;
        if (!startString.equals(Command.getCommandPrefix())) {
            this.calculateCommand(startString.substring(Command.getCommandPrefix().length()));
        }
        this.historyBuffer = historyBuffer;
        this.cursor = cursor;
    }
    
    static int access$000(final KamiGuiChat kamiGuiChat) {
        return kamiGuiChat.cursor;
    }
    
    protected void calculateCommand(final String s) {
        final String[] split = s.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
        final HashMap<String, Command> hashMap = new HashMap<String, Command>();
        if (split.length == 0) {
            return;
        }
        for (final Command command : NobleMod.getInstance().getCommandManager().getCommands()) {
            if ((command.getLabel().startsWith(split[0]) && !s.endsWith(" ")) || command.getLabel().equals(split[0])) {
                hashMap.put(command.getLabel(), command);
            }
        }
        if (hashMap.isEmpty()) {
            this.currentFillinLine = "";
            return;
        }
        final Command command2 = new TreeMap<Object, Command>(hashMap).firstEntry().getValue();
        this.currentFillinLine = command2.getLabel().substring(split[0].length());
        if (command2.getSyntaxChunks() == null || command2.getSyntaxChunks().length == 0) {
            return;
        }
        if (!s.endsWith(" ")) {
            this.currentFillinLine = String.valueOf(new StringBuilder().append(this.currentFillinLine).append(" "));
        }
        final SyntaxChunk[] syntaxChunks = command2.getSyntaxChunks();
        boolean b = false;
        for (int i = 0; i < syntaxChunks.length; ++i) {
            if (i + 1 >= split.length - 1) {
                final SyntaxChunk syntaxChunk = syntaxChunks[i];
                final String chunk = syntaxChunk.getChunk(syntaxChunks, syntaxChunk, split, (i + 1 == split.length - 1) ? split[i + 1] : null);
                if (chunk != "" && (!chunk.startsWith("<") || !chunk.endsWith(">")) && (!chunk.startsWith("[") || !chunk.endsWith("]"))) {
                    b = true;
                }
                this.currentFillinLine = String.valueOf(new StringBuilder().append(this.currentFillinLine).append(chunk).append((chunk == "") ? "" : " ").append(""));
            }
        }
        if (b) {
            this.currentFillinLine = this.currentFillinLine.substring(1);
        }
    }
    
    public void drawScreen(final int n, final int n2, final float n3) {
        drawRect(2, this.height - 14, this.width - 2, this.height - 2, Integer.MIN_VALUE);
        this.inputField.fontRendererInstance.drawStringWithShadow(this.currentFillinLine, (float)(this.inputField.fontRendererInstance.getStringWidth(String.valueOf(new StringBuilder().append(this.inputField.getText()).append(""))) + 4), (float)(this.inputField.getEnableBackgroundDrawing() ? (this.inputField.yPosition + (this.inputField.height - 8) / 2) : this.inputField.yPosition), 6710886);
        this.inputField.drawTextBox();
        final ITextComponent getChatComponent = this.mc.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY());
        if (getChatComponent != null && getChatComponent.getStyle().getHoverEvent() != null) {
            this.handleComponentHover(getChatComponent, n, n2);
        }
        final boolean glIsEnabled = GL11.glIsEnabled(3042);
        final boolean glIsEnabled2 = GL11.glIsEnabled(3553);
        GL11.glDisable(3042);
        GL11.glDisable(3553);
        GL11.glColor3f(0.8f, 0.1f, 0.0f);
        GL11.glBegin(1);
        GL11.glVertex2f((float)(this.inputField.xPosition - 2), (float)(this.inputField.yPosition - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition + this.inputField.getWidth() - 2), (float)(this.inputField.yPosition - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition + this.inputField.getWidth() - 2), (float)(this.inputField.yPosition - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition + this.inputField.getWidth() - 2), (float)(this.inputField.yPosition + this.inputField.height - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition + this.inputField.getWidth() - 2), (float)(this.inputField.yPosition + this.inputField.height - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition - 2), (float)(this.inputField.yPosition + this.inputField.height - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition - 2), (float)(this.inputField.yPosition + this.inputField.height - 2));
        GL11.glVertex2f((float)(this.inputField.xPosition - 2), (float)(this.inputField.yPosition - 2));
        GL11.glEnd();
        if (glIsEnabled) {
            GL11.glEnable(3042);
        }
        if (glIsEnabled2) {
            GL11.glEnable(3553);
        }
    }
}
