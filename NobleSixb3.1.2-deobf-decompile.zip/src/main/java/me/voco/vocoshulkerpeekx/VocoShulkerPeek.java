//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.voco.vocoshulkerpeekx;

import net.minecraftforge.fml.common.*;
import net.minecraft.item.*;
import net.minecraft.client.*;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.common.*;
import net.minecraft.nbt.*;
import me.noble.client.module.*;
import me.noble.client.command.*;
import net.minecraftforge.client.*;
import net.minecraft.server.*;
import net.minecraft.command.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

@Mod(modid = "vocoshulkerpeekx", name = "Peek Bypass for Noble", version = "0.1", acceptedMinecraftVersions = "[1.12.2]")
public class VocoShulkerPeek
{
    public static ItemStack shulker;
    public static final String MOD_NAME;
    public static final String MOD_ID;
    public static final String VERSION;
    public static Minecraft mc;
    
    @Mod.EventHandler
    public void postinit(final FMLPostInitializationEvent fmlPostInitializationEvent) {
        ClientCommandHandler.instance.registerCommand((ICommand)new PeekCommand());
        MinecraftForge.EVENT_BUS.register((Object)new ShulkerPreview());
    }
    
    static {
        MOD_ID = "vocoshulkerpeekx";
        VERSION = "0.1";
        MOD_NAME = "VocoShulkerPeekx";
        VocoShulkerPeek.shulker = ItemStack.field_190927_a;
        VocoShulkerPeek.mc = Minecraft.getMinecraft();
    }
    
    public static NBTTagCompound getShulkerNBT(final ItemStack itemStack) {
        if (VocoShulkerPeek.mc.player == null) {
            return null;
        }
        final NBTTagCompound getTagCompound = itemStack.getTagCompound();
        if (getTagCompound != null && getTagCompound.hasKey("BlockEntityTag", 10)) {
            final NBTTagCompound getCompoundTag = getTagCompound.getCompoundTag("BlockEntityTag");
            if (ModuleManager.getModuleByName("ShulkerBypass").isEnabled()) {
                if (getCompoundTag.hasKey("Items", 9)) {
                    return getCompoundTag;
                }
                Command.sendWarningMessage("[ShulkerBypass] Shulker is empty!");
            }
        }
        return null;
    }
    
    public static class PeekCommand extends CommandBase implements IClientCommand
    {
        public String getCommandName() {
            return "peek";
        }
        
        public boolean checkPermission(final MinecraftServer minecraftServer, final ICommandSender commandSender) {
            return true;
        }
        
        public String getCommandUsage(final ICommandSender commandSender) {
            return null;
        }
        
        public void execute(final MinecraftServer minecraftServer, final ICommandSender commandSender, final String[] array) {
            if (VocoShulkerPeek.mc.player != null && ModuleManager.getModuleByName("ShulkerBypass").isEnabled()) {
                if (!VocoShulkerPeek.shulker.func_190926_b()) {
                    final NBTTagCompound shulkerNBT = VocoShulkerPeek.getShulkerNBT(VocoShulkerPeek.shulker);
                    if (shulkerNBT != null) {
                        final TileEntityShulkerBox tileEntityShulkerBox = new TileEntityShulkerBox();
                        tileEntityShulkerBox.func_190586_e(shulkerNBT);
                        String getString = "container.shulkerBox";
                        boolean b = false;
                        if (shulkerNBT.hasKey("CustomName", 8)) {
                            getString = shulkerNBT.getString("CustomName");
                            b = true;
                        }
                        final InventoryBasic toOpen = new InventoryBasic(getString, b, 27);
                        for (int i = 0; i < 27; ++i) {
                            toOpen.setInventorySlotContents(i, tileEntityShulkerBox.getStackInSlot(i));
                        }
                        ShulkerPreview.toOpen = toOpen;
                        ShulkerPreview.guiTicks = 0;
                    }
                }
                else {
                    Command.sendChatMessage("[ShulkerBypass] No shulker detected! please drop and pickup your shulker.");
                }
            }
        }
        
        public boolean allowUsageWithoutPrefix(final ICommandSender commandSender, final String s) {
            return false;
        }
    }
}
