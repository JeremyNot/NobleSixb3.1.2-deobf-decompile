//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.voco.vocoshulkerpeekx;

import net.minecraft.entity.item.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.client.*;
import net.minecraft.item.*;
import me.noble.client.module.*;
import me.noble.client.command.*;
import net.minecraft.inventory.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.event.entity.*;
import net.minecraft.entity.*;

public class ShulkerPreview
{
    public static int guiTicks;
    public static EntityItem drop;
    public static int metadataTicks;
    public static InventoryBasic toOpen;
    
    static {
        ShulkerPreview.metadataTicks = -1;
        ShulkerPreview.guiTicks = -1;
    }
    
    @SubscribeEvent
    public void onTick(final TickEvent.ClientTickEvent clientTickEvent) {
        if (clientTickEvent.phase == TickEvent.Phase.END && ShulkerPreview.metadataTicks > -1) {
            ++ShulkerPreview.metadataTicks;
        }
        if (clientTickEvent.phase == TickEvent.Phase.END && ShulkerPreview.guiTicks > -1) {
            ++ShulkerPreview.guiTicks;
        }
        if (ShulkerPreview.metadataTicks == 20) {
            if (Minecraft.getMinecraft().player == null) {
                return;
            }
            ShulkerPreview.metadataTicks = -1;
            if (ShulkerPreview.drop.getEntityItem().getItem() instanceof ItemShulkerBox && ModuleManager.getModuleByName("ShulkerBypass").isEnabled()) {
                Command.sendChatMessage("[ShulkerBypass] New shulker found! use /peek to view its content");
                VocoShulkerPeek.shulker = ShulkerPreview.drop.getEntityItem();
            }
        }
        if (ShulkerPreview.guiTicks == 20) {
            ShulkerPreview.guiTicks = -1;
            VocoShulkerPeek.mc.player.displayGUIChest((IInventory)ShulkerPreview.toOpen);
        }
    }
    
    @SubscribeEvent
    public void onEntitySpawn(final EntityJoinWorldEvent entityJoinWorldEvent) {
        final Entity entity = entityJoinWorldEvent.getEntity();
        if (entity instanceof EntityItem) {
            ShulkerPreview.drop = (EntityItem)entity;
            ShulkerPreview.metadataTicks = 0;
        }
    }
}
