//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.nobletp.teleport;

import net.minecraftforge.fml.common.*;
import net.minecraft.client.*;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.common.*;

@Mod(modid = "nobleteleport", name = "nobleteleport", version = "v1.0", acceptedMinecraftVersions = "[1.12.2]")
public class nobleteleport
{
    public static Minecraft mc;
    
    @Mod.EventHandler
    public void post(final FMLPostInitializationEvent fmlPostInitializationEvent) {
        MinecraftForge.EVENT_BUS.register((Object)new nobleteleportModule());
    }
    
    static {
        nobleteleport.mc = Minecraft.getMinecraft();
    }
}
