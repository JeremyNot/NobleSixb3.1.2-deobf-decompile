//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\amyan\Desktop\mcp\conf"!

//Decompiled by Procyon!

package me.nobletp.teleport;

import java.util.regex.*;
import net.minecraftforge.client.event.*;
import java.text.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.util.text.*;

public class nobleteleportModule
{
    public boolean chatdisable;
    
    public boolean HasDigit(final String s) {
        boolean b = false;
        if (Pattern.compile(".*\\d+.*").matcher(s).matches()) {
            b = true;
        }
        return b;
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onChatSent(final ClientChatEvent clientChatEvent) {
        if (clientChatEvent.getMessage().startsWith("@tp")) {
            clientChatEvent.setCanceled(true);
            try {
                nobleteleport.mc.ingameGUI.getChatGUI().addToSentMessages(clientChatEvent.getMessage());
                final String[] split = clientChatEvent.getMessage().substring(3).split(" ");
                if (this.isDouble(split[1])) {
                    if (this.isDouble(split[2])) {
                        if (this.isDouble(split[3])) {
                            final double double1 = Double.parseDouble(split[1]);
                            final double double2 = Double.parseDouble(split[2]);
                            final double double3 = Double.parseDouble(split[3]);
                            if (nobleteleport.mc.player.getRidingEntity() != null) {
                                nobleteleport.mc.player.getRidingEntity().setPosition(double1, double2, double3);
                            }
                            else {
                                nobleteleport.mc.player.setPosition(double1, double2, double3);
                            }
                            final DecimalFormat decimalFormat = new DecimalFormat("##.##");
                            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Teleport you to X: ").append(decimalFormat.format(double1)).append(" Y: ").append(decimalFormat.format(double2)).append(" Z: ").append(decimalFormat.format(double3))));
                        }
                        else {
                            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Inputs is not supported !  ").append(split[3])));
                        }
                    }
                    else {
                        this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Inputs is not supported !  ").append(split[2])));
                    }
                }
                else {
                    this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Inputs is not supported !  ").append(split[1])));
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
                this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Unknown Error ! ")));
            }
            clientChatEvent.setMessage("");
        }
        else if (clientChatEvent.getMessage().startsWith("@help")) {
            clientChatEvent.setCanceled(true);
            nobleteleport.mc.ingameGUI.getChatGUI().addToSentMessages(clientChatEvent.getMessage());
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Commands list")));
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("@tp x y z Take you to the place (x,y,z)")));
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("@disable Switch togglechat")));
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("@info Get more info")));
            clientChatEvent.setMessage("");
        }
        else if (clientChatEvent.getMessage().startsWith("@info")) {
            clientChatEvent.setCanceled(true);
            nobleteleport.mc.ingameGUI.getChatGUI().addToSentMessages(clientChatEvent.getMessage());
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.YELLOW).append("This is a teleport and togglechat mod")));
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.YELLOW).append("Author:botchunkloader")));
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.YELLOW).append("Transplant:xX_NobleSix_Xx")));
            clientChatEvent.setMessage("");
        }
        else if (clientChatEvent.getMessage().startsWith("@")) {
            clientChatEvent.setCanceled(true);
            nobleteleport.mc.ingameGUI.getChatGUI().addToSentMessages(clientChatEvent.getMessage());
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("Unknown Commands Type @help to get helps")));
            clientChatEvent.setMessage("");
        }
        else if (this.HasDigit(clientChatEvent.getMessage()) && this.chatdisable && !clientChatEvent.getMessage().startsWith("/")) {
            clientChatEvent.setCanceled(true);
            nobleteleport.mc.ingameGUI.getChatGUI().addToSentMessages(clientChatEvent.getMessage());
            clientChatEvent.setMessage("");
            this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("You are now in togglechat mode if you want to close please use @disable to close the function")));
        }
        else if (clientChatEvent.getMessage().startsWith("@disable")) {
            clientChatEvent.setCanceled(true);
            if (this.chatdisable) {
                this.chatdisable = false;
                this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("ToggleChat mode is Disabled")));
            }
            else if (!this.chatdisable) {
                this.chatdisable = true;
                this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.RED).append("ToggleChat mode is Enabled")));
            }
            clientChatEvent.setMessage("");
        }
    }
    
    @SubscribeEvent
    public void onjoin(final PlayerEvent.PlayerLoggedInEvent playerLoggedInEvent) {
        this.drawText(String.valueOf(new StringBuilder().append(TextFormatting.YELLOW).append("Loaded , Using @help to get helps")));
    }
    
    public void drawText(final String s) {
        nobleteleport.mc.ingameGUI.func_191742_a(ChatType.CHAT, (ITextComponent)new TextComponentString(s));
    }
    
    public nobleteleportModule() {
        this.chatdisable = false;
    }
    
    public boolean isDouble(final String s) {
        try {
            Double.parseDouble(s);
            return true;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
